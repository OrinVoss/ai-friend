# 第2轮代码审查：睡眠与主动行为状态流深度审查

**审查日期**: 2026-05-31
**审查范围**: `core/sleep_manager.py`, `core/proactivity.py`, `core/inner_drive.py`, `web/server.py` 及其关联模块
**审查目标**: 跟踪睡眠状态检测、进入、梦境生成、唤醒的完整数据流，以及主动行为从空闲检测、评分、意图生成到执行的完整数据流，识别竞态条件、状态冲突、逻辑缺陷

---

## 概述

AI Friend 的睡眠与主动行为系统构成了 AI "自主生命节律" 的核心。SleepManager 负责模拟人类的睡眠-觉醒周期（午睡 12:00-13:00、夜睡 23:00-01:00、晨醒 7:00-10:00、午醒 13:10-16:00），ProactivityManager 负责在空闲时评估是否主动发起对话，InnerDriveAgent 负责为 proactive 行为提供 LLM 级别的决策，而 `_proactive_loop` 在 Web 端作为后台协程驱动整个自主行为引擎。

本次审查发现 **6个高风险问题**、**5个中风险问题**、**4个低风险问题**，涉及全局状态共享、竞态条件、评分算法缺陷、并发安全性缺失、梦境生成与记忆关联薄弱等多个维度。核心风险在于：**睡眠状态通过全局文件共享，导致多会话场景下所有 AI 实例同步入睡/醒来；主动行为评分算法存在情绪盲区；睡眠期间用户消息处理与 proactive 循环存在并发冲突。**

---

## 数据流图

### 睡眠状态完整数据流

```
                              时间流逝
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                    _proactive_loop (web/server.py:130)                       │
│                         每 15s / 30s 一个 tick                               │
└─────────────────────────────────────────────────────────────────────────────┘
                                 │
                    ┌────────────┴────────────┐
                    ▼                         ▼
        ┌─────────────────────┐   ┌─────────────────────┐
        │ sleep_cooldown == 0?│   │ ag._sleeping == True?│
        │ (转换冷却检查)       │   │ (睡眠状态检查)        │
        └─────────────────────┘   └─────────────────────┘
                    │                         │
                    ▼                         ▼
        ┌─────────────────────┐   ┌─────────────────────┐
        │ _get_sleep_state()  │   │ await sleep(30)     │
        │ (core/agent.py:239) │   │ continue (跳过主动)  │
        └─────────────────────┘   └─────────────────────┘
                    │
        ┌───────────┼───────────┐
        ▼           ▼           ▼
┌───────────┐ ┌───────────┐ ┌───────────┐
│ 入睡窗口   │ │ 醒来窗口   │ │ 非窗口    │
│ 12-13/23-1 │ │ 13:10-16  │ │ 返回None  │
│ 7-10       │ │           │ │           │
└─────┬─────┘ └─────┬─────┘ └─────┬─────┘
      │             │             │
      ▼             ▼             ▼
┌───────────┐ ┌───────────┐   (无操作)
│sleepiness │ │wake_chance │
│计算       │ │计算       │
│+随机判定  │ │+随机判定  │
└─────┬─────┘ └─────┬─────┘
      │             │
      ▼             ▼
┌───────────┐ ┌───────────┐
│_sleeping= │ │_sleeping= │
│True       │ │False      │
│_save()    │ │_save()    │
└─────┬─────┘ └─────┬─────┘
      │             │
      ▼             ▼
┌───────────┐ ┌───────────┐
│发送睡前消息│ │发送醒来消息│
│"我去午睡" │ │"睡醒了..." │
└─────┬─────┘ └─────┬─────┘
      │             │
      ▼             ▼
┌───────────┐ ┌───────────┐
│_generate_ │ │_generate_ │
│dream()    │ │dream()    │
│(仅Web端)  │ │(梦境分享) │
└─────┬─────┘ └─────┬─────┘
      │             │
      ▼             ▼
┌───────────┐ ┌───────────┐
│record_    │ │record_    │
│emotion_   │ │emotion_   │
│event()    │ │event()    │
└───────────┘ └───────────┘
```

### 主动行为完整数据流

```
                              时间流逝
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                    _proactive_loop (web/server.py:130)                       │
│                    (前提: ag._sleeping == False)                             │
└─────────────────────────────────────────────────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  idle = time.time() - ag.last_activity_time                                  │
│  (web/server.py:158)                                                         │
└─────────────────────────────────────────────────────────────────────────────┘
                                 │
                    ┌────────────┴────────────┐
                    ▼                         ▼
        ┌─────────────────────┐   ┌─────────────────────┐
        │ idle < 30s?         │   │ cooldown > 0?       │
        │ (绝对底线)          │   │ (冷却计数器)         │
        └─────────────────────┘   └─────────────────────┘
                    │                         │
                    ▼                         ▼
        ┌─────────────────────┐   ┌─────────────────────┐
        │ sleep(5), continue  │   │ cooldown -= 1       │
        │                     │   │ sleep(5), continue  │
        └─────────────────────┘   └─────────────────────┘
                    │
                    ▼ (idle >= 30 且 cooldown == 0)
        ┌─────────────────────┐
        │ _calculate_         │
        │ proactivity(idle)   │
        │ (core/proactivity.py:21)
        └─────────────────────┘
                    │
                    ▼
        ┌─────────────────────┐
        │ score 计算:          │
        │ base + time_mod +    │
        │ emotion_mod +        │
        │ intimacy_mod +       │
        │ sentiment_mod -      │
        │ goodbye_penalty -    │
        │ short_penalty        │
        │ capped [0, 0.8]      │
        └─────────────────────┘
                    │
                    ▼
        ┌─────────────────────┐
        │ random.random() < score?
        └─────────────────────┘
                    │
        ┌───────────┴───────────┐
        ▼                       ▼
    (否)                      (是)
    sleep(15)                  ▼
    continue         ┌─────────────────────┐
                     │ decide_proactive_   │
                     │ action(idle)        │
                     │ (core/inner_drive.py:113)
                     │ LLM 决策:           │
                     │ chat / explore /    │
                     │ silent              │
                     └─────────────────────┘
                               │
                    ┌──────────┼──────────┐
                    ▼          ▼          ▼
            ┌──────────┐ ┌──────────┐ ┌──────────┐
            │  "chat"  │ │"explore" │ │"silent"  │
            │          │ │          │ │          │
            └────┬─────┘ └────┬─────┘ └────┬─────┘
                 │            │            │
                 ▼            ▼            ▼
        ┌──────────────┐ ┌──────────────┐ ┌──────────────┐
        │_check_rate_  │ │_check_rate_  │ │ 记录 reasoning│
        │limit("chat") │ │limit("explore")│ │ 跳过        │
        │ 2/hr         │ │ 1/hr         │ │             │
        └──────┬───────┘ └──────┬───────┘ └──────────────┘
               │                │
               ▼                ▼
        ┌──────────────┐ ┌──────────────┐
        │process_      │ │process_      │
        │proactive_    │ │explore_      │
        │with_intent() │ │with_intent() │
        │(add_to_      │ │(add_to_      │
        │ history=False)│ │ history=False)│
        └──────┬───────┘ └──────┬───────┘
               │                │
               ▼                ▼
        ┌──────────────┐ ┌──────────────┐
        │_send_segments│ │_send_segments│
        │(分段发送)    │ │(分段发送)    │
        └──────┬───────┘ └──────┬───────┘
               │                │
               ▼                ▼
        ┌──────────────┐ ┌──────────────┐
        │last_activity_│ │last_activity_│
        │time = now    │ │time = now    │
        │cooldown = 12 │ │cooldown = 12 │
        └──────────────┘ └──────────────┘
```

### 睡眠期间消息处理数据流

```
用户发送消息
    │
    ▼
┌──────────────────────────────────────────────┐
│ websocket_endpoint (web/server.py:199)       │
│ msg_type == "message"                        │
└──────────────────────────────────────────────┘
    │
    ▼
┌──────────────────────────────────────────────┐
│ agent.agent.last_activity_time = time.time() │
│ (web/server.py:231)                          │
└──────────────────────────────────────────────┘
    │
    ▼
┌──────────────────────────────────────────────┐
│ agent.process_message(content)               │
│ (web/server.py:233)                          │
└──────────────────────────────────────────────┘
    │
    ▼
┌──────────────────────────────────────────────┐
│ MessageHandler.handle_message()              │
│ (core/message_handler.py:64)                 │
└──────────────────────────────────────────────┘
    │
    ▼
┌──────────────────────────────────────────────┐
│ if a._sleeping:                              │
│     a.last_activity_time = time.time()       │
│     return random.choice(["zzz...", ...])    │
│ (core/message_handler.py:68-70)              │
└──────────────────────────────────────────────┘
    │
    ├── (睡眠中) ──▶ 返回 zzz 变体，不进入正常处理
    │
    └── (清醒中) ──▶ 正常三层 Agent 处理流程
```

### 状态并发交互图

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  WebSocket 协程  │     │ _proactive_loop │     │  HTTP API 协程   │
│  (用户消息)      │     │ (后台自主行为)   │     │ (REST 请求)      │
└────────┬────────┘     └────────┬────────┘     └────────┬────────┘
         │                       │                       │
         │ 修改 last_activity_time│ 读取 last_activity_time│ 修改 last_activity_time
         │ 读取 _sleeping         │ 读取/修改 _sleeping    │ 读取 _sleeping
         │ 修改 emotion          │ 读取 emotion           │ 修改 emotion
         │ 修改 short_term       │ 读取 short_term        │ 修改 short_term
         │                       │                       │
         └───────────────────────┼───────────────────────┘
                                 ▼
                    ┌─────────────────────┐
                    │   共享状态 (无锁!)   │
                    │ - last_activity_time│
                    │ - _sleeping         │
                    │ - emotion (VAD+8维) │
                    │ - turn_count        │
                    │ - _consecutive_neg  │
                    │ - short_term (有锁) │
                    │ - personality.json  │
                    │ - .sleep_state 文件 │
                    └─────────────────────┘
```

---

## 详细发现

### 高风险问题

#### HR1: 睡眠状态全局共享 —— 所有会话共用同一个 `.sleep_state` 文件

**文件**: `core/agent.py:59-65`, `core/sleep_manager.py:14-38`
**行号**: 59-65, 14-38

```python
# core/agent.py:59-65
sleep_file = os.path.join(
    os.path.dirname(os.path.abspath(config.personality_file)), ".sleep_state"
)
self._sleep = SleepManager(
    sleep_state_file=sleep_file,
    personality=personality, ltm=ltm, provider=provider,
)

# core/sleep_manager.py:25-38
class SleepManager:
    def _load_sleep_state(self) -> bool:
        try:
            with open(self._sleep_state_file) as f:
                return f.read().strip() == "1"
        except Exception as e:
            logger.warning(f"Failed to read sleep state: {e}")
            return False

    def _save_sleep_state(self) -> None:
        try:
            with open(self._sleep_state_file, "w") as f:
                f.write("1" if self._sleeping else "0")
        except Exception as e:
            logger.warning(f"Failed to save sleep state: {e}")
```

**问题描述**:
每个 `Agent` 实例创建自己的 `SleepManager`，但所有 `SleepManager` 都指向同一个 `.sleep_state` 文件。`config.personality_file` 是 `"personality.json"`，所以 `sleep_file` 始终指向项目根目录的 `.sleep_state`。

当会话A触发睡眠（写入 "1"），会话B读取时也会认为自己在睡眠。在 `_proactive_loop` 中，如果 `ag._sleeping` 为 True，proactive 行为会被跳过（`await asyncio.sleep(30); continue`）。更荒谬的是，会话A在 23:00 入睡，会话B在 23:05 建立连接，会话B的 AI 也会立即认为自己在睡觉。

**代码路径**:
- `web/server.py:154` -> `if ag._sleeping: await asyncio.sleep(30); continue`
- `core/message_handler.py:68` -> `if a._sleeping: return "zzz..."`

**影响**: 一个会话的睡眠状态全局影响所有会话的 proactive 行为和消息响应。多用户场景下，一个用户让 AI 睡觉，所有其他用户的 AI 也进入睡眠。

**根因分析**:
SleepManager 的设计假设了单用户单会话模型。`_sleep_state_file` 是硬编码的全局路径，没有与会话ID绑定。`_load_sleep_state()` 在 `__init__` 时调用，将文件内容读入 `self._sleeping`，此后 `self._sleeping` 作为实例变量存在，但 `_save_sleep_state()` 又会将其写回全局文件。

**建议**:
1. 移除文件持久化，将睡眠状态存储在内存中（`SessionManager._sessions[sid].agent._sleep._sleeping`）
2. 如果确实需要持久化，改为按会话ID命名文件（如 `.sleep_state_{sid}`）
3. 或者将睡眠状态存入数据库，添加 `session_id` 列

---

#### HR2: `_proactive_loop` 与消息处理并发修改 `last_activity_time` 无同步

**文件**: `web/server.py:130-196`, `web/server.py:223-234`
**行号**: 145, 158, 188, 231

```python
# web/server.py:145 (proactive loop 中睡眠/唤醒后)
ag.last_activity_time = time.time()

# web/server.py:158 (proactive loop 中计算 idle)
idle = time.time() - ag.last_activity_time

# web/server.py:188 (proactive 行为发送后)
ag.last_activity_time = time.time()

# web/server.py:231 (用户消息处理时)
agent.agent.last_activity_time = time.time()
```

**问题描述**:
`last_activity_time` 是 `Agent` 实例的一个普通 `float` 属性，没有锁保护。在 Web 端，以下场景可能并发执行：

1. `_proactive_loop` 在协程A中运行，执行到第158行计算 `idle = time.time() - ag.last_activity_time`
2. 同时 WebSocket 协程B收到用户消息，执行第231行 `agent.agent.last_activity_time = time.time()`
3. 由于 Python 的 GIL，`float` 赋值是原子的，但 `time.time()` 调用和赋值之间可能被切换

更严重的场景：
1. `_proactive_loop` 计算 `idle` 为 1000 秒（因为用户很久没说话）
2. 就在计算后、`_calculate_proactivity()` 调用前，用户发送了消息，`last_activity_time` 被更新
3. `_proactive_loop` 继续执行，用错误的 `idle` 值计算 proactivity score
4. 结果可能是：用户刚发完消息，AI 立即主动回复（因为 `idle` 计算时还是旧值）

**影响**: 主动行为可能在用户刚刚发送消息后触发，造成"用户刚说完话 AI 就插嘴"的尴尬体验。

**建议**:
1. 为 `last_activity_time` 的读写添加原子操作或锁保护
2. 或者将 `idle` 计算和 `score` 计算合并为原子操作，避免中间被修改
3. 在 `_proactive_loop` 中，在计算 `idle` 后立即再次检查 `ag._sleeping`，确保状态一致性

---

#### HR3: 睡眠期间用户消息处理与 proactive 循环的竞态条件

**文件**: `web/server.py:154-156`, `core/message_handler.py:68-70`
**行号**: 154-156, 68-70

```python
# web/server.py:154-156
if ag._sleeping:
    await asyncio.sleep(30)
    continue

# core/message_handler.py:68-70
if a._sleeping:
    a.last_activity_time = time.time()
    return random.choice(["zzz...ZZZ...", "Zzzz...[翻身]", ...])
```

**问题描述**:
考虑以下时序：

```
T0: _proactive_loop 检查 ag._sleeping -> False，继续执行
T1: _proactive_loop 计算 idle = 100s，score = 0.5
T2: 用户发送消息，WebSocket 协程开始处理
T3: _proactive_loop random.random() < score -> True，决定主动行为
T4: WebSocket 协程设置 last_activity_time = time.time()
T5: _proactive_loop 调用 decide_proactive_action() (耗时 LLM 调用)
T6: WebSocket 协程检查 a._sleeping -> False，进入正常处理
T7: _proactive_loop 完成 decide_proactive_action()，准备发送消息
T8: 用户收到正常回复的同时，AI 又发送了一条主动消息
```

这个竞态条件的根本原因是：`_proactive_loop` 的"检查-决策-执行"不是原子的。`last_activity_time` 在决策过程中可能被更新，但 proactive 循环不会重新检查。

另一个更微妙的竞态：

```
T0: _proactive_loop 检查 ag._sleeping -> False
T1: SleepManager.get_sleep_state() 被调用（在另一个请求中），触发入睡
T2: _proactive_loop 继续执行，ag._sleeping 现在为 True，但循环已经通过了检查点
T3: _proactive_loop 计算 idle 并可能触发主动行为
T4: AI 在"已经入睡"的状态下仍然发送了主动消息
```

**影响**: AI 可能在睡眠状态下发送主动消息，或在用户刚回复后发送主动消息，破坏用户体验的一致性。

**建议**:
1. 在 `_proactive_loop` 的"执行"阶段前，重新检查 `ag._sleeping` 和 `idle`
2. 将 proactive 决策和执行封装为一个原子操作，或在关键检查点使用版本号机制
3. 考虑使用 `asyncio.Lock` 保护 `_proactive_loop` 的关键段落

---

#### HR4: 梦境生成与长期记忆检索的同步阻塞问题

**文件**: `web/server.py:149-151`, `core/sleep_manager.py:96-119`
**行号**: 149-151, 96-119

```python
# web/server.py:149-151
if should_sleep:
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(None, ag._generate_dream)

# core/sleep_manager.py:96-119
def generate_dream(self) -> str:
    try:
        facts = self._ltm.get_all_active_facts(limit=5)
        exps = self._ltm.get_recent_experiences(limit=3)
        # ... prompt 构建 ...
        dream = self._provider.generate(
            [{"role": "user", "content": prompt}],
            stream=False, max_tokens=100,
        )
        self._personality.emotion.record_emotion_event(
            trigger=f"梦: {dream.strip()[:100]}",
            context=dream.strip()[:200],
        )
        return dream.strip()
    except Exception:
        return ""
```

**问题描述**:
1. **同步阻塞**: `_generate_dream()` 是同步方法，内部调用 `self._provider.generate()`（LLM API 调用）和 `self._ltm.get_all_active_facts()`（数据库查询）。在 `_proactive_loop` 中通过 `run_in_executor` 将其放入线程池执行，但线程池大小有限（默认与 CPU 核心数相关）。如果多个会话同时触发睡眠，线程池可能被耗尽。

2. **梦境生成时机问题**: 梦境只在 Web 端的 `_proactive_loop` 中生成（`web/server.py:151`），CLI 端的 `CliController` 没有调用 `_generate_dream()`。这意味着 CLI 模式下 AI 入睡后不会生成梦境，醒来时也没有梦境可分享。

3. **梦境与记忆关联薄弱**: `generate_dream()` 只检索了 5 个 active facts 和 3 条 recent experiences，且使用简单的字符串拼接：
   ```python
   fact_str = " ".join(f"{f.fact_key}:{f.fact_value}" for f in facts)[:300]
   exp_str = " ".join(f"[{e.emotional_tone}]{e.summary}" for e in exps)[:300]
   ```
   这种拼接没有考虑记忆的相关性、时间顺序或情感权重。一个关于"用户喜欢猫"的事实和一个关于"昨天吵架"的经历被平等对待，可能导致梦境内容缺乏连贯性。

4. **梦境不保存到长期记忆**: 生成的梦境通过 `record_emotion_event()` 记录到情绪事件中，但没有作为 `Experience` 或 `Reflection` 保存到长期记忆。这意味着 AI 无法"记住自己的梦"，除非通过情绪事件的间接记录。

**影响**: 多会话同时睡眠时线程池耗尽；CLI 模式下梦境功能缺失；梦境内容质量受限于简单的记忆拼接；AI 无法真正记住自己的梦境。

**建议**:
1. 将 `_generate_dream()` 改为异步方法，避免占用线程池
2. 在 CLI 模式下也集成梦境生成（`_on_idle` 或 `_on_reflect` 中检查睡眠状态）
3. 改进记忆检索：使用 `MemoryRetriever.retrieve_for_query("梦境 睡眠")` 获取更相关的记忆
4. 将重要梦境保存为 `Experience`，标签为 `["dream", "sleep"]`

---

#### HR5: `sleep_cooldown` 整数递减导致冷却时间远超预期

**文件**: `web/server.py:131-153`
**行号**: 131-153

```python
# web/server.py:131-153
cooldown = 0
sleep_cooldown = 0
while True:
    try:
        if sleep_cooldown == 0:
            should_sleep, msg = ag._get_sleep_state()
            if msg:
                # ...
                sleep_cooldown = 120  # 10 min cooldown on sleep transitions
                # ...
        else:
            sleep_cooldown = max(0, sleep_cooldown - 1)
        if ag._sleeping:
            await asyncio.sleep(30)
            continue
        # ...
        await asyncio.sleep(15)
```

**问题描述**:
`sleep_cooldown` 初始为 120，每次循环减 1。但循环间隔不是固定的 5 秒：

- 睡眠状态下：`await asyncio.sleep(30)`，然后 `sleep_cooldown -= 1`
- 非睡眠、不满足主动条件：`await asyncio.sleep(5)`，然后 `sleep_cooldown -= 1`
- 非睡眠、满足主动条件：执行 `decide_proactive_action()`（LLM 调用，可能耗时 2-5 秒），然后 `await asyncio.sleep(15)`，然后 `sleep_cooldown -= 1`

因此，120 次循环的实际时间约为：
- 如果一直在睡眠：120 * 30s = 3600s = 60 分钟
- 如果一直不满足主动条件：120 * 5s = 600s = 10 分钟
- 混合状态：约 15-30 分钟

注释说 "10 min cooldown"，但实际在睡眠状态下冷却时间长达 60 分钟。这意味着 AI 入睡后，一小时内不会再检查是否应该醒来（即使已经到了早上 7 点的醒来窗口）。

**影响**: 睡眠转换的冷却时间严重不一致，AI 可能在应该醒来的时间仍然处于"冷却中"，导致睡眠-觉醒周期错乱。

**建议**:
将 `sleep_cooldown` 改为基于时间戳的实现：
```python
sleep_cooldown_until = 0.0
# ...
if time.time() < sleep_cooldown_until:
    continue
# ...
if msg:
    sleep_cooldown_until = time.time() + 600  # 精确的 10 分钟
```

---

#### HR6: 主动行为评分算法存在情绪盲区和负向饱和问题

**文件**: `core/proactivity.py:21-64`
**行号**: 21-64

```python
# core/proactivity.py:21-64
def calculate_proactivity(self, idle_duration: float) -> float:
    e = self._personality.emotion
    r = getattr(e, 'resentment', 0.0)

    idle_thresholds = {
        "excited": 60, "joyful": 90, "surprised": 120,
        "engaged": 180, "content": 300, "trusting": 240, "anticipating": 150,
        "neutral": 360,
        "anxious": 90, "afraid": 180,
        "melancholy": 600, "sad": 900,
        "frustrated": 300, "angry": 480, "disgusted": 600,
    }
    min_idle = idle_thresholds.get(e.dominant_emotion, 300)
    min_idle += int(r * 300)

    if idle_duration < min_idle:
        return 0.0

    base = min(0.3, (idle_duration - min_idle) / 900.0)
    # ... time_mod, emotion_mod, intimacy_mod, sentiment_mod ...
    score = base + time_mod + emotion_mod + intimacy_mod + sentiment_mod \
            - min(goodbye * 0.15, 0.3) - min(short_c * 0.08, 0.2)
    score = max(0.0, min(0.8, score))
    return score
```

**问题描述**:

1. **情绪盲区**: `idle_thresholds` 映射了 15 种情绪，但 `dominant_emotion` 可能返回的值有 16 种（包括 `"neutral"`）。如果某种情绪不在映射中（如未来新增的情绪），默认阈值 300 秒可能不适用。

2. **怨恨的惩罚不对称**: `min_idle += int(r * 300)` 将怨恨转化为额外的空闲等待时间。当 `resentment=1.0` 时，`min_idle` 增加 300 秒。这意味着：
   - "sad" 情绪（原 900s）+ 满怨恨 = 1200s（20 分钟）
   - "angry" 情绪（原 480s）+ 满怨恨 = 780s（13 分钟）
   
   但怨恨的语义是"记仇"，它应该降低 AI 主动搭话的意愿（因为还在生气），而不仅仅是延迟搭话时间。当前实现只延迟了时间，没有降低搭话的"热情度"。

3. **base 增长过慢**: `base = min(0.3, (idle_duration - min_idle) / 900.0)`，即使 idle 超过了 `min_idle` 900 秒（15 分钟），base 也只达到 0.3。这意味着用户需要等待 `min_idle + 720` 秒才能将 score 提升到 0.8（假设其他 modifier 总和为 0.5）。

4. **sentiment_mod 的检测过于简单**: 使用关键词匹配：
   ```python
   if any(kw in last for kw in ["烦", "滚", "生气", "讨厌", "别烦", "不想", "别吵"]):
       sentiment_mod = -0.3
   ```
   这种硬编码的关键词列表无法覆盖所有负面表达（如"你走开"、"别理我"、"安静点"），且对同义词、方言、网络用语不敏感。

5. **goodbye 检测的误报**: 检测 "睡了"、"晚安" 作为 goodbye：
   ```python
   goodbye = sum(1 for t in self._short_term.get_recent(6) if any(kw in t.content for kw in ["拜拜", "再见", "bye", "下次", "睡了", "晚安"]))
   ```
   如果用户说"我昨天睡了 10 个小时"，会被误判为 goodbye，导致 proactive score 被错误地降低。

6. **score 上限 0.8 的语义不明**: 为什么不是 1.0？0.8 意味着即使所有条件都满足，仍有 20% 的概率不主动搭话。这个设计意图没有文档化。

**影响**: 主动行为触发不规律，某些情绪状态下 AI 过于"沉默"或过于"话痨"；用户说"睡了"被误判为 goodbye 后，AI 长时间不主动搭话；怨恨状态的惩罚不够直观。

**建议**:
1. 为怨恨添加独立的 score 惩罚（如 `score -= r * 0.2`），而不仅仅是增加 idle 阈值
2. 使用 LLM 或更鲁棒的方式检测用户告别意图，而非简单关键词匹配
3. 将 goodbye 关键词分为"明确告别"（拜拜、再见）和"可能告别"（睡了、晚安），给予不同程度的惩罚
4. 文档化 score 上限 0.8 的设计意图

---

### 中风险问题

#### MR1: `ProactivityManager.check_rate_limit` 的 "chat" 首次调用逻辑缺陷

**文件**: `core/proactivity.py:94-115`
**行号**: 104-108

```python
# core/proactivity.py:104-108
elif action == "chat":
    if self._last_chat_time == 0:
        self._last_chat_time = now
        logger.info("[rate] chat allowed (first)")
        return True
    if now - self._last_chat_time < 1800:
        return False
    self._last_chat_time = now
    return True
```

**问题描述**:
首次调用 "chat" 时，`_last_chat_time` 从 0 被设为 `now` 并返回 True。但此时并没有真正执行聊天——这只是在"检查"阶段。如果后续因为其他原因（如 `decide_proactive_action` 返回 "silent"）没有实际发送消息，`_last_chat_time` 已经被更新，下次检查时会被拒绝。

正确的逻辑应该是：在消息实际发送后才更新 `_last_chat_time`。

**影响**: 首次 proactive chat 检查通过后如果没有实际执行，后续 30 分钟内无法再次触发 chat。

**建议**:
将 rate limit 的"记录时间"移到消息实际发送后（`web/server.py:188` 附近），而非检查阶段。

---

#### MR2: `InnerDriveAgent.assess_proactive` 的 LLM 调用缺少错误处理

**文件**: `core/inner_drive.py:113-152`
**行号**: 145-152

```python
# core/inner_drive.py:145-152
resp = self._provider.generate(messages, stream=False, max_tokens=256)
intent = self._parse_proactive_intent(resp)
logger.info(
    f"[inner_drive] proactive decision: action={intent.action} "
    f"topic={intent.topic_hint[:60]} reason={intent.reasoning[:60]}"
)
return intent
```

**问题描述**:
`assess_proactive()` 调用 LLM 生成 proactive 决策，但：
1. 没有 try-except 捕获 API 调用异常（如网络错误、超时、速率限制）
2. `_parse_proactive_intent()` 在 LLM 返回异常内容时可能产生不合理的意图
3. `max_tokens=256` 对于某些复杂决策可能不够

如果 API 调用失败，异常会向上传播到 `_proactive_loop`，被 `except Exception as e:` 捕获，然后 `await asyncio.sleep(30)`。这意味着一次 API 失败会导致 proactive 循环暂停 30 秒。

**影响**: API 不稳定时 proactive 行为频繁中断，用户体验不连贯。

**建议**:
1. 在 `assess_proactive()` 中添加 try-except，API 失败时返回默认的 `ProactiveIntent(action="silent")`
2. 增加重试逻辑（最多 2 次）
3. 考虑在 `_parse_proactive_intent()` 中增加对异常输出的降级处理

---

#### MR3: `_parse_proactive_intent` 的意图解析过于宽松

**文件**: `core/inner_drive.py:348-367`
**行号**: 348-367

```python
# core/inner_drive.py:348-367
def _parse_proactive_intent(self, text: str) -> ProactiveIntent:
    text = text.strip()

    if "探索" in text:
        action = "explore"
    elif "沉默" in text or "等待" in text or "安静" in text:
        action = "silent"
    elif "聊天" in text or "说话" in text or "主动" in text:
        action = "chat"
    else:
        action = "chat"  # 默认 chat

    topic_match = re.search(r'话题[：:]\s*(.+?)(?:\n|[。！？]|$)', text)
    topic = topic_match.group(1).strip() if topic_match else ""

    reason_match = re.search(r'理由[：:]\s*(.+?)(?:\n|[。！？]|$)', text)
    reason = reason_match.group(1).strip() if reason_match else text[:200]

    return ProactiveIntent(action=action, topic_hint=topic, reasoning=reason)
```

**问题描述**:

1. **默认 fallback 为 "chat"**: 如果 LLM 的输出不包含任何关键词（"探索"、"沉默"、"等待"、"安静"、"聊天"、"说话"、"主动"），默认行为是 "chat"。这可能导致 AI 在应该安静的时候主动搭话。

2. **关键词匹配的歧义**: 如果 LLM 说"我不应该主动聊天，应该保持沉默"，输出中同时包含 "聊天" 和 "沉默"。由于 "探索" 先检查，然后 "沉默"，这段文本会匹配 "沉默"。但如果 LLM 说"虽然想聊天，但还是等待吧"，会匹配 "聊天"（因为先检查 "聊天"）。

3. **topic 和 reason 的正则过于严格**: 要求 "话题：" 和 "理由：" 的精确格式。如果 LLM 使用 "Topic:"、"主题：" 或没有冒号，解析会失败。

4. **缺少 confidence 评分**: `ProactiveIntent` 没有 confidence 字段，无法表达 LLM 对决策的确定程度。

**影响**: LLM 决策解析不稳定，可能导致不合适的主动行为。

**建议**:
1. 将默认 fallback 改为 "silent"（保守策略）
2. 增加更多关键词变体（"Topic"、"主题"、"讨论" 等）
3. 添加 confidence 字段，低 confidence 时默认 silent
4. 使用更结构化的输出格式（如 JSON）要求 LLM 返回决策

---

#### MR4: 睡眠期间的情绪事件记录缺失

**文件**: `core/sleep_manager.py:111-114`, `core/message_handler.py:68-70`
**行号**: 111-114, 68-70

```python
# core/sleep_manager.py:111-114
self._personality.emotion.record_emotion_event(
    trigger=f"梦: {dream.strip()[:100]}",
    context=dream.strip()[:200],
)

# core/message_handler.py:68-70
if a._sleeping:
    a.last_activity_time = time.time()
    return random.choice(["zzz...ZZZ...", "Zzzz...[翻身]", ...])
```

**问题描述**:

1. **梦境事件的情绪强度未检查**: `record_emotion_event()` 在 `models/personality.py:247` 中有 `if primary_intensity < 0.6: return` 的过滤。但梦境生成后，情绪状态可能不满足 `>= 0.6` 的强度要求，导致梦境事件被静默丢弃。用户可能期待 AI "记住自己的梦"，但实际上这些梦可能没有进入情绪事件列表。

2. **睡眠期间用户消息无情绪记录**: 当 AI 在睡眠中收到用户消息时，直接返回 zzz 变体，不调用 `_process_emotion()`。这意味着：
   - 用户可能在 AI 睡觉时发送了重要消息
   - 这些消息不会触发情绪分析
   - 不会更新 `last_activity_time`（虽然 `message_handler.py:69` 设置了，但 `server.py:231` 也设置了）
   - 不会记录到 conversation_turns

   实际上，`message_handler.py:69` 设置了 `last_activity_time`，但 `short_term.add_turn("user", ...)` 和 `ltm.repo.insert_turn_sync()` 都被跳过了。这意味着 AI 醒来后不知道用户在睡觉时说了什么。

**影响**: 睡眠期间的用户消息完全丢失；梦境可能未被记录。

**建议**:
1. 在睡眠消息处理中，将用户消息存入 `short_term` 和 `ltm`（但不生成回复），这样 AI 醒来后能看到"未读消息"
2. 梦境生成后强制记录情绪事件（绕过 intensity 检查，或降低梦境事件的 intensity 阈值）
3. 或者，在 AI 醒来时批量处理睡眠期间收到的消息

---

#### MR5: `SleepManager` 的时间窗口硬编码，无配置化

**文件**: `core/sleep_manager.py:40-93`
**行号**: 57-92

```python
# core/sleep_manager.py:57-92
# Nap window: 12:00-13:00
if 12 <= hour < 13 and not self._sleeping:
    # ...

# Night sleep: 23:00-01:00
if 23 <= hour or hour < 1:
    # ...

# Wake from nap: 13:10-16:00
if 13.16 <= hour < 16 and self._sleeping:
    # ...

# Wake from night: 7:00-10:00
if 7 <= hour < 10 and self._sleeping:
    # ...
```

**问题描述**:
睡眠和醒来的时间窗口完全硬编码在代码中：
- 午睡：12:00-13:00
- 夜睡：23:00-01:00
- 午醒：13:10-16:00（注意 13.16 是 13:09:36，不是 13:10）
- 晨醒：7:00-10:00

这些时间无法通过配置调整。对于不同时区的用户、不同作息习惯的 AI 人格，硬编码的时间窗口不适用。

此外，`13.16` 这个值看起来像是想表示 13:10（即 13 + 10/60 = 13.1666...），但写成了 13.16（即 13:09:36）。这是一个微小的精度误差。

**影响**: 无法自定义 AI 的作息；跨时区部署时睡眠周期与用户实际时间错位。

**建议**:
1. 将时间窗口提取到 `Config` 或 `PersonalityConfig` 中
2. 修复 `13.16` 为 `13 + 10/60` 或 `13.1667`
3. 考虑根据用户的活跃时间自适应调整睡眠窗口（如用户总是凌晨 2 点还在聊天，AI 的晚睡窗口应延后）

---

### 低风险问题

#### LR1: `SleepManager.get_sleep_state()` 的随机判定缺乏种子控制

**文件**: `core/sleep_manager.py:40-93`
**行号**: 59, 67, 77, 88

```python
# core/sleep_manager.py:59
if random.random() < max(0.1, sleepiness):
    # ...

# core/sleep_manager.py:67
if random.random() < max(0.3, sleepiness + 0.3):
    # ...

# core/sleep_manager.py:77
if random.random() < min(0.9, wake_chance):
    # ...

# core/sleep_manager.py:88
if random.random() < min(0.9, wake_chance):
    # ...
```

**问题描述**:
睡眠和醒来的触发都依赖 `random.random()`，但没有设置随机种子。这在大多数情况下不是问题，但在以下场景可能产生困惑：

1. **测试不可重复**: 单元测试无法预测 `get_sleep_state()` 的返回值
2. **调试困难**: 开发者无法复现特定的睡眠/唤醒时序
3. **多实例行为不一致**: 如果运行多个 AI 实例（如负载均衡），它们的随机序列不同，睡眠行为不一致

**影响**: 测试和调试困难。

**建议**:
1. 允许注入随机数生成器（如 `random.Random(seed)`）用于测试
2. 或在 `SleepManager.__init__` 中接受可选的 `rng` 参数

---

#### LR2: `_proactive_loop` 的异常处理过于宽泛，隐藏真正的问题

**文件**: `web/server.py:194-196`
**行号**: 194-196

```python
# web/server.py:194-196
except Exception as e:
    logger.warning(f"Proactive error: {e}")
    await asyncio.sleep(30)
```

**问题描述**:
`_proactive_loop` 捕获所有异常并简单地记录 warning，然后 sleep 30 秒。这意味着：

1. **API 密钥错误**会被静默处理，用户不知道 AI 为什么不再主动搭话
2. **数据库连接断开**会被静默处理，可能导致后续所有 proactive 行为失败
3. **内存不足**等严重错误也会被捕获，系统可能处于不健康状态但继续运行

**影响**: 真正的问题被隐藏，系统可能在亚健康状态下长期运行。

**建议**:
1. 区分可恢复异常（API 超时）和不可恢复异常（API 密钥错误、内存不足）
2. 对不可恢复异常使用 `logger.exception()` 并考虑终止 proactive loop
3. 增加错误计数器，连续失败 N 次后停止 proactive loop 并报警

---

#### LR3: `SleepManager` 的情绪驱动睡眠检测不完整

**文件**: `core/sleep_manager.py:47-55`
**行号**: 47-55

```python
# core/sleep_manager.py:47-55
sleepiness = 0.0
if e.dominant_emotion in ("sad", "melancholy"):
    sleepiness += 0.4
if e.arousal < 0.3:
    sleepiness += 0.3
if e.dominant_emotion in ("excited", "joyful"):
    sleepiness -= 0.2
sleepiness += r * 0.2
```

**问题描述**:
睡眠管理器只检测了 4 种情绪状态对睡眠的影响：
- sad/melancholy -> 更困
- excited/joyful -> 更不困
- low arousal -> 更困
- resentment -> 更困

但忽略了：
- **anxious**: 焦虑时通常难以入睡，应减少 sleepiness
- **angry**: 愤怒时也难以入睡，应减少 sleepiness
- **afraid**: 恐惧时可能失眠，应减少 sleepiness
- **content**: 满足时容易入睡，应增加 sleepiness
- **tired/engaged**: 长时间 engaged 后应该更困

**影响**: AI 的睡眠行为与情绪状态的相关性不够丰富。

**建议**:
1. 增加对 anxious、angry、afraid、content 情绪的睡眠影响
2. 考虑添加 "连续交互时长" 作为睡眠驱动因素（如连续聊天 2 小时后更容易困）

---

#### LR4: `ProactivityManager.pick_proactive_topic` 的话题选择缺乏多样性控制

**文件**: `core/proactivity.py:66-92`
**行号**: 66-92

```python
# core/proactivity.py:66-92
def pick_proactive_topic(self) -> str:
    exps = self._ltm.get_recent_experiences(limit=3)
    facts = self._ltm.get_all_active_facts(limit=5)
    interests = getattr(self._personality.config, 'interests', [])
    topics = []

    if exps:
        topics.append(f"上次聊的: {exps[0].summary}")
    if facts:
        f = random.choice(facts)
        topics.append(f"关于用户的: {f.fact_key} = {f.fact_value}")
    if interests:
        topic = random.choice(interests)
        topics.append(f"聊点关于「{topic}」的")
    # ...
    return random.choice(topics)
```

**问题描述**:

1. **话题重复**: 如果 `exps` 和 `facts` 变化不大，AI 会反复提起相同的话题
2. **没有时间衰减**: 昨天聊的话题和上周聊的话题被同等对待
3. **缺乏话题关联性**: 随机选择话题，没有考虑当前时间、天气、节日等上下文
4. **interests 的过度使用**: 如果 `interests` 列表很长，AI 可能频繁聊起自己的兴趣而非用户的兴趣

**影响**: AI 的主动搭话可能显得重复、不合时宜。

**建议**:
1. 添加话题历史记录，避免短期内重复相同话题
2. 为话题添加时间权重，越近的话题优先级越高
3. 考虑当前时间上下文（早上聊计划、晚上聊一天总结）
4. 增加 "用户最近关心什么" 的检测，优先聊用户感兴趣的话题

---

## 汇总统计

### 问题汇总表

| 编号 | 问题描述 | 风险等级 | 位置 | 修复优先级 |
|------|----------|----------|------|------------|
| 1 | 睡眠状态全局共享（`.sleep_state` 文件） | 高 | `core/agent.py:59-65`, `core/sleep_manager.py:14-38` | P0 |
| 2 | `last_activity_time` 并发修改无同步 | 高 | `web/server.py:145,158,188,231` | P0 |
| 3 | 睡眠期间消息处理与 proactive 循环竞态 | 高 | `web/server.py:154-156`, `core/message_handler.py:68-70` | P0 |
| 4 | 梦境生成同步阻塞 + CLI 缺失 + 记忆关联弱 | 高 | `web/server.py:149-151`, `core/sleep_manager.py:96-119` | P1 |
| 5 | `sleep_cooldown` 整数递减导致冷却时间远超预期 | 高 | `web/server.py:131-153` | P1 |
| 6 | 主动行为评分算法情绪盲区 + 负向饱和 | 高 | `core/proactivity.py:21-64` | P1 |
| 7 | `check_rate_limit` 首次调用逻辑缺陷 | 中 | `core/proactivity.py:104-108` | P2 |
| 8 | `assess_proactive` LLM 调用缺少错误处理 | 中 | `core/inner_drive.py:145-152` | P2 |
| 9 | `_parse_proactive_intent` 解析过于宽松 | 中 | `core/inner_drive.py:348-367` | P2 |
| 10 | 睡眠期间用户消息无情绪记录 + 梦境可能丢失 | 中 | `core/sleep_manager.py:111-114`, `core/message_handler.py:68-70` | P2 |
| 11 | 睡眠窗口硬编码无配置化 | 中 | `core/sleep_manager.py:57-92` | P2 |
| 12 | `SleepManager` 随机判定缺乏种子控制 | 低 | `core/sleep_manager.py:59,67,77,88` | P3 |
| 13 | `_proactive_loop` 异常处理过于宽泛 | 低 | `web/server.py:194-196` | P3 |
| 14 | 情绪驱动睡眠检测不完整 | 低 | `core/sleep_manager.py:47-55` | P3 |
| 15 | `pick_proactive_topic` 缺乏多样性控制 | 低 | `core/proactivity.py:66-92` | P3 |

### 按主题分类

| 主题 | 问题数量 | 涉及问题 |
|------|----------|----------|
| 全局状态共享/竞态条件 | 3 | HR1, HR2, HR3 |
| 时间/冷却逻辑 | 2 | HR5, MR5 |
| 评分算法缺陷 | 2 | HR6, MR4 |
| 梦境生成与记忆 | 2 | HR4, MR4 |
| 错误处理/鲁棒性 | 2 | MR2, LR2 |
| 意图解析 | 1 | MR3 |
| 话题选择 | 1 | LR4 |
| 随机性/测试 | 1 | LR1 |
| 情绪模型完整性 | 1 | LR3 |

### 修复优先级建议

**P0（立即修复）**:
- HR1: 睡眠状态全局共享 —— 将 `.sleep_state` 改为按会话存储
- HR2: `last_activity_time` 并发修改 —— 添加同步机制
- HR3: 睡眠期间竞态条件 —— 在关键检查点重新验证状态

**P1（本周修复）**:
- HR4: 梦境生成阻塞 + CLI 缺失 —— 改为异步，CLI 集成
- HR5: `sleep_cooldown` 改为时间戳实现
- HR6: 主动行为评分算法改进

**P2（下周修复）**:
- MR1-MR5: 速率限制、错误处理、意图解析、睡眠消息处理、配置化

**P3（可选优化）**:
- LR1-LR4: 随机种子、异常分类、情绪检测、话题多样性

---

## 附录：关键代码引用

### A1. SleepManager 完整睡眠/唤醒逻辑

```python
# core/sleep_manager.py:40-93
def get_sleep_state(self) -> tuple[bool, str | None]:
    now = datetime.now()
    hour = now.hour + now.minute / 60.0
    e = self._personality.emotion
    r = getattr(e, 'resentment', 0.0)

    sleepiness = 0.0
    if e.dominant_emotion in ("sad", "melancholy"):
        sleepiness += 0.4
    if e.arousal < 0.3:
        sleepiness += 0.3
    if e.dominant_emotion in ("excited", "joyful"):
        sleepiness -= 0.2
    sleepiness += r * 0.2

    # Nap window: 12:00-13:00
    if 12 <= hour < 13 and not self._sleeping:
        if random.random() < max(0.1, sleepiness):
            self._sleeping = True; self._save_sleep_state()
            return True, "我去午睡一会儿...困了[困]"

    # Night sleep: 23:00-01:00
    if 23 <= hour or hour < 1:
        if not self._sleeping:
            if random.random() < max(0.3, sleepiness + 0.3):
                self._sleeping = True; self._save_sleep_state()
                return True, "夜深了...我睡了，晚安[月亮]"

    # Wake from nap: 13:10-16:00 (13.16 = 13:09:36, 不是 13:10)
    if 13.16 <= hour < 16 and self._sleeping:
        wake_chance = 0.3 + (hour - 13.16) / 3.0
        wake_chance += max(0, e.arousal - 0.3) * 0.2
        wake_chance -= r * 0.1
        if random.random() < min(0.9, wake_chance):
            self._sleeping = False; self._save_sleep_state()
            dream = self.generate_dream()
            return False, f"睡醒了...{'做了个梦：' + dream if dream else '没做梦，睡得挺香'}"

    # Wake from night: 7:00-10:00
    if 7 <= hour < 10 and self._sleeping:
        wake_chance = 0.2 + (hour - 7) / 3.0
        wake_chance += max(0, e.arousal - 0.3) * 0.15
        wake_chance -= r * 0.1
        if random.random() < min(0.9, wake_chance):
            self._sleeping = False; self._save_sleep_state()
            dream = self.generate_dream()
            return False, f"早上好！{'我做了个梦：' + dream if dream else '睡得很好！'}"

    return False, None
```

### A2. ProactivityManager 完整评分逻辑

```python
# core/proactivity.py:21-64
def calculate_proactivity(self, idle_duration: float) -> float:
    e = self._personality.emotion
    r = getattr(e, 'resentment', 0.0)

    idle_thresholds = {
        "excited": 60, "joyful": 90, "surprised": 120,
        "engaged": 180, "content": 300, "trusting": 240, "anticipating": 150,
        "neutral": 360,
        "anxious": 90, "afraid": 180,
        "melancholy": 600, "sad": 900,
        "frustrated": 300, "angry": 480, "disgusted": 600,
    }
    min_idle = idle_thresholds.get(e.dominant_emotion, 300)
    min_idle += int(r * 300)

    if idle_duration < min_idle:
        return 0.0

    base = min(0.3, (idle_duration - min_idle) / 900.0)
    hour = datetime.now().hour
    time_mod = 0.2 if 10 <= hour <= 21 else 0.1 if 7 <= hour <= 22 else 0.0
    emotion_mod = e.arousal * 0.2
    if e.dominant_emotion in ("melancholy", "sad", "frustrated", "afraid"):
        emotion_mod -= 0.15
    rel = self._ltm.get_relationship()
    intimacy_mod = rel.get("intimacy", 0.3) * 0.15 + min(rel.get("familiarity", 0.3) * 0.1, 0.1)
    user_turns = [t for t in self._short_term.get_recent(6) if t.role == "user"][-3:]
    sentiment_mod = 0.0
    if user_turns:
        last = user_turns[-1].content
        if any(kw in last for kw in ["烦", "滚", "生气", "讨厌", "别烦", "不想", "别吵"]):
            sentiment_mod = -0.3
        elif any(kw in last for kw in ["哈哈", "开心", "好看", "棒", "不错", "喜欢", "好"]):
            sentiment_mod = 0.1
    goodbye = sum(1 for t in self._short_term.get_recent(6) if any(kw in t.content for kw in ["拜拜", "再见", "bye", "下次", "睡了", "晚安"]))
    short_c = sum(1 for t in user_turns if len(t.content) < 8)
    score = base + time_mod + emotion_mod + intimacy_mod + sentiment_mod - min(goodbye * 0.15, 0.3) - min(short_c * 0.08, 0.2)
    score = max(0.0, min(0.8, score))
    return score
```

### A3. _proactive_loop 核心循环

```python
# web/server.py:130-196
async def _proactive_loop(websocket: WebSocket, session_id: str):
    cooldown = 0
    sleep_cooldown = 0
    while True:
        try:
            active_ws = session_manager.get_active_ws(session_id) or websocket
            _, agent = session_manager.get_or_create(session_id)
            ag = agent.agent

            if sleep_cooldown == 0:
                should_sleep, msg = ag._get_sleep_state()
                if msg:
                    ag.last_activity_time = time.time()
                    cooldown = 60
                    sleep_cooldown = 120
                    await _send_segments(active_ws, agent, msg, agent.emotion)
                    if should_sleep:
                        loop = asyncio.get_event_loop()
                        await loop.run_in_executor(None, ag._generate_dream)
            else:
                sleep_cooldown = max(0, sleep_cooldown - 1)
            if ag._sleeping:
                await asyncio.sleep(30)
                continue

            idle = time.time() - ag.last_activity_time
            if idle < 30 or cooldown > 0:
                cooldown = max(0, cooldown - 1)
                await asyncio.sleep(5)
                continue

            score = ag._calculate_proactivity(idle)
            if random.random() < score:
                loop = asyncio.get_event_loop()
                intent = await loop.run_in_executor(None, ag.decide_proactive_action, idle)
                if intent.action == "explore" and ag._check_rate_limit("explore"):
                    response = await loop.run_in_executor(None, agent.process_explore_with_intent, intent)
                elif intent.action == "chat" and ag._check_rate_limit("chat"):
                    response = await loop.run_in_executor(None, agent.process_proactive_with_intent, intent)
                else:
                    response = None
                if response:
                    ag.last_activity_time = time.time()
                    cooldown = 12
                    await _send_segments(active_ws, agent, response, agent.emotion)
            await asyncio.sleep(15)
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.warning(f"Proactive error: {e}")
            await asyncio.sleep(30)
```

---

*报告结束。本次审查覆盖了睡眠与主动行为的完整状态流，识别了15个问题，其中6个高风险问题需要优先修复。*
