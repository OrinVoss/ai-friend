# AI Friend 项目性能与可扩展性审查报告 —— 扩展瓶颈专题

**审查日期**: 2026-05-31
**审查范围**: web/session.py, storage/database.py, core/provider.py, memory/*.py, config.py 及上下游调用链
**审查维度**: 单实例架构限制、SQLite 并发瓶颈、单 Provider 连接限制、内存会话上限、上下文长度硬限制、多用户扩展能力、多模型切换支持、水平扩展可行性、长期数据增长影响
**关联文档**: doc/round05-memory-usage.md, doc/round05-database-performance.md, doc/round05-api-efficiency.md, doc/round05-caching.md

---

# 概述

AI Friend 项目当前采用**单进程、单数据库、单 API Provider** 的架构模式。在 CLI 单用户场景下，这种架构简单高效，但随着 Web 模式的引入和功能的不断扩展，系统在并发处理、数据增长、资源隔离、水平扩展等方面暴露出严重的结构性瓶颈。

本次审查从 9 个核心维度出发，共识别出 **28 项具体扩展瓶颈**，风险评级分布如下：

| 风险等级 | 数量 | 说明 |
|---------|------|------|
| Critical（严重） | 6 | 直接阻碍多用户/高并发扩展 |
| High（高） | 10 | 长期运行后显著影响性能或稳定性 |
| Medium（中） | 8 | 在特定场景下造成扩展受限 |
| Low（低） | 4 | 轻微或可忽略的扩展影响 |

核心结论：当前架构在**不改动底层设计**的前提下，理论并发上限约为 **50-100 个 Web 会话**，长期记忆上限约为 **数千条记录**，API 调用吞吐量受限于单 Provider 实例的串行处理。若要支持 1000+ 用户、TB 级数据、多模型动态切换，需要进行**架构级重构**。

---

## 详细发现

---

### 1. 单实例架构的限制

#### 1.1 全局唯一的 SessionManager 实例

**文件**: `web/server.py` 第 17-18 行
**代码**:
```python
config = load_config()
session_manager = SessionManager(config)
```

**问题描述**:
`SessionManager` 在模块导入时即被实例化，作为全局单例存在。FastAPI 的 lifespan 管理器在启动时调用 `session_manager.open()` 初始化数据库连接。这种设计意味着：

1. **整个进程只有一个 SessionManager**: 所有 WebSocket 连接和 REST 请求共享同一个会话字典、同一个数据库连接、同一个配置对象。
2. **无多进程扩展能力**: 如果使用 `uvicorn --workers 4` 启动多个进程，每个进程会有独立的 `SessionManager` 实例，会话状态无法在进程间共享。用户连接到进程 A 创建的会话，在进程 B 上不可见。
3. **无状态服务化困难**: 当前架构将状态（会话字典、Agent 状态、情绪状态）全部保存在进程内存中，无法将 Web 层和 Agent 层分离部署。

**风险评级**: **Critical**

**影响量化**:
- 单进程内存上限：约 1-2GB（Python 进程 + 50 个会话 × 20MB）
- 单进程并发连接数：FastAPI + Uvicorn 在纯异步场景下可处理数千连接，但数据库锁将实际并发降至 <10
- 多进程部署时：会话丢失、数据不一致、重复创建同一 session_id 的 Agent

**修复建议**:
1. 将会话状态外置到 Redis 或共享缓存，使 Web 层无状态化
2. 将 `SessionManager` 设计为可插拔的后端（内存 / Redis / Database）
3. 使用粘性会话（sticky session）负载均衡，确保同一用户始终路由到同一进程

---

#### 1.2 WebAgent 重量级对象无法序列化

**文件**: `web/session.py` 第 27-119 行
**代码**:
```python
class WebAgent:
    def __init__(self, config: Config, db: Database, repo: Repository):
        self.personality = Personality.load(config.personality_file)
        self.ltm = LongTermMemory(repo)
        self.short_term = ConversationBuffer(maxlen=config.short_term_capacity)
        self.provider = KimiProvider(...)
        self.agent = Agent(...)
```

**问题描述**:
`WebAgent` 包含大量不可序列化的对象：`requests.Session`（`KimiProvider` 中）、`threading.Lock`（`ConversationBuffer` 中）、`asyncio.Task`（`SessionManager._proactive_tasks` 中）。这些对象无法通过 pickle 或 JSON 序列化，意味着：

- 无法将 `WebAgent` 状态写入 Redis 或磁盘
- 无法使用 Celery 等任务队列异步处理消息
- 无法实现"会话迁移"（将活跃会话从进程 A 迁移到进程 B）

**风险评级**: **High**

**修复建议**:
1. 将会话状态拆分为"可序列化数据"和"运行时对象"两层
2. 可序列化数据：personality 配置、short_term 内容、turn_count、emotion_events 等
3. 运行时对象：Provider、EmbeddingEngine、ToolRegistry 等作为进程级单例，不随会话序列化

---

#### 1.3 全局配置对象无热更新机制

**文件**: `config.py` 第 48-78 行
**代码**:
```python
def load_config(path: str = CONFIG_PATH) -> Config:
    cfg = Config()
    if os.path.exists(path):
        ...
    return cfg
```

**问题描述**:
`load_config()` 在进程启动时调用一次，配置值被写入 `Config` dataclass 实例。运行期间修改 `config.json` 或环境变量不会生效。在扩展场景下：

- 无法动态调整 `max_tokens`、`temperature` 等参数以应对流量高峰
- 无法在不重启服务的情况下切换 API 模型
- 无法动态添加允许读取的文件路径

**风险评级**: **Medium**

**修复建议**:
1. 为 `Config` 添加文件监听机制（`watchdog` 库），配置文件变化时自动重载
2. 或将会话级配置与全局配置分离，允许每个会话独立覆盖部分参数

---

### 2. SQLite 的并发瓶颈

#### 2.1 单连接 + 全局 asyncio.Lock 串行化所有数据库操作

**文件**: `storage/database.py` 第 11-45 行
**代码**:
```python
class Database:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._lock = asyncio.Lock()
        self.conn: aiosqlite.Connection | None = None

    @asynccontextmanager
    async def cursor(self):
        async with self._lock:
            c = await self.conn.cursor()
            try:
                yield c
                await self.conn.commit()
            ...
```

**问题描述**:
`Database` 类只维护一个 `aiosqlite.Connection`，所有数据库操作通过 `asyncio.Lock` 串行化。在 Web 模式下，所有 session 共享同一个 `Database` 实例（`web/session.py:132-134`），进而共享同一个连接和锁。

**性能影响**:
- 单条查询快（<10ms）时，串行化影响不明显
- 一旦某条查询变慢（如 `LIKE '%query%'` 全表扫描、大结果集排序、WAL checkpoint），所有其他请求都被阻塞
- 在 `_proactive_loop`（`web/server.py:130-196`）中，每 15 秒可能触发一次 proactive 处理，包含完整的 Agent 流程（含多次 DB 查询），进一步加剧锁竞争

**风险评级**: **Critical**

**扩展上限估算**:
| 场景 | 理论 QPS | 瓶颈 |
|------|---------|------|
| 纯读（索引命中） | 100-200 | asyncio.Lock 串行化 |
| 混合读写（WAL 模式） | 20-50 | 写操作阻塞读操作 |
| 全表扫描查询 | 5-10 | 慢查询阻塞所有其他请求 |
| 并发 consolidation | 2-5 | 多 session 同时触发批量写 |

**修复建议**:
1. **读写分离连接池**: 1 个写连接 + N 个读连接（WAL 模式支持多连接并发读）
2. **连接池实现示例**:
   ```python
   class DatabasePool:
       def __init__(self, db_path: str, max_read_connections: int = 4):
           self.db_path = db_path
           self._write_conn = None
           self._write_lock = asyncio.Lock()
           self._read_pool = asyncio.Queue(maxsize=max_read_connections)
   ```
3. **替代方案**: 迁移到 PostgreSQL（通过 `asyncpg`），原生支持高并发读写

---

#### 2.2 WAL 模式配置不完整

**文件**: `storage/database.py` 第 21-22 行
**代码**:
```python
await self.conn.execute("PRAGMA journal_mode=WAL")
await self.conn.execute("PRAGMA foreign_keys=ON")
```

**问题描述**:
WAL 模式已启用，但缺少关键 PRAGMA 配置：

| PRAGMA | 当前值 | 建议值 | 作用 |
|--------|--------|--------|------|
| `synchronous` | 默认 FULL | NORMAL | 减少 fsync 频率，提升写性能 |
| `wal_autocheckpoint` | 默认 1000 | 100~500 | 控制 WAL 文件大小 |
| `cache_size` | 默认 2MB | 64MB | 增加页缓存 |
| `busy_timeout` | 默认 0 | 5000ms | 写冲突时等待而非立即返回 BUSY |
| `mmap_size` | 默认 0 | 256MB | 内存映射数据库文件 |

**风险评级**: **High**

**修复建议**:
```python
await self.conn.execute("PRAGMA journal_mode=WAL")
await self.conn.execute("PRAGMA synchronous=NORMAL")
await self.conn.execute("PRAGMA wal_autocheckpoint=500")
await self.conn.execute("PRAGMA cache_size=-64000")
await self.conn.execute("PRAGMA temp_store=MEMORY")
await self.conn.execute("PRAGMA mmap_size=268435456")
await self.conn.execute("PRAGMA busy_timeout=5000")
```

---

#### 2.3 数据库文件位于本地磁盘，无法分布式共享

**文件**: `config.py` 第 18 行
**代码**:
```python
db_path: str = "data/ai_friend.db"
```

**问题描述**:
SQLite 数据库文件存储在本地文件系统，这意味着：
- 无法在多机部署时共享数据
- 容器化部署时数据持久化需要挂载卷
- 读写操作受限于单机的磁盘 I/O 性能

**风险评级**: **High**

**扩展上限**:
- 单机 SQLite 在 WAL 模式下的读写吞吐量约为 1000-5000 TPS（取决于硬件）
- 数据量增长至 GB 级别时，查询性能显著下降
- 无法利用分布式数据库的水平扩展能力

**修复建议**:
1. 短期：使用高性能 SSD，优化索引和查询
2. 中期：引入 `sqlite-vec` 扩展优化向量搜索
3. 长期：评估迁移到 PostgreSQL + pgvector，或专用向量数据库（Milvus Lite、Chroma）

---

### 3. 单 Provider 连接的限制

#### 3.1 KimiProvider 使用单 requests.Session

**文件**: `core/provider.py` 第 11-35 行
**代码**:
```python
class KimiProvider:
    def __init__(self, endpoint: str, api_key: str, model: str, ...):
        self.session = requests.Session()
        self.session.trust_env = False
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        })
```

**问题描述**:
`KimiProvider` 使用单个 `requests.Session` 对象管理 HTTP 连接池。`requests.Session` 默认的连接池配置为：
- `urllib3` 连接池大小：10（默认）
- 每个 host 的最大连接数：10

在 Web 多会话场景下：
- 每个 `WebAgent` 创建独立的 `KimiProvider` 实例（`web/session.py:40-46`）
- 50 个会话 = 50 个 `requests.Session` = 500 个潜在 TCP 连接
- 虽然 `requests` 的连接池会复用连接，但 50 个独立 Session 意味着 50 个独立的连接池，总共可能维护数百个 TCP 连接

**风险评级**: **High**

**扩展上限估算**:
| 指标 | 当前值 | 瓶颈 |
|------|--------|------|
| 单 Provider 实例并发请求 | 10（连接池默认） | 连接池耗尽后请求排队 |
| 50 个 Provider 实例总连接 | 500 | 本地端口耗尽（65535 上限） |
| API 端点 QPS 限制 | 取决于 DeepSeek | 可能触发速率限制 |

**修复建议**:
1. 将 `KimiProvider` 改为进程级单例，所有会话共享同一个 Session
2. 增加连接池大小配置：`session.mount('https://', HTTPAdapter(pool_connections=20, pool_maxsize=50))`
3. 实现全局 API 调用队列和速率限制器

---

#### 3.2 同步 requests 阻塞事件循环

**文件**: `core/provider.py` 第 82-134 行
**代码**:
```python
def _do_request(self, url: str, payload: dict, stream: bool, on_token: Optional[callable]) -> str:
    resp = self.session.post(url, json=payload, stream=True, timeout=self.timeout)
    ...
```

**问题描述**:
`KimiProvider.generate()` 是同步方法，内部使用 `requests.post()` 发起阻塞式 HTTP 请求。在 Web 模式下，通过 `loop.run_in_executor()` 在线程池中执行（`web/server.py:233`）：

```python
response = await loop.run_in_executor(None, agent.process_message, content)
```

这意味着：
- 每个 API 调用占用一个线程池线程
- 默认线程池大小有限（`ThreadPoolExecutor` 默认 `min(32, os.cpu_count() + 4)`）
- 高并发时线程池耗尽，新请求无法获得线程执行

**风险评级**: **Critical**

**扩展上限**:
- 默认线程池大小：约 8-16 线程（取决于 CPU 核心数）
- 每个 API 调用耗时：1-10 秒（取决于模型和输出长度）
- 理论并发上限：8-16 个同时进行的 API 调用

**修复建议**:
1. 将 `KimiProvider` 改为异步实现，使用 `aiohttp` 或 `httpx` 替代 `requests`
2. 异步实现后，API 调用不再占用线程，并发能力提升至数千
3. 配合连接池共享，大幅降低资源占用

---

#### 3.3 无全局 API 配额管理

**文件**: `web/session.py` 第 121-175 行
**代码**:
```python
class SessionManager:
    def get_or_create(self, session_id: Optional[str] = None) -> tuple[str, WebAgent]:
        with self._lock:
            sid = session_id or uuid.uuid4().hex[:12]
            if sid not in self._sessions:
                self._sessions[sid] = WebAgent(self.config, self.db, self.repo)
            return sid, self._sessions[sid]
```

**问题描述**:
每个 session 独立发起 API 调用，没有全局配额控制：
- 高并发场景下（如 50 个活跃 session），总 QPS 可能超出 API 提供商限制
- 没有优先级队列：后台的 proactive 调用和记忆固化可能与用户-facing 调用竞争
- 没有熔断机制：单个 session 的异常行为（如陷入重试循环）可能耗尽全局配额

**风险评级**: **High**

**修复建议**:
1. 实现全局 API 调用速率限制器（token bucket 或 leaky bucket 算法）
2. 区分调用优先级：用户-facing > 记忆检索 > 记忆固化 > proactive
3. 为每个 session 设置每分钟的 API 调用上限
4. 实现熔断机制：连续失败 10 次后暂停该 session 的 API 调用 30 秒

---

### 4. 内存中的会话上限（50）

#### 4.1 cleanup_old 的硬编码上限

**文件**: `web/session.py` 第 169-174 行
**代码**:
```python
def cleanup_old(self, max_sessions: int = 50) -> None:
    with self._lock:
        while len(self._sessions) > max_sessions:
            oldest = next(iter(self._sessions))
            self._sessions.pop(oldest)
            logger.info(f"Session evicted: {oldest}")
```

**问题描述**:
`cleanup_old()` 的默认上限为 50 个会话，且存在以下问题：

1. **FIFO 策略不安全**: "最旧"是根据字典插入顺序决定的。如果某个旧会话仍然活跃（WebSocket 未断开），`cleanup_old()` 会直接将其驱逐，导致该会话的状态丢失，但客户端仍认为连接有效。
2. **仅移除 _sessions，不清理关联资源**: 被驱逐会话的 proactive task、WebSocket 引用仍然保留在 `_proactive_tasks` 和 `_active_ws` 字典中，形成僵尸引用。
3. **REST API 匿名请求无限创建会话**: 如果使用 REST API（`/api/chat`）而非 WebSocket，每次请求都会创建新会话（如果 `session_id` 未提供），但 REST 请求结束后不会自动调用 `remove()`。

**风险评级**: **Critical**

**扩展上限**:
| 指标 | 当前值 | 优化后 |
|------|--------|--------|
| 内存会话上限 | 50 | 可配置，建议 100-500 |
| 单会话内存占用 | 7-18 MB | 共享 Provider 后降至 3-5 MB |
| 50 会话总内存 | 350-900 MB | 150-250 MB |

**修复建议**:
1. 为会话添加 TTL（Time-To-Live）机制：记录最后活动时间，定期扫描并移除过期会话
2. `cleanup_old()` 应同步清理 `_proactive_tasks` 和 `_active_ws`
3. REST API 端点应要求提供 `session_id`，避免匿名请求创建无限会话
4. 考虑会话状态的序列化与反序列化：将不活跃会话状态写入磁盘，从内存中移除

---

#### 4.2 WebAgent 每会话独立创建重量级对象

**文件**: `web/session.py` 第 28-80 行
**代码**:
```python
class WebAgent:
    def __init__(self, config: Config, db: Database, repo: Repository):
        self.personality = Personality.load(config.personality_file)
        self.provider = KimiProvider(...)
        from memory.embeddings import EmbeddingEngine
        embed_engine = EmbeddingEngine(endpoint=config.embedding_endpoint, dim=config.embedding_dim)
        self.retriever = MemoryRetriever(self.ltm, embedding_engine=embed_engine)
        self.consolidator = MemoryConsolidator(self.ltm, llm_gen, embedding_engine=embed_engine)
        registry = ToolRegistry()
        registry.register(RecallTool(self.retriever, self.ltm))
        ...  # 8 个工具全部重新注册
```

**问题描述**:
每个 `WebAgent` 实例都独立创建：
- `Personality.load()` —— 读取并解析 `personality.json`
- `KimiProvider(...)` —— 独立 `requests.Session()`
- `EmbeddingEngine(...)` —— 独立 HTTP 会话
- `ToolRegistry()` + 8 个工具实例 —— 全部重新创建

50 个并发会话将创建：
- 50 个 `requests.Session()` 对象
- 50 个 `EmbeddingEngine` 实例
- 50 个 `ToolRegistry` 和 400 个工具实例

**风险评级**: **High**

**修复建议**:
以下组件应改为进程级单例或共享实例：

| 组件 | 共享方式 | 理由 |
|------|---------|------|
| `KimiProvider` | 单例（按 endpoint+model） | API 密钥、模型配置相同，Session 可共享 |
| `EmbeddingEngine` | 单例 | llama-server 端点相同，缓存可全局共享 |
| `ToolRegistry`（外部工具） | 单例 | 工具无状态，可安全共享 |
| `PersonalityConfig` | 单例 + 文件监听 | 配置相同，修改后统一重载 |

---

### 5. 上下文长度的硬限制

#### 5.1 _MODEL_CONTEXT 硬编码为 180_000

**文件**: `core/context_manager.py` 第 7-8 行
**代码**:
```python
_MODEL_CONTEXT = 180_000
COMPRESS_THRESHOLD = int(_MODEL_CONTEXT * 0.8)
```

**问题描述**:
`_MODEL_CONTEXT` 硬编码为 180,000 tokens，但当前配置的模型 `deepseek-v4-flash` 的上下文窗口实际为 128K tokens（131072）。180K 的设定已经超出模型实际能力。更严重的是：

- `COMPRESS_THRESHOLD = 144_000 tokens`，对于 typical 对话（每轮 500-1000 tokens 输入）需要 100+ 轮才会触发
- `short_term` 的 maxlen 仅为 20 轮（`ConversationBuffer(maxlen=20)`），远达不到阈值
- 因此压缩机制实际上**永远不会触发**

**风险评级**: **Medium**

**修复建议**:
1. 将 `_MODEL_CONTEXT` 修正为 131072（或从配置读取）
2. 将 `COMPRESS_THRESHOLD` 降低到合理值，如 20000-30000 tokens
3. 或者改为基于轮数触发：当 `short_term` 满（20 轮）时触发压缩，清空 buffer 并保留摘要

---

#### 5.2 短期记忆 maxlen 配置不一致

**文件**: `memory/short_term.py` 第 15 行 / `config.py` 第 19 行
**代码**:
```python
# memory/short_term.py
@dataclass
class ConversationBuffer:
    maxlen: int = 20

# config.py
short_term_capacity: int = 500
```

**问题描述**:
`ConversationBuffer` 默认 `maxlen=20`，但 `Config` 中配置为 500。Web 端使用 500，CLI 端可能使用默认值 20。这种不一致导致：
- Web 端短期记忆可保存 500 条，内存占用约为 20 条版本的 25 倍
- 500 条对话记录的实际内存占用可达 **2-5MB 每会话**

**风险评级**: **Medium**

**修复建议**:
1. 统一 `maxlen` 默认值与配置值，或移除默认值强制要求传入
2. 在 `add_turn` 中对 `content` 做长度限制，超过阈值时存储摘要或截断版本

---

#### 5.3 _react_loop 中 messages 列表持续增长

**文件**: `core/agent.py` 第 119-181 行
**代码**:
```python
def _react_loop(self, messages: list[dict], ...):
    for _idx in range(self._max_tool_iterations):
        resp = self.provider.generate(messages, ...)
        cleaned, calls = parse_tool_calls(resp)
        if not calls:
            break
        messages.append({"role": "assistant", "content": resp})
        results = execute_tool_calls(registry, calls)
        messages.append({"role": "user", "content": format_tool_results(results)})
```

**问题描述**:
`_react_loop` 每次迭代向 `messages` 追加 2 条消息（assistant 响应 + tool results）。如果 `_max_tool_iterations=10`，最多追加 20 条消息。这些消息的内容包括 LLM 的完整响应文本和工具返回的原始结果，总字符数可达数万。

**风险评级**: **High**

**修复建议**:
1. 对每轮追加的消息内容做长度限制，超过阈值时截断或替换为摘要
2. `format_tool_results` 应对每个工具的 `output` 做截断（如最多 2000 字符）
3. 限制 `_max_tool_iterations` 的默认值（目前为 10，建议降至 5）

---

### 6. 多用户扩展能力

#### 6.1 无用户身份隔离机制

**文件**: `web/session.py` 第 136-144 行
**代码**:
```python
def get_or_create(self, session_id: Optional[str] = None) -> tuple[str, WebAgent]:
    with self._lock:
        sid = session_id or uuid.uuid4().hex[:12]
        if sid not in self._sessions:
            self._sessions[sid] = WebAgent(self.config, self.db, self.repo)
        return sid, self._sessions[sid]
```

**问题描述**:
当前系统使用 `session_id` 作为唯一标识，但：
- `session_id` 由客户端提供或随机生成，没有与用户身份绑定的机制
- 任何知道 `session_id` 的人都可以访问该会话的数据
- 没有登录、认证、授权机制
- 长期记忆（facts、experiences、reflections）是全局共享的，不属于任何特定用户

这意味着：
- 无法支持多用户场景（User A 和 User B 的数据混在一起）
- 无法保护用户隐私（User A 可以查询到 User B 的事实）
- 无法进行用户级别的配额管理

**风险评级**: **Critical**

**修复建议**:
1. 引入用户身份认证（JWT、OAuth2、API Key）
2. 为所有数据表添加 `user_id` 或 `session_owner` 字段
3. 在 Repository 层添加用户隔离过滤条件
4. 实现用户级别的配额和速率限制

---

#### 6.2 长期记忆无用户隔离

**文件**: `storage/database.py` 第 55-109 行
**代码**:
```sql
CREATE TABLE IF NOT EXISTS user_facts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    fact_key TEXT NOT NULL,
    fact_value TEXT NOT NULL,
    ...
);
```

**问题描述**:
所有数据表（`user_facts`、`experiences`、`reflections`、`relationship_metrics`、`conversation_turns`）都没有 `user_id` 或 `session_id` 字段。这意味着：

- 所有会话共享同一个长期记忆池
- User A 的个人信息可能被 User B 的会话检索到
- 关系指标（trust、familiarity、intimacy）是全局的，不针对特定用户

**风险评级**: **Critical**

**修复建议**:
1. 为所有核心表添加 `user_id` 字段
2. 在 `Repository` 的所有查询方法中添加 `WHERE user_id = ?` 过滤
3. 考虑为每个用户创建独立的数据库文件（SQLite 支持 ATTACH DATABASE）

---

#### 6.3 无会话级别的资源配额

**文件**: `config.py` 第 19-28 行
**代码**:
```python
short_term_capacity: int = 500
consolidation_interval: int = 5
max_facts: int = 200
max_experiences: int = 100
max_reflections: int = 50
```

**问题描述**:
所有配额配置都是全局的，没有会话级别的限制：
- 一个恶意用户可以通过大量对话快速填满全局记忆上限
- 没有每用户的 API 调用配额
- 没有每用户的存储空间限制

**风险评级**: **Medium**

**修复建议**:
1. 引入每用户的配额配置
2. 实现存储空间监控和告警
3. 为高频用户自动降级（减少记忆保留量、降低 API 调用频率）

---

### 7. 多模型切换支持

#### 7.1 Provider 类硬编码为 KimiProvider

**文件**: `core/provider.py` 第 11 行 / `web/session.py` 第 40 行
**代码**:
```python
# core/provider.py
class KimiProvider:
    def __init__(self, endpoint: str, api_key: str, model: str, ...):

# web/session.py
self.provider = KimiProvider(
    endpoint=config.api_endpoint, api_key=config.api_key,
    model=config.api_model, ...
)
```

**问题描述**:
项目中只有一个 `KimiProvider` 类，硬编码了对 DeepSeek API 的调用格式。若要支持多模型切换（如同时支持 DeepSeek、OpenAI、Anthropic、本地模型），需要：

- 修改所有引用 `KimiProvider` 的代码
- 每个 Provider 的 API 格式不同（messages 格式、stream 格式、response_format 支持等）
- 没有统一的 Provider 接口抽象

**风险评级**: **High**

**修复建议**:
1. 定义统一的 `LLMProvider` 抽象接口：
   ```python
   from abc import ABC, abstractmethod
   class LLMProvider(ABC):
       @abstractmethod
       async def generate(self, messages: list[dict], **kwargs) -> str: ...
       @abstractmethod
       def estimate_tokens(self, text: str) -> int: ...
   ```
2. 实现 `DeepSeekProvider`、`OpenAIProvider`、`AnthropicProvider` 等具体类
3. 在配置中支持模型路由规则（如"Agent 1 使用轻量级模型，Agent 3 使用主力模型"）

---

#### 7.2 模型配置全局唯一

**文件**: `config.py` 第 13 行
**代码**:
```python
api_model: str = "deepseek-v4-flash"
```

**问题描述**:
整个系统只能配置一个模型。不同 Agent 阶段对模型的需求不同：
- Agent 1（决策）: 需要快速、低成本，适合轻量级模型（如 deepseek-v4-flash）
- Agent 2（工具执行）: 需要结构化输出能力，适合支持 JSON schema 的模型
- Agent 3（对话生成）: 需要高质量、长上下文，适合主力模型
- 记忆固化: 可以容忍延迟，使用最便宜的模型

**风险评级**: **Medium**

**修复建议**:
1. 将 `api_model` 拆分为多个配置项：`agent1_model`、`agent2_model`、`agent3_model`、`consolidation_model`
2. 或引入模型路由配置，根据任务类型自动选择模型

---

#### 7.3 无模型降级机制

**问题描述**:
当主模型不可用时（API 故障、速率限制、网络问题），系统没有自动降级到备用模型的机制。`KimiProvider.generate()` 在 3 次重试后抛出 `ConnectionError`，导致整个请求失败。

**风险评级**: **Medium**

**修复建议**:
1. 实现模型健康检查（定期 ping）
2. 主模型失败时自动切换到备用模型
3. 本地模型（如 llama-server）作为最终 fallback

---

### 8. 水平扩展可行性

#### 8.1 状态全部保存在进程内存

**问题描述**:
如前所述，所有会话状态、情绪状态、短期记忆、工具历史等都保存在 Python 进程的内存中。这导致：

- **无法水平扩展**: 增加服务器节点无法分担负载，因为状态不共享
- **单点故障**: 进程崩溃后所有会话状态丢失
- **无法滚动更新**: 部署新版本时必须中断所有会话

**风险评级**: **Critical**

**扩展架构对比**:

```
当前架构（单进程）:
┌─────────────────────────────────────┐
│  Uvicorn + FastAPI                  │
│  ├─ SessionManager (内存)           │
│  ├─ 50 × WebAgent (内存)            │
│  ├─ SQLite (本地文件)               │
│  └─ DeepSeek API (远程)             │
└─────────────────────────────────────┘

目标架构（水平扩展）:
┌─────────┐  ┌─────────┐  ┌─────────┐
│ Web Pod │  │ Web Pod │  │ Web Pod │
│ (无状态) │  │ (无状态) │  │ (无状态) │
└────┬────┘  └────┬────┘  └────┬────┘
     └─────────────┼─────────────┘
                   ▼
        ┌─────────────────────┐
        │   Redis (会话状态)   │
        └─────────────────────┘
                   ▼
        ┌─────────────────────┐
        │ PostgreSQL + pgvector│
        │   (长期记忆)         │
        └─────────────────────┘
                   ▼
        ┌─────────────────────┐
        │   API Gateway       │
        │  (配额/路由/熔断)    │
        └─────────────────────┘
```

**修复建议**:
1. 将会话状态外置到 Redis
2. 将长期记忆迁移到 PostgreSQL + pgvector
3. Web 层完全无状态化，支持任意数量的 Pod
4. 使用 Kubernetes HPA 根据负载自动扩缩容

---

#### 8.2 无服务发现与负载均衡

**问题描述**:
当前架构没有服务发现机制。如果部署多个实例：
- 没有负载均衡器分发请求
- 没有健康检查剔除故障节点
- 没有会话粘性确保同一用户路由到同一实例

**风险评级**: **Medium**

**修复建议**:
1. 使用 Nginx 或 Traefik 作为反向代理
2. 配置会话粘性（sticky session）
3. 或将会话状态外置，使任意实例都可处理任意请求

---

#### 8.3 无容器化与编排支持

**问题描述**:
项目中没有 Dockerfile、docker-compose.yml 或 Kubernetes 配置。部署依赖手动安装 Python 依赖、手动启动进程。

**风险评级**: **Low**

**修复建议**:
1. 添加 Dockerfile 和 docker-compose.yml
2. 添加 Kubernetes Deployment 和 Service 配置
3. 使用 Helm Chart 管理配置

---

### 9. 长期数据增长的影响

#### 9.1 无数据归档策略

**文件**: `storage/repository.py` 第 241-295 行
**代码**:
```python
async def prune_facts(self, max_count: int) -> int:
    await c.execute("""
        UPDATE user_facts SET is_active = 0, composite_score = 0
        WHERE id IN (
            SELECT id FROM user_facts WHERE is_active = 1
            ORDER BY composite_score ASC, recall_count ASC
            LIMIT ?
        )
    """, (excess,))
```

**问题描述**:
当前的"剪枝"机制只是将记录标记为 `is_active=0` 或 `is_archived=1`，并没有真正删除数据。长期运行后：
- `user_facts` 表可能积累数万条已归档记录
- `conversation_turns` 表无上限增长（每轮对话 2 条记录）
- 数据库文件大小持续膨胀

**风险评级**: **High**

**数据增长估算**:
| 表 | 单条大小 | 日增长（100 轮对话） | 年增长 |
|---|---------|-------------------|--------|
| conversation_turns | ~2KB | 200KB | ~73MB |
| user_facts | ~1KB | 10-50KB | ~18MB |
| experiences | ~2KB | 5-20KB | ~7MB |
| reflections | ~1KB | 5-20KB | ~7MB |
| **总计** | | **~220-290KB/日** | **~105MB/年** |

虽然年增长 105MB 不算巨大，但这是单用户数据。若支持 1000 用户：
- 年增长：**105GB**
- 对话记录表：73GB（无上限增长）

**修复建议**:
1. 实现数据归档策略：将超过 1 年的对话记录迁移到归档表或外部存储
2. 定期清理已归档的 facts、experiences、reflections
3. 为 `conversation_turns` 添加保留策略（如保留最近 1000 轮）

---

#### 9.2 嵌入向量 BLOB 导致数据库膨胀

**文件**: `storage/database.py` 第 122-127 行
**代码**:
```sql
ALTER TABLE user_facts ADD COLUMN embedding BLOB NULL;
ALTER TABLE experiences ADD COLUMN embedding BLOB NULL;
ALTER TABLE reflections ADD COLUMN embedding BLOB NULL;
```

**问题描述**:
每条记录的 embedding 为 512 维 float32 向量，占用 2KB。以 `user_facts` 上限 200 条计算：
- 200 × 2KB = 400KB
- 若扩展到 10000 条：10000 × 2KB = 20MB

虽然单表 20MB 不算大，但：
- 每次查询需要反序列化 BLOB 为 ndarray，CPU 开销随数据量增长
- SQLite 的 BLOB 存储不如专用向量数据库高效
- 无法利用近似最近邻（ANN）索引加速搜索

**风险评级**: **Medium**

**修复建议**:
1. 评估迁移到 `sqlite-vec` 扩展，提供原生向量索引
2. 或引入 FAISS 内存索引，将向量加载到内存中做 ANN 搜索
3. 长期考虑专用向量数据库（Milvus Lite、Chroma、pgvector）

---

#### 9.3 无数据库分片或分区策略

**问题描述**:
所有数据存储在单个 SQLite 文件中。当数据量增长到一定规模时：
- 查询性能下降（即使建立了索引，大表的操作开销也会增加）
- 备份和恢复时间增长
- 无法将热数据和冷数据分离存储

**风险评级**: **Medium**

**修复建议**:
1. 短期：按时间分区 `conversation_turns` 表（如每月一个表）
2. 中期：按用户分片，每个用户独立的数据库文件
3. 长期：迁移到支持自动分片的分布式数据库

---

#### 9.4 无监控与告警机制

**问题描述**:
项目中没有任何性能监控、日志聚合或告警机制。在扩展场景下：
- 无法及时发现数据库查询变慢
- 无法监控 API 调用成功率和延迟
- 无法追踪内存使用和会话数量
- 无法设置自动扩容触发条件

**风险评级**: **Low**

**修复建议**:
1. 引入 Prometheus + Grafana 监控体系
2. 暴露关键指标：活跃会话数、API 延迟、数据库查询时间、内存使用
3. 配置告警规则：API 错误率 > 5%、内存使用 > 80%、活跃会话 > 40

---

## 汇总统计

### 风险分布汇总表

| 序号 | 问题类别 | 风险等级 | 影响范围 | 文件位置 | 扩展限制 |
|-----|---------|---------|---------|---------|---------|
| 1.1 | 全局唯一的 SessionManager 实例 | Critical | Web 模式 | web/server.py:17-18 | 无法多进程部署 |
| 1.2 | WebAgent 重量级对象无法序列化 | High | Web 模式 | web/session.py:27-119 | 无法分布式存储会话 |
| 1.3 | 全局配置对象无热更新机制 | Medium | 所有模式 | config.py:48-78 | 无法动态调参 |
| 2.1 | 单连接 + 全局 Lock 串行化 | Critical | Web 模式 | storage/database.py:11-45 | 并发 < 10 QPS |
| 2.2 | WAL 模式配置不完整 | High | 所有模式 | storage/database.py:21-22 | 写性能降低 50% |
| 2.3 | 数据库文件本地存储 | High | 所有模式 | config.py:18 | 无法多机共享 |
| 3.1 | KimiProvider 单 Session | High | 所有模式 | core/provider.py:11-35 | 连接池耗尽 |
| 3.2 | 同步 requests 阻塞事件循环 | Critical | Web 模式 | core/provider.py:82-134 | 并发 < 16 |
| 3.3 | 无全局 API 配额管理 | High | Web 模式 | web/session.py:121-175 | 配额耗尽风险 |
| 4.1 | cleanup_old 硬编码上限 50 | Critical | Web 模式 | web/session.py:169-174 | 内存会话上限 50 |
| 4.2 | WebAgent 每会话独立创建对象 | High | Web 模式 | web/session.py:28-80 | 内存占用线性增长 |
| 5.1 | _MODEL_CONTEXT 硬编码 180K | Medium | 所有模式 | core/context_manager.py:7-8 | 压缩机制失效 |
| 5.2 | 短期记忆 maxlen 配置不一致 | Medium | 所有模式 | memory/short_term.py:15 | 内存浪费 |
| 5.3 | _react_loop messages 持续增长 | High | 所有模式 | core/agent.py:119-181 | 上下文爆炸 |
| 6.1 | 无用户身份隔离机制 | Critical | Web 模式 | web/session.py:136-144 | 无法多用户 |
| 6.2 | 长期记忆无用户隔离 | Critical | 所有模式 | storage/database.py:55-109 | 数据泄露风险 |
| 6.3 | 无会话级别资源配额 | Medium | Web 模式 | config.py:19-28 | 资源滥用风险 |
| 7.1 | Provider 硬编码为 KimiProvider | High | 所有模式 | core/provider.py:11 | 无法多模型 |
| 7.2 | 模型配置全局唯一 | Medium | 所有模式 | config.py:13 | 无法模型路由 |
| 7.3 | 无模型降级机制 | Medium | 所有模式 | core/provider.py:57-80 | 单点故障 |
| 8.1 | 状态全部保存在进程内存 | Critical | Web 模式 | 全局 | 无法水平扩展 |
| 8.2 | 无服务发现与负载均衡 | Medium | Web 模式 | 全局 | 无法多实例 |
| 8.3 | 无容器化与编排支持 | Low | 部署 | 全局 | 手动部署 |
| 9.1 | 无数据归档策略 | High | 所有模式 | storage/repository.py:241-295 | 数据库无限膨胀 |
| 9.2 | 嵌入向量 BLOB 导致膨胀 | Medium | 所有模式 | storage/database.py:122-127 | 查询性能下降 |
| 9.3 | 无数据库分片或分区 | Medium | 所有模式 | 全局 | 大表性能下降 |
| 9.4 | 无监控与告警机制 | Low | 运维 | 全局 | 运维盲区 |

### 扩展能力矩阵

| 扩展维度 | 当前上限 | 瓶颈 | 优化后上限 | 所需改动 |
|---------|---------|------|----------|---------|
| 并发 Web 会话 | 50 | 内存 + 数据库锁 | 500+ | 共享 Provider + 连接池 |
| 单进程并发 API 调用 | 8-16 | 线程池大小 | 100+ | 异步 Provider |
| 数据库 QPS | 20-50 | 单连接串行 | 500+ | 读写分离 + 连接池 |
| 长期记忆 facts | 200（配置） | 无索引全表扫描 | 10000+ | 索引 + FTS5 |
| 用户数 | 1（无隔离） | 数据模型 | 1000+ | user_id 字段 |
| 数据量 | ~1GB | SQLite 单文件 | 100GB+ | PostgreSQL / 分片 |
| 水平扩展节点数 | 1 | 进程内存状态 | 10+ | Redis + 无状态化 |
| 模型切换 | 1 | 硬编码 Provider | 任意 | 抽象接口 + 路由 |

### 架构演进路线图

```
阶段 0（当前）: 单进程 + SQLite + 单模型
    ├─ 适用场景: 个人使用、本地部署
    └─ 上限: 1 用户、50 会话、1GB 数据

阶段 1（短期优化）: 单进程优化
    ├─ 共享 Provider / EmbeddingEngine / ToolRegistry
    ├─ SQLite 读写分离 + 连接池
    ├─ 异步 Provider（aiohttp）
    ├─ 索引优化 + WAL 配置
    └─ 上限: 1 用户、200 会话、5GB 数据

阶段 2（中期扩展）: 多用户 + 数据隔离
    ├─ 用户身份认证
    ├─ 数据表添加 user_id
    ├─ 每用户配额管理
    ├─ 数据归档策略
    └─ 上限: 100 用户、100 会话/用户、50GB 数据

阶段 3（长期演进）: 水平扩展
    ├─ Redis 会话状态
    ├─ PostgreSQL + pgvector 长期记忆
    ├─ API Gateway（配额/路由/熔断）
    ├─ 容器化 + Kubernetes
    ├─ 多模型动态路由
    └─ 上限: 10000+ 用户、无单点瓶颈
```

### 关键修复优先级

**P0（立即修复 — 阻塞任何扩展）**:
1. 为所有数据表添加 `user_id` 字段，实现用户隔离
2. 将 `KimiProvider` 改为异步实现（aiohttp/httpx）
3. 实现 SQLite 读写分离连接池
4. 将 `KimiProvider`、`EmbeddingEngine`、`ToolRegistry` 改为进程级单例

**P1（短期修复 — 显著提升扩展能力）**:
5. 为 `SessionManager` 添加 TTL 和自动清理机制
6. 实现全局 API 调用配额管理和速率限制
7. 优化 WAL 模式 PRAGMA 配置
8. 为数据库核心表建立复合索引
9. 定义统一的 `LLMProvider` 抽象接口

**P2（中期优化 — 架构级改进）**:
10. 将会话状态外置到 Redis
11. 将长期记忆迁移到 PostgreSQL + pgvector
12. 实现数据归档和清理策略
13. 添加容器化和 Kubernetes 支持
14. 引入监控和告警体系

**P3（长期演进）**:
15. 实现多模型动态路由和降级
16. 数据库分片或按用户隔离
17. 使用 CDN 加速静态资源
18. 引入边缘计算节点降低延迟

---

*本报告由 Claude Code 自动生成，基于对代码的静态分析。实际扩展上限可能因运行环境、硬件配置、网络条件等因素有所不同。建议通过负载测试（如 Locust、k6）进行实际验证。*
