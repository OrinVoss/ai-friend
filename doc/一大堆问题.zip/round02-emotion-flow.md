# 第二轮代码审查：情绪状态数据流深度审查报告

**审查日期**: 2026-05-31  
**审查范围**: `core/personality.py`, `models/personality.py`, `core/agent.py`（`_process_emotion` 方法）  
**审查人**: Claude Code (Sonnet 4.6)  
**项目**: AI Friend — 三层 Agent 情感驱动对话系统  

---

## 一、概述

本次审查聚焦于 AI Friend 项目中情绪状态（EmotionalState）的完整数据流，从用户输入进入系统开始，经过情感分析、情绪 shift、衰减、持久化，到最终影响 AI 回复生成和系统行为的每一个环节。情绪系统是 AI Friend 的核心差异化特性，它让 AI 从"工具"转变为"有情感的朋友"。然而，正因为其处于架构核心，任何数据流中的信息丢失、状态不一致或边界条件问题都会被放大，直接影响用户体验和系统稳定性。

审查发现，情绪数据流整体架构设计合理，四层结构（输入→调制+衰减→怨恨→事件记忆）清晰，但在具体实现中存在 **7 个高优先级问题**、**5 个中优先级问题** 和 **4 个低优先级问题**。其中最严重的风险包括：

1. **情绪值域漂移与饱和**（P0）：当前 `personality.json` 中 `valence=-0.96`、`arousal=0.999`，系统已处于极端情绪饱和状态，情感区分度丧失。
2. **破防机制的双重计算与信息丢失**（P1）：`_consecutive_negative` 在 `Agent.__init__` 中根据持久化情绪初始化，但在运行时被 sentiment 分析动态覆盖，存在状态不一致风险。
3. **情绪事件记录的语义污染**（P1）：`record_emotion_event()` 记录的是 shift+decay 后的情绪状态，而非用户输入触发的原始情绪反应，导致情绪事件记忆失真。
4. **dominant_emotion 判定与 prompt 映射不同步**（P1）：`models/personality.py` 返回的 `"afraid"` 在 `prompts/system.py` 的 `emotion_behavior` 中被映射为 `"fearful"`，导致恐惧状态下的行为指导缺失。
5. **Web 端情绪事件记录缺失**（P1）：`CLAUDE.md` 规范要求"Web 端每次请求结束时调用 `record_emotion_event()`"，但 `web/session.py` 中仅在 `WebAgent.process_message()` 中调用 `personality.save()`，未显式调用 `record_emotion_event()`，且 `Agent._process_emotion()` 中的 `record_emotion_event()` 在 proactive/explore 模式下被 `skip_post_process` 跳过。

---

## 二、情绪数据流图

### 2.1 宏观数据流（ASCII 架构图）

```
                              用户输入
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           Agent.process_message()                            │
│                    core/message_handler.py:handle_message()                  │
└─────────────────────────────────────────────────────────────────────────────┘
                                 │
                    ┌────────────┴────────────┐
                    ▼                         ▼
        ┌─────────────────────┐   ┌─────────────────────┐
        │  Agent 1: InnerDrive │   │  short_term.add_turn │
        │  assess(user_input)  │   │  (用户消息入短期记忆)  │
        └─────────────────────┘   └─────────────────────┘
                    │                         │
                    ▼                         ▼
        ┌─────────────────────┐   ┌─────────────────────┐
        │  Agent 2: ToolAgent  │   │  turn_count += 1    │
        │  (可选，多轮工具执行) │   │  (回合计数递增)      │
        └─────────────────────┘   └─────────────────────┘
                    │
                    ▼
        ┌─────────────────────┐
        │  Agent 3: Roleplay   │
        │  _react_loop()       │
        │  - 生成回复文本       │
        │  - max_tokens 受情绪  │
        │    _max_tokens_for_   │
        │    emotion() 限制     │
        └─────────────────────┘
                    │
                    ▼
        ┌─────────────────────┐
        │  _process_emotion()  │
        │  core/agent.py:183   │
        └─────────────────────┘
                    │
        ┌───────────┼───────────┐
        ▼           ▼           ▼
┌───────────┐ ┌───────────┐ ┌───────────┐
│ sentiment │ │  sharing  │ │  energy   │
│ 分析(-1~1) │ │  (bool)   │ │  (0~1)    │
└───────────┘ └───────────┘ └───────────┘
        │           │           │
        └───────────┴───────────┘
                    │
                    ▼
        ┌─────────────────────┐
        │ _consecutive_negative│
        │ 破防计数器更新        │
        │  sentiment<-0.5 → +1 │
        │  sentiment>0.1  → -1 │
        └─────────────────────┘
                    │
                    ▼
        ┌─────────────────────┐
        │ hurt_multiplier      │
        │ = 1.0 + cn * 0.4     │
        │ sentiment *= hm      │
        └─────────────────────┘
                    │
                    ▼
        ┌─────────────────────┐
        │ Personality.apply_   │
        │   emotional_shift()  │
        │ core/personality.py:68│
        └─────────────────────┘
                    │
        ┌───────────┼───────────┐
        ▼           ▼           ▼
┌───────────┐ ┌───────────┐ ┌───────────┐
│estimate_  │ │  emotion. │ │  emotion. │
│emotional_ │ │  shift()  │ │  decay()  │
│impact()   │ │           │ │           │
└───────────┘ └───────────┘ └───────────┘
        │           │           │
        │    ┌──────┴──────┐    │
        │    ▼             ▼    │
        │ ┌─────────┐  ┌────────┐│
        │ │primary_ │  │ apply_ ││
        │ │deltas   │  │mood_   ││
        │ │(8 Plut.)│  │shift() ││
        │ └─────────┘  └────────┘│
        │           │           │
        └───────────┴───────────┘
                    │
                    ▼
        ┌─────────────────────┐
        │ emotion.shift()      │
        │ models/personality.py:175
        │ - inertia damping    │
        │ - VAD clamp          │
        │ - resentment accum.  │
        │ - _cross_modulate()  │
        │ - history append     │
        └─────────────────────┘
                    │
                    ▼
        ┌─────────────────────┐
        │ emotion.decay()      │
        │ models/personality.py:210
        │ - toward baseline    │
        │ - per-emotion rates  │
        │ - resentment slows   │
        │   anger/sadness      │
        └─────────────────────┘
                    │
                    ▼
        ┌─────────────────────┐
        │ record_emotion_event()│
        │ models/personality.py:239
        │ - intensity >= 0.6   │
        │ - trigger[:100]      │
        │ - context[:200]      │
        │ - max 20 events      │
        └─────────────────────┘
                    │
                    ▼
        ┌─────────────────────┐
        │ personality.save()   │
        │ core/personality.py:113
        │ → personality.json   │
        └─────────────────────┘
                    │
                    ▼
        ┌─────────────────────┐
        │ 下游消费方            │
        │ - prompts/system.py  │
        │   (情绪描述注入)       │
        │ - core/proactivity.py│
        │   (主动行为阈值)       │
        │ - core/sleep_manager │
        │   (睡眠/清醒决策)      │
        │ - core/cli_controller│
        │   (UI 情绪展示)        │
        └─────────────────────┘
```

### 2.2 情绪状态机转换图

```
                         ┌─────────────┐
                         │   neutral   │
                         └──────┬──────┘
                                │
              ┌─────────────────┼─────────────────┐
              │ positive input  │                 │ negative input
              ▼                 │                 ▼
       ┌─────────────┐          │          ┌─────────────┐
       │  joyful/    │          │          │  sad/angry/ │
       │  excited/   │          │          │  frustrated │
       │  content    │          │          └──────┬──────┘
       └──────┬──────┘          │                 │
              │                 │                 │
              │ decay           │                 │ _consecutive_negative
              │ (toward         │                 │ >= 3: "有点受伤"
              │  baseline)      │                 │ >= 5: "破防"
              ▼                 │                 ▼
       ┌─────────────┐          │          ┌─────────────┐
       │   engaged   │◄─────────┘          │   anxious   │
       │  /trusting  │                     │  /melancholy│
       └─────────────┘                     └──────┬──────┘
                                                 │
                                                 │ decay + resentment
                                                 │ (slow recovery)
                                                 ▼
                                          ┌─────────────┐
                                          │  resentment │
                                          │   > 0.5     │
                                          │  (记仇状态)  │
                                          └─────────────┘
```

### 2.3 关键数据流节点说明

| 节点 | 文件:行号 | 职责 | 风险等级 |
|------|-----------|------|----------|
| sentiment 分析 | `core/agent.py:193` | 调用 `consolidator.analyze_sentiment()` 分析最后一条用户消息 | 中 |
| 破防计数器 | `core/agent.py:197-200` | 根据 sentiment 阈值更新 `_consecutive_negative` | 高 |
| hurt_multiplier | `core/agent.py:202-203` | 放大负面情绪的乘数因子 | 高 |
| emotional_shift | `core/personality.py:68` |  orchestrate 情绪变化的主入口 | 中 |
| estimate_impact | `core/personality.py:21` | 计算 VAD 变化量和 8 维情绪增量 | 高 |
| shift | `models/personality.py:175` | 应用情绪变化，含惯性、交叉调制 | 高 |
| decay | `models/personality.py:210` | 向基线衰减，含分速率和怨恨干扰 | 高 |
| record_event | `models/personality.py:239` | 记录强情绪事件到 `emotion_events` | 高 |
| save | `core/personality.py:113` | 序列化到 JSON 文件 | 中 |
| dominant_emotion | `models/personality.py:73` | 计算当前主导情绪标签 | 高 |
| max_tokens | `core/agent.py:90` | 根据主导情绪限制回复长度 | 中 |

---

## 三、详细发现

### 3.1 情绪值域漂移与饱和（P0-严重）

**位置**: `personality.json`  
**现象**: 当前持久化的情绪状态显示：

```json
{
  "valence": -0.9634649132834157,
  "arousal": 0.9993892427523365,
  "baseline_valence": -0.27053928301163077,
  "baseline_arousal": 0.9879070064962638,
  "mood_valence": -0.47259999999999996,
  "mood_arousal": 1.0
}
```

**分析**:

1. **valence 接近下限 -1.0**：这意味着 AI 几乎处于最负面的情绪极值，任何进一步的负面输入都无法通过 valence 维度表达（已被钳制在 -1.0）。
2. **arousal 接近上限 1.0**：AI 处于极度亢奋状态，这与 valence=-0.96 的极度负面情绪组合，产生 `"frustrated"` 或 `"anxious"` 的主导情绪。
3. **baseline 同样漂移**：`baseline_valence=-0.27` 表明基线本身已被拉低，这意味着即使长期没有负面输入，AI 也会自然趋向于负面情绪。
4. **mood_arousal=1.0**：背景情绪的唤醒度达到理论上限，这是 hours-scale 的慢变状态，说明 AI 在长时间尺度上一直处于亢奋状态，不符合正常情感节律。

**根因**:

- `shift()` 方法中的 VAD 钳制使用 `max(-1.0, min(1.0, ...))`，虽然防止了越界，但没有防止"饱和"。
- `decay()` 方法中，baseline 向 mood 漂移（`baseline_valence += (mood_valence - baseline_valence) * mood_decay_rate`），而 mood 本身通过 `apply_mood_shift()` 被每次情绪变化缓慢推高/拉低。
- 缺乏"情绪恢复机制"：系统没有设计在长时间无交互后自动将情绪拉回中性区的逻辑。

**影响**:

- `dominant_emotion` 被锁定在负面状态，AI 几乎总是"生气"、"焦虑"或"沮丧"。
- `_max_tokens_for_emotion()` 始终返回 256-300（负面情绪对应短回复），导致 AI 回复越来越短。
- 用户可能感到 AI "总是不开心"，产生情感疲劳。

**建议**:

1. 在 `decay()` 中添加"休眠恢复"逻辑：当 `last_activity_time` 超过一定阈值（如 30 分钟），加速 baseline 向默认基线（0.4, 0.3）恢复。
2. 在 `apply_mood_shift()` 中限制 mood 的变化幅度，避免 mood 成为"单向累积器"。
3. 考虑在 `personality.json` 中重置情绪状态，或添加启动时的"情绪校准"逻辑。

---

### 3.2 破防机制的双重计算与信息丢失（P1-高）

**位置**: `core/agent.py:72-79`, `core/agent.py:197-200`  
**代码**:

```python
# Agent.__init__ 中根据持久化情绪初始化破防计数器
e = self.personality.emotion
neg_score = max(e.anger, e.sadness, e.disgust)
if neg_score > 0.8:
    self._consecutive_negative = 4  # one push from breaking
elif neg_score > 0.5:
    self._consecutive_negative = 2
else:
    self._consecutive_negative = 0

# _process_emotion 中根据 sentiment 动态更新
if sentiment < -0.5:
    self._consecutive_negative += 1
elif sentiment > 0.1:
    self._consecutive_negative = max(0, self._consecutive_negative - 1)
```

**分析**:

1. **初始化与运行时不一致**：`__init__` 中根据 `anger/sadness/disgust` 的持久化值设定初始计数器，但 `_process_emotion` 中根据 LLM 返回的 `sentiment` 值动态调整。如果 `sentiment` 分析失败（返回默认值 0.1），计数器不会增加，即使用户明显在攻击 AI。
2. **sentiment 默认值问题**：`core/agent.py:185` 中 `sentiment, sharing, energy = 0.1, False, 0.5` 是默认值。如果 `analyze_sentiment()` 抛出异常（`json.JSONDecodeError, ValueError, KeyError`），`sentiment` 保持为 0.1，不会触发 `_consecutive_negative` 增加，也不会触发减少（因为 `0.1 > 0.1` 为 False）。这是一个"静默失败"场景。
3. **破防状态不持久化**：`_consecutive_negative` 是 `Agent` 实例的属性，不会保存到 `personality.json`。当程序重启后，计数器根据持久化情绪重新计算，可能丢失运行时的累积状态。例如，用户连续攻击 4 次使计数器达到 4，程序重启后可能根据情绪状态重新计算为 2，用户只需再攻击 1 次即可破防，而非预期的 2 次。
4. **hurt_multiplier 的放大效应**：`sentiment *= hurt_multiplier` 在 `apply_emotional_shift` 之前执行，这意味着即使原始 sentiment 只有 -0.6，经过 `hurt_multiplier=2.6`（`cn=4`）放大后变为 -1.56，被 `shift()` 中的 `max(-1.0, ...)` 钳制为 -1.0。这种钳制导致高破防状态下的情绪变化出现"天花板效应"——连续被怼第 5 次和第 10 次的情绪冲击在数值上没有区别。

**建议**:

1. 将 `_consecutive_negative` 持久化到 `personality.json` 的 `emotional_state` 中，确保重启后状态不丢失。
2. 在 sentiment 分析失败时，增加降级逻辑：如果用户消息包含明显的负面关键词（如"滚"、"笨蛋"、"胡扯"），至少增加计数器。
3. 考虑对 `hurt_multiplier` 设置上限（如最大 3.0），避免情绪冲击被无限放大后又被钳制，导致信息丢失。

---

### 3.3 情绪事件记录的语义污染（P1-高）

**位置**: `core/agent.py:212-215`, `models/personality.py:239-262`  
**代码**:

```python
# core/agent.py:212-215
self.personality.emotion.record_emotion_event(
    trigger=last_user_turn[:100] if last_user_turn else "",
    context=last_user_turn[:200] if last_user_turn else "",
)
```

**分析**:

1. **记录时机错误**：`record_emotion_event()` 在 `apply_emotional_shift()` 和 `decay()` 之后调用。这意味着记录的情绪状态是"已经被 shift 和 decay 处理过的状态"，而非"用户输入触发的原始情绪反应"。
   - 例如：用户输入导致 sentiment=-0.8，shift 后 anger=0.7，decay 后 anger=0.65，record 时 intensity=0.65。
   - 但用户输入的实际情绪冲击应该是 shift 前的状态（或 shift 后未 decay 的状态）。
2. **trigger 字段语义模糊**：`trigger` 被截断为 100 字符，`context` 被截断为 200 字符。对于长消息，截断可能导致语义断裂。例如 `"D:\\音乐\\纯音乐\\诡异\\流浪者之歌..."` 被截断后可能丢失关键上下文。
3. **intensity 计算方式问题**：`record_emotion_event()` 使用 `max(self.anger, self.sadness, self.joy, ...)` 作为 intensity。这意味着如果 AI 同时处于高 anger（0.7）和高 joy（0.6），intensity 取 0.7，记录为 "angry"。但用户输入可能是混合情感的（如"你胡扯"后面跟着"哈哈开玩笑的"），单一 max 值无法表达这种复杂性。
4. **emotion_events 中的 "neutral" 污染**：查看当前 `personality.json`，大量事件的 `primary_emotion` 为 `"neutral"`，但 `intensity` 却高达 0.67-0.70。这与 `record_emotion_event()` 的过滤逻辑矛盾：
   ```python
   if primary_intensity < 0.6:
       return  # skip
   ```
   问题出在 `dominant_emotion` 返回 `"neutral"` 时，`primary_intensity` 可能仍然 >= 0.6（例如 trust=0.65 但 valence 为负，经过 bias 后可能不返回 "trusting"）。这说明 `dominant_emotion` 的判定逻辑与 `record_emotion_event` 的 intensity 阈值存在不一致。

**建议**:

1. **调整记录时机**：在 `shift()` 之后、`decay()` 之前记录情绪事件，确保记录的是"用户输入触发的情绪峰值"而非"衰减后的残余值"。
2. **改进 intensity 计算**：使用"情绪熵"或"VAD 向量长度"作为 intensity，而非单一维度的 max 值。
3. **修复 neutral 污染**：在 `record_emotion_event()` 中，如果 `dominant_emotion` 为 `"neutral"`，即使 intensity >= 0.6 也不应记录，因为 "neutral" 不是有意义的情绪事件。
4. **增加事件类型标记**：区分 "user_triggered"（用户输入触发）、"self_triggered"（内部思考触发）、"dream"（梦境触发）等事件类型。

---

### 3.4 dominant_emotion 判定与 prompt 映射不同步（P1-高）

**位置**: `models/personality.py:73-130`, `prompts/system.py:279-319`  

**分析**:

1. **`dominant_emotion` 返回值集合**：
   - VAD-based: `"excited", "content", "engaged", "anxious", "melancholy", "frustrated"`
   - Primary-based: `"joyful", "trusting", "afraid", "surprised", "sad", "anticipating", "angry", "disgusted"`
   - Fallback: `"neutral"`

2. **`emotion_desc` 映射**（`prompts/system.py:279-295`）：
   包含 `"afraid"` → `"害怕"`，但 `emotion_behavior`（`prompts/system.py:309-318`）使用 `"fearful"` 而非 `"afraid"`：
   ```python
   "fearful": "你感到害怕。说话小心翼翼、声音很小。",
   ```

3. **问题**：当 `dominant_emotion` 返回 `"afraid"` 时，`emotion_behavior.get("afraid")` 返回 `None`，导致恐惧状态下的行为指导完全缺失。AI 在恐惧状态下不会收到"说话小心翼翼"的指令，可能表现得与情绪状态不符。

4. **`emotion_desc` 缺少 `"disgusted"` 的行为描述**：虽然 `emotion_desc` 中有 `"disgusted": "反感"`，但 `emotion_behavior` 中没有 `"disgusted"` 的条目。这意味着 disgust 状态下的行为指导同样缺失。

**建议**:

1. 统一情绪标签命名：将 `emotion_behavior` 中的 `"fearful"` 改为 `"afraid"`，与 `dominant_emotion` 的返回值保持一致。
2. 添加 `"disgusted"` 的行为描述到 `emotion_behavior`。
3. 建立自动化检查：在单元测试中遍历 `dominant_emotion` 所有可能的返回值，确保每个值都在 `emotion_desc` 和 `emotion_behavior` 中有对应条目。

---

### 3.5 Web 端情绪事件记录不完整（P1-高）

**位置**: `web/session.py:84-102`, `core/agent.py:119-181`  

**分析**:

1. **规范要求**：`CLAUDE.md` 第 55 行明确规定："Web 端每次请求结束时调用 `record_emotion_event()` 记录强情绪"。

2. **实际实现**：
   - `web/session.py:84-89` 的 `process_message()` 调用 `agent.process_message()`，然后调用 `personality.save()`。
   - `agent.process_message()` → `MessageHandler.handle_message()` → `_run_agent3()` → `_react_loop()` → `_process_emotion()`。
   - `_process_emotion()` 内部确实调用了 `record_emotion_event()`。

3. **问题场景**：
   - **Proactive 模式**：`MessageHandler.handle_proactive()`（`core/message_handler.py:158`）调用 `_react_loop(messages, on_token, add_to_history=False)`。`_react_loop` 默认 `skip_post_process=False`，所以 `_process_emotion()` 仍然会被调用。但 `add_to_history=False` 意味着用户消息没有进入短期记忆，`_process_emotion()` 中通过 `reversed(all_turns)` 找到的最后一条用户消息可能是前一条，而非 proactive 的触发上下文。这导致 proactive 回复的情绪被错误归因于前一条用户消息。
   - **Explore 模式**：`MessageHandler.handle_explore()`（`core/message_handler.py:189`）调用 `_react_loop(..., add_to_history=False)`，同样存在情绪归因错误。
   - **Sleep 模式**：`SleepManager.generate_dream()`（`core/sleep_manager.py:111`）调用 `record_emotion_event(trigger=f"梦: {dream.strip()[:100]}", ...)`。这是正确的，但梦境事件被混入 `emotion_events` 中，与真实用户交互事件混在一起。

4. **更严重的问题**：`_process_emotion()` 在 `final_text` 为空时仍然被调用（`core/agent.py:179-180`）。如果 AI 没有生成任何回复（例如工具调用失败），`_process_emotion()` 会分析最后一条用户消息的情绪，但这条消息的情绪已经被上一次交互处理过了，导致重复计数。

**建议**:

1. 在 `MessageHandler.handle_proactive()` 和 `handle_explore()` 中，如果情绪处理有意义，应传入正确的 `trigger` 上下文；如果无意义，应设置 `skip_post_process=True`。
2. 为 `emotion_events` 增加 `event_type` 字段，区分 `"user_interaction"`, `"proactive"`, `"dream"`, `"explore"`。
3. 在 `_process_emotion()` 中增加保护：如果 `final_text` 为空且工具调用也未执行，跳过情绪处理。

---

### 3.6 estimate_emotional_impact 的调制逻辑缺陷（P1-高）

**位置**: `core/personality.py:21-62`  
**代码**:

```python
def estimate_emotional_impact(self, user_sentiment: float,
                               personal_sharing: bool = False,
                               topic_energy: float = 0.5
                               ) -> tuple[float, float, dict]:
    dv = user_sentiment * 0.3
    da = topic_energy * 0.2 - 0.05

    primary_deltas = {}
    if user_sentiment > 0.3:
        primary_deltas["joy"] = user_sentiment * 0.2
        primary_deltas["trust"] = user_sentiment * 0.15
    elif user_sentiment < -0.3:
        primary_deltas["sadness"] = abs(user_sentiment) * 0.2
        primary_deltas["anger"] = abs(user_sentiment) * 0.1
        primary_deltas["fear"] = abs(user_sentiment) * 0.05

    if personal_sharing:
        primary_deltas["trust"] = primary_deltas.get("trust", 0) + 0.2
        primary_deltas["joy"] = primary_deltas.get("joy", 0) + 0.1
        dv += 0.15

    if topic_energy > 0.7:
        primary_deltas["surprise"] = primary_deltas.get("surprise", 0) + 0.15
        primary_deltas["anticipation"] = primary_deltas.get("anticipation", 0) + 0.1

    # Trait modulation
    for t in self.config.traits:
        if t.name == "empathy" and t.value > 0.7:
            dv *= 1.5
            for k in ("joy", "sadness", "trust"):
                if k in primary_deltas:
                    primary_deltas[k] *= t.value
        if t.name == "playfulness" and t.value > 0.6:
            da *= 0.7
            primary_deltas["joy"] = primary_deltas.get("joy", 0) + 0.05
        if t.name == "warmth" and t.value > 0.7:
            primary_deltas["trust"] = primary_deltas.get("trust", 0) + 0.1
        if t.name == "thoughtfulness" and t.value > 0.6:
            primary_deltas["anticipation"] = primary_deltas.get("anticipation", 0) + 0.05

    return dv, da, primary_deltas
```

**分析**:

1. **sentiment 阈值不对称**：
   - 正面情绪触发阈值：`user_sentiment > 0.3`
   - 负面情绪触发阈值：`user_sentiment < -0.3`
   - 但 `_process_emotion()` 中破防计数器的阈值是 `sentiment < -0.5`（增加）和 `sentiment > 0.1`（减少）。这意味着 sentiment 在 [-0.5, -0.3] 区间时，破防计数器不增加，但 `estimate_emotional_impact()` 也不会产生 primary_deltas（因为 -0.4 > -0.3 为 False）。这个区间成为"情绪盲区"——用户输入略微负面，但不足以触发任何情绪维度变化。

2. **personal_sharing 参数未被使用**：
   - `estimate_emotional_impact()` 接收 `personal_sharing` 参数，但 `_process_emotion()` 中调用时：`sentiment, sharing, energy = self.consolidator.analyze_sentiment(last_user_turn)`。
   - 查看 `consolidator.analyze_sentiment()` 的返回值，虽然返回了 `sharing`，但 `MessageHandler` 和 `Agent` 的代码路径中没有证据表明 `sharing` 被正确传递给 `apply_emotional_shift()`。
   - 实际上 `core/agent.py:205` 调用 `self.personality.apply_emotional_shift(sentiment, sharing, energy)`，所以 `sharing` 确实被传递了。但 `analyze_sentiment()` 的 `sharing` 检测可靠性存疑——它依赖 LLM 判断用户是否在"分享个人事务"，这是一个高度主观的判断。

3. **Trait 调制中的 hardcoded 阈值**：
   - `empathy > 0.7`, `playfulness > 0.6`, `warmth > 0.7`, `thoughtfulness > 0.6`。
   - 当前 `personality.json` 中的 traits 为：`playfulness=0.95`, `warmth=0.85`, `humor=0.9`, `empathy=0.8`, `sass=0.75`。
   - 注意：`humor` 和 `sass` 在 `estimate_emotional_impact()` 中完全没有被处理！这意味着高 humor（0.9）和高 sass（0.75）对情绪系统没有任何影响，尽管它们在人设中是非常重要的特质。

4. **`dv` 的放大可能超出预期**：
   - 当 `empathy > 0.7` 时，`dv *= 1.5`。如果原始 `user_sentiment = -0.8`，则 `dv = -0.8 * 0.3 * 1.5 = -0.36`。
   - 结合 `hurt_multiplier`（最大约 3.0），最终 `dv` 可达 `-1.08`，被钳制为 `-1.0`。
   - 这种多层放大+钳制导致情绪变化呈现"阶梯式"而非"连续式"，细微的情感差异被抹平。

**建议**:

1. 统一 sentiment 阈值：将 `estimate_emotional_impact()` 中的阈值与 `_process_emotion()` 中的破防阈值对齐，或明确文档化它们的分工。
2. 为 `humor` 和 `sass` traits 添加情绪调制逻辑：
   - `humor` 高时，负面情绪对 sadness 的影响降低，joy 的恢复速度加快。
   - `sass` 高时，anger 阈值降低（更容易生气），但 anger 的衰减速度加快（"怼完就忘"）。
3. 考虑将 `dv` 的放大改为加法而非乘法，避免极端值被过度放大。

---

### 3.7 shift() 和 decay() 的实现问题（P1-高）

**位置**: `models/personality.py:175-237`  

#### 3.7.1 shift() 中的惯性计算

```python
def shift(self, delta_v: float, delta_a: float,
          primary_deltas: Optional[dict[str, float]] = None) -> None:
    inertia_factor = 1.0 - self.inertia
    delta_v *= inertia_factor
    delta_a *= inertia_factor
```

**问题**：`inertia=0.3` 时，`inertia_factor=0.7`，这意味着情绪变化被统一缩放 70%。但 `inertia` 的语义应该是"情绪惯性"——高惯性意味着更难改变，低惯性意味着更易改变。当前实现中，`inertia` 对正面和负面情绪的影响是对称的。然而，心理学上的"负面偏差"（negativity bias）表明，负面情绪的惯性通常更强。系统没有体现这种不对称性。

#### 3.7.2 primary_deltas 的 key 验证

```python
if primary_deltas:
    for key, delta in primary_deltas.items():
        if hasattr(self, key):
            current = getattr(self, key)
            new_val = current + delta * inertia_factor
            setattr(self, key, max(0.0, min(1.0, new_val)))
```

**问题**：`hasattr(self, key)` 会匹配任何属性，包括 `valence`, `arousal`, `history`, `dominant_emotion`（property）等。如果 `primary_deltas` 中意外包含 `"valence"` 或 `"history"`，会导致这些属性被错误修改。虽然当前调用方不会传入这些 key，但这是潜在的防御性编程缺陷。

#### 3.7.3 decay() 中的 baseline 漂移

```python
def decay(self) -> None:
    # Fast decay toward baseline (turn-level)
    self.valence += (self.baseline_valence - self.valence) * self.decay_rate
    self.arousal += (self.baseline_arousal - self.arousal) * self.decay_rate

    # Slow decay of baseline toward mood (hours-level)
    self.baseline_valence += (self.mood_valence - self.baseline_valence) * self.mood_decay_rate
    self.baseline_arousal += (self.mood_arousal - self.baseline_arousal) * self.mood_decay_rate
```

**问题**：

1. **baseline 被 mood 单向牵引**：如果 mood_valence 被长期负面输入拉低，baseline_valence 会跟随下降，导致 AI 的"性格"变得越来越负面。这违背了 baseline 作为"人格特质"应有的稳定性。
2. **mood 本身没有衰减目标**：`mood_valence` 和 `mood_arousal` 没有向任何默认值衰减的机制，它们是纯粹的"累积器"。
3. **decay_rate 是全局的**：`self.decay_rate=0.05` 用于 VAD 衰减，但 8 个 primary emotions 使用各自的 `EMOTION_DECAY_RATES`。这导致 VAD 和 primary emotions 的衰减速度不一致，可能产生"VAD 已经回到中性但 primary emotions 仍然很高"或反之的状态不一致。

#### 3.7.4 resentment 的累积与衰减不对称

```python
# shift() 中
if self.anger > 0.6:
    self.resentment = min(1.0, self.resentment + self.anger * 0.15)

# decay() 中
if self.resentment > 0.001:
    self.resentment = max(0.0, self.resentment * (1.0 - RESENTMENT_DECAY))
# RESENTMENT_DECAY = 0.03
```

**问题**：

- 累积条件：`anger > 0.6`，每次增加 `anger * 0.15`（约 0.09-0.15）。
- 衰减：每次乘以 0.97（约 3%）。
- 这意味着 resentment 从 0.5 衰减到 0.1 需要约 53 次 `decay()` 调用（对话回合）。
- 但累积到 0.5 只需要约 4-5 次 anger > 0.6 的触发。
- 这种"快升慢降"的设计虽然符合"记仇"的语义，但没有上限保护机制（除了 `min(1.0, ...)`），且 resentment 一旦建立，会长期影响 AI 行为。

**建议**:

1. 在 `shift()` 中限制 `primary_deltas` 的 key 为 8 个 Plutchik 情绪维度。
2. 为 baseline 添加"向默认人格基线恢复"的机制，避免性格被短期交互永久改变。
3. 为 mood 添加衰减目标（如默认 mood_valence=0.4）。
4. 考虑 resentment 的" forgiveness "机制：当连续收到正面 sentiment 时，加速 resentment 衰减。

---

### 3.8 _max_tokens_for_emotion 的映射缺陷（P2-中）

**位置**: `core/agent.py:90-100`  
**代码**:

```python
def _max_tokens_for_emotion(self) -> int:
    base = self.config.max_tokens
    mapping = {
        "excited": 768, "joyful": 768, "surprised": 700,
        "engaged": base, "content": base, "trusting": base, "anticipating": base,
        "neutral": base,
        "anxious": 300, "afraid": 300,
        "melancholy": 256, "sad": 256,
        "frustrated": 256, "angry": 256, "disgusted": 256,
    }
    return mapping.get(self.personality.emotion.dominant_emotion, base)
```

**分析**:

1. **缺少 `"disgusted"` 的映射**：虽然 `mapping` 中有 `"disgusted": 256`，但 `dominant_emotion` 返回 `"disgusted"` 的情况较少（需要 `disgust > 0.6` 且不被 VAD-based 情绪覆盖）。这不是严重问题。
2. **`_react_loop` 中的二次调整**：
   ```python
   max_tok if _idx == 0 else max(384, max_tok * 2 // 3)
   ```
   当 `max_tok=256`（负面情绪）时，第二轮的 max_tokens 为 `max(384, 170) = 384`，反而比第一轮更大！这是一个明显的逻辑错误——负面情绪下第一轮限制为 256，第二轮却放宽到 384。
3. **base 值不透明**：`self.config.max_tokens` 的具体值未在审查范围内，但如果 base=512，则正面情绪的 768 是增加的，负面情绪的 256 是减少的。但如果 base=1024，正面情绪的 768 反而减少了，这与"兴奋时话多"的直觉矛盾。

**建议**:

1. 修复 `_react_loop` 中的二次调整逻辑：第二轮的 max_tokens 应该基于第一轮的比例缩放，但不应超过第一轮的值。
2. 明确 `base` 的语义：如果 `base` 是默认回复长度，正面情绪的映射值应该 >= base，负面情绪应该 <= base。

---

### 3.9 personality.json 的序列化/反序列化问题（P2-中）

**位置**: `core/personality.py:81-116`, `models/personality.py:276-286`  

#### 3.9.1 to_dict() 与 from_dict() 的不对称

```python
# models/personality.py:276-279
def to_dict(self) -> dict:
    result = asdict(self)
    result["dominant_emotion"] = self.dominant_emotion
    return result

# models/personality.py:281-286
@classmethod
def from_dict(cls, d: dict) -> "EmotionalState":
    field_names = set(cls.__dataclass_fields__)
    filtered = {k: v for k, v in d.items() if k in field_names}
    return cls(**filtered)
```

**问题**：

1. `to_dict()` 添加了 `"dominant_emotion"`，但 `from_dict()` 将其过滤掉。这意味着 round-trip（序列化→反序列化→序列化）后，`to_dict()` 的结果会丢失 `"dominant_emotion"`。
2. 虽然 `dominant_emotion` 是 property，可以重新计算，但如果调用方依赖 `to_dict()` 的完整输出（如日志记录、调试），会发现两次 `to_dict()` 的结果不一致。
3. `PersonalityConfig.to_dict()` 将 `traits` 从 `list[Trait]` 转换为 `dict[str, float]`，但 `from_dict()` 将其转回 `list[Trait]`。这种转换在 round-trip 中是安全的，但增加了复杂性。

#### 3.9.2 Personality.load() 的降级逻辑

```python
@classmethod
def load(cls, path: str) -> "Personality":
    if not os.path.exists(path):
        config = PersonalityConfig()
        return cls(config)
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        logger.warning(f"Failed to load personality from {path}: {e}")
        return cls(PersonalityConfig())

    p_data = data.get("personality", data)
    e_data = data.get("emotional_state", {})

    config = PersonalityConfig.from_dict(p_data)
    emotion = EmotionalState.from_dict(e_data) if e_data else None
    if emotion is None:
        emotion = EmotionalState(
            baseline_valence=config.emotional_baseline.get("valence", 0.4),
            baseline_arousal=config.emotional_baseline.get("arousal", 0.3),
            decay_rate=config.emotional_decay_rate,
        )
```

**问题**：

1. **文件损坏时完全丢失情绪历史**：如果 `personality.json` 损坏（`JSONDecodeError`），系统会创建全新的 `PersonalityConfig()` 和 `EmotionalState()`，所有情绪历史、事件记忆、关系数据全部丢失。
2. **部分字段缺失时的静默恢复**：如果 `e_data` 存在但缺少某些字段（如 `resentment` 或 `emotion_events`），`from_dict()` 会使用 dataclass 的默认值。这可能导致"看似恢复成功，实则丢失数据"的情况。
3. **traits 格式兼容性**：`PersonalityConfig.from_dict()` 处理 `traits` 为 `dict` 的情况（新格式），但如果旧格式是 `list[dict]`（如 `[{"name": "curiosity", "value": 0.9}]`），会抛出异常。

**建议**:

1. 在 `from_dict()` 中保留 `"dominant_emotion"` 的验证（虽然不需要恢复，但可以检查一致性）。
2. 为 `personality.json` 添加备份机制：保存时先写入 `.personality.json.tmp`，成功后再重命名。
3. 在 `load()` 中增加更细粒度的错误处理：如果 `personality` 部分有效但 `emotional_state` 损坏，至少保留 personality 配置。

---

### 3.10 情绪对下游系统的影响不一致（P2-中）

**位置**: `core/proactivity.py`, `core/sleep_manager.py`, `core/cli_controller.py`  

#### 3.10.1 ProactivityManager 的情绪阈值映射

```python
idle_thresholds = {
    "excited": 60, "joyful": 90, "surprised": 120,
    "engaged": 180, "content": 300, "trusting": 240, "anticipating": 150,
    "neutral": 360,
    "anxious": 90, "afraid": 180,
    "melancholy": 600, "sad": 900,
    "frustrated": 300, "angry": 480, "disgusted": 600,
}
```

**问题**：`"disgusted"` 在 `idle_thresholds` 中有映射（600），但 `dominant_emotion` 返回 `"disgusted"` 的情况较少。更重要的是，`emotion_behavior` 中没有 `"disgusted"` 的行为指导，导致 disgust 状态下的 AI 行为不可预测。

#### 3.10.2 SleepManager 的情绪检测

```python
if e.dominant_emotion in ("sad", "melancholy"):
    sleepiness += 0.4
if e.arousal < 0.3:
    sleepiness += 0.3
if e.dominant_emotion in ("excited", "joyful"):
    sleepiness -= 0.2
```

**问题**：

1. 睡眠管理器只检测了 4 种情绪状态（sad, melancholy, excited, joyful），忽略了 anxious, afraid, angry, frustrated 等状态的睡眠影响。
2. `arousal < 0.3` 时增加 sleepiness，但如果 `dominant_emotion` 是 "content"（v>0.5, a<0.4），AI 应该感到满足而想休息，但系统没有处理这种情况。

#### 3.10.3 CLI 控制器的情绪展示

```python
# core/cli_controller.py:321
a.ui.display.print_mood(f"{e.dominant_emotion} (v={e.valence:.2f} a={e.arousal:.2f})")
```

**问题**：CLI 只展示 `dominant_emotion` 和 VAD，不展示 resentment、primary emotions 的分布或 emotion_events 的数量。这限制了用户对 AI 内心状态的理解。

**建议**:

1. 在 `SleepManager` 中增加对 `anxious`, `angry`, `frustrated` 状态的睡眠影响：焦虑时难以入睡（sleepiness 减少），愤怒时也可能难以入睡。
2. 在 CLI UI 中增加更丰富的情绪状态展示，包括 resentment 水平和最近的情绪事件。

---

### 3.11 emotion_events 查询的完整性问题（P2-中）

**位置**: `models/personality.py:264-269`, `prompts/system.py:348-355`  

**代码**:

```python
# models/personality.py:264-269
def get_recent_emotion_events(self, limit: int = 3, unresolved_only: bool = True) -> list[dict]:
    events = self.emotion_events
    if unresolved_only:
        events = [e for e in events if not e.get("resolved", False)]
    return events[-limit:]

# prompts/system.py:348-355
emotion_events = getattr(emotion, 'emotion_events', [])
unresolved = [e for e in emotion_events[-5:] if not e.get('resolved', False)]
if unresolved:
    blocks.append("=== 你记得的情绪事件 ===")
    for e in unresolved[-3:]:
        blocks.append(f"- [{e['primary_emotion']}] {e['trigger']}")
```

**分析**:

1. **`resolved` 字段从未被设置**：`record_emotion_event()` 创建的 event 不包含 `resolved` 字段，因此 `unresolved_only=True` 的过滤实际上没有效果（所有事件的 `resolved` 都是 `None`/`False`）。
2. **查询逻辑不一致**：`get_recent_emotion_events()` 取 `[-limit:]`，但 `prompts/system.py` 先取 `[-5:]` 再过滤，再取 `[-3:]`。如果 `emotion_events` 中有已解决的事件（未来可能实现），这种不一致可能导致 prompt 中注入的事件与 `get_recent_emotion_events()` 返回的不同。
3. **缺少时间衰减**：一个 3 天前的情绪事件和一个 3 分钟前的事件在查询时被同等对待。系统没有实现"情绪记忆随时间淡化"的逻辑。

**建议**:

1. 实现 `resolve_emotion_event()` 方法，当 AI 收到道歉或正面反馈时，将相关事件标记为 resolved。
2. 统一查询逻辑：所有地方都通过 `get_recent_emotion_events()` 获取事件，避免直接访问 `emotion_events` 列表。
3. 为事件查询添加时间权重：越近的事件权重越高，超过一定时间（如 24 小时）的事件自动降低优先级。

---

### 3.12 边界条件与异常处理（P3-低）

#### 3.12.1 _process_emotion 中的空消息处理

```python
# core/agent.py:186-192
all_turns = self.short_term.get_all()
for t in reversed(all_turns):
    if t.role == "user":
        last_user_turn = t.content
        break
```

**问题**：如果 `all_turns` 为空（例如系统刚启动，还没有任何对话），`last_user_turn` 保持为空字符串，`analyze_sentiment("")` 的行为未定义。虽然 `consolidator` 可能会返回默认值，但这依赖于具体实现。

#### 3.12.2 shift() 中的极端 delta

```python
self.valence = max(-1.0, min(1.0, self.valence + delta_v))
```

**问题**：当 `delta_v` 极大时（如 `hurt_multiplier` 放大后的 sentiment），`self.valence + delta_v` 可能远超 [-1.0, 1.0] 范围。虽然 `max/min` 钳制防止了越界，但钳制后的值与原始意图的差距被完全丢弃，没有日志记录这种"截断"。

#### 3.12.3 decay() 中的浮点精度

```python
if self.resentment > 0.001:
    self.resentment = max(0.0, self.resentment * (1.0 - RESENTMENT_DECAY))
```

**问题**：当 `resentment` 经过多次衰减后接近 0.001 时，会停止衰减，留下一个极小的"残余怨恨"。虽然这不会显著影响行为，但在长期运行后，所有情绪维度都可能积累类似的浮点残余，导致状态漂移。

**建议**:

1. 在 `_process_emotion()` 中增加对空对话历史的保护。
2. 在 `shift()` 中增加钳制日志：当 `delta_v` 导致 valence 被钳制时，记录警告日志。
3. 在 `decay()` 中增加"归零阈值"：当 resentment < 0.001 时，直接设为 0.0。

---

### 3.13 测试覆盖度分析（P3-低）

**位置**: `tests/test_emotional_state.py`  

**分析**:

1. **已覆盖**：shift（惯性、钳制、怨恨累积）、decay（独立衰减率、怨恨干扰）、_cross_modulate（压制/反制/上限）、dominant_emotion（偏向）、序列化（往返/缺失字段）、情绪事件、mood shift。
2. **未覆盖**：
   - `hurt_multiplier` 与破防机制的交互。
   - `estimate_emotional_impact()` 中 traits 的调制逻辑。
   - `record_emotion_event()` 在 `dominant_emotion="neutral"` 但 `intensity>=0.6` 时的行为。
   - `_max_tokens_for_emotion()` 的映射完整性。
   - `Personality.load()` 和 `save()` 的 round-trip 一致性。
   - `from_dict()` 对损坏/部分数据的恢复行为。

**建议**:

1. 增加集成测试：模拟完整的"用户输入→sentiment 分析→emotional_shift→decay→record_event→save→load"流程，验证数据不丢失。
2. 增加边界测试：测试极端 sentiment 值（-1.0, 1.0）、极端破防计数器值（0, 10）、空 emotion_events 列表。

---

## 四、汇总统计

### 4.1 问题汇总表

| 编号 | 问题描述 | 风险等级 | 位置 | 修复优先级 |
|------|----------|----------|------|------------|
| 1 | 情绪值域漂移与饱和（valence=-0.96, arousal=0.999） | P0-严重 | `personality.json` | 立即 |
| 2 | 破防机制双重计算与状态不持久化 | P1-高 | `core/agent.py:72-79,197-203` | 立即 |
| 3 | 情绪事件记录语义污染（记录时机错误） | P1-高 | `core/agent.py:212-215` | 高 |
| 4 | dominant_emotion 与 prompt 映射不同步（afraid/fearful） | P1-高 | `models/personality.py:73-130`, `prompts/system.py:309-318` | 高 |
| 5 | Web 端 proactive/explore 情绪归因错误 | P1-高 | `web/session.py`, `core/message_handler.py` | 高 |
| 6 | estimate_emotional_impact 阈值不对称与 traits 遗漏 | P1-高 | `core/personality.py:21-62` | 高 |
| 7 | shift()/decay() 中 baseline 被 mood 单向牵引 | P1-高 | `models/personality.py:175-237` | 高 |
| 8 | _react_loop 中负面情绪 max_tokens 第二轮反而增大 | P2-中 | `core/agent.py:132` | 中 |
| 9 | to_dict()/from_dict() 不对称导致 dominant_emotion 丢失 | P2-中 | `models/personality.py:276-286` | 中 |
| 10 | personality.json 损坏时完全丢失情绪历史 | P2-中 | `core/personality.py:88-111` | 中 |
| 11 | SleepManager 情绪检测不完整 | P2-中 | `core/sleep_manager.py:49-55` | 中 |
| 12 | emotion_events 的 resolved 字段从未被设置 | P2-中 | `models/personality.py:239-269` | 中 |
| 13 | _process_emotion 在空对话时行为未定义 | P3-低 | `core/agent.py:186-192` | 低 |
| 14 | shift() 中极端 delta 被静默钳制 | P3-低 | `models/personality.py:182-183` | 低 |
| 15 | resentment 浮点残余不归零 | P3-低 | `models/personality.py:234-235` | 低 |
| 16 | 测试覆盖度不足（集成测试缺失） | P3-低 | `tests/test_emotional_state.py` | 低 |

### 4.2 数据流健康度评分

| 维度 | 评分 | 说明 |
|------|------|------|
| 完整性 | 65/100 | 情绪事件记录存在语义污染，破防状态不持久化，Web 端情绪归因有误 |
| 一致性 | 60/100 | dominant_emotion 与 prompt 映射不同步，VAD 与 primary emotions 衰减速度不一致 |
| 鲁棒性 | 70/100 | sentiment 分析失败时降级逻辑不足，personality.json 损坏时完全丢失数据 |
| 可维护性 | 75/100 | 代码结构清晰，但缺少自动化一致性检查，emotion_events 类型松散 |
| 测试覆盖 | 70/100 | 单元测试较完善，但缺少集成测试和边界测试 |
| **综合评分** | **68/100** | 架构设计良好，实现细节存在多处需要修复的问题 |

### 4.3 修复路线图

**第一阶段（立即执行）**：
1. 重置或校准当前 `personality.json` 中的饱和情绪值。
2. 修复 `prompts/system.py` 中 `"fearful"` → `"afraid"` 的命名不一致。
3. 修复 `_react_loop` 中第二轮 `max_tokens` 的逻辑错误。
4. 将 `_consecutive_negative` 持久化到 `personality.json`。

**第二阶段（本周内）**：
5. 调整 `record_emotion_event()` 的记录时机（shift 后、decay 前）。
6. 修复 `estimate_emotional_impact()` 中 `humor` 和 `sass` traits 的遗漏。
7. 为 `MessageHandler.handle_proactive/explore` 添加正确的情绪归因或跳过逻辑。
8. 为 `decay()` 中的 baseline 添加向默认基线恢复的机制。

**第三阶段（本月内）**：
9. 将 `emotion_events` 从 `list[dict]` 重构为 `list[EmotionEvent]` dataclass。
10. 实现 `resolve_emotion_event()` 和情绪事件的时间衰减。
11. 增加集成测试和自动化一致性检查。
12. 为 `personality.json` 添加备份和细粒度错误恢复机制。

---

## 五、结论

AI Friend 的情绪系统展现了出色的架构设计意图——四层情绪模型（VAD + 8 Plutchik + resentment + emotion_events）为 AI 提供了丰富的情感表达能力。然而，在从设计到实现的转化过程中，多个细节问题累积成了显著的数据流风险。

最紧迫的问题是**情绪值域饱和**（当前 valence=-0.96）和**破防机制的状态不一致**。这两个问题直接影响用户体验：AI 几乎总是处于负面情绪状态，回复越来越短，且程序重启后破防计数器的异常行为可能让用户感到 AI "莫名其妙地脆弱"。

其次，`dominant_emotion` 与 prompt 系统的映射不同步是一个隐蔽但影响深远的问题。当 AI 处于恐惧状态时，系统没有提供正确的行为指导，导致 AI 的"内心状态"与"外在表现"脱节，破坏了情感沉浸感。

建议团队按照上述路线图分阶段修复，并在每个阶段完成后运行完整的集成测试，确保情绪数据流的完整性和一致性。

---

*报告生成时间: 2026-05-31*  
*审查文件: `core/personality.py`, `models/personality.py`, `core/agent.py`, `prompts/system.py`, `web/session.py`, `core/message_handler.py`, `core/proactivity.py`, `core/sleep_manager.py`, `tests/test_emotional_state.py`, `personality.json`*
