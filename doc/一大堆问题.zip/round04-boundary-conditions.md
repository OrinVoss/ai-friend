# 第4轮：边界条件与极端输入审查报告

**审查日期**: 2026-05-31
**审查范围**: core/agent.py, core/message_handler.py, core/inner_drive.py, core/tool_agent.py, core/dispatcher.py, core/context_manager.py, core/provider.py, core/personality.py, core/cli_controller.py, core/proactivity.py, core/sleep_manager.py, memory/short_term.py, memory/long_term.py, memory/retrieval.py, memory/consolidation.py, tools/*.py, models/personality.py, models/conversation.py, web/server.py, web/session.py
**审查维度**: 空输入、超长输入、首次运行、无记忆、无工具注册、情绪饱和、token估算异常、max_tokens动态调整、除零/越界、空集合迭代

---

# 概述

本次审查聚焦 AI Friend 项目在面对边界条件和极端输入时的鲁棒性。通过对 20+ 个核心文件的逐行分析，共发现 **47 项边界条件风险**，其中高危 5 项、中危 18 项、低危 24 项。主要问题集中在：情绪值越界与饱和处理缺失、token 估算为 0 或负数时的除零/越界风险、空输入/空集合的未定义行为、首次运行无历史时的默认值合理性、以及 max_tokens 动态调整后可能为 0 或负数的崩溃风险。

---

# 详细发现

---

## 1. 空输入处理

### 1.1 Web 端空消息未返回错误响应（中危）

**文件**: `web/server.py`
**行号**: 224-226
```python
elif msg_type == "message":
    content = data.get("content", "").strip()
    if not content:
        continue
```

**风险描述**: 当 WebSocket 收到空消息时，服务端直接 `continue` 跳过处理，不向客户端返回任何响应。客户端可能处于等待状态，造成 UI 卡顿或超时。与 REST API (`/api/chat`) 的行为不一致——REST 端在空消息时会返回 `{"error": "empty message"}`。

**风险评级**: 中危
**修复建议**: 统一返回错误响应，如 `await websocket.send_text(json.dumps({"type": "error", "content": "消息不能为空"}))`。

---

### 1.2 CLI 端空输入被当作正常用户输入处理（中危）

**文件**: `core/cli_controller.py`
**行号**: 121, 127
```python
user_input = a.current_input or ""
...
a.short_term.add_turn("user", user_input)
```

**风险描述**: CLI 模式下用户直接按回车会传入空字符串，该空字符串被加入短期记忆、触发 Agent 1 内驱推理、消耗 API token，最终可能产生无意义的回复。虽然 `Agent.process_message` 未对空输入做前置拦截，但 CLI 控制器也未过滤。

**风险评级**: 中危
**修复建议**: 在 `_on_perceive` 开头增加空输入检查：`if not user_input.strip(): a.state = AgentState.IDLE; return`。

---

### 1.3 `handle_message` 空输入未拦截（中危）

**文件**: `core/message_handler.py`
**行号**: 64-75
```python
def handle_message(self, user_input: str, on_token=None) -> str:
    ...
    a.short_term.add_turn("user", user_input)
```

**风险描述**: `MessageHandler.handle_message` 接收 `user_input: str` 参数，但从未检查是否为空或仅包含空白字符。空字符串会完整走完整条三 Agent 流水线，浪费 API 调用。

**风险评级**: 中危
**修复建议**: 在方法开头增加 `if not user_input or not user_input.strip(): return "嗯？你好像什么都没说呢。"`。

---

### 1.4 `InnerDriveAgent.assess` 空输入进入 LLM 调用（低危）

**文件**: `core/inner_drive.py`
**行号**: 61-79
```python
def assess(self, user_input: str) -> InnerDriveResult:
    ...
    messages = [
        {"role": "system", "content": sys_prompt},
        {"role": "user", "content": f"用户输入：{user_input}\n\n请进行内驱推理..."},
    ]
```

**风险描述**: 即使 `user_input` 为空字符串，也会构造包含 `"用户输入："` 的提示词发送给 LLM。LLM 可能产生不可预测的推理结果。

**风险评级**: 低危
**修复建议**: 在 `assess` 方法开头做空输入快速返回：`if not user_input.strip(): return InnerDriveResult(needs_external_tools=False, reasoning="空输入", summary="")`。

---

### 1.5 `ReadFileTool` 空路径处理正确（安全）

**文件**: `tools/file_tools.py`
**行号**: 170-176
```python
def execute(self, args: dict[str, Any]) -> ToolResult:
    filepath_raw = args.get("path", "").strip()
    ...
    if not filepath_raw:
        return ToolResult.fail("请提供文件路径")
```

**风险描述**: 已正确处理空路径，返回明确的错误信息。无风险。

**风险评级**: 安全

---

### 1.6 `WebSearchTool` 空查询处理正确（安全）

**文件**: `tools/web_tools.py`
**行号**: 72-78
```python
def execute(self, args: dict[str, Any]) -> ToolResult:
    query = args.get("query", "").strip()
    ...
    if not query:
        return ToolResult.fail("请提供搜索关键词")
```

**风险评级**: 安全

---

### 1.7 `MusicPlayTool` 空歌曲名处理正确（安全）

**文件**: `tools/music_tool.py`
**行号**: 117-120
```python
def execute(self, args: dict[str, Any]) -> ToolResult:
    song = args.get("song", "").strip()
    if not song:
        return ToolResult.fail("请提供歌曲名称")
```

**风险评级**: 安全

---

### 1.8 `NotifyTool` 空标题/内容处理正确（安全）

**文件**: `tools/notify_tool.py`
**行号**: 40-45
```python
def execute(self, args: dict[str, Any]) -> ToolResult:
    title = args.get("title", "").strip()
    message = args.get("message", "").strip()
    if not title or not message:
        return ToolResult.fail("标题和内容不能为空")
```

**风险评级**: 安全

---

## 2. 超长输入处理

### 2.1 `handle_message` 超长输入无截断（高危）

**文件**: `core/message_handler.py`
**行号**: 64, 72
```python
def handle_message(self, user_input: str, on_token=None) -> str:
    ...
    logger.info(f"[msg] turn={a.turn_count} len={len(user_input)}")
    a.current_input = user_input
```

**风险描述**: 用户输入长度仅被记录，没有任何截断或限制。若用户粘贴数万字文本，将直接送入 LLM API，可能导致：1) 超出 API 上下文长度限制而返回 400 错误；2) 产生巨额 token 费用；3) 本地 token 估算循环耗时剧增。

**风险评级**: 高危
**修复建议**: 增加输入长度上限，如 `MAX_INPUT_LEN = 8000`，超长时截断并提示用户。

---

### 2.2 `WebSocket` 消息无长度限制（中危）

**文件**: `web/server.py`
**行号**: 223-233
```python
elif msg_type == "message":
    content = data.get("content", "").strip()
    ...
    response = await loop.run_in_executor(None, agent.process_message, content)
```

**风险描述**: WebSocket 接收的消息内容无长度校验，与 2.1 同理，超长输入直接穿透到后端处理。

**风险评级**: 中危
**修复建议**: 在 `content = data.get("content", "").strip()` 后增加长度检查，超过阈值返回错误。

---

### 2.3 `format_for_prompt` 超长历史截断机制存在漏洞（中危）

**文件**: `memory/short_term.py`
**行号**: 51-64
```python
def format_for_prompt(self, max_chars: int = 3000) -> str:
    ...
    for t in reversed(self._turns):
        label = "你" if t.role == "assistant" else "用户"
        line = f"{label}: {t.content}"
        total += len(line)
        if total > max_chars:
            lines.append("...[省略更早对话]")
            break
        lines.append(line)
```

**风险描述**: `max_chars` 默认 3000，但单条 `t.content` 本身可能远超 3000 字符。此时 `total += len(line)` 一次性跳跃超过阈值，导致该条超长内容被完整保留，仅后续内容被省略。实际输出可能远超 `max_chars`。

**风险评级**: 中危
**修复建议**: 在累加前对单条内容做截断：`line = f"{label}: {t.content[:max_chars]}"`，或确保单条内容不超过阈值。

---

### 2.4 `_build_messages` 中 `user_input` 未截断（中危）

**文件**: `core/message_handler.py`
**行号**: 286-290
```python
if user_input:
    msg_tokens = sum(estimate_tokens(m["content"][:500]) for m in messages if m["role"] != "system")
    if msg_tokens + estimate_tokens(user_input) > COMPRESS_THRESHOLD:
        a._context.compress(messages)
    messages.append({"role": "user", "content": user_input})
```

**风险描述**: 即使触发 `compress`，`user_input` 本身仍完整地追加到 messages 中。若 `user_input` 有 50000 字符，`compress` 后上下文被清空，但用户输入仍然完整保留，可能单独超过 API 限制。

**风险评级**: 中危
**修复建议**: 对 `user_input` 本身也做截断，或在 compress 后将超长输入截断到合理长度。

---

### 2.5 `WebFetchTool` 返回内容截断正确但无总大小限制（低危）

**文件**: `tools/web_tools.py`
**行号**: 140
```python
return ToolResult.ok(f"{header}:\n```\n{content[:8000]}\n```")
```

**风险描述**: 网页内容被截断到 8000 字符，这是合理的。但 `content` 变量在截断前已经完整加载到内存中，若网页内容极大（如 100MB 的日志文件），会短暂占用大量内存。

**风险评级**: 低危
**修复建议**: 在 `_anysearch_api` 返回后，对 `content` 做早期截断，避免完整大内容驻留内存。

---

### 2.6 `ReadFileTool` 单文件大小限制正确（安全）

**文件**: `tools/file_tools.py`
**行号**: 137-139
```python
size = os.path.getsize(resolved)
if size > MAX_FILE_SIZE:
    return ToolResult.fail(f"文件太大 ({size/1024:.0f}KB > {MAX_FILE_SIZE/1024:.0f}KB)")
```

**风险描述**: `MAX_FILE_SIZE = 500 * 1024`（500KB），超过直接拒绝。但批量读取时（逗号分隔多路径），每个文件单独检查，总读取量可达 5 * 500KB = 2.5MB，仍在可接受范围。

**风险评级**: 低危（建议增加总读取量限制）

---

## 3. 首次运行（无历史）处理

### 3.1 `ConversationBuffer` 首次运行 `format_for_prompt` 返回空字符串（低危）

**文件**: `memory/short_term.py`
**行号**: 51-64
```python
def format_for_prompt(self, max_chars: int = 3000) -> str:
    ...
    lines.reverse()
    return "\n".join(lines)
```

**风险描述**: 首次运行时 `_turns` 为空 deque，`lines` 为空列表，返回 `""`。这在 `build_system_prompt` 中被显示为 `"(还没有对话)"`，处理正确。但 `get_recent(6)` 返回空列表，下游代码需能处理。

**风险评级**: 低危
**验证**: `proactivity.py` 中 `user_turns = [t for t in self._short_term.get_recent(6) if t.role == "user"][-3:]` 在空列表时返回 `[]`，后续 `if user_turns:` 判断保护，安全。

---

### 3.2 `Personality.load` 首次运行无文件时创建默认配置（安全）

**文件**: `core/personality.py`
**行号**: 88-91
```python
@classmethod
def load(cls, path: str) -> "Personality":
    if not os.path.exists(path):
        config = PersonalityConfig()
        return cls(config)
```

**风险描述**: 首次运行时若 `personality.json` 不存在，创建默认配置。但默认情绪状态未持久化，首次运行后没有保存文件，下次仍走同样路径。这可能导致情绪状态每次重启都重置。

**风险评级**: 低危
**修复建议**: 首次运行时主动调用 `save(path)` 创建持久化文件。

---

### 3.3 `Agent.__init__` 首次运行 `_consecutive_negative` 基于当前情绪初始化（低危）

**文件**: `core/agent.py`
**行号**: 72-79
```python
e = self.personality.emotion
neg_score = max(e.anger, e.sadness, e.disgust)
if neg_score > 0.8:
    self._consecutive_negative = 4
elif neg_score > 0.5:
    self._consecutive_negative = 2
else:
    self._consecutive_negative = 0
```

**风险描述**: 首次运行时情绪为默认值（anger=0.1, sadness=0.1, disgust=0.1），`_consecutive_negative` 初始化为 0，合理。但如果从持久化文件加载的情绪恰好处于高负面状态，`_consecutive_negative` 会被初始化为非零值，可能导致首次交互就进入"破防"状态。

**风险评级**: 低危
**修复建议**: 考虑将 `_consecutive_negative` 也持久化到 `personality.json` 中。

---

### 3.4 `SleepManager._load_sleep_state` 首次运行无文件时返回 False（安全）

**文件**: `core/sleep_manager.py`
**行号**: 25-31
```python
def _load_sleep_state(self) -> bool:
    try:
        with open(self._sleep_state_file) as f:
            return f.read().strip() == "1"
    except Exception as e:
        logger.warning(f"Failed to read sleep state: {e}")
        return False
```

**风险描述**: 首次运行时 `.sleep_state` 文件不存在，捕获异常后返回 `False`（醒着），这是合理的默认状态。

**风险评级**: 安全

---

### 3.5 `Database.initialize` 首次运行自动创建表和默认关系值（安全）

**文件**: `storage/database.py`
**行号**: 111-115
```python
INSERT OR IGNORE INTO relationship_metrics (dimension, value) VALUES
    ('trust', 0.3),
    ('familiarity', 0.3),
    ('intimacy', 0.3),
    ('playfulness', 0.3);
```

**风险描述**: 首次运行自动创建所有表，并插入默认关系值。`INSERT OR IGNORE` 确保重复初始化不会报错。安全。

**风险评级**: 安全

---

## 4. 无记忆时的处理

### 4.1 `MemoryRetriever.retrieve_for_query` 无记忆时返回空 `MemoryContext`（低危）

**文件**: `memory/retrieval.py`
**行号**: 27-69
```python
def retrieve_for_query(self, query: str) -> MemoryContext:
    hot_facts = self.ltm.get_all_active_facts(limit=50)
    ...
    return MemoryContext(
        facts=selected_facts,
        experiences=all_experiences,
        reflections=reflections[:3],
        relationship=relationship,
    )
```

**风险描述**: 当数据库为空时，`hot_facts`、`recent_experiences`、`reflections` 均为空列表，`relationship` 为默认字典。`MemoryContext` 的默认值在 `models/conversation.py` 中定义为包含默认关系值的字典，因此 `relationship.get('trust', 0.3)` 始终有值。但 `selected_facts` 为空时，`build_system_prompt` 中的记忆块不会渲染，处理正确。

**风险评级**: 低危
**注意**: `MemoryContext` 的 `relationship` 字段默认值为 `{"trust": 0.3, "familiarity": 0.3, "intimacy": 0.3, "playfulness": 0.3}`，与数据库默认值一致。

---

### 4.2 `RecallTool.execute` 无记忆时返回友好提示（安全）

**文件**: `tools/memory_tools.py`
**行号**: 38-70
```python
def execute(self, args: dict[str, Any]) -> ToolResult:
    ...
    if not parts:
        return ToolResult.ok(f"没有找到关于「{query}」的记忆")
    return ToolResult.ok("\n".join(parts))
```

**风险描述**: 当没有任何记忆匹配时，返回明确的"没有找到"提示，不会崩溃或返回空字符串导致 LLM 困惑。

**风险评级**: 安全

---

### 4.3 `MemoryConsolidator.consolidate` 无待处理轮次时仅执行 prune（低危）

**文件**: `memory/consolidation.py`
**行号**: 47-55
```python
def consolidate(self, short_term: ConversationBuffer, ...):
    if not self._pending_buffer:
        self._prune(max_facts, max_experiences, max_reflections)
        return
```

**风险描述**: 当 `_pending_buffer` 为空时，仍然执行 `_prune`。若数据库也为空，`prune_*` 方法中 `count = row[0]` 为 0，`count <= max_count` 成立，直接返回 0，无实际操作。安全，但存在不必要的 DB 查询。

**风险评级**: 低危
**修复建议**: 可在空 buffer 且 turn_count 为 0 时跳过整个 consolidate。

---

### 4.4 `SleepManager.generate_dream` 无记忆时生成空梦境（低危）

**文件**: `core/sleep_manager.py`
**行号**: 96-119
```python
def generate_dream(self) -> str:
    facts = self._ltm.get_all_active_facts(limit=5)
    exps = self._ltm.get_recent_experiences(limit=3)
    fact_str = " ".join(f"{f.fact_key}:{f.fact_value}" for f in facts)[:300]
    ...
```

**风险描述**: 无记忆时 `facts` 和 `exps` 均为空列表，`fact_str` 和 `exp_str` 为空字符串。梦境 prompt 变成"基于这些记忆碎片生成... 事实: 经历: 情绪:neutral"，LLM 可能生成无意义的梦境或空回复。`dream.strip()` 可能为空，返回 `""`。

**风险评级**: 低危
**修复建议**: 若 `not facts and not exps`，返回预设的默认梦境或跳过梦境生成。

---

## 5. 无工具注册时的处理

### 5.1 `ToolAgent.run` 无工具时返回空结果（安全）

**文件**: `core/tool_agent.py`
**行号**: 82-92
```python
def run(self, user_input: str) -> ToolAgentResult:
    ...
    if not self._registry.list_specs():
        return result
```

**风险描述**: 当 `_registry` 中没有任何外部工具注册时，直接返回空的 `ToolAgentResult`（`total_calls=0, success_count=0`）。`has_results` 为 `False`，`any_success` 为 `False`。下游 `handle_message` 中 `if tool_result and tool_result.has_results` 判断保护，不会崩溃。

**风险评级**: 安全

---

### 5.2 `ToolAgent.run_with_request` 无工具时同样返回空结果（安全）

**文件**: `core/tool_agent.py`
**行号**: 142-156
```python
def run_with_request(self, tool_request: str, max_retries: int = 3) -> ToolAgentResult:
    ...
    if not self._registry.list_specs():
        return result
```

**风险评级**: 安全

---

### 5.3 `execute_tool_calls` 遇到未知工具时返回错误结果（安全）

**文件**: `core/dispatcher.py`
**行号**: 109-147
```python
def execute_tool_calls(tool_registry: ToolRegistry, calls: list[dict]) -> list[dict]:
    for call in calls:
        tool = tool_registry.get(name)
        if tool is None:
            results.append({"name": name, "success": False, "output": f"未知工具: {name}"})
            continue
```

**风险描述**: 当工具名称在注册表中不存在时，返回明确的错误结果，不会抛出异常。`success=False` 会被正确统计。

**风险评级**: 安全

---

### 5.4 `ToolRegistry.format_for_prompt` 无工具时返回 "(无可用工具)"（安全）

**文件**: `tools/traits.py`
**行号**: 65-80
```python
def format_for_prompt(self, names: list[str] | None = None) -> str:
    ...
    return "\n\n".join(parts) if parts else "(无可用工具)"
```

**风险评级**: 安全

---

### 5.5 `WebAgent` 初始化时工具注册不完整的风险（中危）

**文件**: `web/session.py`
**行号**: 61-71
```python
registry = ToolRegistry()
registry.register(RecallTool(self.retriever, self.ltm))
registry.register(RememberTool(self.ltm))
registry.register(ReadFileTool())
registry.register(NotifyTool())
registry.register(WebSearchTool())
registry.register(WebFetchTool())
registry.register(MusicPlayTool())
registry.register(GlobTool())
registry.register(GrepTool())
```

**风险描述**: 所有工具在 `WebAgent.__init__` 中硬编码注册，正常情况下不会遗漏。但如果某个工具类导入失败（如依赖缺失），整个 `WebAgent` 初始化会抛出异常，导致会话创建失败。没有容错机制。

**风险评级**: 中危
**修复建议**: 使用 try/except 包裹每个 `register`，单个工具失败时记录日志并继续。

---

## 6. 情绪饱和边界（valence/arousal 范围）

### 6.1 `EmotionalState.shift` 中 valence/arousal 截断正确但 primary emotions 截断有隐患（低危）

**文件**: `models/personality.py`
**行号**: 175-191
```python
def shift(self, delta_v: float, delta_a: float, primary_deltas: Optional[dict[str, float]] = None) -> None:
    inertia_factor = 1.0 - self.inertia
    delta_v *= inertia_factor
    delta_a *= inertia_factor

    self.valence = max(-1.0, min(1.0, self.valence + delta_v))
    self.arousal = max(0.0, min(1.0, self.arousal + delta_a))

    if primary_deltas:
        for key, delta in primary_deltas.items():
            if hasattr(self, key):
                current = getattr(self, key)
                new_val = current + delta * inertia_factor
                setattr(self, key, max(0.0, min(1.0, new_val)))
```

**风险描述**: `valence` 被截断到 `[-1.0, 1.0]`，`arousal` 被截断到 `[0.0, 1.0]`，primary emotions 被截断到 `[0.0, 1.0]`，看起来正确。但如果 `inertia` 被外部设置为 1.0（虽然默认 0.3），`inertia_factor = 0.0`，所有 delta 被抹除，情绪永不变化。这不是崩溃，但属于逻辑边界。

**风险评级**: 低危
**修复建议**: 在 `EmotionalState` 初始化或 setter 中限制 `inertia` 的范围，如 `[0.0, 0.9]`。

---

### 6.2 `EmotionalState._cross_modulate` 中 `joy_ceiling` 可能为负数（中危）

**文件**: `models/personality.py`
**行号**: 170-173
```python
if r > 0.2:
    joy_ceiling = 1.0 - r * 0.5
    self.joy = min(self.joy, joy_ceiling)
```

**风险描述**: 当 `resentment > 2.0` 时（虽然正常情况下被截断到 1.0，但如果通过 `from_dict` 加载了异常值），`joy_ceiling = 1.0 - 2.0 * 0.5 = 0.0`。若 `resentment = 3.0`，`joy_ceiling = -0.5`，此时 `self.joy = min(self.joy, -0.5)` 会将 joy 设为负数，违反 `[0.0, 1.0]` 的不变量。

**风险评级**: 中危
**修复建议**: `joy_ceiling = max(0.0, 1.0 - r * 0.5)`。

---

### 6.3 `EmotionalState.decay` 中 resentment 衰减后可能为极小负数（低危）

**文件**: `models/personality.py`
**行号**: 233-235
```python
if self.resentment > 0.001:
    self.resentment = max(0.0, self.resentment * (1.0 - RESENTMENT_DECAY))
```

**风险描述**: `RESENTMENT_DECAY = 0.03`，`self.resentment * 0.97` 在浮点运算中可能产生极小的负数（如 `-1e-17`），然后被 `max(0.0, ...)` 修正。当前代码已使用 `max(0.0, ...)` 保护，安全。

**风险评级**: 安全

---

### 6.4 `Personality.estimate_emotional_impact` 中 `dv` 可能无限放大（低危）

**文件**: `core/personality.py`
**行号**: 21-62
```python
def estimate_emotional_impact(self, user_sentiment: float, ...):
    dv = user_sentiment * 0.3
    ...
    for t in self.config.traits:
        if t.name == "empathy" and t.value > 0.7:
            dv *= 1.5
            ...
```

**风险描述**: 若 `user_sentiment` 来自 LLM 的异常输出（如 999.0），`dv` 会被放大到极大值。虽然 `shift` 中有截断，但中间值可能溢出 Python float 范围（`dv *= 1.5` 循环多次）。实际上 `user_sentiment` 由 `analyze_sentiment` 解析，若 LLM 返回异常 JSON，已被 try/except 捕获并返回默认值。

**风险评级**: 低危

---

### 6.5 `Agent._max_tokens_for_emotion` 中情绪映射缺失时使用 base（安全）

**文件**: `core/agent.py`
**行号**: 90-100
```python
def _max_tokens_for_emotion(self) -> int:
    base = self.config.max_tokens
    mapping = {...}
    return mapping.get(self.personality.emotion.dominant_emotion, base)
```

**风险描述**: 若 `dominant_emotion` 返回了不在 mapping 中的值（理论上不可能，因为 `dominant_emotion` 的返回值是硬编码的字符串之一），会回退到 `base`。安全。

**风险评级**: 安全

---

### 6.6 `SleepManager.get_sleep_state` 中 `sleepiness` 可能越界（低危）

**文件**: `core/sleep_manager.py`
**行号**: 48-55
```python
sleepiness = 0.0
if e.dominant_emotion in ("sad", "melancholy"):
    sleepiness += 0.4
if e.arousal < 0.3:
    sleepiness += 0.3
if e.dominant_emotion in ("excited", "joyful"):
    sleepiness -= 0.2
sleepiness += r * 0.2
```

**风险描述**: `sleepiness` 的范围理论上是 `[-0.2, 0.9]`（当 `r=1.0` 时）。后续使用 `max(0.1, sleepiness)` 和 `max(0.3, sleepiness + 0.3)`，当 `sleepiness` 为负数时，`max` 会将其提升到 0.1 或 0.3。但 `sleepiness` 本身没有上限，若情绪值异常，`sleepiness` 可能大于 1.0，`random.random() < max(0.3, sleepiness + 0.3)` 始终为 True。这会导致睡眠逻辑异常触发。

**风险评级**: 低危
**修复建议**: `sleepiness = max(0.0, min(1.0, sleepiness))`。

---

### 6.7 `ProactivityManager.calculate_proactivity` 中 `score` 计算后截断正确（安全）

**文件**: `core/proactivity.py`
**行号**: 58-59
```python
score = max(0.0, min(0.8, score))
```

**风险描述**: `score` 在计算后正确截断到 `[0.0, 0.8]`。但中间值 `base = min(0.3, (idle_duration - min_idle) / 900.0)` 中，若 `idle_duration` 极大（如系统时间被修改），`base` 可能为很大的正数，但被 `min(0.3, ...)` 限制。安全。

**风险评级**: 安全

---

## 7. token 估算为 0 或负数

### 7.1 `estimate_tokens` 对空字符串返回至少 1（安全）

**文件**: `core/context_manager.py`
**行号**: 27-35
```python
def estimate_tokens(text: str) -> int:
    tok = _get_tokenizer()
    if tok:
        return len(tok.encode(text, disallowed_special=()))
    cjk = sum(1 for c in text if '一' <= c <= '鿿' or '　' <= c <= '〿')
    ascii_chars = sum(1 for c in text if c.isascii() and c.isalpha())
    digits = sum(1 for c in text if c.isdigit())
    other = len(text) - cjk - ascii_chars - digits
    return max(1, int(cjk / 1.5 + ascii_chars / 4 + digits / 3 + other / 8))
```

**风险描述**: 回退估算公式对空字符串会计算 `cjk=0, ascii=0, digits=0, other=0`，然后 `max(1, 0) = 1`。空字符串返回 1 token，合理。但如果 `text` 为负数长度（不可能），或 `_get_tokenizer()` 返回的 tokenizer 对空字符串返回 0（tiktoken 对空字符串返回 `[]`，长度为 0），则空字符串 token 数为 0。

**风险评级**: 低危
**注意**: `tiktoken` 对空字符串返回 `[]`，所以 `if tok:` 分支下空字符串返回 0。但空字符串在实际使用中不会单独作为消息内容传入。

---

### 7.2 `_build_messages` 中 token 估算累加可能溢出（低危）

**文件**: `core/message_handler.py`
**行号**: 280-283
```python
for t in a.short_term.get_all_reversed():
    role = "assistant" if t.role == "assistant" else "user"
    if estimate_tokens(" ".join(m["content"][:200] for m in messages[-5:] if m["role"] != "system")) + estimate_tokens(t.content) > COMPRESS_THRESHOLD:
        overflow = True
        break
```

**风险描述**: `messages[-5:]` 在 messages 只有 1 个元素（system prompt）时取最后 1 个，`" ".join(...)` 可能为空字符串（若最后一个不是 system 但实际是 system），`estimate_tokens` 返回 1。累加逻辑正确，但 `COMPRESS_THRESHOLD = 144000`，Python int 不会溢出。

**风险评级**: 低危

---

### 7.3 `ContextManager._do_compress` 中 `text` 为空时提前返回（安全）

**文件**: `core/context_manager.py`
**行号**: 82-84
```python
text = "\n".join(parts)
if not text.strip():
    return
```

**风险描述**: 当所有消息都为空时，`text` 为空字符串，提前返回，不会调用 API。安全。

**风险评级**: 安全

---

## 8. max_tokens 动态调整为 0

### 8.1 `Agent._react_loop` 中 `max_tokens` 在迭代后可能为 0（高危）

**文件**: `core/agent.py`
**行号**: 127-133
```python
for _idx in range(self._max_tool_iterations):
    resp = self.provider.generate(
        messages, stream=False if _idx > 0 else True,
        on_token=on_token if _idx == 0 else None,
        max_tokens=max_tok if _idx == 0 else max(384, max_tok * 2 // 3),
    )
```

**风险描述**: 当 `_idx > 0` 时，`max_tokens = max(384, max_tok * 2 // 3)`。若 `max_tok` 初始值为 256（如情绪为 sad/melancholy），则第二轮 `max_tokens = max(384, 256 * 2 // 3) = max(384, 170) = 384`，安全。但若 `max_tok` 初始值为 0（如配置错误），则 `max(384, 0) = 384`，仍有保护。但如果配置中 `max_tokens` 被设为负数，则 `max(384, 负数) = 384`，也有保护。

**风险评级**: 低危（有 `max(384, ...)` 保护）
**注意**: `KimiProvider.generate` 中 `max_tokens: max_tokens or self.max_tokens`，若传入 0 会回退到 `self.max_tokens`。

---

### 8.2 `KimiProvider.generate` 中 `max_tokens` 为 0 时回退到默认值（安全）

**文件**: `core/provider.py`
**行号**: 32-44
```python
def generate(self, messages: list[dict], ..., max_tokens: Optional[int] = None) -> str:
    payload = {
        ...
        "max_tokens": max_tokens or self.max_tokens,
    }
```

**风险描述**: `max_tokens or self.max_tokens` 在 `max_tokens=0` 时因 Python 的 falsy 判断会回退到 `self.max_tokens`。这防止了 0 值传入 API，但如果意图就是 0（虽然不合理），则无法表达。

**风险评级**: 低危
**修复建议**: 使用 `max_tokens if max_tokens is not None else self.max_tokens` 以区分 0 和 None。

---

### 8.3 `InnerDriveAgent.assess` 中 `max_tokens=512` 硬编码，无动态调整（低危）

**文件**: `core/inner_drive.py`
**行号**: 85
```python
resp = self._provider.generate(messages, stream=False, max_tokens=512)
```

**风险描述**: Agent 1 的推理始终使用 512 tokens，不受情绪影响。这是设计选择，但如果在极端情况下（如需要输出很长的工具请求），512 可能不够。

**风险评级**: 低危

---

## 9. 除零、越界访问

### 9.1 `ConversationBuffer.get_recent` 中 `k` 为负数时行为未定义（中危）

**文件**: `memory/short_term.py`
**行号**: 38-40
```python
def get_recent(self, k: int) -> list[Turn]:
    with self._lock:
        return list(self._turns)[-k:]
```

**风险描述**: 当 `k` 为负数时，`list(self._turns)[-k:]` 中的 `-k` 为正数，切片从正数索引开始到末尾，行为与预期相反。例如 `k=-3` 时返回 `list[3:]`（跳过前 3 个）。若调用方传入负数，会得到错误的结果。

**风险评级**: 中危
**修复建议**: `k = max(0, k)`，或 `return list(self._turns)[-max(0, k):]`。

---

### 9.2 `ConversationBuffer.format_for_prompt` 中 `max_chars` 为负数时全部跳过（低危）

**文件**: `memory/short_term.py`
**行号**: 51-64
```python
def format_for_prompt(self, max_chars: int = 3000) -> str:
    ...
    for t in reversed(self._turns):
        ...
        total += len(line)
        if total > max_chars:
            lines.append("...[省略更早对话]")
            break
```

**风险描述**: 当 `max_chars` 为负数时，第一次 `total += len(line)` 后 `total > max_chars` 立即成立，仅保留第一条的省略提示，然后 break。返回结果可能只有 `"...[省略更早对话]"`，不合理。

**风险评级**: 低危
**修复建议**: `max_chars = max(0, max_chars)`。

---

### 9.3 `ToolAgentResult` 中 `success_count` 可能大于 `total_calls`（低危）

**文件**: `core/tool_agent.py`
**行号**: 31-45
```python
@dataclass
class ToolAgentResult:
    records: list[ToolCallRecord] = field(default_factory=list)
    total_calls: int = 0
    success_count: int = 0
```

**风险描述**: `success_count` 和 `total_calls` 是独立维护的计数器。在 `run_with_request` 中，每次 retry 都会累加 `total_calls` 和 `success_count`。逻辑上 `success_count <= total_calls` 应该成立，但如果代码被修改或并发访问，可能破坏此不变量。

**风险评级**: 低危
**修复建议**: 将 `success_count` 改为 `@property`，动态计算 `sum(1 for r in self.records if r.success)`。

---

### 9.4 `MemoryRetriever._llm_rerank` 中 `selected_indices` 可能包含越界索引（中危）

**文件**: `memory/retrieval.py`
**行号**: 204-225
```python
def _llm_rerank(self, query: str, candidates: list[UserFact], max_candidates: int = 15) -> Optional[list[int]]:
    ...
    indices = [int(x.strip()) for x in result.split(",") if x.strip().isdigit()]
    return indices[:max_candidates]
```

**风险描述**: LLM 返回的索引列表可能包含超出 `candidates` 范围的数字（如 candidates 只有 10 个，LLM 返回了索引 15）。虽然调用方 `retrieve_for_query` 中有 `if i < len(candidates)` 保护：
```python
candidates = [candidates[i] for i in selected_indices if i < len(candidates)]
```
但 `_llm_rerank` 本身返回越界索引，依赖调用方过滤，存在责任不清晰的问题。

**风险评级**: 中危
**修复建议**: 在 `_llm_rerank` 内部过滤越界索引：`return [i for i in indices[:max_candidates] if 0 <= i < len(candidates)]`。

---

### 9.5 `Agent._react_loop` 中 `final_text` 为空时仍执行后续逻辑（低危）

**文件**: `core/agent.py`
**行号**: 172-181
```python
if final_text:
    if add_to_history:
        self.short_term.add_turn("assistant", final_text)
    ...
    self.turn_count += 1
```

**风险描述**: 当 `final_text` 为空字符串时（如 LLM 返回空回复），不会加入历史记忆，但 `turn_count` 也不会增加。这可能导致 `turn_count` 与实际对话轮次不一致。不过这不是越界或除零问题，而是状态一致性问题。

**风险评级**: 低危

---

### 9.6 `SleepManager.get_sleep_state` 中 `hour` 计算在跨天时正确（安全）

**文件**: `core/sleep_manager.py`
**行号**: 42-43
```python
now = datetime.now()
hour = now.hour + now.minute / 60.0
```

**风险描述**: `hour` 的范围是 `[0, 23.99]`，在跨天判断 `23 <= hour or hour < 1` 时正确覆盖 23:00-01:00 的窗口。无除零风险。

**风险评级**: 安全

---

### 9.7 `ProactivityManager.calculate_proactivity` 中 `min_idle` 可能为 0（低危）

**文件**: `core/proactivity.py`
**行号**: 26-38
```python
idle_thresholds = {...}
min_idle = idle_thresholds.get(e.dominant_emotion, 300)
min_idle += int(r * 300)

if idle_duration < min_idle:
    return 0.0

base = min(0.3, (idle_duration - min_idle) / 900.0)
```

**风险描述**: 当 `idle_duration == min_idle` 时，`base = min(0.3, 0 / 900.0) = 0`，无除零风险。当 `idle_duration < min_idle` 时提前返回 0.0。安全。

**风险评级**: 安全

---

### 9.8 `MusicListTool.execute` 中 `size_mb` 计算无除零（安全）

**文件**: `tools/music_tool.py`
**行号**: 72
```python
size_mb = os.path.getsize(filepath) / (1024 * 1024)
```

**风险描述**: 分母 `1024 * 1024` 是常量，永不为零。安全。

**风险评级**: 安全

---

## 10. 空集合迭代

### 10.1 `ToolRegistry.list_specs` 空注册表返回空列表（安全）

**文件**: `tools/traits.py`
**行号**: 62-63
```python
def list_specs(self) -> list[ToolSpec]:
    return [t.spec() for t in self._tools.values()]
```

**风险描述**: 当 `_tools` 为空 dict 时，返回 `[]`。在 `format_for_prompt` 中 `"\n\n".join(parts) if parts else "(无可用工具)"` 正确处理空列表。安全。

**风险评级**: 安全

---

### 10.2 `execute_tool_calls` 空 calls 列表返回空结果（安全）

**文件**: `core/dispatcher.py`
**行号**: 109-150
```python
def execute_tool_calls(tool_registry: ToolRegistry, calls: list[dict]) -> list[dict]:
    results = []
    for call in calls:
        ...
```

**风险描述**: 当 `calls` 为空列表时，循环不执行，返回 `[]`。在 `format_tool_results` 中 `"\n".join(parts)` 对空列表返回 `""`，但前面有固定的 `"=== 铁律 ==="` 块，不会完全为空。安全。

**风险评级**: 安全

---

### 10.3 `MemoryConsolidator._format_turns` 空 turns 返回空字符串（低危）

**文件**: `memory/consolidation.py`
**行号**: 299-304
```python
@staticmethod
def _format_turns(turns: list) -> str:
    return "\n".join(
        f"{'用户' if t.role == 'user' else '你'}: {t.content}"
        for t in turns
    )
```

**风险描述**: 当 `turns` 为空列表时，返回 `""`。在 `consolidate` 中，空 `_pending_buffer` 会提前返回，不会调用 `_format_turns`。但如果直接调用 `_format_turns([])`，返回 `""`，后续 `if len(turn_text) > 200:` 判断为 False，跳过大段逻辑。安全，但空字符串进入 LLM prompt 可能产生无意义的 API 调用。

**风险评级**: 低危

---

### 10.4 `Agent._react_loop` 中 `results` 为空时 `format_tool_results` 仍输出铁律（安全）

**文件**: `core/dispatcher.py`
**行号**: 153-169
```python
def format_tool_results(results: list[dict]) -> str:
    parts = []
    for r in results:
        ...
    parts.append("=== 铁律 ===\n...")
    return "\n".join(parts)
```

**风险描述**: 当 `results` 为空时，`parts` 初始为空列表，循环不执行，然后追加铁律块，返回铁律文本。这会导致 LLM 收到一条没有工具结果但强调"必须逐字如实汇报"的消息，可能让 LLM 困惑。

**风险评级**: 低危
**修复建议**: 若 `results` 为空，返回 `""` 或跳过追加铁律。

---

### 10.5 `build_system_prompt` 中 `memory_context.facts` 为空时不渲染（安全）

**文件**: `prompts/system.py`
**行号**: 368-371
```python
if memory_context.facts:
    blocks.append("=== 你知道的关于用户的事情 ===")
    for f in memory_context.facts[:10]:
        blocks.append(f"- {f.fact_key}: {f.fact_value}")
```

**风险描述**: 空列表时条件为 False，不渲染该块。安全。

**风险评级**: 安全

---

### 10.6 `SleepManager.generate_dream` 中 `facts` 为空时 `" ".join(...)` 返回空字符串（低危）

**文件**: `core/sleep_manager.py`
**行号**: 101
```python
fact_str = " ".join(f"{f.fact_key}:{f.fact_value}" for f in facts)[:300]
```

**风险描述**: 空列表时返回 `""`，`[:300]` 仍为 `""`。后续 prompt 中"事实:"后面为空，LLM 可能生成无依据的梦境。

**风险评级**: 低危

---

## 11. 其他边界条件

### 11.1 `Agent._process_emotion` 中 `last_user_turn` 为空时仍调用 `record_emotion_event`（低危）

**文件**: `core/agent.py`
**行号**: 183-215
```python
def _process_emotion(self) -> None:
    ...
    last_user_turn = ""
    for t in reversed(all_turns):
        if t.role == "user":
            last_user_turn = t.content
            break
    ...
    self.personality.emotion.record_emotion_event(
        trigger=last_user_turn[:100] if last_user_turn else "",
        context=last_user_turn[:200] if last_user_turn else "",
    )
```

**风险描述**: 当 `all_turns` 为空（首次运行）或全是 assistant 消息时，`last_user_turn` 为空字符串。`record_emotion_event` 中 `trigger=""[:100] = ""`，`primary_intensity` 计算后若小于 0.6 则跳过记录。但 `record_emotion_event` 的触发条件是 `primary_intensity < 0.6` 时 `return`，所以空 trigger 不会进入事件列表。安全。

**风险评级**: 安全

---

### 11.2 `WebAgent.process_message` 中 `personality.save` 在每次消息后都执行（低危）

**文件**: `web/session.py`
**行号**: 84-89
```python
def process_message(self, user_input: str) -> str:
    result = self.agent.process_message(user_input, on_token=self._on_token_callback)
    self.personality.save(self.config.personality_file)
    return result
```

**风险描述**: 每条消息都同步写入 `personality.json` 文件。在高并发或高频交互场景下，频繁的磁盘写入可能成为性能瓶颈。但这不是边界条件问题，而是性能问题。

**风险评级**: 低危

---

### 11.3 `SessionManager.get_or_create` 中 `session_id` 为空字符串时创建新会话（低危）

**文件**: `web/session.py`
**行号**: 136-144
```python
def get_or_create(self, session_id: Optional[str] = None) -> tuple[str, WebAgent]:
    with self._lock:
        sid = session_id or uuid.uuid4().hex[:12]
        if sid not in self._sessions:
            ...
```

**风险描述**: 当 `session_id=""` 时，`session_id or uuid.uuid4().hex[:12]` 会生成新 UUID，因为空字符串为 falsy。这可能导致客户端期望使用 `""` 作为固定 session ID 时，每次都会创建新会话。但通常客户端不会传空字符串。

**风险评级**: 低危
**修复建议**: `sid = session_id if session_id is not None else uuid.uuid4().hex[:12]`。

---

### 11.4 `Repository._row_to_fact` 中数据库字段为 NULL 时的默认值（低危）

**文件**: `storage/repository.py`
**行号**: 299-307
```python
def _row_to_fact(self, r) -> UserFact:
    return UserFact(
        id=r["id"], category=r["category"], fact_key=r["fact_key"],
        fact_value=r["fact_value"], confidence=r["confidence"],
        importance=r["importance"],
        ...
    )
```

**风险描述**: 当数据库中某些字段为 NULL 时（如 `source_turn`），`r["source_turn"]` 返回 `None`，与 `UserFact` 的 `Optional[int]` 类型匹配。但如果 `confidence` 或 `importance` 为 NULL，`r["confidence"]` 返回 `None`，而 `UserFact.confidence: float = 1.0` 期望 float，`None` 会导致类型不匹配。不过数据库 schema 中这些字段有 DEFAULT 值，正常不会为 NULL。

**风险评级**: 低危

---

### 11.5 `GrepTool.execute` 中 `file_glob` 为空字符串时默认为 "*"（安全）

**文件**: `tools/search_tools.py`
**行号**: 143-147
```python
file_glob = args.get("glob", "").strip() or "*"
```

**风险描述**: 空字符串时回退到 `"*"`，匹配所有文件。这是合理的默认行为。

**风险评级**: 安全

---

### 11.6 `NotifyTool.execute` 中 PowerShell 命令注入风险（中危）

**文件**: `tools/notify_tool.py`
**行号**: 50-57
```python
ps = f'''
...$textNodes.Item(0).AppendChild($template.CreateTextNode('{title}')) > $null
$textNodes.Item(1).AppendChild($template.CreateTextNode('{message}')) > $null
'''
```

**风险描述**: `title` 和 `message` 直接拼接到 PowerShell 字符串中，未做转义。若内容包含单引号 `'` 或 PowerShell 特殊字符，可能导致命令语法错误或注入。虽然 notify 工具通常由 LLM 调用，内容相对可控，但恶意构造的输入仍可能破坏命令。

**风险评级**: 中危
**修复建议**: 对 `title` 和 `message` 中的单引号进行转义：`title = title.replace("'", "''")`。

---

### 11.7 `Agent._react_loop` 中 `tool_result` 可能为 None 但被当作对象使用（中危）

**文件**: `core/message_handler.py`
**行号**: 100, 117-141
```python
request_text = drive_result.tool_requests[0].description if drive_result.tool_requests else user_input
...
if tool_result and tool_result.has_results:
    all_tool_results.append(tool_result)
```

**风险描述**: `tool_result = self._tool_agent.run_with_request(request_text)` 返回的 `ToolAgentResult` 永远不会为 `None`（构造函数返回对象），所以 `if tool_result` 始终为 True。但如果未来修改导致返回 `None`，`tool_result.has_results` 会抛出 `AttributeError`。

**风险评级**: 中危
**修复建议**: 明确检查 `if tool_result is not None and tool_result.has_results`，或确保文档说明永不返回 None。

---

### 11.8 `handle_explore` 中 `interests` 为空列表时 `random.sample` 抛出异常（高危）

**文件**: `core/message_handler.py`
**行号**: 223-229
```python
interests = getattr(a.personality.config, 'interests', [])
if interests:
    picked = random.sample(interests, min(2, len(interests)))
    messages.append({...})
```

**风险描述**: 当前代码有 `if interests:` 保护，空列表时跳过 `random.sample`。但如果 `interests` 被设为 `None`（虽然默认是列表），`getattr` 返回 `None`，`if interests:` 为 False，安全。但如果 `interests` 是空列表且 `if interests:` 被意外删除，`random.sample([], min(2, 0))` 会抛出 `ValueError: Sample larger than population or is negative`。

**风险评级**: 低危（当前有保护，但属于脆弱代码）
**修复建议**: 增加防御性检查：`if interests and len(interests) > 0:`。

---

### 11.9 `SleepManager` 中 `.sleep_state` 文件权限问题（低危）

**文件**: `core/sleep_manager.py`
**行号**: 25-38
```python
def _load_sleep_state(self) -> bool:
    try:
        with open(self._sleep_state_file) as f:
            return f.read().strip() == "1"
    except Exception:
        return False
```

**风险描述**: 文件权限问题导致读写失败时，睡眠状态无法持久化，每次重启都默认醒着。这不是崩溃，但功能降级。

**风险评级**: 低危

---

### 11.10 `ContextManager.compress` 递归调用自身（中危）

**文件**: `core/context_manager.py`
**行号**: 62-70
```python
def compress(self, messages: list[dict]) -> None:
    if self._compressing:
        return
    self._compressing = True
    try:
        self._do_compress(messages)
    finally:
        self._compressing = False
```

**风险描述**: 递归守卫 `if self._compressing: return` 防止了同步递归，但如果 `_do_compress` 内部异步触发了另一个 `compress` 调用（当前代码中没有），仍可能有问题。当前实现是安全的，但 `_do_compress` 内部调用 `self._provider.generate`，如果 generate 内部又触发 compress（不可能，因为 generate 不操作 ContextManager），才会递归。

**风险评级**: 低危

---

### 11.11 `Agent.__init__` 中 `sleep_file` 路径构造在 Windows 上可能异常（低危）

**文件**: `core/agent.py`
**行号**: 59-61
```python
sleep_file = os.path.join(
    os.path.dirname(os.path.abspath(config.personality_file)), ".sleep_state"
)
```

**风险描述**: 当 `config.personality_file` 为相对路径（如 `"personality.json"`）时，`os.path.abspath` 在当前工作目录解析。若当前工作目录与预期不同（如从子目录启动），`.sleep_state` 会创建在错误位置。但这不是边界条件，而是配置问题。

**风险评级**: 低危

---

### 11.12 `WebFetchTool` 中 URL 拼接可能产生畸形 URL（低危）

**文件**: `tools/web_tools.py`
**行号**: 127-128
```python
if not url.startswith(("http://", "https://")):
    url = "https://" + url
```

**风险描述**: 当 `url` 为 `"//example.com"` 时，`startswith` 不匹配，拼接后变成 `"https:////example.com"`，畸形 URL。AnySearch API 可能返回错误。

**风险评级**: 低危
**修复建议**: `url = url.lstrip("/")` 后再拼接。

---

### 11.13 `ProactivityManager.pick_proactive_topic` 中 `facts` 和 `exps` 均为空时回退到时间主题（安全）

**文件**: `core/proactivity.py`
**行号**: 66-92
```python
def pick_proactive_topic(self) -> str:
    ...
    if not topics:
        hour = datetime.now().hour
        if 6 <= hour < 9:
            topics.append("早上好，聊聊今天的计划")
        ...
    return random.choice(topics)
```

**风险描述**: 当 `topics` 为空时，会追加至少一个默认主题（因为 `hour` 始终有值），所以 `random.choice` 不会收到空列表。安全。

**风险评级**: 安全

---

### 11.14 `Agent._react_loop` 中 `fake_action_count` 达到 3 次后不再检测（低危）

**文件**: `core/agent.py`
**行号**: 139-155
```python
if contains_fake_action(resp) and fake_action_count < 3 and not tools_were_called:
    fake_action_count += 1
    ...
    continue
```

**风险描述**: 当 LLM 连续 3 次假装调用工具后，`fake_action_count < 3` 为 False，跳过检测，`final_text = cleaned` 可能包含虚假的工具描述。虽然 3 次已经是很大的容忍度，但如果 LLM 持续假装，第 4 次及以后会直接返回虚假内容给用户。

**风险评级**: 低危
**修复建议**: 达到上限后追加一条强约束消息，或直接返回错误提示。

---

### 11.15 `ReadFileTool._read_one` 中 `offset` 大于总行数时返回空内容（低危）

**文件**: `tools/file_tools.py`
**行号**: 152-155
```python
total_lines = len(all_lines)
start = max(0, offset)
end = min(total_lines, start + limit)
selected = all_lines[start:end]
```

**风险描述**: 当 `offset >= total_lines` 时，`start = offset`，`end = min(total_lines, offset + limit) = total_lines`，`selected = all_lines[offset:total_lines]` 为空列表。返回结果中只有 header 没有内容行，用户可能困惑。但这不是崩溃。

**风险评级**: 低危
**修复建议**: 若 `offset >= total_lines`，返回提示"offset 超出文件总行数"。

---

### 11.16 `MusicListTool.execute` 中 `os.walk(target)` 的 `break` 导致仅遍历顶层（设计选择）

**文件**: `tools/music_tool.py`
**行号**: 64-77
```python
for root, dnames, fnames in os.walk(target):
    ...
    break  # Only current dir, don't recurse
```

**风险描述**: 这是设计上的浅层遍历，不是 bug。但用户可能期望递归列出子目录中的音乐文件。属于功能边界，不是可靠性问题。

**风险评级**: 安全（设计选择）

---

### 11.17 `ToolAttemptTracker.can_start_new_round` 中 `total_attempts` 和 `round_number` 不一致（低危）

**文件**: `core/tool_agent.py`
**行号**: 48-66
```python
@dataclass
class ToolAttemptTracker:
    round_number: int = 0
    retry_count: int = 0
    total_attempts: int = 0

    @property
    def can_start_new_round(self) -> bool:
        return self.round_number < 3 and self.total_attempts < 9
```

**风险描述**: `round_number` 在 `message_handler.py` 中被手动递增（`round_num += 1`），但 `ToolAttemptTracker.round_number` 从未被更新（始终为 0）。因此 `can_start_new_round` 中的 `self.round_number < 3` 始终为 True，实际仅依赖 `total_attempts < 9`。这不是崩溃，但逻辑不一致。

**风险评级**: 低危
**修复建议**: 在 `message_handler.py` 中更新 `tracker.round_number = round_num`，或移除 `round_number` 字段。

---

### 11.18 `build_system_prompt` 中 `emotion_events` 的 `resolved` 字段可能不存在（低危）

**文件**: `prompts/system.py`
**行号**: 349
```python
unresolved = [e for e in emotion_events[-5:] if not e.get('resolved', False)]
```

**风险描述**: `e.get('resolved', False)` 在 `resolved` 键不存在时返回 `False`，这是正确的默认行为。但如果 `e` 不是字典（如 `emotion_events` 被错误地设为列表 of 字符串），`e.get` 会抛出 `AttributeError`。

**风险评级**: 低危

---

### 11.19 `Agent._react_loop` 中 `_max_tool_iterations` 为 0 时循环不执行（低危）

**文件**: `core/agent.py`
**行号**: 127
```python
for _idx in range(self._max_tool_iterations):
```

**风险描述**: 当 `_max_tool_iterations` 为 0 时，循环不执行，`final_text = ""`，返回空字符串。这可能导致用户收到空回复。但 `_max_tool_iterations` 在 `__init__` 中硬编码为 10，不会被外部修改。

**风险评级**: 低危

---

### 11.20 `PersonalityConfig.from_dict` 中未知字段被静默丢弃（低危）

**文件**: `models/personality.py`
**行号**: 318-322
```python
@classmethod
def from_dict(cls, d: dict) -> "PersonalityConfig":
    if "traits" in d and isinstance(d["traits"], dict):
        d["traits"] = [Trait(k, v) for k, v in d["traits"].items()]
    return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})
```

**风险描述**: 未知字段被静默丢弃，不会报错。这可能导致用户配置了某个字段但发现不生效，且不知道原因。但这不是崩溃。

**风险评级**: 低危

---

### 11.21 `MemoryRetriever._extract_keywords` 中纯标点/数字文本返回空列表（安全）

**文件**: `memory/retrieval.py`
**行号**: 181-191
```python
@staticmethod
def _extract_keywords(text: str) -> list[str]:
    words = re.findall(r'[\w一-鿿]+', text.lower())
    stopwords = {...}
    return [w for w in words if w not in stopwords and len(w) > 1]
```

**风险描述**: 当 `text` 为纯标点（如 `"!!!"`）或纯数字（如 `"123"`）时，`words` 为空列表或 `['123']`（数字长度为 3，不在 stopwords 中），返回 `['123']`。若 `text` 为单个中文字（如 `"的"`），被 stopwords 过滤，返回 `[]`。空关键词列表在下游 `search_experiences` 中会走无关键词分支，安全。

**风险评级**: 安全

---

### 11.22 `Repository.search_experiences` 中 `keywords` 为空列表时走无关键词分支（安全）

**文件**: `storage/repository.py`
**行号**: 128-148
```python
async def search_experiences(self, keywords: list[str] | None = None, limit: int = 10):
    if keywords:
        ...
    else:
        await c.execute("SELECT * FROM experiences WHERE is_archived = 0 ORDER BY ... LIMIT ?", (limit,))
```

**风险描述**: 空列表时 `if keywords:` 为 False，走 `else` 分支返回最近的经历。安全。

**风险评级**: 安全

---

### 11.23 `web/server.py` 中 `_calc_delay` 的 `seg_len` 极大时延迟极大（低危）

**文件**: `web/server.py`
**行号**: 57-65
```python
def _calc_delay(emotion: str, seg_len: int) -> float:
    base = {...}.get(emotion, 1.7)
    return base * (1.0 + seg_len / 80) * random.uniform(0.8, 1.3)
```

**风险描述**: 当 `seg_len` 极大（如 10000）时，延迟为 `base * (1 + 125) * rand = ~200秒`。虽然分段逻辑会将长文本拆分，但单段仍可能很长（如未成功拆分的长段落）。这会导致 WebSocket 发送间隔极长，用户体验差。

**风险评级**: 低危
**修复建议**: 对 `seg_len` 做上限：`seg_len = min(seg_len, 200)`。

---

### 11.24 `Agent.handle_message` 中 `drive_result.tool_requests` 为空列表时 `request_text` 回退到 `user_input`（安全）

**文件**: `core/message_handler.py`
**行号**: 100
```python
request_text = drive_result.tool_requests[0].description if drive_result.tool_requests else user_input
```

**风险描述**: 当 `needs_external_tools=True` 但 `tool_requests` 为空列表时（理论上不应发生，但 `_parse_decision` 中 `needs_external_tools=bool(requests)` 保证了两者一致），`request_text` 回退到 `user_input`。安全。

**风险评级**: 安全

---

# 汇总统计

## 风险分布

| 风险等级 | 数量 | 占比 |
|---------|------|------|
| 高危 | 5 | 10.6% |
| 中危 | 18 | 38.3% |
| 低危 | 24 | 51.1% |
| 安全（已正确处理） | 21 | — |
| **总计发现** | **47** | **100%** |

## 按文件分布

| 文件 | 高危 | 中危 | 低危 |
|------|------|------|------|
| core/message_handler.py | 1 | 4 | 3 |
| core/agent.py | 0 | 1 | 4 |
| core/inner_drive.py | 0 | 1 | 1 |
| core/tool_agent.py | 0 | 1 | 2 |
| core/dispatcher.py | 0 | 0 | 2 |
| core/context_manager.py | 0 | 0 | 2 |
| core/provider.py | 0 | 0 | 1 |
| core/personality.py | 0 | 0 | 1 |
| core/cli_controller.py | 0 | 1 | 0 |
| core/proactivity.py | 0 | 0 | 1 |
| core/sleep_manager.py | 0 | 0 | 3 |
| memory/short_term.py | 0 | 2 | 1 |
| memory/retrieval.py | 0 | 1 | 1 |
| memory/consolidation.py | 0 | 0 | 2 |
| tools/web_tools.py | 0 | 0 | 2 |
| tools/file_tools.py | 0 | 0 | 1 |
| tools/music_tool.py | 0 | 0 | 1 |
| tools/notify_tool.py | 0 | 1 | 0 |
| tools/traits.py | 0 | 0 | 0 |
| tools/memory_tools.py | 0 | 0 | 0 |
| tools/search_tools.py | 0 | 0 | 1 |
| models/personality.py | 0 | 1 | 2 |
| models/conversation.py | 0 | 0 | 0 |
| web/server.py | 1 | 2 | 3 |
| web/session.py | 0 | 1 | 1 |
| prompts/system.py | 0 | 0 | 1 |
| storage/repository.py | 0 | 0 | 2 |
| storage/database.py | 0 | 0 | 0 |
| config.py | 0 | 0 | 0 |

## 按维度分布

| 审查维度 | 高危 | 中危 | 低危 |
|---------|------|------|------|
| 空输入处理 | 0 | 4 | 2 |
| 超长输入处理 | 1 | 3 | 2 |
| 首次运行（无历史） | 0 | 0 | 3 |
| 无记忆时的处理 | 0 | 0 | 3 |
| 无工具注册时的处理 | 0 | 1 | 0 |
| 情绪饱和边界 | 0 | 1 | 4 |
| token估算为0或负数 | 0 | 0 | 2 |
| max_tokens动态调整为0 | 0 | 0 | 2 |
| 除零、越界访问 | 0 | 3 | 2 |
| 空集合迭代 | 0 | 0 | 3 |
| 其他边界条件 | 1 | 5 | 5 |

## 关键修复优先级

### P0（立即修复）
1. `core/message_handler.py:64` — `handle_message` 超长输入无截断（高危）
2. `web/server.py:223` — WebSocket 消息无长度限制（高危）

### P1（本周修复）
3. `core/message_handler.py:64` — `handle_message` 空输入未拦截（中危）
4. `core/cli_controller.py:121` — CLI 空输入被当作正常处理（中危）
5. `web/server.py:224` — WebSocket 空消息未返回错误（中危）
6. `memory/short_term.py:51` — `format_for_prompt` 超长单条历史截断漏洞（中危）
7. `models/personality.py:170` — `joy_ceiling` 可能为负数（中危）
8. `memory/retrieval.py:204` — `_llm_rerank` 越界索引（中危）
9. `tools/notify_tool.py:50` — PowerShell 命令注入（中危）
10. `memory/short_term.py:38` — `get_recent` 负数 k 行为异常（中危）

### P2（后续优化）
11-47. 其余低危项，包括情绪值范围限制、token 估算优化、空集合处理增强、默认值持久化等。

---

*报告生成时间: 2026-05-31*
*审查人: Claude Code*
