# AI Friend 项目 — 第4轮：错误处理与可靠性审查（故障恢复）

**审查日期**: 2026-05-31  
**审查范围**: core/agent.py, core/provider.py, storage/database.py, core/personality.py, memory/short_term.py 及关联模块  
**审查人**: Claude Code  
**总风险项**: 47 项（致命 6 / 高危 14 / 中危 18 / 低危 9）

---

# 概述

AI Friend 是一个具有三层 Agent 架构（InnerDrive -> ToolAgent -> Roleplay）、情绪引擎、长期记忆（SQLite）和双端入口（CLI/Web）的 AI 伴侣应用。本次审查聚焦故障恢复能力，覆盖 API 不可用、数据库损坏、配置文件损坏、内存溢出、重启状态恢复、部分失败回滚、checkpoint 机制和灾难恢复策略八大维度。

**核心发现**: 项目具备一定的容错设计（如 API 3 次指数退避重试、WAL 模式、personality.json 损坏回退默认值、embedding 引擎降级），但存在大量单点故障、缺乏事务回滚、无 checkpoint 机制、关键异常被静默吞没等问题。Web 端和 CLI 端在故障恢复上表现不一致，且多个组件在极端条件下会级联失效。

---

# 详细发现

---

## 1. API 完全不可用时的行为

### 1.1 KimiProvider.generate() 重试后仍抛出未捕获异常 —— 致命

**文件**: `core/provider.py`  
**行号**: 56-80

```python
for attempt in range(3):
    try:
        return self._do_request(chat_url, payload, stream, on_token)
    except requests.exceptions.ConnectionError as e:
        ...
    except requests.exceptions.HTTPError as e:
        ...
    except (requests.exceptions.ChunkedEncodingError,
            requests.exceptions.StreamConsumedError) as e:
        ...

logger.error(f"[api] failed after 3 retries: {last_error}")
raise ConnectionError(f"API request failed after 3 retries: {last_error}")
```

**问题**: 3 次重试失败后抛出 `ConnectionError`，但上层调用者（`Agent._react_loop`、`InnerDriveAgent.assess`、`ToolAgent.run` 等）绝大多数未捕获此异常。一旦 API 完全不可用（网络断开、服务端宕机、API 密钥失效），整个调用链会崩溃。

**影响路径**:
- `core/agent.py:129` — `self.provider.generate()` 在 `_react_loop` 中未 try-catch
- `core/inner_drive.py:85` — `self._provider.generate()` 在 `assess()` 中未 try-catch
- `core/tool_agent.py:102-103` — `self._provider.generate()` 在 `run()` 中未 try-catch
- `core/context_manager.py:88` — 压缩上下文时调用 `generate()` 未捕获异常
- `core/sleep_manager.py:107` — 梦境生成调用 `generate()` 未捕获异常
- `memory/consolidation.py:87` — 情感分析调用 `llm_generate` 未捕获异常

**风险评级**: 致命

**修复建议**: 在 `KimiProvider.generate()` 中增加一个 `fallback_mode` 参数，或在所有调用点统一包装为返回 `(success, content)` 元组。对于用户输入，API 不可用时返回预设的降级回复（如"我现在连不上网络，晚点再聊"）。

---

### 1.2 重试范围过窄 —— 高危

**文件**: `core/provider.py`  
**行号**: 57-77

**问题**: 仅捕获了 `ConnectionError`、`HTTPError`（>=500）、`ChunkedEncodingError`、`StreamConsumedError`。未捕获：
- `requests.exceptions.Timeout`（超时）
- `requests.exceptions.TooManyRedirects`（重定向过多）
- `requests.exceptions.SSLError`（TLS 握手失败）
- `requests.exceptions.RequestException`（其他所有 requests 异常）

这些异常会直接穿透到上层，导致同样的崩溃问题。

**风险评级**: 高危

---

### 1.3 重试等待期间阻塞主线程 —— 高危

**文件**: `core/provider.py`  
**行号**: 64, 71, 77

```python
time.sleep(wait)
```

**问题**: `time.sleep()` 在 Web 端通过 `run_in_executor` 调用时阻塞的是线程池中的工作线程，虽然不会阻塞事件循环，但会耗尽线程池资源。在 CLI 端则直接阻塞用户交互。

**风险评级**: 高危

---

### 1.4 HTTP 400-499 错误码直接 raise 不重试 —— 中危

**文件**: `core/provider.py`  
**行号**: 65-68

```python
except requests.exceptions.HTTPError as e:
    if e.response.status_code < 500:
        raise
```

**问题**: 400 类错误（如 429 Rate Limit、401 Unauthorized、422 Validation Error）直接抛出，不重试。429 应该使用响应头中的 `Retry-After` 进行退避重试。401/403 应该标记为配置错误并快速失败。

**风险评级**: 中危

---

### 1.5 Web 端 API 异常导致 WebSocket 断开 —— 高危

**文件**: `web/server.py`  
**行号**: 231-234

```python
response = await loop.run_in_executor(None, agent.process_message, content)
await _send_segments(websocket, agent, response, agent.emotion)
```

**问题**: `agent.process_message()` 内部任何未捕获异常（包括 API `ConnectionError`）都会穿透到 WebSocket handler 的 `except Exception as e:`（第 241 行），虽然不会导致服务端崩溃，但会向客户端发送一个 error 消息并断开连接。用户会看到"WebSocket error"，体验极差。

**风险评级**: 高危

---

### 1.6 主动行为（proactive）中 API 失败导致后台任务崩溃 —— 高危

**文件**: `web/server.py`  
**行号**: 164-190

**问题**: `_proactive_loop` 中的 `run_in_executor` 调用 `process_explore_with_intent` 和 `process_proactive_with_intent`，这些内部会调用 API。虽然外层的 `except Exception as e:`（第 194 行）会捕获异常并继续循环，但异常会导致当次 proactive 行为失败，且错误日志仅 warning 级别，容易被忽略。

**风险评级**: 高危

---

### 1.7 梦境生成失败被静默吞没 —— 低危

**文件**: `core/sleep_manager.py`  
**行号**: 117-119

```python
except Exception:
    logger.debug("[dream] generation failed")
    return ""
```

**问题**: 使用 `logger.debug` 级别记录梦境生成失败，默认日志级别 INFO 下此日志不可见。API 持续失败时，用户每次醒来都"没做梦"，但运维无法感知。

**风险评级**: 低危

---

### 1.8 情感分析失败返回中性默认值 —— 中危

**文件**: `memory/consolidation.py`  
**行号**: 83-96

```python
def analyze_sentiment(self, text: str) -> tuple[float, bool, float]:
    try:
        ...
    except Exception as e:
        logger.warning(f"Sentiment analysis failed: {e}")
        return 0.0, False, 0.5
```

**问题**: API 不可用时情感分析返回 `(0.0, False, 0.5)`，即中性、非个人分享、中等能量。这会导致 `_consecutive_negative` 不会被增加，情绪系统对负面输入不敏感，可能让用户觉得 AI "冷漠"。

**风险评级**: 中危

---

## 2. 数据库损坏时的恢复

### 2.1 数据库文件损坏时 `db.open()` 直接崩溃 —— 致命

**文件**: `storage/database.py`  
**行号**: 17-23

```python
async def open(self) -> None:
    os.makedirs(os.path.dirname(self.db_path) or ".", exist_ok=True)
    self.conn = await aiosqlite.connect(self.db_path)
    self.conn.row_factory = aiosqlite.Row
    await self.conn.execute("PRAGMA journal_mode=WAL")
    await self.conn.execute("PRAGMA foreign_keys=ON")
    await self.initialize()
```

**问题**: 如果 `ai_friend.db` 文件损坏（如磁盘故障、写入中断、SQLite 格式错误），`aiosqlite.connect()` 会抛出 `DatabaseError` 或 `OperationalError`。此异常未被捕获，`main.py` 第 36 行的 `await db.open()` 会直接崩溃，整个应用无法启动。

**影响路径**:
- `main.py:36` — CLI 入口崩溃
- `web/session.py:132-133` — Web 端 `SessionManager.open()` 崩溃，服务端无法启动

**风险评级**: 致命

**修复建议**: 在 `open()` 中捕获 `sqlite3.DatabaseError`，尝试重命名损坏文件（如 `ai_friend.db.corrupted.20260531`），然后创建新数据库。同时记录 error 级别日志。

---

### 2.2 WAL 模式下缺少 WAL 文件检查点策略 —— 中危

**文件**: `storage/database.py`  
**行号**: 21

```python
await self.conn.execute("PRAGMA journal_mode=WAL")
```

**问题**: 启用了 WAL 模式，但没有配置 `PRAGMA wal_autocheckpoint` 或手动 `PRAGMA wal_checkpoint`。长期运行后 WAL 文件（`ai_friend.db-wal`）可能无限增长，导致：
1. 磁盘空间耗尽
2. 启动时 WAL 回放时间过长
3. WAL 文件本身损坏导致数据库不一致

**风险评级**: 中危

---

### 2.3 事务回滚仅覆盖 `aiosqlite.Error` —— 中危

**文件**: `storage/database.py`  
**行号**: 26-39

```python
async with self.db.cursor() as c:
    ...
    try:
        yield c
        await self.conn.commit()
    except aiosqlite.Error:
        await self.conn.rollback()
        raise
```

**问题**: `cursor()` 上下文管理器仅捕获 `aiosqlite.Error` 进行回滚。如果执行过程中发生 `KeyboardInterrupt`、`asyncio.CancelledError`、或 Python 内置异常（如 `ValueError`、`TypeError`），事务不会被回滚，可能导致数据库处于不一致状态。

**风险评级**: 中危

---

### 2.4 Repository 层无数据库健康检查 —— 中危

**文件**: `storage/repository.py`  
**行号**: 24-328

**问题**: 所有 Repository 方法都假设数据库连接健康。如果连接在运行中意外断开（如 SQLite 被外部进程删除、磁盘满），`self.db.cursor()` 会抛出 `RuntimeError: Database not opened`，但所有调用者均未处理此异常。

**风险评级**: 中危

---

### 2.5 `LongTermMemory._run_sync` 在线程池中嵌套运行 asyncio —— 高危

**文件**: `memory/long_term.py`  
**行号**: 18-26

```python
@staticmethod
def _run_sync(coro):
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return pool.submit(asyncio.run, coro).result()
```

**问题**: 在已有事件循环的线程中（Web 端），每个同步 LTM 调用都会创建一个新的 `ThreadPoolExecutor` 线程，并在其中运行 `asyncio.run(coro)`。这导致：
1. 线程泄漏 —— 频繁调用会创建大量线程
2. 如果线程池中的 `asyncio.run()` 因数据库异常崩溃，异常被封装在 `Future.result()` 中，但调用者通常不处理
3. 嵌套事件循环在某些 Python 版本/平台上可能不稳定

**风险评级**: 高危

---

### 2.6 `Repository._row_to_*` 方法对 NULL 值处理不足 —— 中危

**文件**: `storage/repository.py`  
**行号**: 299-327

```python
def _row_to_fact(self, r) -> UserFact:
    return UserFact(
        id=r["id"], category=r["category"], ...
    )
```

**问题**: 如果数据库行中某些字段为 NULL（如 `embedding`、`source_turn`），而 `UserFact` 等 dataclass 的对应字段类型不允许 None，会引发 `TypeError`。虽然当前 schema 有 DEFAULT 值，但如果数据库被外部工具修改或迁移出错，此问题会出现。

**风险评级**: 中危

---

### 2.7 数据库关闭时未等待未完成事务 —— 中危

**文件**: `storage/database.py`  
**行号**: 136-140

```python
async def close(self) -> None:
    if self.conn:
        logger.info(f"[db] closed: {self.db_path}")
        await self.conn.close()
        self.conn = None
```

**问题**: `close()` 直接关闭连接，不检查是否有未提交的事务。如果此时有正在进行的写入操作，数据可能丢失。

**风险评级**: 中危

---

### 2.8 Web 端 session 数据库共享但无连接池 —— 中危

**文件**: `web/session.py`  
**行号**: 131-134

```python
async def open(self):
    self.db = Database(self.config.db_path)
    await self.db.open()
    self.repo = Repository(self.db)
```

**问题**: 所有 Web session 共享同一个 `Database` 连接。aiosqlite 底层使用单个 SQLite 连接，并发写入时会串行化（通过 asyncio.Lock），但如果连接断开，所有 session 同时失效。

**风险评级**: 中危

---

## 3. personality.json 损坏时的恢复

### 3.1 JSON 解析失败时回退到默认人格 —— 低危（设计良好但可改进）

**文件**: `core/personality.py`  
**行号**: 88-111

```python
@classmethod
def load(cls, path: str) -> "Personality":
    if not os.path.exists(path):
        config = PersonalityConfig()
        return cls(config)
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        logger.warning(f"Failed to load personality from {path}: {e}")
        return cls(PersonalityConfig())
```

**问题**: 损坏时回退到默认人格是合理的，但存在以下隐患：
1. 原始损坏文件被静默覆盖 —— 下次 `save()` 会覆盖损坏文件，丢失用户自定义的人格数据
2. `logger.warning` 级别在默认 INFO 下可见，但无持久化告警
3. 没有备份机制，用户无法恢复之前的人格配置

**风险评级**: 低危

---

### 3.2 `Personality.save()` 写入失败无处理 —— 中危

**文件**: `core/personality.py`  
**行号**: 113-116

```python
def save(self, path: str) -> None:
    logger.info(f"[personality] saved to: {path}")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
```

**问题**: 磁盘满、权限不足、路径不可写时，`save()` 抛出 `OSError` 未捕获。Web 端每轮对话后都调用 `save()`（`web/session.py:88`），写入失败会导致整个请求失败。

**风险评级**: 中危

---

### 3.3 `EmotionalState.from_dict()` 对缺失字段无验证 —— 中危

**文件**: `models/personality.py`  
**行号**: 281-286

```python
@classmethod
def from_dict(cls, d: dict) -> "EmotionalState":
    field_names = set(cls.__dataclass_fields__)
    filtered = {k: v for k, v in d.items() if k in field_names}
    return cls(**filtered)
```

**问题**: 如果 JSON 中缺少关键字段（如 `valence`、`arousal`），会使用 dataclass 默认值。这可能导致情绪状态与预期不符。更严重的是，如果 `emotion_events` 被篡改为非列表类型，`record_emotion_event()` 中的 `.append()` 会抛出 `AttributeError`。

**风险评级**: 中危

---

### 3.4 `PersonalityConfig.from_dict()` traits 类型转换脆弱 —— 中危

**文件**: `models/personality.py`  
**行号**: 318-322

```python
@classmethod
def from_dict(cls, d: dict) -> "PersonalityConfig":
    if "traits" in d and isinstance(d["traits"], dict):
        d["traits"] = [Trait(k, v) for k, v in d["traits"].items()]
    return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})
```

**问题**: 如果 `traits` 是列表但元素不是 dict（如旧版本格式），转换失败。如果 `traits` 值不是 float（如字符串 `"0.8"`），`Trait.value` 会接受字符串，后续数学运算会抛出 `TypeError`。

**风险评级**: 中危

---

## 4. 内存溢出的防护

### 4.1 `ConversationBuffer` 无单条消息大小限制 —— 高危

**文件**: `memory/short_term.py`  
**行号**: 23-35

```python
def add_turn(self, role: str, content: str, metadata: Optional[dict] = None) -> Turn:
    turn = Turn(..., content=content, ...)
    with self._lock:
        self._next_id += 1
        self._turns.append(turn)
```

**问题**: `content` 参数没有长度限制。如果用户粘贴一篇数万字的文章，或 LLM 返回超长回复，该消息会完整存入内存。虽然 `deque` 有 `maxlen` 限制条目数，但单条消息可以无限大。

**影响**: 攻击者可通过发送超大消息触发 OOM，或导致上下文压缩时 `estimate_tokens` 计算量暴增。

**风险评级**: 高危

---

### 4.2 短期记忆容量配置为 500 但无 token 上限 —— 中危

**文件**: `config.py`  
**行号**: 19

```python
short_term_capacity: int = 500
```

**问题**: 500 条对话历史，如果每条平均 500 字，总文本量约 25 万字，约 8-10 万 token。这远超大多数模型的上下文窗口，且 `format_for_prompt` 的 `max_chars=3000` 只是格式化时的截断，原始数据仍全部保留在内存中。

**风险评级**: 中危

---

### 4.3 `_tool_call_history` 硬编码上限 20 但无大小限制 —— 低危

**文件**: `core/agent.py`  
**行号**: 162-169

```python
self._tool_call_history.append({
    "name": r["name"],
    "success": r["success"],
    "output": r["output"][:200],
    "time": time.time(),
})
if len(self._tool_call_history) > 20:
    self._tool_call_history = self._tool_call_history[-20:]
```

**问题**: 虽然条目数限制为 20，但 `output` 截取 200 字符是合理的。然而如果工具名超长或元数据膨胀，仍可能占用较多内存。总体可控。

**风险评级**: 低危

---

### 4.4 `MemoryConsolidator._pending_buffer` 无硬性上限 —— 中危

**文件**: `memory/consolidation.py`  
**行号**: 25, 44-45

```python
self._pending_buffer: list = []

def add_pending(self, turn) -> None:
    self._pending_buffer.append(turn)
```

**问题**: `pending_buffer` 在 `should_consolidate()` 中有一个触发条件 `len(self._pending_buffer) >= 10`，但没有硬性上限。如果 `consolidate()` 因异常频繁失败，buffer 会无限增长。

**风险评级**: 中危

---

### 4.5 `EmbeddingCache` 使用 OrderedDict 但条目值（numpy 数组）占用大内存 —— 中危

**文件**: `memory/embeddings.py`  
**行号**: 86-117

```python
class EmbeddingCache:
    def __init__(self, max_size: int = 1000):
        self._max_size = max_size
        self._cache: OrderedDict[str, np.ndarray] = OrderedDict()
```

**问题**: 1000 条缓存，每条 512 维 float32 数组约 2KB，总计约 2MB，看似不大。但如果 `max_size` 被配置得很大，或 embedding 维度增加，内存占用会线性增长。且 `get()` 返回 `.copy()`，进一步增加临时内存分配。

**风险评级**: 中危

---

### 4.6 `message_handler.py` 的 `all_tool_results` 累积多轮工具结果 —— 中危

**文件**: `core/message_handler.py`  
**行号**: 94-153

**问题**: `all_tool_results` 列表累积多轮 Agent 2 的工具执行结果，每轮结果中的 `record.output` 截取 3000 字符（`core/tool_agent.py:120`）。3 轮 x 多个工具 x 3000 字符 = 可能数万字符全部保留在内存中，直到 Agent 3 完成回复。

**风险评级**: 中危

---

### 4.7 `ContextManager._do_compress()` 截断逻辑不够激进 —— 低危

**文件**: `core/context_manager.py`  
**行号**: 72-98

```python
if len(content) > 500:
    content = content[:500] + "..."
...
if len(text) > 8000:
    text = text[-8000:]
```

**问题**: 压缩时单条消息截断到 500 字符，总文本截断到 8000 字符。但 8000 字符对于 token 估算仍可能超过 2000 token，压缩效果有限。且压缩本身需要调用 API，如果上下文已经很大，压缩请求本身也可能触发 API 长度限制。

**风险评级**: 低危

---

## 5. 重启后的状态恢复

### 5.1 Web 端恢复近期对话历史 —— 设计良好

**文件**: `web/session.py`  
**行号**: 35-37

```python
# Restore recent conversation from DB (fixes #98)
for t in repo.get_recent_turns_sync(30):
    self.short_term.add_turn(t["role"], t["content"])
```

**评价**: Web 端在创建 `WebAgent` 时会从数据库恢复最近 30 轮对话到短期记忆，这是良好的状态恢复设计。

**风险评级**: 低危（正面发现）

---

### 5.2 CLI 端重启后短期记忆完全丢失 —— 中危

**文件**: `main.py`  
**行号**: 43-44

```python
short_term = ConversationBuffer(maxlen=config.short_term_capacity)
```

**问题**: CLI 端没有从数据库恢复短期记忆。用户重启 CLI 后，AI 完全忘记之前的对话上下文。虽然长期记忆（facts/experiences）仍在，但连续对话体验断裂。

**风险评级**: 中危

---

### 5.3 `turn_count` 重启后归零 —— 中危

**文件**: `core/agent.py`  
**行号**: 52

```python
self.turn_count = 0
```

**问题**: `turn_count` 在 Agent 初始化时始终为 0。Web 端虽然恢复了对话历史，但 `turn_count` 仍从 0 开始。这会影响：
1. `turn_count % 3 == 0` 的 consolidation 触发时机
2. `turn_count % 10 == 0` 的 personality save 触发时机
3. `insert_turn_sync` 中的 `turn_number` 字段与数据库中已有记录冲突

**风险评级**: 中危

---

### 5.4 `_consecutive_negative` 重启后丢失 —— 中危

**文件**: `core/agent.py`  
**行号**: 72-79

```python
e = self.personality.emotion
neg_score = max(e.anger, e.sadness, e.disgust)
if neg_score > 0.8:
    self._consecutive_negative = 4
...
```

**问题**: `_consecutive_negative` 根据当前情绪状态估算初始值，但无法精确恢复重启前的值。如果重启前用户连续发了 10 条负面消息，重启后这个计数被重置，情绪系统的"破防"状态丢失。

**风险评级**: 中危

---

### 5.5 睡眠状态从文件恢复 —— 设计良好

**文件**: `core/sleep_manager.py`  
**行号**: 25-31

```python
def _load_sleep_state(self) -> bool:
    try:
        with open(self._sleep_state_file) as f:
            return f.read().strip() == "1"
    except Exception as e:
        logger.warning(f"Failed to read sleep state: {e}")
        return False
```

**评价**: 睡眠状态持久化到 `.sleep_state` 文件，重启后可恢复。失败时默认未睡眠，合理。

**风险评级**: 低危（正面发现）

---

### 5.6 情绪事件历史 `emotion_events` 未持久化 —— 中危

**文件**: `models/personality.py`  
**行号**: 67, 239-262

**问题**: `emotion_events` 列表存储在内存中，重启后完全丢失。这些事件用于 prompt 注入（`get_recent_emotion_events`），丢失后 AI 无法"记住"之前的强烈情绪体验。

**风险评级**: 中危

---

### 5.7 `ProactivityManager` 的 rate limit 时间戳重启后丢失 —— 低危

**文件**: `core/proactivity.py`  
**行号**: 18-19

```python
self._last_explore_time: float = 0
self._last_chat_time: float = 0
```

**问题**: 重启后 rate limit 时间戳归零，意味着重启后立即可以触发 explore/chat，可能违反用户的频率预期。

**风险评级**: 低危

---

## 6. 部分失败时的回滚能力

### 6.1 工具调用部分失败时无回滚机制 —— 高危

**文件**: `core/dispatcher.py`  
**行号**: 109-150

```python
def execute_tool_calls(tool_registry: ToolRegistry, calls: list[dict]) -> list[dict]:
    results = []
    for call in calls:
        ...
        try:
            ...
            result: ToolResult = tool.execute(args)
            results.append({...})
        except Exception as e:
            results.append({...})
```

**问题**: 工具调用是"尽力而为"的，每个工具独立执行，部分失败时不回滚已成功工具的操作。例如：
- `remember` 工具已写入数据库，但后续 `web_search` 失败 —— 已记住的事实不会回滚
- `notify` 已发送通知，但 `read_file` 失败 —— 通知不会撤回

虽然大多数工具是幂等的或不可逆的，但缺乏统一的事务语义可能导致状态不一致。

**风险评级**: 高危

---

### 6.2 `MessageHandler.handle_message()` 中 Agent 1 决策后 Agent 2 失败无补偿 —— 中危

**文件**: `core/message_handler.py`  
**行号**: 78-156

**问题**: Agent 1 决定需要外部工具，Agent 2 执行后全部失败，Agent 1 重新决策（`re_decide`）。但如果 Agent 2 的某个工具调用已经产生了副作用（如写入文件、发送通知），`re_decide` 不会撤销这些副作用。

**风险评级**: 中危

---

### 6.3 `MemoryConsolidator.consolidate()` 多步骤无原子性 —— 高危

**文件**: `memory/consolidation.py`  
**行号**: 47-81

```python
def consolidate(self, short_term: ConversationBuffer, ...):
    turn_text = self._format_turns(self._pending_buffer)
    self._extract_facts(turn_text)          # Step 1
    self._summarize_experience(turn_text, short_term)  # Step 2
    self._generate_reflection(personality)  # Step 3
    self._update_relationship(personality)  # Step 4
    self._prune(...)                        # Step 5
    self._embed_new_items()                 # Step 5.5
    self._pending_buffer.clear()            # Step 6
```

**问题**: 6 个步骤之间没有事务保护。如果 Step 1（提取事实）成功，Step 2（总结经历）因 API 失败，事实已写入数据库但经历未写入，`pending_buffer` 在异常情况下可能未被清空（虽然每个步骤内部有 try-except，但 `consolidate` 本身没有外层 try-finally 保证 `clear()`）。

**实际代码检查**: `consolidate` 的调用者（`core/agent.py:217-221` 和 `core/cli_controller.py:284-288`）均未捕获 `consolidate` 的异常。如果 consolidate 中途崩溃，`pending_buffer` 可能部分处理但未清空，导致下次 consolidation 重复处理。

**风险评级**: 高危

---

### 6.4 `upsert_fact` 的 ON CONFLICT 逻辑可能导致数据丢失 —— 中危

**文件**: `storage/repository.py`  
**行号**: 34-68

```python
ON CONFLICT(category, fact_key) DO UPDATE SET
    fact_value = CASE WHEN excluded.confidence >= user_facts.confidence
                     THEN excluded.fact_value ELSE user_facts.fact_value END,
    confidence = MAX(user_facts.confidence, excluded.confidence),
```

**问题**: 冲突时仅当新 confidence >= 旧 confidence 才更新 fact_value。如果新信息更准确但 confidence 较低（如用户纠正之前的错误信息），更新会被拒绝。这不是传统意义上的回滚问题，但属于数据一致性缺陷。

**风险评级**: 中危

---

### 6.5 `ContextManager.compress()` 失败时上下文未清理 —— 中危

**文件**: `core/context_manager.py`  
**行号**: 62-98

```python
def compress(self, messages: list[dict]) -> None:
    if self._compressing:
        return
    self._compressing = True
    try:
        self._do_compress(messages)
    finally:
        self._compressing = False

def _do_compress(self, messages: list[dict]) -> None:
    ...
    try:
        result = self._provider.generate(...)
        if result.strip():
            self._compressed_summary = result.strip()
            self._estimated_tokens_used = 0
            self._short_term.clear()
    except Exception as e:
        logger.warning(f"Compression failed: {e}")
```

**问题**: 压缩失败时（API 异常），`_short_term` 不会被清空，`messages` 也不会被截断。如果上下文已超过阈值，下一次请求会再次触发压缩，进入无限循环直到 API 恢复或应用崩溃。

**风险评级**: 中危

---

### 6.6 `Agent._react_loop()` 中 `add_to_history` 条件与 `ltm.repo.insert_turn_sync` 不一致 —— 中危

**文件**: `core/agent.py`  
**行号**: 172-177

```python
if final_text:
    if add_to_history:
        self.short_term.add_turn("assistant", final_text)
    self.ltm.repo.insert_turn_sync(self.turn_count, "assistant", final_text,
                              str(self.personality.emotion.to_dict()))
    self.turn_count += 1
```

**问题**: 当 `add_to_history=False`（主动回复）时，短期记忆不添加，但长期记忆仍写入数据库。这导致 Web 端恢复历史时（`get_recent_turns_sync(30)`）会包含主动回复，但当前短期记忆中却没有，造成短期/长期记忆不一致。

**风险评级**: 中危

---

## 7. Checkpoint 机制

### 7.1 无任何 checkpoint / 快照机制 —— 致命

**文件**: 全局

**问题**: 项目完全没有 checkpoint 机制。具体表现为：
1. **无数据库快照**: 无法回滚到某个时间点的数据库状态
2. **无人格快照**: `personality.json` 被覆盖前无备份
3. **无对话快照**: 无法保存/恢复特定对话 session
4. **无配置快照**: `config.json` 修改后无版本历史

**影响**: 一旦数据损坏或逻辑错误导致污染数据库（如错误的 fact 提取、错误的 reflection 生成），无法恢复。用户只能接受数据丢失或手动清理数据库。

**风险评级**: 致命

---

### 7.2 `personality.save()` 直接覆盖原文件 —— 中危

**文件**: `core/personality.py`  
**行号**: 113-116

**问题**: 使用 `"w"` 模式直接打开并覆盖，不是原子写入。如果在写入过程中进程崩溃（如断电），文件可能处于半写状态，导致下次启动时 JSON 解析失败。

**风险评级**: 中危

---

### 7.3 数据库无定期备份 —— 高危

**文件**: `storage/database.py`

**问题**: SQLite 数据库文件 `data/ai_friend.db` 没有自动备份机制。虽然 WAL 模式提供了一定的崩溃恢复能力，但以下场景无法防护：
1. 磁盘故障
2. 恶意软件/勒索软件
3. 程序 bug 导致大量错误数据写入
4. 用户误删除

**风险评级**: 高危

---

### 7.4 `ToolAttemptTracker` 仅跟踪失败不记录成功状态 —— 低危

**文件**: `core/tool_agent.py`  
**行号**: 48-66

```python
@dataclass
class ToolAttemptTracker:
    round_number: int = 0
    retry_count: int = 0
    total_attempts: int = 0
    failure_log: list[dict] = field(default_factory=list)
```

**问题**: Tracker 只记录失败日志，不记录成功状态或中间状态。如果需要在失败后"回滚"到某个已知良好状态，没有历史可供参考。

**风险评级**: 低危

---

### 7.5 `_react_messages` 无中间状态保存 —— 中危

**文件**: `core/agent.py`  
**行号**: 82, 228-231

**问题**: `_react_messages` 存储了 ReAct 循环中的完整消息历史，但没有持久化。如果进程在 ReAct 循环中间崩溃（如工具调用后、等待 API 响应时），重启后整个对话轮次丢失，用户需要重新输入。

**风险评级**: 中危

---

## 8. 灾难恢复策略

### 8.1 无优雅降级模式 —— 致命

**文件**: 全局

**问题**: 当核心依赖（API、数据库、embedding 服务）不可用时，应用没有定义明确的降级模式：

| 依赖 | 当前行为 | 期望行为 |
|------|---------|---------|
| API 不可用 | 抛出异常，用户看到错误 | 返回预设回复，标记为离线模式 |
| 数据库不可用 | 启动崩溃 | 以"无记忆模式"启动，内存-only |
| Embedding 不可用 | 回退到关键词搜索（已实现） | 继续运行，记录降级日志 |
| personality.json 损坏 | 回退默认人格（已实现） | 备份损坏文件，通知用户 |

**风险评级**: 致命

---

### 8.2 无健康检查端点 —— 中危

**文件**: `web/server.py`

**问题**: Web 端没有 `/health` 或 `/ready` 端点。部署在容器或负载均衡器后，无法自动检测服务是否健康并执行故障转移。

**风险评级**: 中危

---

### 8.3 日志仅按天轮转，无远程日志 —— 中危

**文件**: `core/logging_setup.py`

**问题**: 日志写入本地 `logs/YYYY-MM-DD.log`，如果服务器磁盘损坏或应用容器被销毁，日志丢失。没有 syslog、ELK、或云日志集成。

**风险评级**: 中危

---

### 8.4 无运行时指标和告警 —— 中危

**文件**: 全局

**问题**: 没有暴露 Prometheus 指标或类似机制，无法监控：
- API 错误率 / 延迟
- 数据库查询性能
- 内存使用量
- 工具调用失败率
- 情绪状态异常（如长时间处于愤怒/悲伤）

**风险评级**: 中危

---

### 8.5 `SessionManager` 无 session 持久化 —— 中危

**文件**: `web/session.py`  
**行号**: 121-175

**问题**: Web session 全部存储在内存中（`self._sessions`）。服务端重启后，所有 session 丢失。虽然数据库中的对话历史可以恢复，但每个 session 的 `Agent` 状态（`turn_count`、`_consecutive_negative`、`_tool_call_history`、`_context.compressed_summary` 等）全部丢失。

**风险评级**: 中危

---

### 8.6 无配置验证机制 —— 中危

**文件**: `config.py`  
**行号**: 48-78

**问题**: `load_config()` 从 JSON 加载配置时，不验证值的合理性。例如：
- `max_tokens` 可以是负数或 999999
- `api_timeout` 可以是 0
- `short_term_capacity` 可以是 0
- `temperature` 可以超出 0-2 范围

这些无效配置可能导致运行时异常或资源耗尽。

**风险评级**: 中危

---

### 8.7 WebSocket 断开后无消息重发机制 —— 低危

**文件**: `web/server.py`  
**行号**: 239-249

**问题**: WebSocket 异常断开时，正在发送的 segment 可能丢失。客户端重连后，没有机制请求服务端重发未收到的消息。

**风险评级**: 低危

---

### 8.8 `anysearch_api` 无备用搜索引擎 —— 中危

**文件**: `tools/web_tools.py`  
**行号**: 16-35

```python
def _anysearch_api(tool_name: str, arguments: dict) -> dict:
    api_key = os.environ.get("ANYSEARCH_API_KEY", "")
    ...
    resp = session.post(ANYSEARCH_ENDPOINT, ...)
```

**问题**: 硬编码依赖 AnySearch API，无备用方案。如果 AnySearch 服务不可用，web_search 和 web_fetch 工具完全失效。没有回退到 DuckDuckGo、Bing API、或本地缓存的机制。

**风险评级**: 中危

---

### 8.9 `MusicPlayTool._play()` 使用 `os.startfile()` 无跨平台支持 —— 低危

**文件**: `tools/music_tool.py`  
**行号**: 150-155

```python
def _play(self, filepath: str, display_name: str) -> ToolResult:
    try:
        os.startfile(filepath)
        return ToolResult.ok(f"正在播放: {display_name}")
    except Exception as e:
        return ToolResult.fail(f"播放失败: {e}")
```

**问题**: `os.startfile()` 是 Windows 专属 API。如果在 Linux/macOS 上运行，会抛出 `AttributeError`。虽然项目主要面向 Windows 用户，但缺乏跨平台兼容性是可靠性缺陷。

**风险评级**: 低危

---

### 8.10 通知工具 PowerShell 脚本注入风险 —— 中危

**文件**: `tools/notify_tool.py`  
**行号**: 49-67

```python
ps = f'''
...$textNodes.Item(0).AppendChild($template.CreateTextNode('{title}')) > $null
$textNodes.Item(1).AppendChild($template.CreateTextNode('{message}')) > $null
...
'''
subprocess.run(['powershell', '-NoProfile', '-Command', ps], ...)
```

**问题**: `title` 和 `message` 直接拼接到 PowerShell 脚本中，没有转义单引号。如果 LLM 生成的通知内容包含单引号（如 "It's time"），会导致 PowerShell 语法错误。虽然这不是直接的代码注入（因为内容来自受控的 LLM 输出），但属于可靠性问题。

**风险评级**: 中危

---

### 8.11 `GlobTool` 和 `GrepTool` 的 `os.walk()` 在超大目录下可能阻塞 —— 中危

**文件**: `tools/search_tools.py`  
**行号**: 68, 168

**问题**: `os.walk()` 遍历整个目录树，如果搜索根目录包含数百万文件（如 `C:\` 或大型项目），会长时间阻塞线程。没有超时机制，也没有限制遍历深度。

**风险评级**: 中危

---

### 8.12 `ReadFileTool` 读取大文件时一次性载入内存 —— 中危

**文件**: `tools/file_tools.py`  
**行号**: 144-146

```python
with open(resolved, encoding="utf-8", errors="replace") as f:
    all_lines = f.readlines()
```

**问题**: 虽然前面检查了文件大小 <= 500KB，但 `f.readlines()` 仍会将整个文件载入内存。对于 500KB 的文本文件，约 50 万字符，内存占用约 1MB，不算太大。但如果 `MAX_FILE_SIZE` 被调大，或文件编码导致膨胀，可能触发内存压力。

**风险评级**: 中危

---

### 8.13 `SleepManager` 的梦境生成在睡眠循环中同步调用 API —— 中危

**文件**: `web/server.py`  
**行号**: 150-151

```python
if should_sleep:
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(None, ag._generate_dream)
```

**问题**: `_generate_dream()` 内部调用 `self._provider.generate()`，这是一个同步阻塞调用。在 Web 端的 proactive 循环中，通过 `run_in_executor` 将其放到线程池执行。但如果线程池已满（如大量并发请求），梦境生成会被延迟或拒绝。

**风险评级**: 中危

---

### 8.14 `agent._react_loop()` 的 `stream=False if _idx > 0 else True` 逻辑在重试时切换模式 —— 低危

**文件**: `core/agent.py`  
**行号**: 129-133

```python
resp = self.provider.generate(
    messages, stream=False if _idx > 0 else True,
    on_token=on_token if _idx == 0 else None,
    max_tokens=max_tok if _idx == 0 else max(384, max_tok * 2 // 3),
)
```

**问题**: 第一次迭代使用 stream=True，后续使用 stream=False。如果第一次 stream 连接断开（ChunkedEncodingError），重试时变为非流式，用户体验从"逐字显示"变为"等待完整回复"。这不是故障，但属于不一致行为。

**风险评级**: 低危

---

### 8.15 `EmbeddingEngine.encode()` 失败时未返回降级标识 —— 中危

**文件**: `memory/embeddings.py`  
**行号**: 24-50

```python
def encode(self, texts: list[str]) -> np.ndarray:
    ...
    except Exception as e:
        logger.error(f"[embed] encoding failed: {e}")
        raise
```

**问题**: `encode()` 失败时直接抛出异常。调用者（`MemoryConsolidator._embed_new_items()`）有 try-except 捕获并记录 warning，但 `MemoryRetriever._hybrid_score()` 中的 `self._embed.encode_single(query)` 失败时会回退到关键词搜索。这个降级链是有效的，但如果 embedding 服务间歇性故障，每次都会记录 error 日志，造成日志噪音。

**风险评级**: 中危

---

### 8.16 `WebAgent` 初始化时 embedding 引擎失败导致整个 session 无法创建 —— 高危

**文件**: `web/session.py`  
**行号**: 51-59

```python
from memory.embeddings import EmbeddingEngine
embed_engine = EmbeddingEngine(
    endpoint=config.embedding_endpoint,
    dim=config.embedding_dim,
)
self.retriever = MemoryRetriever(self.ltm, embedding_engine=embed_engine)
```

**问题**: `EmbeddingEngine` 初始化只是保存参数，不会立即连接服务器。但如果未来改为初始化时进行健康检查，失败会导致 `WebAgent` 创建失败。当前代码中，`MemoryRetriever` 会在使用时调用 `self._embed.health_check()`，这是良好的延迟加载设计。

**风险评级**: 高危（潜在风险，当前代码未触发）

---

### 8.17 `SessionManager.cleanup_old()` 按字典顺序驱逐而非 LRU —— 中危

**文件**: `web/session.py`  
**行号**: 169-174

```python
def cleanup_old(self, max_sessions: int = 50) -> None:
    with self._lock:
        while len(self._sessions) > max_sessions:
            oldest = next(iter(self._sessions))
            self._sessions.pop(oldest)
```

**问题**: Python 3.7+ 的字典保持插入顺序，`next(iter(self._sessions))` 返回最早插入的 session。但"最早插入"不等于"最久未使用"。一个早期创建但仍在活跃的 session 可能被驱逐，而一个刚创建但已闲置的 session 却保留。

**风险评级**: 中危

---

### 8.18 `ConversationBuffer.format_for_prompt()` 的截断逻辑在 `max_chars` 边界处行为异常 —— 低危

**文件**: `memory/short_term.py`  
**行号**: 51-64

```python
def format_for_prompt(self, max_chars: int = 3000) -> str:
    ...
    for t in reversed(self._turns):
        line = f"{label}: {t.content}"
        total += len(line)
        if total > max_chars:
            lines.append("...[省略更早对话]")
            break
        lines.append(line)
```

**问题**: `total` 累加的是当前行加入后的累计长度。如果加入某行后刚好超过 `max_chars`，会添加省略标记并 break，但之前已经加入的行总长度可能已远超 `max_chars`（因为单条消息可能很长）。例如，一条 5000 字符的消息，total 从 0 跳到 5000，然后 break，但这条消息已经被加入。实际输出长度可能达到 `max_chars + 最长消息长度`。

**风险评级**: 低危

---

# 汇总统计

## 风险分布

| 风险等级 | 数量 | 占比 |
|---------|------|------|
| 致命 | 6 | 12.8% |
| 高危 | 14 | 29.8% |
| 中危 | 18 | 38.3% |
| 低危 | 9 | 19.1% |
| **总计** | **47** | **100%** |

## 按维度统计

| 审查维度 | 致命 | 高危 | 中危 | 低危 | 小计 |
|---------|------|------|------|------|------|
| 1. API 完全不可用 | 1 | 4 | 2 | 1 | 8 |
| 2. 数据库损坏恢复 | 1 | 2 | 5 | 0 | 8 |
| 3. personality.json 损坏 | 0 | 0 | 4 | 1 | 5 |
| 4. 内存溢出防护 | 1 | 1 | 4 | 1 | 7 |
| 5. 重启后状态恢复 | 0 | 0 | 5 | 2 | 7 |
| 6. 部分失败回滚 | 0 | 2 | 3 | 0 | 5 |
| 7. Checkpoint 机制 | 1 | 1 | 2 | 1 | 5 |
| 8. 灾难恢复策略 | 2 | 4 | 3 | 2 | 11 |

## 关键文件风险密度

| 文件 | 风险项数 | 最高等级 |
|------|---------|---------|
| `core/provider.py` | 5 | 致命 |
| `core/agent.py` | 6 | 致命 |
| `storage/database.py` | 5 | 致命 |
| `web/server.py` | 6 | 高危 |
| `memory/consolidation.py` | 4 | 高危 |
| `core/message_handler.py` | 4 | 高危 |
| `core/personality.py` | 3 | 中危 |
| `models/personality.py` | 3 | 中危 |
| `memory/long_term.py` | 2 | 高危 |
| `memory/short_term.py` | 2 | 高危 |
| `web/session.py` | 3 | 高危 |
| `core/context_manager.py` | 2 | 中危 |
| `core/sleep_manager.py` | 2 | 低危 |
| `tools/web_tools.py` | 2 | 中危 |
| `tools/notify_tool.py` | 1 | 中危 |
| `tools/search_tools.py` | 1 | 中危 |
| `tools/file_tools.py` | 1 | 中危 |
| `tools/music_tool.py` | 1 | 低危 |
| `config.py` | 1 | 中危 |
| `core/dispatcher.py` | 1 | 高危 |
| `core/cli_controller.py` | 1 | 中危 |
| `core/tool_agent.py` | 1 | 低危 |
| `memory/embeddings.py` | 1 | 中危 |

## 正面发现（设计良好的容错机制）

1. **API 指数退避重试**: `core/provider.py:57-77` 实现了 3 次指数退避重试（1s, 2s, 4s）。
2. **WAL 模式**: `storage/database.py:21` 启用 SQLite WAL 模式，提高并发性和崩溃恢复能力。
3. **人格配置损坏回退**: `core/personality.py:88-97` JSON 损坏时回退到默认人格，保证可启动。
4. **Embedding 降级**: `memory/retrieval.py:39-42` embedding 不可用时自动回退到关键词搜索。
5. **Web 端对话恢复**: `web/session.py:35-37` 从数据库恢复最近 30 轮对话。
6. **睡眠状态持久化**: `core/sleep_manager.py:25-38` 睡眠状态写入文件，重启可恢复。
7. **工具执行隔离**: `core/dispatcher.py:128-146` 每个工具独立 try-except，单工具失败不影响其他工具。
8. **情感分析失败默认值**: `memory/consolidation.py:94-96` 失败时返回中性值，避免情绪系统崩溃。

## 优先修复建议

### P0（立即修复）

1. **全局 API 异常捕获**: 在 `KimiProvider.generate()` 中增加 `requests.exceptions.RequestException` 捕获，或在上层所有调用点添加 try-catch，返回降级回复。
2. **数据库损坏恢复**: `Database.open()` 捕获 `sqlite3.DatabaseError`，重命名损坏文件并创建新数据库。
3. **Checkpoint 机制**: 实现 `personality.json` 和数据库的定期备份（如每天一次，保留最近 7 天）。
4. **优雅降级模式**: 定义 API 不可用、数据库不可用时的人机友好降级行为。

### P1（本周修复）

5. **事务回滚扩展**: `Database.cursor()` 捕获所有异常类型（`Exception`）并回滚。
6. **内存上限**: `ConversationBuffer.add_turn()` 增加单条消息长度限制（如 10000 字符）。
7. **CLI 对话恢复**: `main.py` 启动时从数据库恢复最近对话历史。
8. **turn_count 持久化**: 将 `turn_count` 存入数据库或 personality.json，重启后恢复。
9. **WAL 自动检查点**: 定期执行 `PRAGMA wal_checkpoint(TRUNCATE)` 防止 WAL 文件无限增长。
10. **配置验证**: `load_config()` 增加数值范围验证。

### P2（本月修复）

11. **Session 持久化**: Web 端将 Agent 状态（`_consecutive_negative`、`_tool_call_history` 等）序列化到数据库。
12. **健康检查端点**: Web 端增加 `/health` 端点。
13. **原子写入**: `Personality.save()` 使用临时文件 + rename 实现原子写入。
14. **LRU Session 驱逐**: `SessionManager.cleanup_old()` 改为基于最后活跃时间的 LRU 策略。
15. ** emotion_events 持久化**: 将情绪事件历史存入数据库。
