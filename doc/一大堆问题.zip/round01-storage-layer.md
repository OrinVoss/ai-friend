# AI Friend 项目 — 存储层架构深度审查报告（Round 01）

**审查日期**：2026-05-31
**审查范围**：`storage/database.py`、`storage/repository.py` 及其上下游依赖
**审查者**：Claude Code（Sonnet 4.6）
**代码基线**：Git main 分支，commit `3c24cd3`

---

# 概述

AI Friend 的存储层由两个核心文件构成：`storage/database.py`（141 行）负责 SQLite 连接管理与 Schema 初始化，`storage/repository.py`（328 行）封装所有 CRUD 操作。底层驱动从 `sqlite3` 于 2026-05-31 迁移至 `aiosqlite`，并引入 `asyncio.Lock` 替代 `threading.Lock`。本次审查覆盖数据库连接管理、SQL 安全性、Repository 模式、事务管理、Schema 定义与迁移、并发安全性、架构与性能问题、数据完整性风险等八个维度。

**总体评估**：存储层在从同步到异步的迁移中做出了正确方向的选择（aiosqlite + WAL），但在事务粒度、连接池管理、Schema 版本化、会话隔离、并发模型等方面存在显著缺陷。部分问题（如 `_run_sync` 的嵌套事件循环风险）已在生产环境中引发过测试失败（见 `tests/real_api/test_dream.py` 的 SyncMinimalDB 规避方案）。存储层当前处于"功能可用但工程化不足"的状态，距离生产级可靠性尚有差距。

---

## 详细发现

### 1. 数据库连接管理（异步/同步混合模型）

#### 1.1 单连接全局共享，无连接池

**文件**：`storage/database.py:11-25`

```python
class Database:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._lock = asyncio.Lock()
        self.conn: aiosqlite.Connection | None = None

    async def open(self) -> None:
        os.makedirs(os.path.dirname(self.db_path) or ".", exist_ok=True)
        self.conn = await aiosqlite.connect(self.db_path)
        self.conn.row_factory = aiosqlite.Row
        await self.conn.execute("PRAGMA journal_mode=WAL")
        await self.conn.execute("PRAGMA foreign_keys=ON")
        await self.initialize()
```

**问题分析**：

- `Database` 类只维护**一个** `aiosqlite.Connection` 实例。`aiosqlite` 底层仍使用 `sqlite3` 线程池（默认一个后台线程），虽然异步 API 不会阻塞事件循环，但所有数据库操作最终仍序列化到单个 SQLite 连接上。
- SQLite 的 WAL 模式确实支持**一个写连接 + 多个读连接**的并发模型，但当前实现未利用这一点——所有读写共用同一连接。
- 在 Web 模式下，`SessionManager` 为所有 session 共享同一个 `Database` 实例（`web/session.py:131-134`），这意味着所有 Web 用户的 DB 请求全部串行化。

**风险**：高并发场景下，单个耗时查询（如 `search_facts` 的 `LIKE '%query%'` 全表扫描）会阻塞所有其他用户的 DB 操作，形成全局瓶颈。

**建议**：

- 短期：为读操作引入只读连接池（`aiosqlite` 支持多连接），写操作保留单一连接保证一致性。
- 长期：考虑 `sqlite3` 的多连接模式或迁移到支持真正并发读写的嵌入式数据库（如 DuckDB、RocksDB）。

#### 1.2 `_run_sync` 嵌套事件循环风险

**文件**：`storage/repository.py:13-22`

```python
def _run_sync(coro):
    """Run coroutine in a thread-safe way for sync callers."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return pool.submit(asyncio.run, coro).result()
```

**问题分析**：

- 当调用方已经在一个事件循环中（如 FastAPI 的 Web 请求处理），`_run_sync` 会创建一个 `ThreadPoolExecutor`，在新线程中调用 `asyncio.run(coro)`。
- 这会导致**每个同步调用都创建一个新线程**，线程 overhead 高，且在高并发下可能耗尽线程池。
- 更严重的是，如果 `coro` 内部再次调用 `asyncio.get_running_loop()` 或依赖线程局部状态，可能产生不可预期的行为。
- `memory/long_term.py:18-26` 存在完全相同的 `_run_sync` 实现，代码重复。

**实际影响**：

- `tests/real_api/test_dream.py:24-38` 专门创建了一个 `SyncMinimalDB` 来规避 `_run_sync` 的线程问题，说明开发者已经意识到该问题但采用了规避而非修复的策略。

**建议**：

- 统一使用 `asyncio.run_coroutine_threadsafe()` 替代 `pool.submit(asyncio.run, coro).result()`，避免在新线程中启动独立的事件循环。
- 或者，彻底消除同步调用路径：所有上层代码（包括 `LongTermMemory` 的 sync wrapper）改为 async，Web 路径直接使用 async，CLI 路径在 `main.py` 的 `asyncio.run()` 中统一调度。

#### 1.3 `get_connection()` 暴露原始连接，破坏封装

**文件**：`storage/database.py:41-45`

```python
def get_connection(self):
    """Return connection for direct use (bulk operations). Caller must manage locking."""
    if self.conn is None:
        raise RuntimeError("Database not opened.")
    return self.conn
```

**问题分析**：

- `get_connection()` 返回原始 `aiosqlite.Connection`，绕过了 `cursor()` context manager 的锁管理和自动 commit/rollback 机制。
- 调用方（如 `memory/consolidation.py:262`）需要自行管理锁，但注释仅提示 "Caller must manage locking"，无强制机制。

```python
# memory/consolidation.py:262
with self.ltm.repo.db.get_connection() as conn:
    rows = conn.execute(
        f"SELECT id, {col_list} FROM {table} "
        "WHERE embedding IS NULL LIMIT 50"
    ).fetchall()
```

- 此处 `conn.execute()` 是同步调用（因为 `get_connection()` 返回的 `aiosqlite.Connection` 在 `with` 语句中会被包装为同步上下文管理器，但 `.execute()` 在 `aiosqlite` 中仍返回 coroutine）。实际上这段代码存在**严重的 async/await 缺失 bug**：`conn.execute()` 返回 coroutine，未 await，且 `.fetchall()` 也是 coroutine。在同步上下文中调用会导致 coroutine 对象被当作结果使用，或触发 RuntimeWarning。

**验证**：在 Python 3.12 中，`aiosqlite.Connection.execute()` 返回 `aiosqlite.Cursor`（awaitable），如果在同步代码中不 await，会得到一个 coroutine 对象，后续 `.fetchall()` 会抛出 `AttributeError: 'coroutine' object has no attribute 'fetchall'`。

**风险评级**：**高** — 这是一个运行时崩溃级别的 bug。

**建议**：

- 立即修复 `consolidation.py` 中的 `_embed_new_items()`：使用 `async with self.ltm.repo.db.cursor()` 或在 async 方法中 await。
- 移除 `get_connection()` 方法，或将其改为返回 async context manager，强制调用方使用 async 模式。

---

### 2. SQL 语句安全性

#### 2.1 参数化查询使用正确（良好）

**文件**：`storage/repository.py`

Repository 中所有数据操作均使用 `?` 占位符参数化查询：

- `upsert_fact`（line 41-67）：`VALUES (?, ?, ?, ?, ?, ?, ?, 1, CURRENT_TIMESTAMP)`
- `search_facts`（line 74-88）：`WHERE fact_key LIKE ? OR fact_value LIKE ?`
- `insert_turn`（line 222-226）：`VALUES (?, ?, ?, ?)`
- `prune_facts`（line 250-258）：`WHERE id IN (SELECT id ... LIMIT ?)`

**结论**：未发现 SQL 注入漏洞。所有用户输入（`query`、`keywords`、`content` 等）均通过参数绑定传递。

#### 2.2 `bulk_update_embeddings` 存在表名注入风险

**文件**：`storage/repository.py:189-197`

```python
async def bulk_update_embeddings(self, table: str, updates: list[tuple[int, bytes]]):
    if not updates:
        return
    async with self.db.cursor() as c:
        await c.executemany(
            f"UPDATE {table} SET embedding = ?, embedding_version = 1 WHERE id = ?",
            [(emb, rid) for rid, emb in updates],
        )
```

**问题分析**：

- `table` 参数直接拼接到 SQL 字符串中，未做白名单校验。
- 当前调用方（`memory/consolidation.py:294`）传递的是硬编码表名：`"user_facts"`、`"experiences"`、`"reflections"`，无外部输入。
- 但如果未来有动态表名需求，或调用链被篡改，存在注入风险。

**建议**：添加表名白名单校验：

```python
VALID_TABLES = {"user_facts", "experiences", "reflections"}
if table not in VALID_TABLES:
    raise ValueError(f"Invalid table: {table}")
```

#### 2.3 Schema 迁移中的 `PRAGMA table_info` 和 `ALTER TABLE`

**文件**：`storage/database.py:129-134`

```python
await c.execute(f"PRAGMA table_info({table})")
rows = await c.fetchall()
columns = [row[1] for row in rows]
if column not in columns:
    await c.execute(f"ALTER TABLE {table} ADD COLUMN {column} {col_type} DEFAULT {default_val}")
```

**问题分析**：

- `table` 和 `column` 来自硬编码的元组列表，无外部输入，注入风险极低。
- 但 `PRAGMA table_info({table})` 和 `ALTER TABLE ... ADD COLUMN ...` 使用了 f-string 拼接，虽然当前安全，但不符合防御性编程原则。

**建议**：将 `table` 加入白名单校验，或至少添加注释说明这些值来自硬编码列表。

---

### 3. Repository 模式实现

#### 3.1 Repository 职责划分清晰但缺乏抽象接口

**文件**：`storage/repository.py:24-328`

`Repository` 类按领域模型分组：

- User Facts（line 34-109）
- Experiences（line 113-165）
- Reflections（line 168-187）
- Relationship（line 201-214）
- Conversation Turns（line 218-237）
- Pruning（line 241-295）

**优点**：

- 方法命名规范（`upsert_*`、`search_*`、`get_recent_*`、`prune_*`）。
- 每个方法职责单一，符合 Repository 模式意图。

**缺陷**：

- 无抽象基类（ABC）或 Protocol 定义。`LongTermMemory`（`memory/long_term.py`）直接依赖具体 `Repository` 类，无法 mock 或替换实现。
- 所有方法返回具体模型（`UserFact`、`Experience`、`Reflection`），耦合度高。

**建议**：

- 定义 `AbstractRepository` 接口，便于测试和 future migration。
- 或者使用 Python 的 `typing.Protocol` 进行结构化子类型化。

#### 3.2 `Repository` 直接暴露 `db` 属性

**文件**：`storage/repository.py:25-26`

```python
class Repository:
    def __init__(self, db: Database):
        self.db = db
```

**问题分析**：

- `self.db` 是 public 属性，`memory/consolidation.py:262` 直接访问 `self.ltm.repo.db.get_connection()`，破坏了 Repository 的封装边界。
- 这种 "穿透式调用" 使得 `Database` 的内部状态（如连接是否打开、锁状态）被外部代码依赖，增加了重构难度。

**建议**：

- 将 `self.db` 改为 `self._db`，并通过 Repository 提供高层方法（如 `bulk_update_embeddings` 已经存在，应完全替代直接连接访问）。
- 移除 `memory/consolidation.py` 中对 `self.ltm.repo.db.get_connection()` 的直接调用。

#### 3.3 `_row_to_*` helper 方法缺乏空值保护

**文件**：`storage/repository.py:299-327`

```python
def _row_to_fact(self, r) -> UserFact:
    return UserFact(
        id=r["id"], category=r["category"], fact_key=r["fact_key"],
        fact_value=r["fact_value"], confidence=r["confidence"],
        importance=r["importance"],
        source_turn=r["source_turn"], created_at=r["created_at"],
        updated_at=r["updated_at"], recall_count=r["recall_count"],
        is_active=bool(r["is_active"]), composite_score=r["composite_score"],
    )
```

**问题分析**：

- `r` 是 `aiosqlite.Row` 对象，通过列名索引访问。如果查询的 `SELECT *` 因 Schema 变更导致某些列不存在，会抛出 `IndexError`。
- `bool(r["is_active"])` 对 SQLite 的 INTEGER 类型（0/1）转换正确，但如果列值为 `None`，`bool(None)` 为 `False`，语义上可能不符合预期（新插入记录默认 `is_active=1`）。

**建议**：

- 使用 `r.get("column", default)` 替代直接索引，增加对 Schema 演化的容错性。
- 对关键字段（如 `is_active`）显式处理 `None`：
  ```python
  is_active=False if r.get("is_active") is None else bool(r["is_active"])
  ```

---

### 4. 事务管理

#### 4.1 `cursor()` context manager 自动 commit/rollback

**文件**：`storage/database.py:26-39`

```python
@asynccontextmanager
async def cursor(self):
    if self.conn is None:
        raise RuntimeError("Database not opened. Call await db.open() first.")
    async with self._lock:
        c = await self.conn.cursor()
        try:
            yield c
            await self.conn.commit()
        except aiosqlite.Error:
            await self.conn.rollback()
            raise
        finally:
            await c.close()
```

**问题分析**：

- **自动 commit**：每次 `yield cursor` 后都自动 `commit`。这意味着 Repository 中的每个方法都是一个独立事务。
- **优点**：简单，不会忘记 commit。
- **缺点**：
  1. **无法组合多操作事务**：如果业务逻辑需要 "插入 fact + 插入 experience" 原子执行，当前架构无法实现。
  2. **性能开销**：频繁的单操作 commit 导致 WAL 文件频繁刷新，增加 I/O。
  3. **rollback 粒度粗**：`except aiosqlite.Error` 捕获所有数据库错误并 rollback，但如果异常类型不是 `aiosqlite.Error`（如 `KeyboardInterrupt`、`RuntimeError`），则不会 rollback，可能导致事务悬挂。

**建议**：

- 提供显式事务控制 API：
  ```python
  @asynccontextmanager
  async def transaction(self):
      async with self._lock:
          await self.conn.execute("BEGIN")
          try:
              yield self.conn
              await self.conn.commit()
          except Exception:
              await self.conn.rollback()
              raise
  ```
- Repository 方法默认使用 `cursor()`（自动 commit），但支持在 `transaction()` 中批量执行。

#### 4.2 `initialize()` 中的 `executescript()` 与后续 `execute()` 不在同一事务

**文件**：`storage/database.py:47-134`

```python
async def initialize(self) -> None:
    async with self.cursor() as c:
        await c.executescript("""
            CREATE TABLE IF NOT EXISTS schema_version (...);
            CREATE TABLE IF NOT EXISTS user_facts (...);
            ...
        """)
        for table, column, col_type, default_val in [...]:
            await c.execute(f"PRAGMA table_info({table})")
            ...
            if column not in columns:
                await c.execute(f"ALTER TABLE {table} ADD COLUMN {column} {col_type} DEFAULT {default_val}")
```

**问题分析**：

- `executescript()` 在 SQLite 中自动 commit，且 `async with self.cursor()` 退出时再次 commit。虽然 `CREATE TABLE IF NOT EXISTS` 是幂等的，多次 commit 无害，但逻辑上冗余。
- 更关键的是，`executescript()` 和后续的 `ALTER TABLE` 系列操作不在同一事务中。如果 `executescript()` 成功但某个 `ALTER TABLE` 失败（如磁盘空间不足），数据库将处于**部分迁移状态**。

**建议**：

- 将 Schema 创建和迁移拆分为两个独立方法：`create_tables()` 和 `migrate_schema()`。
- 使用显式事务包裹所有迁移操作，确保原子性。
- 引入 `schema_version` 表记录版本号，避免每次启动都检查列存在性。

---

### 5. Schema 定义与迁移

#### 5.1 Schema 版本化机制缺失

**文件**：`storage/database.py:50-53`

```sql
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY,
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**问题分析**：

- `schema_version` 表已创建，但**从未被写入或读取**。当前迁移逻辑（line 118-134）完全依赖 `PRAGMA table_info()` 检查列存在性，而非版本号。
- 这意味着每次启动都执行 `PRAGMA table_info()` × 4 张表 × 8 个列 = 32 次查询，虽然开销不大，但逻辑混乱。
- 更严重的是，如果未来需要**修改列类型**或**删除列**（SQLite 不支持直接 ALTER DROP COLUMN），`PRAGMA table_info()` 方案完全无法处理。

**建议**：

- 实现真正的版本化迁移：
  ```python
  async def get_schema_version(self) -> int:
      async with self.cursor() as c:
          await c.execute("SELECT MAX(version) FROM schema_version")
          row = await c.fetchone()
          return row[0] or 0

  async def migrate(self) -> None:
      version = await self.get_schema_version()
      migrations = [
          (1, self._migrate_v1),  # initial schema
          (2, self._migrate_v2),  # add embeddings
          (3, self._migrate_v3),  # add importance, is_active
      ]
      for target, migration in migrations:
          if version < target:
              await migration()
              await self._record_version(target)
  ```

#### 5.2 `composite_score` 无默认值约束，导致 NULL 风险

**文件**：`storage/database.py:55-69`

```sql
CREATE TABLE IF NOT EXISTS user_facts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    fact_key TEXT NOT NULL,
    fact_value TEXT NOT NULL,
    confidence REAL DEFAULT 1.0,
    importance REAL DEFAULT 0.5,
    source_turn INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    recall_count INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    composite_score REAL DEFAULT 1.0,
    UNIQUE(category, fact_key)
);
```

**问题分析**：

- `composite_score` 在 `user_facts` 中默认 `1.0`，在 `experiences` 中默认 `0.5`，在 `reflections` 中**无该列**。
- `prune_facts` 按 `composite_score ASC` 排序（`repository.py:254`），如果某行因 bug 写入 `NULL`，`ORDER BY ... ASC` 时 SQLite 将 NULL 视为最小值，导致该行被优先裁剪，可能误删有效数据。

**建议**：

- 为所有 `composite_score` 列添加 `NOT NULL DEFAULT x` 约束。
- 在 `prune_*` 方法中排除 `composite_score IS NULL` 的行，或添加修复迁移将 NULL 更新为默认值。

#### 5.3 `conversation_turns` 表缺少 `session_id` 列

**文件**：`storage/database.py:102-109`

```sql
CREATE TABLE IF NOT EXISTS conversation_turns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    turn_number INTEGER NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
    content TEXT NOT NULL,
    emotional_state TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**问题分析**：

- 这是已知问题（见 `doc/milestones-and-issues.md:#10`、`doc/code-review-report-2026-05-28.md:5.1`）。
- 所有 CLI 和 Web 用户的对话历史写入同一张表，无用户/会话隔离。
- `Repository.insert_turn()` 和 `get_recent_turns()` 均不区分 session（`repository.py:218-237`）。
- Web 模式下，`SessionManager` 的所有 session 共享同一个 `Repository`，导致：
  1. 用户 A 的对话出现在用户 B 的短期记忆恢复中（`web/session.py:36`：`for t in repo.get_recent_turns_sync(30)`）。
  2. `turn_number` 全局递增，不同用户的轮次相互干扰。

**风险评级**：**高** — 数据隐私和会话完整性风险。

**建议**：

- 添加 `session_id TEXT` 列，并为现有数据设置默认值（如 `"cli"` 或 `"legacy"`）。
- 修改 `insert_turn` 和 `get_recent_turns` 增加 `session_id` 参数。
- 添加索引：`CREATE INDEX idx_turns_session ON conversation_turns(session_id, id DESC)`。

#### 5.4 `user_facts` 的 `UNIQUE(category, fact_key)` 与 `ON CONFLICT` 逻辑

**文件**：`storage/repository.py:41-67`

```sql
INSERT INTO user_facts (category, fact_key, fact_value, confidence, importance, ...)
VALUES (?, ?, ?, ?, ?, ?, ?, 1, CURRENT_TIMESTAMP)
ON CONFLICT(category, fact_key) DO UPDATE SET
    fact_value = CASE WHEN excluded.confidence >= user_facts.confidence
                     THEN excluded.fact_value ELSE user_facts.fact_value END,
    confidence = MAX(user_facts.confidence, excluded.confidence),
    importance = MAX(user_facts.importance, excluded.importance),
    recall_count = user_facts.recall_count + 1,
    ...
```

**问题分析**：

- `ON CONFLICT` 的 `fact_value` 更新逻辑是：仅当新记录的 `confidence` >= 旧记录的 `confidence` 时才更新。这可能导致**高置信度的错误事实无法被纠正**。
- 例如：AI 最初以 0.9 confidence 记录了 "用户喜欢苹果"，后来用户明确纠正 "我不喜欢苹果"，但新纠正的 confidence 可能只有 0.7（因为用户纠正时的语气不确定），导致旧错误事实保留。
- `recall_count` 在每次 upsert 时都 +1，无论事实是否真的被 "回忆"。这导致 `recall_count` 实际上是 "写入次数" 而非 "检索次数"。

**建议**：

- 区分 `write_count` 和 `recall_count`：仅在 `search_facts` / `get_active_facts` 被调用时递增 `recall_count`。
- 为事实修正设计专门的逻辑：用户明确纠正时，应允许覆盖高 confidence 的旧记录。

---

### 6. 并发访问安全性

#### 6.1 `asyncio.Lock` 保护单连接，但锁粒度粗

**文件**：`storage/database.py:14`、`line 30`

```python
self._lock = asyncio.Lock()

async with self._lock:
    c = await self.conn.cursor()
    ...
```

**问题分析**：

- `asyncio.Lock` 确保同一时刻只有一个协程执行数据库操作，避免了 `aiosqlite` 底层的线程安全问题。
- 但锁的粒度是**整个 cursor 生命周期**（从获取 cursor 到 close），这意味着：
  1. 长时间查询（如 `LIKE '%query%'` 全表扫描）会阻塞所有其他 DB 操作。
  2. 无法并发执行独立的读操作（WAL 模式理论上支持多连接并发读）。

**建议**：

- 引入读写锁（`asyncio.Lock` + `asyncio.Condition` 或第三方 `aiofiles` 的 RWLock）：
  - 读操作：共享锁（多个读并发）。
  - 写操作：独占锁（阻塞所有读写）。
- 或者，使用连接池：多个读连接共享读锁，写连接独占。

#### 6.2 `LongTermMemory` 的 sync wrapper 与 Web async 路径的竞争

**文件**：`memory/long_term.py:95-105`

```python
def store_fact(self, *a, **kw): return self._run_sync(self._store_fact(*a, **kw))
def search_facts(self, *a, **kw): return self._run_sync(self._search_facts(*a, **kw))
...
```

**问题分析**：

- Web 路径（`web/server.py`）通过 `loop.run_in_executor(None, agent.process_message)` 在线程池中执行同步代码。
- `agent.process_message` → `MessageHandler.handle_message` → `ltm.repo.insert_turn_sync()` → `_run_sync(self.insert_turn())`。
- 这意味着 Web 请求处理线程中，`_run_sync` 会创建新的 `ThreadPoolExecutor` 线程来运行 `asyncio.run()`，而该线程中的事件循环会竞争 `Database._lock`。
- 虽然 `asyncio.Lock` 是协程级别的锁，但 `asyncio.run()` 在新线程中创建独立的事件循环，锁对象是否跨线程安全取决于 Python 版本和实现。在 Python 3.10+ 中，`asyncio.Lock` 不是线程安全的，跨线程使用可能导致死锁或数据竞争。

**风险评级**：**高** — 潜在的死锁和数据竞争。

**建议**：

- Web 路径彻底 async 化：移除 `loop.run_in_executor(None, agent.process_message)`，改为直接 await `agent.process_message()`（前提是 `Agent` 全部 async 化）。
- 或者，使用 `asyncio.run_coroutine_threadsafe()` 将协程提交到主事件循环执行，而非在新线程中启动新的事件循环。

#### 6.3 `MemoryConsolidator._embed_new_items()` 的同步 SQLite 访问

**文件**：`memory/consolidation.py:255-297`

```python
def _embed_new_items(self) -> None:
    if not self._embed or not self._embed.health_check():
        return
    try:
        with self.ltm.repo.db.get_connection() as conn:
            for table, text_cols in [...]:
                col_list = ", ".join(text_cols)
                rows = conn.execute(
                    f"SELECT id, {col_list} FROM {table} "
                    "WHERE embedding IS NULL LIMIT 50"
                ).fetchall()
                ...
```

**问题分析**：

- 如前所述，`conn.execute()` 和 `.fetchall()` 在 `aiosqlite` 中都是 coroutine，此处未 await。
- 此外，`with self.ltm.repo.db.get_connection() as conn` 在 `aiosqlite` 中，`Connection` 的上下文管理器是 async 的（`__aenter__` / `__aexit__`），在同步 `with` 语句中使用会触发 `AttributeError: __enter__`。

**结论**：这段代码在当前实现下**根本无法运行**，除非 `get_connection()` 返回的是同步 `sqlite3.Connection`。但 `Database.get_connection()` 返回的是 `aiosqlite.Connection`。

**风险评级**：**严重** — 运行时崩溃。

**建议**：

- 将 `_embed_new_items()` 改为 async 方法。
- 使用 `async with self.ltm.repo.db.cursor() as c:` 执行查询。
- 或者，如果必须在同步上下文中运行，使用 `sqlite3` 创建独立的同步连接（如 `test_dream.py` 中的 `SyncMinimalDB` 方案）。

---

### 7. 架构问题

#### 7.1 存储层与业务层耦合

**文件**：`memory/long_term.py`、`memory/consolidation.py`、`core/cli_controller.py`、`core/message_handler.py`

**问题分析**：

- `LongTermMemory` 不是纯粹的内存管理器，而是 Repository 的薄包装。它既负责业务语义（如 `build_context`），又负责数据持久化协调。
- `MemoryConsolidator` 直接访问 `self.ltm.repo.db.get_connection()`，穿透了两层抽象。
- `CliController` 和 `MessageHandler` 直接调用 `a.ltm.repo.insert_turn_sync()`，绕过了 `LongTermMemory` 的封装。

**建议**：

- 明确分层：
  ```
  Application Layer (Agent, MessageHandler)
    -> Service Layer (LongTermMemory, MemoryConsolidator)
      -> Repository Layer (Repository)
        -> Data Access Layer (Database)
  ```
- 禁止任何上层代码直接访问 `repo.db`。

#### 7.2 `Repository` 与 `Database` 一对一绑定，无法水平扩展

**问题分析**：

- 每个 `Database` 实例只有一个连接，每个 `Repository` 绑定一个 `Database`。如果未来需要分库分表、读写分离、或切换到 PostgreSQL/MySQL，当前架构无法平滑迁移。

**建议**：

- 引入连接工厂（Connection Factory）和配置化的数据库后端选择。
- 即使短期内仍用 SQLite，也应预留多连接池的扩展点。

#### 7.3 缺乏存储层单元测试

**问题分析**：

- 全项目 181 个单元测试中，**没有任何一个**直接测试 `storage/database.py` 或 `storage/repository.py`。
- `tests/` 目录下无 `test_database.py` 或 `test_repository.py`。
- `tests/re_api/test_*.py` 使用 `:memory:` 数据库，但测试重点是上层业务逻辑，非存储层本身。

**风险**：Schema 变更、迁移逻辑、边界条件（如空结果、大数据量）缺乏自动化验证。

**建议**：

- 添加 `tests/test_database.py`：测试连接打开/关闭、WAL 模式、Schema 初始化、迁移逻辑。
- 添加 `tests/test_repository.py`：测试每个 Repository 方法的 CRUD、边界条件、并发行为（使用 `pytest-asyncio`）。

---

### 8. 性能问题

#### 8.1 `search_facts` 的 `LIKE '%query%'` 无法使用索引

**文件**：`storage/repository.py:74-88`

```sql
SELECT * FROM user_facts
WHERE is_active = 1
  AND (fact_key LIKE ? OR fact_value LIKE ? OR category LIKE ?)
ORDER BY composite_score DESC, recall_count DESC
LIMIT ?
```

**问题分析**：

- `LIKE '%query%'` 前缀通配导致 SQLite 无法使用 B-tree 索引，必须全表扫描。
- 当前 `user_facts` 表无索引（除主键和 UNIQUE 约束外）。
- 随着数据量增长（`max_facts=200` 默认限制，但可配置），查询性能线性下降。

**建议**：

- 添加全文搜索索引（FTS5）：`CREATE VIRTUAL TABLE user_facts_fts USING fts5(category, fact_key, fact_value)`。
- 或者，为 `fact_key` 和 `category` 添加前缀索引：`CREATE INDEX idx_facts_key ON user_facts(fact_key)`（仅对 `LIKE 'prefix%'` 有效，对 `%suffix%` 无效）。
- 最佳方案：利用已有的向量嵌入（embedding BLOB），在应用层做近似最近邻（ANN）搜索，替代 LIKE 查询。

#### 8.2 `prune_*` 方法的子查询 + UPDATE 模式效率低

**文件**：`storage/repository.py:241-295`

```sql
UPDATE user_facts SET is_active = 0, composite_score = 0
WHERE id IN (
    SELECT id FROM user_facts WHERE is_active = 1
    ORDER BY composite_score ASC, recall_count ASC
    LIMIT ?
)
```

**问题分析**：

- 每次 prune 执行 `SELECT COUNT(*)` + `UPDATE ... WHERE id IN (SELECT ...)`，两次扫描表。
- SQLite 的 `UPDATE ... WHERE id IN (SELECT ...)` 在子查询返回大量行时性能较差。

**建议**：

- 合并为单次操作：使用 `DELETE` 或 `UPDATE` 配合 `ROWID` 子查询，或直接使用 `ORDER BY ... LIMIT ...` 的 CTE：
  ```sql
  WITH to_prune AS (
      SELECT id FROM user_facts WHERE is_active = 1
      ORDER BY composite_score ASC, recall_count ASC
      LIMIT ?
  )
  UPDATE user_facts SET is_active = 0, composite_score = 0
  WHERE id IN (SELECT id FROM to_prune)
  ```
- 或者，使用游标逐行处理，避免大事务。

#### 8.3 `embedding` BLOB 存储无压缩，空间效率低

**文件**：`storage/database.py:122-127`

- 512 维 float32 向量 = 512 × 4 = 2048 字节/条。
- 200 facts + 100 experiences + 50 reflections = 350 条 × 2KB = 700KB 嵌入数据。
- 虽然当前数据量小，但如果未来扩展到数千条，SQLite 的 BLOB 存储效率不如专门的向量数据库（如 FAISS、Chroma、Milvus Lite）。

**建议**：

- 短期：使用 `numpy.float16` 序列化（512 维 × 2B = 1KB/条），精度损失对余弦相似度影响极小。
- 长期：评估迁移到专用向量数据库或 SQLite 的向量扩展（如 `sqlite-vec`）。

---

### 9. 数据完整性风险

#### 9.1 `json.dumps` 存储列表，无 Schema 校验

**文件**：`storage/repository.py:124`、`line 177`

```python
json.dumps(tags, ensure_ascii=False)
json.dumps(related_ids)
```

**问题分析**：

- `experiences.tags` 和 `reflections.related_experience_ids` 以 JSON 字符串存储。
- 读取时通过 `json.loads()` 反序列化（`repository.py:314`、`line 324`），但如果数据库中的 JSON 因外部修改或 bug 而损坏，`json.loads()` 会抛出异常，导致整个查询失败。
- 当前代码无 try/catch 保护。

**建议**：

- 在 `_row_to_experience` 和 `_row_to_reflection` 中包裹 `try/except json.JSONDecodeError`，返回空列表作为 fallback，并记录错误日志。
- 长期考虑使用 SQLite 的 JSON1 扩展（原生 JSON 支持），但 `aiosqlite` 默认编译可能未启用。

#### 9.2 `relationship_metrics` 的 `value` 无范围约束

**文件**：`storage/database.py:96-100`

```sql
CREATE TABLE IF NOT EXISTS relationship_metrics (
    dimension TEXT PRIMARY KEY,
    value REAL DEFAULT 0.3,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**问题分析**：

- `value` 无 `CHECK(value BETWEEN 0.0 AND 1.0)` 约束。
- `Repository.upsert_relationship`（`repository.py:206-214`）通过 `min(1.0, ...)` 在应用层限制，但如果直接操作数据库或存在 bug，可能写入越界值。

**建议**：

- 添加数据库级约束：`value REAL DEFAULT 0.3 CHECK(value BETWEEN 0.0 AND 1.0)`。

#### 9.3 `conversation_turns` 的 `turn_number` 无唯一性约束

**文件**：`storage/database.py:102-109`

**问题分析**：

- `turn_number` 在应用层（`Agent.turn_count`）维护，但数据库无 `UNIQUE` 约束。
- 如果并发插入或代码 bug 导致重复 `turn_number`，数据库不会拒绝。

**建议**：

- 添加 `UNIQUE(session_id, turn_number)` 约束（在添加 `session_id` 列后）。

---

### 10. 其他发现

#### 10.1 `requirements.txt` 缺少 `aiosqlite`

**文件**：`requirements.txt`

```
requests==2.34.2
tiktoken==0.13.0
plyer==2.1.0
fastapi==0.111.0
uvicorn==0.30.1
numpy>=1.24.0
```

**问题**：`aiosqlite` 未列入 `requirements.txt`，但 `storage/database.py` 已依赖它。新环境安装依赖后会因缺少 `aiosqlite` 而无法启动。

**建议**：立即添加 `aiosqlite>=0.20.0`。

#### 10.2 `database.py` 的 `close()` 不等待未完成操作

**文件**：`storage/database.py:136-140`

```python
async def close(self) -> None:
    if self.conn:
        logger.info(f"[db] closed: {self.db_path}")
        await self.conn.close()
        self.conn = None
```

**问题**：关闭前不检查是否有活跃的 cursor 或挂起的事务。如果某个协程正在持有 `_lock` 执行查询，`close()` 可能强制关闭连接，导致该协程抛出 `OperationalError`。

**建议**：

- 添加 `_closing` 标志，拒绝新的 cursor 请求。
- 等待 `_lock` 释放后再关闭连接（使用 `asyncio.wait_for` 设置超时）。

#### 10.3 `repository.py` 的 `upsert_fact` 中 `embedding_version` 硬编码为 1

**文件**：`storage/repository.py:41-67`

`embedding_version = 1` 在 INSERT 和 UPDATE 中均硬编码。如果未来需要升级嵌入模型（如从 512 维到 768 维），需要批量更新 `embedding_version`，但当前无版本管理机制。

**建议**：将 `embedding_version` 定义为类常量或配置项，便于全局管理。

---

## 汇总统计

### 问题分类统计

| 类别 | 数量 | 严重（High/Critical） | 中等（Medium） | 低（Low） |
|------|------|----------------------|---------------|----------|
| 并发/异步模型 | 5 | 3 | 2 | 0 |
| 事务管理 | 3 | 1 | 2 | 0 |
| Schema/迁移 | 5 | 2 | 2 | 1 |
| SQL 安全性 | 2 | 0 | 1 | 1 |
| 性能 | 3 | 0 | 2 | 1 |
| 数据完整性 | 4 | 1 | 2 | 1 |
| 架构/设计 | 4 | 1 | 2 | 1 |
| 测试覆盖 | 1 | 1 | 0 | 0 |
| 其他 | 3 | 1 | 1 | 1 |
| **总计** | **30** | **10** | **14** | **6** |

### 风险评级详情

| 评级 | 数量 | 代表问题 |
|------|------|---------|
| **Critical** | 2 | `consolidation.py` 同步代码调用 async API 导致崩溃；`_run_sync` 跨线程事件循环死锁风险 |
| **High** | 8 | 单连接全局瓶颈；无 session_id 隔离；无连接池；Repository 无抽象接口；缺乏存储层单元测试；`close()` 不等待活跃操作；`composite_score` NULL 风险；`requirements.txt` 缺 `aiosqlite` |
| **Medium** | 14 | 事务粒度粗；Schema 版本化缺失；`bulk_update_embeddings` 表名注入；`get_connection()` 破坏封装；`_row_to_*` 无空值保护；JSON 存储无校验；WAL 未配置 checkpoint；`prune_*` 效率低；`upsert_fact` confidence 逻辑缺陷；`recall_count` 语义错误；嵌入 BLOB 无压缩；`relationship_metrics` 无范围约束；`turn_number` 无唯一性；`embedding_version` 硬编码 |
| **Low** | 6 | 参数化查询良好（正面）；`executescript()` 冗余 commit；`schema_version` 表未使用；`LIKE` 查询无索引（已知）；`json.dumps` 无 try/catch；代码重复（`_run_sync`） |

### 关键文件问题密度

| 文件 | 行数 | 问题数 | 密度 |
|------|------|--------|------|
| `storage/database.py` | 141 | 12 | 8.5/100行 |
| `storage/repository.py` | 328 | 14 | 4.3/100行 |
| `memory/consolidation.py` | 305 | 8 | 2.6/100行 |
| `memory/long_term.py` | 106 | 5 | 4.7/100行 |
| `web/session.py` | 175 | 3 | 1.7/100行 |
| `core/cli_controller.py` | 335 | 2 | 0.6/100行 |
| `core/message_handler.py` | 302 | 2 | 0.7/100行 |

### 修复优先级建议

#### P0（立即修复，阻塞生产）

1. **修复 `memory/consolidation.py:_embed_new_items()` 的 async/await 缺失**（Critical）
2. **添加 `aiosqlite` 到 `requirements.txt`**（High）
3. **为 `conversation_turns` 添加 `session_id` 列及索引**（High）
4. **修复 `_run_sync` 的线程安全，统一使用 `run_coroutine_threadsafe`**（High）

#### P1（本周修复，显著改善可靠性）

5. **实现 Schema 版本化迁移机制**（High）
6. **为 `composite_score` 添加 `NOT NULL` 约束**（High）
7. **移除 `get_connection()`，禁止穿透式访问**（High）
8. **添加 `AbstractRepository` 接口**（Medium）
9. **为 `relationship_metrics.value` 添加 `CHECK` 约束**（Medium）
10. **为 `turn_number` 添加唯一性约束**（Medium）

#### P2（下月修复，工程化改进）

11. **引入连接池或读写分离**（High）
12. **添加存储层单元测试（pytest-asyncio）**（High）
13. **优化 `prune_*` 方法性能**（Medium）
14. **为 `search_facts` 引入 FTS5 或向量索引**（Medium）
15. **嵌入 BLOB 使用 float16 压缩**（Medium）
16. **分离 `recall_count` 和 `write_count` 语义**（Medium）

---

## 附录：引用代码位置索引

| 问题 | 文件 | 行号 |
|------|------|------|
| 单连接全局共享 | `storage/database.py` | 11-25 |
| `_run_sync` 嵌套事件循环 | `storage/repository.py` | 13-22 |
| `get_connection()` 破坏封装 | `storage/database.py` | 41-45 |
| `consolidation.py` async 调用缺失 | `memory/consolidation.py` | 262-275 |
| `cursor()` 自动 commit | `storage/database.py` | 26-39 |
| `executescript()` 与 `ALTER TABLE` 不在同一事务 | `storage/database.py` | 47-134 |
| `schema_version` 表未使用 | `storage/database.py` | 50-53 |
| `composite_score` 无 NOT NULL | `storage/database.py` | 67, 83 |
| `conversation_turns` 无 session_id | `storage/database.py` | 102-109 |
| `upsert_fact` ON CONFLICT 逻辑 | `storage/repository.py` | 41-67 |
| `bulk_update_embeddings` 表名注入 | `storage/repository.py` | 189-197 |
| `_row_to_*` 无空值保护 | `storage/repository.py` | 299-327 |
| `search_facts` LIKE 无索引 | `storage/repository.py` | 74-88 |
| `prune_*` 子查询效率 | `storage/repository.py` | 241-295 |
| `LongTermMemory` sync wrapper | `memory/long_term.py` | 18-26, 95-105 |
| `requirements.txt` 缺 aiosqlite | `requirements.txt` | 1-7 |
| `database.close()` 不等待 | `storage/database.py` | 136-140 |

---

*本报告基于 2026-05-31 的代码基线（commit 3c24cd3）生成。建议修复后重新审查验证。*
