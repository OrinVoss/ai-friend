# 第2轮深度代码审查：工具调用数据流

**审查日期**: 2026-05-31  
**审查范围**: core/tool_agent.py, core/dispatcher.py, tools/traits.py, core/inner_drive.py, core/message_handler.py, core/agent.py, core/cli_controller.py, prompts/system.py  
**审查人**: Claude Code (Sonnet 4.6)  
**项目路径**: `D:\桌面\编程作品\AI朋友`  

---

## 1. 概述

本次审查聚焦 AI Friend 三层 Agent 架构中工具调用的完整数据流，从 Agent 1 (InnerDriveAgent) 的内驱推理决策，到 Agent 2 (ToolAgent) 的外部工具执行与重试，再到 Agent 3 (Roleplay Agent) 的结果消费与最终回复。审查覆盖 8 个核心文件，总计约 2500 行代码，同时关联 `tests/test_tool_agent.py`、`tests/test_dispatcher.py` 等测试文件。

三层 Agent 的设计意图是清晰的：Agent 1 负责"要不要调用工具"的决策，Agent 2 负责"怎么调用工具"的执行，Agent 3 负责"基于工具结果怎么回复"的表达。但在实现层面，这一数据流存在多处断裂、信息丢失、状态不一致和重试逻辑缺陷。整体风险评级为 **中高风险**，其中数据流断裂、状态管理失效和重试机制漏洞是最突出的三大问题。

本次审查在前一轮 (`round01-three-layer-agent.md`) 的基础上，进一步深入跟踪工具请求从 Agent 1 -> Agent 2 -> 工具执行 -> 结果返回 -> Agent 1 review 的完整链路，特别关注 ToolAttemptTracker 的状态管理、retry 机制、failure_log 累积、工具结果格式化、工具调用历史维护，以及内驱推理中内部工具与外部工具的区分。

---

## 2. 数据流图

### 2.1 完整工具调用数据流（Web 路径）

```
用户输入
    │
    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│  Agent 1: InnerDriveAgent.assess()                                      │
│  core/inner_drive.py:61-111                                              │
│  ─────────────────────────────────────────────────────────────────────  │
│  输入: user_input + memory_context + conversation_history + tools       │
│  输出: InnerDriveResult                                                  │
│    ├─ needs_external_tools: bool                                        │
│    ├─ reasoning: str                                                    │
│    ├─ tool_requests: list[ToolRequest]                                  │
│    └─ summary: str                                                      │
│  内部循环: recall/remember (max 5 iter)                                 │
│  ⚠️ 使用 full_registry，无运行时隔离                                    │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
              ┌──────────────┴──────────────┐
              │  needs_external_tools=False │
              └──────────────┬──────────────┘
                             │
                             ▼
              ┌──────────────────────────────┐
              │  直接跳至 Agent 3 (_run_agent3)│
              │  tool_result=None              │
              └──────────────────────────────┘
                             │
              ┌──────────────┴──────────────┐
              │  needs_external_tools=True  │
              └──────────────┬──────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│  Agent 2: ToolAgent.run_with_request()                                  │
│  core/tool_agent.py:142-224                                              │
│  ─────────────────────────────────────────────────────────────────────  │
│  输入: tool_request (自然语言描述)                                       │
│  输出: ToolAgentResult                                                   │
│    ├─ records: list[ToolCallRecord]                                     │
│    ├─ total_calls: int                                                  │
│    ├─ success_count: int                                                │
│    └─ elapsed_ms: float                                                 │
│  重试: max_retries=3 (内部循环)                                          │
│  ⚠️ 当 parse_tool_calls 返回空时，last_failure 未更新                   │
│  ⚠️ ToolCallRecord.arguments 永远为空字典 {}                             │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│  MessageHandler: 多轮编排循环                                            │
│  core/message_handler.py:98-141                                          │
│  ─────────────────────────────────────────────────────────────────────  │
│  MAX_AGENT2_ROUNDS = 3                                                   │
│  all_tool_results = []  (累积所有 round 的结果)                          │
│  tracker = ToolAttemptTracker()  ⚠️ 每轮新建，状态不共享                  │
│                                                                           │
│  while round_num < 3 and drive_result.needs_external_tools:             │
│    round_num += 1                                                        │
│    ├─ tool_result = run_with_request(request_text)                      │
│    ├─ tracker.total_attempts += 1                                        │
│    ├─ track_failures(tracker, tool_result)  ⚠️ 不记录"无工具调用"失败   │
│    │                                                                     │
│    ├─ while tracker.can_retry_in_round and not any_success:             │
│    │    tracker.retry_count += 1                                        │
│    │    tool_result = run_with_request(request_text)                    │
│    │    tracker.total_attempts += 1                                     │
│    │    track_failures(tracker, tool_result)                            │
│    │                                                                     │
│    ├─ if any_success and round_num < 3:                                 │
│    │    drive_result = inner_drive.review(user_input, combined_records) │
│    │                                                                     │
│    └─ elif not any_success:                                             │
│         if tracker.can_start_new_round:                                 │
│    │       drive_result = inner_drive.re_decide(user_input,             │
│    │                         tracker.failure_log)  ⚠️ failure_log 不完整│
│         else: break                                                      │
│                                                                           │
│  ⚠️ tracker.round_number 永远是 0                                        │
│  ⚠️ tracker.can_start_new_round 逻辑与 MessageHandler 循环条件重复       │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│  Agent 1: InnerDriveAgent.review() / re_decide()                        │
│  core/inner_drive.py:154-264                                             │
│  ─────────────────────────────────────────────────────────────────────  │
│  review():                                                               │
│    输入: user_input + tool_records_text (前 3000 字符)                   │
│    输出: InnerDriveResult (是否需要更多工具)                             │
│    ⚠️ 内部工具调用结果不传递给 Agent 3                                   │
│                                                                           │
│  re_decide():                                                            │
│    输入: user_input + failure_log[-5:]                                   │
│    输出: InnerDriveResult (换策略或放弃)                                 │
│    ⚠️ failure_log 可能遗漏"无工具调用"的失败场景                         │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│  工具结果格式化: format_for_phase2()                                     │
│  core/tool_agent.py:226-249                                              │
│  ─────────────────────────────────────────────────────────────────────  │
│  输入: ToolAgentResult (单轮结果)                                        │
│  输出: str (prompt-friendly text)                                        │
│  特性:                                                                   │
│    - 显示调用次数、成功数、耗时                                           │
│    - 每条记录显示工具名、状态、条目数                                     │
│    - 输出截断至 6000 字符/条                                             │
│    - 嵌入"禁止编造"铁律                                                  │
│  ⚠️ 只接收单轮结果，多轮累积在 MessageHandler 中手动拼接                │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│  Agent 3: Roleplay Agent (_react_loop)                                  │
│  core/agent.py:119-181                                                   │
│  ─────────────────────────────────────────────────────────────────────  │
│  输入: messages (含 system_prompt + tool_records + user_input)          │
│  输出: final_text (最终回复)                                             │
│  内部工具: recall/remember (通过 phase2_registry)                        │
│  工具调用历史: _tool_call_history (最多 20 条)                           │
│  ⚠️ Web 路径中 Agent 3 只能调用内部工具                                  │
│  ⚠️ CLI 路径中 Agent 3 可调用全部工具（如果 Agent 1 未请求外部工具）      │
└─────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Agent 2 内部重试数据流

```
run_with_request(tool_request, max_retries=3)
    │
    ▼
构建 messages: [system_prompt, user_msg(tool_request)]
    │
    ▼
for attempt in 1..3:
    │
    ├─ resp = provider.generate(messages, response_format=json_schema)
    │   ⚠️ 无 try-except 包裹 Provider 异常
    │
    ├─ cleaned, calls = parse_tool_calls(resp)
    │   ├─ Tier 1: structured JSON {"calls": [...]}
    │   ├─ Tier 2: XML <tool_call> tags
    │   └─ Tier 3: bare JSON object fallback
    │
    ├─ if not calls:
    │      ⚠️ continue (直接进入下一次 retry)
    │      ⚠️ last_failure 未更新，retry prompt 显示旧信息或 None
    │
    ├─ messages.append(assistant, resp)
    │
    ├─ results = execute_tool_calls(registry, calls)
    │   ├─ for each call:
    │   │    tool = registry.get(name)
    │   │    if tool is None: 记录失败
    │   │    else:
    │   │       ⚠️ asyncio.run(tool.execute(args)) 循环调用
    │   │       ⚠️ import asyncio/inspect 在循环内部
    │   │       result = ToolResult(success, output)
    │   │    append to results
    │   └─ log: X ok, Y failed
    │
    ├─ for r in results:
    │      record = ToolCallRecord(name, arguments={}, success, output[:3000])
    │      ⚠️ arguments 永远为空
    │      append to result.records
    │      result.total_calls += 1
    │      if success: result.success_count += 1
    │
    ├─ result_text = _format_raw_results(results)
    │   (内部 ReAct 循环使用的极简格式)
    │
    ├─ messages.append(user, result_text)
    │
    ├─ if result.any_success: break
    │
    └─ last_failure = "; ".join(failed outputs[:100])
    │      ⚠️ 只记录最后一批失败的输出，不累积历史
    │
    ▼
返回 ToolAgentResult
```

### 2.3 工具调用历史维护数据流

```
Agent 3 _react_loop() 中每次执行工具后:
    │
    ├─ results = execute_tool_calls(registry, calls)
    │
    ├─ for r in results:
    │      self._tool_call_history.append({
    │          "name": r["name"],
    │          "success": r["success"],
    │          "output": r["output"][:200],   ⚠️ 截断至 200 字符
    │          "time": time.time(),
    │      })
    │
    ├─ if len(self._tool_call_history) > 20:
    │      self._tool_call_history = self._tool_call_history[-20:]
    │      ⚠️ 直接赋值，非原子操作，并发时可能丢失记录
    │
    └─ messages.append(user, format_tool_results(results))
    │      format_tool_results 输出含 <tool_result> 标签 + "铁律"
    │
    ▼
_tool_call_history 注入 Agent 3 system prompt:
    build_system_prompt(tool_call_history=a._tool_call_history)
    │
    └─ Block 8: "=== 你的工具调用记录 ==="
        for tc in tool_history[-5:]:
            status = "✅" if tc["success"] else "❌"
            blocks.append(f"- {status} {tc['name']}: {tc['output'][:100]}")
        ⚠️ 再次截断至 100 字符
```

### 2.4 CLI 路径 vs Web 路径数据流对比

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           CLI 路径                                       │
│  core/cli_controller.py:137-157                                          │
│  ─────────────────────────────────────────────────────────────────────  │
│  _on_perceive() -> _on_think() -> _on_act() -> _on_reflect()            │
│                                                                           │
│  Agent 1: assess() 在 _on_perceive() 中执行                              │
│  Agent 2: run_with_request() 在 _on_think() 中执行，仅一轮               │
│    ⚠️ 无多轮 review/re_decide 循环                                       │
│    ⚠️ 无 ToolAttemptTracker                                              │
│  Agent 3: _on_think() 调用 provider.generate()                           │
│         _on_act() 执行工具，可调用全部工具（如果 Agent 1 未请求外部工具）│
│                                                                           │
│  状态机: _react_iteration 在 _on_think() 中递增                          │
│  上限检查: _on_act() 中 _react_iteration > _max_tool_iterations          │
│    ⚠️ 边界条件错误: 10 > 10 为 False，实际允许 11 次迭代                  │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                           Web 路径                                       │
│  core/message_handler.py:64-156                                          │
│  ─────────────────────────────────────────────────────────────────────  │
│  handle_message() 直接编排三层 Agent                                     │
│                                                                           │
│  Agent 1: assess() -> 可能 review() / re_decide()                        │
│  Agent 2: run_with_request() 在多轮 while 循环中执行                     │
│    ⚠️ ToolAttemptTracker 每轮新建，状态不共享                            │
│    ⚠️ tracker.round_number 永远是 0                                      │
│  Agent 3: _run_agent3() -> _react_loop()                                 │
│    ⚠️ 只能调用内部工具 (recall/remember)                                 │
│                                                                           │
│  无状态机，无 _react_iteration 计数                                      │
│  _react_loop() 使用 for _idx in range(10)                               │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 3. 详细发现

### 3.1 Agent 1 内驱推理中的工具隔离缺陷

**文件**: `core/inner_drive.py:61-111` (`assess()` 方法)

Agent 1 的 `assess()` 方法使用 ReAct 循环执行内部工具（recall/remember）来构建上下文，然后做出决策。关键代码：

```python
# core/inner_drive.py:64
from core.dispatcher import parse_tool_calls, execute_tool_calls
# core/inner_drive.py:99
results = execute_tool_calls(self._full_registry, calls)
```

这里传入的是 `self._full_registry`，包含所有工具（包括 web_fetch、web_search 等外部工具）。虽然 prompt 会引导 LLM 只调用 recall/remember，但没有任何运行时防护。如果 LLM 错误地输出了外部工具调用（如 `<tool_call>{"name": "web_fetch", ...}</tool_call>`），`execute_tool_calls()` 会直接执行它，完全绕过 Agent 2 的 retry 机制、结果格式化和 ToolAttemptTracker 状态管理。

**风险分析**:
- **高**: Agent 1 可以直接执行外部工具，破坏了"Agent 1 决策 -> Agent 2 执行"的架构隔离。这意味着外部工具的错误不会被 Agent 2 的 retry 机制捕获，失败结果也不会被 format_for_phase2() 正确格式化，Agent 3 可能收到格式不一致的工具结果。
- 更严重的是，Agent 1 的 ReAct 循环中没有 `contains_fake_action()` 检测，如果 LLM 在内部工具循环中虚构了工具调用结果，系统无法识别。

**同样的缺陷也存在于 `review()` 和 `re_decide()` 方法**:

```python
# core/inner_drive.py:200-206 (review 方法)
if calls:
    messages.append({"role": "assistant", "content": resp})
    results = execute_tool_calls(self._full_registry, calls)
    result_text = self._format_internal_results(results)
    messages.append({"role": "user", "content": result_text})
    resp = self._provider.generate(messages, stream=False, max_tokens=512)
    cleaned, _ = parse_tool_calls(resp)

# core/inner_drive.py:250-256 (re_decide 方法)
if calls:
    messages.append({"role": "assistant", "content": resp})
    results = execute_tool_calls(self._full_registry, calls)
    result_text = self._format_internal_results(results)
    messages.append({"role": "user", "content": result_text})
    resp = self._provider.generate(messages, stream=False, max_tokens=512)
    cleaned, _ = parse_tool_calls(resp)
```

`review()` 和 `re_decide()` 同样使用 `self._full_registry`，存在同样的隔离缺陷。

**建议**: 为 Agent 1 创建隔离的内部工具 Registry：

```python
def _make_internal_registry(self):
    from tools.traits import ToolRegistry
    r = ToolRegistry()
    for name in ("recall", "remember"):
        tool = self._full_registry.get(name)
        if tool:
            r.register(tool)
    return r

# 在 assess/review/re_decide 中使用
internal_registry = self._make_internal_registry()
results = execute_tool_calls(internal_registry, calls)
```

---

### 3.2 Agent 2 的 retry 机制缺陷

**文件**: `core/tool_agent.py:142-224` (`run_with_request()` 方法)

#### 3.2.1 last_failure 未更新问题

```python
# core/tool_agent.py:183-186
resp = self._provider.generate(messages, stream=False, max_tokens=512,
                              response_format=json_schema)
cleaned, calls = parse_tool_calls(resp)
if not calls:
    logger.debug("[tool_agent] no tool calls parsed from response")
    continue  # 直接进入下一次 retry
```

当 `parse_tool_calls()` 返回空 calls 时（即 LLM 没有输出任何工具调用），代码直接 `continue` 进入下一次 retry 循环，但 `last_failure` 变量没有被更新。这意味着 retry prompt 中的 `"之前的尝试失败了（{last_failure}）"` 会显示上一次非空调用的失败信息，或者如果是第一次尝试就返回空，则显示 `None`。

**影响**: Agent 2 的 retry prompt 向 LLM 提供了错误的上下文信息，可能导致 LLM 无法正确理解之前失败的原因，降低 retry 成功率。

#### 3.2.2 retry 只覆盖工具解析/执行失败，不覆盖 Provider 异常

```python
# core/tool_agent.py:181-182
resp = self._provider.generate(messages, stream=False, max_tokens=512,
                              response_format=json_schema)
```

这行代码没有 try-except 包裹。如果 Provider 抛出 `ConnectionError`、`ReadTimeout`、`HTTPError` 等异常，整个 `run_with_request()` 会崩溃，异常向上传播到 `MessageHandler.handle_message()`。而 `handle_message()` 中：

```python
# core/message_handler.py:105
tool_result = self._tool_agent.run_with_request(request_text)
```

同样没有 try-except 包裹。这意味着一个 Provider 异常会导致整个消息处理流程中断，用户收到错误而不是优雅降级。

#### 3.2.3 retry 消息丢失历史上下文

```python
# core/tool_agent.py:172-178
messages = [
    {"role": "system", "content": sys_prompt},
    {"role": "user", "content": (
        f"Agent 1 的内驱推理请求：\n{tool_request}\n\n"
        f"之前的尝试失败了（{last_failure}）。"
        "请调整方式后重新输出 JSON 格式的工具调用。"
    )},
]
```

在 retry 时，`messages` 被完全重建，丢失了之前 assistant 的响应和工具执行结果。这意味着 Agent 2 在 retry 时看不到自己之前输出了什么、工具返回了什么，只能依赖 `last_failure` 这一行简短的描述。这种信息丢失在多步推理场景中（如搜索后需要根据结果调整查询词）尤为致命。

#### 3.2.4 max_retries 参数与 ToolAttemptTracker 的重复

`run_with_request()` 接收 `max_retries: int = 3` 参数，但 `MessageHandler` 中同时使用了 `ToolAttemptTracker` 来控制重试。两者的关系是：
- `run_with_request()` 内部实现 max_retries 次重试
- `MessageHandler` 在 `run_with_request()` 返回后，根据 `tracker.can_retry_in_round` 决定是否再次调用 `run_with_request()`

这造成了两层重试逻辑的嵌套和混淆。实际上，`run_with_request()` 内部的重试是"同一请求的同一次执行中的重试"，而 `MessageHandler` 的重试是"同一 round 内的多次执行"。但两者的语义边界不清晰，且 `ToolAttemptTracker` 的状态管理存在严重缺陷（见 3.3）。

---

### 3.3 ToolAttemptTracker 状态管理完全失效

**文件**: `core/tool_agent.py:48-67` (类定义), `core/message_handler.py:98-141` (使用)

#### 3.3.1 round_number 永远是 0

```python
# core/tool_agent.py:48-67
@dataclass
class ToolAttemptTracker:
    round_number: int = 0
    retry_count: int = 0
    total_attempts: int = 0
    failure_log: list[dict] = field(default_factory=list)

    @property
    def can_retry_in_round(self) -> bool:
        return self.retry_count < 3

    @property
    def can_start_new_round(self) -> bool:
        return self.round_number < 3 and self.total_attempts < 9

    @property
    def is_exhausted(self) -> bool:
        return self.total_attempts >= 9
```

`round_number` 在 `MessageHandler.handle_message()` 中从未被递增：

```python
# core/message_handler.py:98-106
while round_num < MAX_AGENT2_ROUNDS and drive_result.needs_external_tools:
    round_num += 1
    ...
    tracker = ToolAttemptTracker()  # 每轮新建！
    tool_result = self._tool_agent.run_with_request(request_text)
    tracker.total_attempts += 1
```

注意：
1. `round_num` 是 `MessageHandler` 的局部变量，与 `tracker.round_number` 完全无关
2. 每个 round 都新建一个 `ToolAttemptTracker`，所以 tracker 的 `round_number` 永远是 0
3. `tracker.can_start_new_round` 永远返回 `total_attempts < 9`（因为 `round_number < 3` 永远为 True）

#### 3.3.2 tracker 每轮新建导致状态不共享

"3 rounds x 3 retries = max 9 attempts" 的设计意图完全没有实现。实际情况是：
- Round 1: 新建 tracker1, retry_count 0->1->2->3, total_attempts 1->2->3->4
- Round 2: 新建 tracker2, retry_count 0->1->2->3, total_attempts 1->2->3->4
- Round 3: 新建 tracker3, retry_count 0->1->2->3, total_attempts 1->2->3->4

每个 tracker 独立计算，跨 round 的 total_attempts 不累积。这意味着系统实际上允许了最多 12 次尝试（3 rounds x 4 attempts，因为 retry_count 从 0 开始，can_retry_in_round 在 retry_count=3 时返回 False，所以每轮最多 4 次），而不是设计的 9 次。

#### 3.3.3 can_start_new_round 与外层循环条件重复

```python
# core/message_handler.py:135-139
elif tool_result and not tool_result.any_success:
    if tracker.can_start_new_round:
        logger.info(f"[msg] agent1: re-decide after failures")
        drive_result = self._inner_drive.re_decide(user_input, tracker.failure_log)
    else:
        break
```

外层循环条件是 `round_num < MAX_AGENT2_ROUNDS`（即 `round_num < 3`），而 `tracker.can_start_new_round` 检查 `round_number < 3 and total_attempts < 9`。由于 `round_number` 永远是 0，`can_start_new_round` 实际上只检查 `total_attempts < 9`。但外层循环已经保证了最多 3 轮，所以这个检查是冗余的，且由于 tracker 每轮新建，`total_attempts` 永远不会达到 9。

#### 3.3.4 failure_log 不完整

```python
# core/message_handler.py:294-301
def track_failures(tracker, tool_result):
    for r in tool_result.records:
        if not r.success:
            tracker.failure_log.append({
                "name": r.name,
                "output": r.output[:200],
            })
```

这个函数只记录 `tool_result.records` 中的失败，但如果：
- `tool_result` 为空（没有工具被调用，`parse_tool_calls` 返回空）
- `tool_result.records` 为空但 `run_with_request()` 内部有异常

这些场景不会被记录到 `failure_log` 中。当 `re_decide()` 收到一个不完整的 `failure_log` 时，Agent 1 无法全面了解失败原因，可能做出错误的重新决策。

**建议**: 移除 `ToolAttemptTracker` 类，将重试和 round 控制逻辑直接集成到 `MessageHandler.handle_message()` 中，或者重写 `ToolAttemptTracker` 使其真正跨 round 共享状态：

```python
# 方案 A: 移除 ToolAttemptTracker，直接在 MessageHandler 中控制
MAX_AGENT2_ROUNDS = 3
MAX_RETRIES_PER_ROUND = 3
total_attempts = 0
failure_log = []

for round_num in range(1, MAX_AGENT2_ROUNDS + 1):
    for retry in range(MAX_RETRIES_PER_ROUND):
        total_attempts += 1
        if total_attempts > 9:
            break
        tool_result = self._tool_agent.run_with_request(request_text)
        # 记录所有类型的失败
        if not tool_result or not tool_result.has_results:
            failure_log.append({"name": "(no tool calls)", "output": "Agent 2 未输出任何工具调用"})
        else:
            for r in tool_result.records:
                if not r.success:
                    failure_log.append({"name": r.name, "output": r.output[:200]})
        if tool_result and tool_result.any_success:
            break
    # ... review/re_decide logic
```

---

### 3.4 工具结果格式化中的信息丢失

**文件**: `core/tool_agent.py:226-249` (`format_for_phase2()`), `core/dispatcher.py:153-169` (`format_tool_results()`)

#### 3.4.1 format_for_phase2 只接收单轮结果

```python
# core/tool_agent.py:226-249
def format_for_phase2(self, result: ToolAgentResult) -> str:
    if not result.has_results:
        return ""
    total_entries = sum(r.output.count("\n") + 1 for r in result.records)
    parts = [
        "=== 系统已获取的真实数据...",
        f"共执行 {result.total_calls} 个工具，成功 {result.success_count} 个...",
        ...
    ]
    for i, r in enumerate(result.records, 1):
        status = "成功" if r.success else "失败"
        entry_count = r.output.count("\n") + 1 if r.output else 0
        parts.append(
            f"[工具 {i}] {r.name}（{status}，{entry_count} 条结果）:\n"
            f"{r.output[:6000]}\n"
        )
    ...
```

`format_for_phase2()` 接收单个 `ToolAgentResult`，但 `MessageHandler` 中需要累积多轮结果。在 `MessageHandler` 中：

```python
# core/message_handler.py:121-123
combined_records = ""
for i, r in enumerate(all_tool_results):
    combined_records += self._tool_agent.format_for_phase2(r) + "\n"
```

这导致每轮结果都有独立的头部（"=== 系统已获取的真实数据 ==="），Agent 3 的 prompt 中会出现多个重复的头部，浪费 token 且可能让 LLM 困惑。

#### 3.4.2 _run_agent3 中的结果传递错误

```python
# core/message_handler.py:155-156
return self._run_agent3(user_input, drive_result, tool_result, on_token=on_token)
```

这里传递的是最后一轮的 `tool_result`，而不是所有轮次的累积结果 `all_tool_results`。虽然 `_run_agent3()` 中：

```python
# core/message_handler.py:255
tool_records = self._tool_agent.format_for_phase2(tool_result) if tool_result else ""
```

但 `tool_result` 是最后一轮的结果。如果最后一轮失败但前面轮次成功，`tool_records` 会错误地显示为空或只有失败信息。虽然 `handle_message()` 前面已经构建了 `tool_records`（第144-149行），但 `_run_agent3()` 又重新格式化，覆盖了前面的工作。

**行号引用**: `core/message_handler.py:143-156`

#### 3.4.3 ToolCallRecord.arguments 永远为空

```python
# core/tool_agent.py:116-120 (run 方法)
record = ToolCallRecord(
    name=r["name"],
    arguments={},  # 永远是空！
    success=r["success"],
    output=r["output"][:3000],
)

# core/tool_agent.py:193-198 (run_with_request 方法)
record = ToolCallRecord(
    name=r["name"],
    arguments={},  # 永远是空！
    success=r["success"],
    output=r["output"][:3000],
)
```

`execute_tool_calls()` 返回的 `results` 中没有保留原始 `arguments`，所以 `ToolCallRecord.arguments` 永远是空字典。这意味着：
- Agent 3 无法知道工具具体使用了什么参数（如搜索了什么关键词、获取了哪个 URL）
- 调试和日志中无法追踪工具调用的具体参数
- `format_for_phase2()` 中无法显示参数信息

**建议**: 修改 `execute_tool_calls()` 返回结果中保留原始 arguments：

```python
# core/dispatcher.py:135-138
results.append({
    "name": name,
    "success": result.success,
    "output": result.output,
    "arguments": args,  # 新增
})
```

然后修改 `ToolCallRecord` 的创建：

```python
record = ToolCallRecord(
    name=r["name"],
    arguments=r.get("arguments", {}),  # 使用实际参数
    success=r["success"],
    output=r["output"][:3000],
)
```

#### 3.4.4 format_tool_results 与 format_for_phase2 的重复

`core/dispatcher.py:153-169` 的 `format_tool_results()` 和 `core/tool_agent.py:226-249` 的 `format_for_phase2()` 都负责将工具结果格式化为 prompt-friendly 文本，但两者的使用场景不同：
- `format_tool_results()`: 用于 Agent 3 的 ReAct 循环内部，将工具结果注入 messages
- `format_for_phase2()`: 用于将 Agent 2 的结果传递给 Agent 3

两者的格式不同：
- `format_tool_results()` 使用 `<tool_result name="...">` XML 标签 + "铁律" 约束
- `format_for_phase2()` 使用 `[工具 N] name（状态，条目数）` 格式 + "禁止编造" 约束

这种重复增加了维护成本，且两种格式的约束力度不同。`format_tool_results()` 的 "铁律" 约束更强（"你必须逐字如实汇报，不得编造、不得润色"），而 `format_for_phase2()` 的约束相对较弱。

---

### 3.5 工具调用历史维护的并发风险

**文件**: `core/agent.py:161-169` (`_react_loop()` 方法)

```python
# core/agent.py:161-169
for r in results:
    self._tool_call_history.append({
        "name": r["name"],
        "success": r["success"],
        "output": r["output"][:200],
        "time": time.time(),
    })
if len(self._tool_call_history) > 20:
    self._tool_call_history = self._tool_call_history[-20:]
```

#### 3.5.1 非原子截断操作

`_tool_call_history` 的截断操作是"先检查长度，再赋值截断"，这不是原子操作。在 Web 模式下，如果多个并发请求同时执行 `_react_loop()`，可能出现竞态条件：
- 请求 A 检查长度 > 20，准备截断
- 请求 B 同时 append 了一条记录
- 请求 A 赋值截断，可能丢失请求 B 刚 append 的记录

虽然当前 Web 服务器的并发模型（asyncio）在单个事件循环中是单线程的，但如果未来引入多 worker 或多进程，这个问题会暴露。

#### 3.5.2 截断后丢失历史上下文

`_tool_call_history` 只保留最近 20 条记录，但在长对话中，Agent 3 可能需要参考更早的工具调用历史来理解上下文。例如，用户可能在第 10 轮提到了"刚才搜索的结果"，但第 10 轮的搜索记录可能已经被截断（如果中间进行了多次内部工具调用）。

#### 3.5.3 不记录工具参数

`_tool_call_history` 只记录工具名、成功状态、输出截断和时间戳，不记录工具参数。这意味着当 Agent 3 查看工具调用历史时，无法知道"之前搜索了什么关键词"、"之前获取了哪个 URL"。

#### 3.5.4 Agent 2 的工具调用不记录到 _tool_call_history

`_tool_call_history` 只在 Agent 3 的 `_react_loop()` 中更新，Agent 2 执行的外部工具调用不会被记录。这意味着 Agent 3 看不到 Agent 2 的工具调用历史，只能看到 Agent 2 返回的格式化结果。如果 Agent 2 执行了多次搜索和获取，Agent 3 只能看到最终结果，看不到中间过程。

---

### 3.6 内驱推理中内部工具与外部工具的区分

**文件**: `core/inner_drive.py:17-20`, `core/tool_agent.py:15-18`

#### 3.6.1 EXTERNAL_TOOL_NAMES 重复定义

```python
# core/inner_drive.py:17-20
EXTERNAL_TOOL_NAMES = [
    "web_fetch", "web_search", "read_file", "glob", "grep",
    "music_play", "notify",
]

# core/tool_agent.py:15-18
EXTERNAL_TOOL_NAMES = [
    "web_fetch", "web_search", "read_file", "glob", "grep",
    "music_play", "notify",
]
```

同一个列表在两个文件中重复定义，违反了 DRY 原则。如果新增或删除外部工具，需要修改两个文件，容易遗漏。

#### 3.6.2 内部工具列表没有集中定义

内部工具（recall、remember）的列表分散在多个文件中：
- `core/message_handler.py:58-61` (`_make_internal_registry()`)
- `core/cli_controller.py:44-51` (`_make_internal_registry()`)
- `core/inner_drive.py` (prompt 中硬编码)

没有统一的内部工具列表定义，维护成本高。

#### 3.6.3 Agent 1 的 _parse_decision 中的外部工具检测过于宽松

```python
# core/inner_drive.py:281-286
has_external = any(
    name in text for name in EXTERNAL_TOOL_NAMES
) or any(kw in text for kw in [
    "需要调用", "需要外部", "需要获取", "需要搜索", "需要读取",
    "调用web", "用web", "需要查", "需要打开",
])
```

这种基于关键词的检测方式容易误报和漏报：
- **误报**: 如果 Agent 1 的 reasoning 中提到了"用户说不需要搜索"，关键词"需要搜索"会触发误报
- **漏报**: 如果 Agent 1 用其他词汇描述工具需求（如"想查一下"、"看看网页"），可能漏检

更可靠的方式是让 Agent 1 输出结构化的决策格式（如 JSON），然后解析结构化输出，而不是依赖关键词匹配。

#### 3.6.4 Agent 1 的 _extract_tool_requests 解析能力有限

```python
# core/inner_drive.py:304-346
def _extract_tool_requests(self, text: str) -> list[ToolRequest]:
    requests = []
    # Look for URL patterns
    urls = re.findall(r'https?://[^\s一-鿿]+', text)
    ...
    # Look for search intent
    search_matches = re.findall(r'(?:搜索|查询|搜一下|搜)[：:]\s*(.+?)(?:[，。,\.\n]|$)', text)
    ...
    # Look for file-related intent
    file_matches = re.findall(r'(?:读取|打开|查看)[：:]\s*(.+?)(?:[，。,\.\n]|$)', text)
    ...
```

这个解析器只能识别三种模式：URL、搜索意图、文件读取意图。对于其他外部工具（如 `music_play`、`notify`、`glob`、`grep`），没有对应的解析逻辑。如果 Agent 1 请求了这些工具，`_extract_tool_requests()` 会返回一个 generic request（第339-344行），`suggested_tool` 为空，`params_hint` 为空。

这意味着 Agent 2 收到一个"需要调用某个工具"的请求，但不知道具体是什么工具、什么参数，只能依赖 Agent 2 自己从自然语言描述中推断。这增加了 Agent 2 的推理负担，降低了工具调用的准确性。

---

### 3.7 数据流中的信息丢失

#### 3.7.1 Agent 1 review 过程中的新记忆对 Agent 3 不可见

```python
# core/inner_drive.py:200-206 (review 方法)
if calls:
    messages.append({"role": "assistant", "content": resp})
    results = execute_tool_calls(self._full_registry, calls)
    result_text = self._format_internal_results(results)
    messages.append({"role": "user", "content": result_text})
    resp = self._provider.generate(messages, stream=False, max_tokens=512)
    cleaned, _ = parse_tool_calls(resp)
```

Agent 1 在 `review()` 中可能调用 recall/remember 获取新记忆，但这些记忆只在 Agent 1 的局部 `messages` 列表中，不会被传递给 Agent 3。Agent 3 的 prompt 使用的是：

```python
# core/message_handler.py:249
mem_ctx = a.retriever.retrieve_for_query(user_input)
```

这是重新检索的记忆，不是 Agent 1 review 时获取的记忆。如果 Agent 1 在 review 过程中通过 recall 获取了关键信息（如"用户之前提到过喜欢某部电影"），这些信息对 Agent 3 是不可见的。

#### 3.7.2 Agent 2 的 arguments 信息丢失

如前所述，`ToolCallRecord.arguments` 永远为空，Agent 3 无法知道 Agent 2 具体使用了什么参数。这在调试和用户体验上都是问题——如果 Agent 2 搜索了错误的关键词，Agent 3 无法知道搜索了什么，也就无法向用户解释。

#### 3.7.3 Agent 2 的多轮结果在 _run_agent3 中丢失

```python
# core/message_handler.py:155-156
return self._run_agent3(user_input, drive_result, tool_result, on_token=on_token)
```

`_run_agent3()` 接收的是最后一轮的 `tool_result`，而不是所有轮次的 `all_tool_results`。虽然 `handle_message()` 前面构建了 `tool_records`（第144-149行），但 `_run_agent3()` 中：

```python
# core/message_handler.py:255
tool_records = self._tool_agent.format_for_phase2(tool_result) if tool_result else ""
```

这里重新从 `tool_result` 格式化，覆盖了前面构建的 `tool_records`。如果最后一轮失败但前面轮次成功，Agent 3 将看不到前面轮次的成功结果。

#### 3.7.4 run_with_request 的 retry 丢失历史上下文

```python
# core/tool_agent.py:172-178
messages = [
    {"role": "system", "content": sys_prompt},
    {"role": "user", "content": (
        f"Agent 1 的内驱推理请求：\n{tool_request}\n\n"
        f"之前的尝试失败了（{last_failure}）。"
        "请调整方式后重新输出 JSON 格式的工具调用。"
    )},
]
```

在 retry 时，messages 被完全重建，丢失了之前 assistant 的响应和工具执行结果。Agent 2 在 retry 时看不到自己之前输出了什么、工具返回了什么，只能依赖 `last_failure` 这一行简短的描述。

---

### 3.8 状态不一致问题

#### 3.8.1 Web 路径与 CLI 路径的 Agent 3 工具权限不一致

**Web 路径** (`core/message_handler.py:270-272`):
```python
phase2_registry = self._make_internal_registry() if tool_records else None
return a._react_loop(messages, on_token, add_to_history=True,
                    tool_registry=phase2_registry)
```

如果 `tool_records` 存在（即 Agent 2 执行了外部工具），Agent 3 只能调用内部工具（recall/remember）。

**CLI 路径** (`core/cli_controller.py:251-253`):
```python
active_registry = a._tool_registry
if self._tool_records:
    active_registry = self._make_internal_registry()
results = execute_tool_calls(active_registry, tool_calls)
```

如果 Agent 1 没有请求外部工具（`self._tool_records` 为空），Agent 3 可以调用全部工具。

这种不一致意味着：
- Web 路径：Agent 3 永远不能在表达阶段调用外部工具
- CLI 路径：Agent 3 可以在表达阶段调用外部工具（如果 Agent 1 没有预先请求）

这违反了"架构行为一致性"原则，同一套 Agent 逻辑在不同入口点表现不同。

#### 3.8.2 Agent 1 达到 max_iterations 后的默认行为不一致

```python
# core/inner_drive.py:105-111
logger.warning("[inner_drive] max iterations, defaulting to no tools")
return InnerDriveResult(
    needs_external_tools=False,
    reasoning="达到最大迭代次数，默认不需要外部工具",
    summary="",
)
```

当 Agent 1 的 ReAct 循环达到 `max_iterations=5` 次仍未做出决策时，默认返回"不需要外部工具"。但这个默认行为可能是错误的——如果 Agent 1 在循环中一直在调用 recall 获取信息，说明它认为需要更多信息才能决策，此时默认"不需要工具"可能导致遗漏关键的外部工具调用。

#### 3.8.3 _tool_call_history 与 Agent 2 记录不同步

`_tool_call_history` 只在 Agent 3 的 `_react_loop()` 中更新，Agent 2 执行的外部工具调用不会被记录。这意味着：
- `_tool_call_history` 中只包含 Agent 3 调用的工具（主要是 recall/remember）
- Agent 2 调用的外部工具（web_fetch、web_search 等）不在 `_tool_call_history` 中
- Agent 3 的 system prompt 中显示的"工具调用记录"只包含内部工具，不包含外部工具

用户可能问"你刚才搜索了什么"，Agent 3 查看 `_tool_call_history` 发现没有搜索记录，会回答"我没有搜索"，但实际上 Agent 2 已经执行了搜索。

---

### 3.9 重试逻辑缺陷

#### 3.9.1 Agent 2 的 retry 不区分失败类型

`run_with_request()` 的 retry 逻辑对所有失败一视同仁：
- LLM 未输出工具调用（parse_tool_calls 返回空）
- LLM 输出了工具调用但参数错误（工具执行失败）
- 工具执行成功但返回空结果
- Provider API 调用失败

这些不同类型的失败需要不同的 retry 策略：
- 未输出工具调用：可能是 prompt 不够清晰，需要调整 prompt
- 参数错误：需要让 LLM 修正参数
- 返回空结果：可能需要换搜索词或工具
- API 失败：需要指数退避重试

当前的统一 retry 策略无法针对具体失败原因进行优化。

#### 3.9.2 MessageHandler 的 in-round retry 与 run_with_request 的 retry 嵌套

```python
# core/message_handler.py:110-115
while tracker.can_retry_in_round and not tool_result.any_success:
    tracker.retry_count += 1
    logger.info(f"[msg] agent2: retry {tracker.retry_count}/3")
    tool_result = self._tool_agent.run_with_request(request_text)
    tracker.total_attempts += 1
    track_failures(tracker, tool_result)
```

`run_with_request()` 内部已经有 max_retries=3 的重试，而 `MessageHandler` 又在 `run_with_request()` 返回后根据 `can_retry_in_round` 再次调用 `run_with_request()`。这形成了两层嵌套重试：
- 内层：`run_with_request()` 内部最多 3 次尝试
- 外层：`MessageHandler` 最多 3 次调用 `run_with_request()`

理论上最多 9 次尝试，但由于 `ToolAttemptTracker` 的状态管理缺陷，实际行为不可预测。

#### 3.9.3 retry 时未增加 temperature

在 retry 时，系统使用相同的 temperature（Agent 2 默认未显式设置，可能使用 provider 默认值）调用 LLM。如果 LLM 连续多次输出相同的错误结果（如相同的错误参数），相同的 temperature 不会帮助探索新的解决方案。更好的策略是在 retry 时略微增加 temperature，鼓励 LLM 尝试不同的参数组合。

---

### 3.10 解析逻辑的边界情况

#### 3.10.1 parse_tool_calls 的 Tier 1 与 Tier 3 冲突

```python
# core/dispatcher.py:29-33
calls = _try_structured_json(text)
if calls:
    return "", calls

# core/dispatcher.py:67-76
if not calls:
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            name = obj.get("name") or obj.get("tool", "")
            if name:
                args = _normalize_args(obj.get("arguments", {}))
                calls.append({"name": name, "arguments": args})
                cleaned = ""
    except json.JSONDecodeError:
        pass
```

如果 LLM 输出 `{"calls": [...], "name": "something"}`（同时包含 calls 数组和顶层 name 字段），Tier 1 会解析 calls 数组并忽略顶层 name，Tier 3 永远不会执行。但如果 calls 数组为空而顶层 name 有效，Tier 1 返回空 calls，Tier 3 会捕获顶层 name。这种优先级逻辑没有文档说明，可能导致意外行为。

#### 3.10.2 _normalize_args 的类型安全问题

```python
# core/dispatcher.py:197-212
def _normalize_args(args: dict) -> dict:
    result = dict(args)
    ...
```

如果 `args` 不是 dict（如字符串、list、None），`dict(args)` 会抛出 `TypeError`。Tier 3 的 fallback 路径中没有检查 `arguments` 的类型：

```python
# core/dispatcher.py:72-74
args = _normalize_args(obj.get("arguments", {}))
```

如果 `obj["arguments"]` 是字符串 `"{}"` 而不是 dict，`_normalize_args` 会崩溃。

---

## 4. 汇总统计

### 4.1 代码规模

| 文件 | 行数 | 类/函数数 | 审查重点 |
|------|------|----------|---------|
| core/tool_agent.py | 259 | 4 类 / 4 方法 | Agent 2 执行、重试、格式化 |
| core/dispatcher.py | 213 | 6 函数 | 工具解析、执行、格式化 |
| tools/traits.py | 95 | 4 类 | 工具基类、Registry、Schema |
| core/inner_drive.py | 376 | 4 类 / 10+ 方法 | Agent 1 决策、review、re_decide |
| core/message_handler.py | 302 | 1 类 / 8 方法 | 三层编排、ToolAttemptTracker 使用 |
| core/agent.py | 253 | 1 类 / 15+ 方法 | Agent 3 ReAct、_tool_call_history |
| core/cli_controller.py | 335 | 1 类 / 15+ 方法 | CLI 路径、状态机 |
| prompts/system.py | 521 | 5 函数 | Prompt 构建、工具描述注入 |
| **合计** | **~2354** | **20+ 类 / 60+ 方法** | |

### 4.2 问题统计

| 类别 | 数量 | 高优先级 | 中优先级 | 低优先级 |
|------|------|---------|---------|---------|
| 工具隔离缺陷 | 3 | 2 | 1 | 0 |
| 重试机制缺陷 | 5 | 2 | 2 | 1 |
| 状态管理失效 | 4 | 1 | 2 | 1 |
| 信息丢失 | 5 | 2 | 2 | 1 |
| 状态不一致 | 4 | 1 | 2 | 1 |
| 数据流断裂 | 3 | 2 | 1 | 0 |
| 解析逻辑缺陷 | 2 | 1 | 1 | 0 |
| 代码重复/DRY | 3 | 0 | 2 | 1 |
| **合计** | **29** | **11** | **13** | **5** |

### 4.3 风险评级汇总

| 风险项 | 严重等级 | 影响范围 | 文件位置 |
|--------|---------|---------|---------|
| Agent 1 可绕过 Agent 2 直接执行外部工具 | **高** | 工具执行隔离、数据安全 | `core/inner_drive.py:99` |
| Agent 2 retry 时 last_failure 未更新 | **高** | 工具调用成功率 | `core/tool_agent.py:183-186` |
| MessageHandler 中 Agent 2 结果传递错误 | **高** | 数据流断裂、回复质量 | `core/message_handler.py:155-156` |
| ToolAttemptTracker 状态管理完全失效 | **高** | 重试机制、循环控制 | `core/message_handler.py:104` |
| Agent 2 的 Provider 异常未捕获 | **高** | 系统稳定性 | `core/tool_agent.py:181-182` |
| execute_tool_calls 中 asyncio.run() 循环调用 | **高** | 性能、兼容性 | `core/dispatcher.py:128-133` |
| ToolCallRecord.arguments 永远为空 | **中** | 可观测性、调试 | `core/tool_agent.py:119` |
| _tool_call_history 不记录 Agent 2 调用 | **中** | 工具历史完整性 | `core/agent.py:161-169` |
| Agent 1 review 新记忆对 Agent 3 不可见 | **中** | 上下文完整性 | `core/inner_drive.py:200-206` |
| Web/CLI 路径 Agent 3 工具权限不一致 | **中** | 架构一致性 | `core/message_handler.py:270` vs `core/cli_controller.py:251` |
| EXTERNAL_TOOL_NAMES 重复定义 | **低** | 可维护性 | `core/inner_drive.py:17` / `core/tool_agent.py:15` |
| _tool_call_history 并发截断风险 | **低** | 并发安全 | `core/agent.py:168-169` |
| format_for_phase2 多轮结果重复头部 | **低** | Token 效率 | `core/tool_agent.py:226-249` |

### 4.4 关键结论

1. **Agent 1 的工具隔离是最严重的架构漏洞**。Agent 1 使用 `full_registry` 执行内部工具，没有任何运行时防护阻止外部工具的直接执行。这破坏了"Agent 1 决策 -> Agent 2 执行"的核心架构隔离，可能导致外部工具绕过 Agent 2 的 retry 机制和结果格式化。

2. **ToolAttemptTracker 完全失效**。`round_number` 永远是 0，tracker 每轮新建导致状态不共享，"3 rounds x 3 retries = 9 attempts"的设计意图完全没有实现。实际行为是不可预测的，最多可能执行 12 次尝试。

3. **Agent 2 的结果在传递给 Agent 3 时存在断裂**。`_run_agent3()` 接收最后一轮的 `tool_result` 而不是所有轮次的累积结果，导致前面轮次的成功结果可能丢失。

4. **Agent 2 的 retry 机制存在多层缺陷**。`last_failure` 未更新、Provider 异常未捕获、retry 时丢失历史上下文、不区分失败类型，这些问题叠加导致 retry 的实际效果远低于预期。

5. **工具调用历史 `_tool_call_history` 不完整**。只记录 Agent 3 调用的内部工具，不记录 Agent 2 调用的外部工具，且不记录工具参数。这导致 Agent 3 无法全面了解工具调用历史。

6. **Web 路径和 CLI 路径的 Agent 3 工具权限不一致**。Web 路径中 Agent 3 只能调用内部工具，CLI 路径中 Agent 3 可以调用全部工具（如果 Agent 1 未请求外部工具）。这种不一致违反了架构行为一致性原则。

7. **整体风险评级：中高风险**。建议优先修复高优先级问题（Agent 1 工具隔离、Agent 2 retry 逻辑、结果传递、ToolAttemptTracker、Provider 异常捕获），然后逐步处理中优先级问题（参数记录、历史完整性、路径一致性）。

---

*报告生成时间: 2026-05-31*  
*审查范围: core/tool_agent.py, core/dispatcher.py, tools/traits.py, core/inner_drive.py, core/message_handler.py, core/agent.py, core/cli_controller.py, prompts/system.py*  
*关联测试: tests/test_tool_agent.py, tests/test_dispatcher.py*
