# AI Friend 项目第4轮审查：错误处理与重试机制可靠性审查

**审查日期**: 2026-05-31
**审查范围**: core/provider.py, core/tool_agent.py, core/dispatcher.py, core/message_handler.py, tools/web_tools.py, tools/file_tools.py, tools/search_tools.py, tools/memory_tools.py, tools/notify_tool.py, tools/music_tool.py, core/inner_drive.py, core/agent.py, core/context_manager.py
**审查重点**: 重试机制有效性、错误处理完整性、退避策略合理性、模块间一致性

---

## 一、概述

AI Friend 项目采用三层 Agent 架构，重试机制分布在多个层级：

- **Provider 层** (`core/provider.py`): KimiProvider.generate() 实现 API 调用级重试（3次，指数退避）
- **ToolAgent 层** (`core/tool_agent.py`): run_with_request() 实现单轮内重试（默认3次），ToolAttemptTracker 实现跨轮次状态追踪（3轮 x 3重试 = 最多9次）
- **MessageHandler 层** (`core/message_handler.py`): handle_message() 实现 Agent 2 的多轮执行循环（最多3轮），以及每轮内部的 in-round retry
- **Dispatcher 层** (`core/dispatcher.py`): 工具调用解析和执行，无独立重试逻辑
- **各 Tool 实现**: 无独立重试逻辑，异常捕获后返回 ToolResult.fail()

本次审查发现 **高风险问题 5 项，中风险问题 8 项，低风险问题 6 项**，核心风险集中在：重试条件遗漏关键异常类型、退避策略无抖动导致惊群效应、嵌套重试导致总尝试次数爆炸、重试耗尽后降级策略缺失、以及跨模块重试策略不一致。

---

## 二、详细发现

### 2.1 Provider 层重试机制（core/provider.py）

#### 2.1.1 高风险：重试条件遗漏关键异常类型

**文件路径**: `core/provider.py`
**行号**: 56-80

```python
for attempt in range(3):
    try:
        return self._do_request(chat_url, payload, stream, on_token)
    except requests.exceptions.ConnectionError as e:
        ...
    except requests.exceptions.HTTPError as e:
        ...
    except (requests.exceptions.ChunkedEncodingError,
            requests.exceptions.StreamConsumedError) as e:
        ...
```

**问题描述**:
`generate()` 方法仅捕获了 4 类异常：ConnectionError、HTTPError（且仅对 >=500 重试）、ChunkedEncodingError、StreamConsumedError。但以下常见网络异常被完全遗漏，会直接抛到上层：

1. **`requests.exceptions.Timeout`**（连接超时、读取超时）：第 88-91 行设置了 `timeout=self.timeout`（默认180秒），但超时异常未被捕获。当 API 响应缓慢或网络抖动时，Timeout 会直接中断整个调用链，不会触发任何重试。
2. **`requests.exceptions.TooManyRedirects`**：虽然较少见，但在 API 网关变更或 DNS 问题时可能出现。
3. **`requests.exceptions.SSLError`** / **`requests.exceptions.ProxyError`**：SSL 握手失败或代理问题，这些通常是暂时性的（如证书更新、代理重启）。
4. **`json.JSONDecodeError`**：第 125-126 行在流式解析时捕获了 JSONDecodeError，但只是 `continue` 跳过该行。如果流式响应中大量行都解析失败（如 API 返回了 HTML 错误页面而非 SSE），`_do_request` 会返回空字符串，但 `generate()` 不会对此进行重试。
5. **`requests.exceptions.RequestException`** 的其他子类：如 `InvalidURL`、`ChunkedEncodingError` 的兄弟异常等。

**风险评级**: **高风险**

**影响**: 任何一次网络超时都会导致整个对话流程中断，用户会看到异常堆栈或空白回复。在高负载或网络不稳定场景下，这是最常见的外部故障模式。

**建议修复**:
```python
import requests.exceptions as req_exc

RETRYABLE_EXCEPTIONS = (
    req_exc.ConnectionError,
    req_exc.Timeout,           # 新增
    req_exc.ChunkedEncodingError,
    req_exc.StreamConsumedError,
    req_exc.ProxyError,        # 新增
)

for attempt in range(3):
    try:
        return self._do_request(...)
    except RETRYABLE_EXCEPTIONS as e:
        last_error = e
        wait = 2 ** attempt
        logger.warning(f"[api] retryable error attempt={attempt+1}/3 retry_in={wait}s: {e}")
        time.sleep(wait)
    except req_exc.HTTPError as e:
        last_error = e
        if e.response.status_code < 500:
            raise
        wait = 2 ** attempt
        logger.warning(...)
        time.sleep(wait)
    except req_exc.SSLError as e:   # 可单独处理，视业务需求决定是否重试
        last_error = e
        # SSL 错误通常不应重试，直接抛出
        raise
```

---

#### 2.1.2 中风险：退避策略无抖动，存在惊群效应风险

**文件路径**: `core/provider.py`
**行号**: 62-64, 69-71, 75-77

```python
wait = 2 ** attempt
logger.warning(f"[api] connection error attempt={attempt+1}/3 retry_in={wait}s: {e}")
time.sleep(wait)
```

**问题描述**:
退避间隔严格为 `2^attempt` 秒：第1次等待1秒，第2次等待2秒，第3次等待4秒。存在以下问题：

1. **无抖动（Jitter）**: 如果多个实例同时遇到同一 API 端点的故障（如 API 网关短暂过载），它们会在完全相同的时刻（1s, 2s, 4s）发起重试，形成"惊群效应"，进一步压垮已恢复的 API。
2. **退避过短**: 对于 500 类服务器错误，1-4 秒的退避可能不足以让后端服务恢复。业界常用"指数退避 + 抖动 + 上限"，如 `min(2^attempt + random(0,1), 60)`。
3. **无总超时控制**: 三次重试最多等待 7 秒，加上原始请求 180 秒超时，单次 `generate()` 调用可能耗时 187 秒。上层调用者（如 ToolAgent）对此无感知。

**风险评级**: **中风险**

**建议修复**:
```python
import random

MAX_BACKOFF = 30  # 最大退避30秒
wait = min(2 ** attempt + random.uniform(0, 1), MAX_BACKOFF)
```

---

#### 2.1.3 中风险：HTTP 429 (Rate Limit) 未被特殊处理

**文件路径**: `core/provider.py`
**行号**: 65-71

```python
except requests.exceptions.HTTPError as e:
    last_error = e
    if e.response.status_code < 500:
        raise
```

**问题描述**:
HTTP 429 (Too Many Requests) 属于 4xx 错误，当前逻辑直接 `raise`，不会触发重试。但 429 是最典型的"应该重试"的客户端错误，且通常响应头中包含 `Retry-After` 字段指示等待时间。当前实现：
- 不识别 429 状态码
- 不读取 `Retry-After` 头
- 不将 429 视为可重试错误

**风险评级**: **中风险**

**建议修复**:
```python
except requests.exceptions.HTTPError as e:
    last_error = e
    status = e.response.status_code
    if status == 429:
        retry_after = e.response.headers.get("Retry-After")
        wait = int(retry_after) if retry_after else 2 ** attempt
        logger.warning(f"[api] rate limited, retry_after={retry_after}")
        time.sleep(wait)
        continue
    if status < 500:
        raise
    wait = min(2 ** attempt + random.uniform(0, 1), MAX_BACKOFF)
    logger.warning(...)
    time.sleep(wait)
```

---

#### 2.1.4 低风险：流式响应中的 JSONDecodeError 被静默跳过

**文件路径**: `core/provider.py`
**行号**: 125-126

```python
except json.JSONDecodeError:
    continue
```

**问题描述**:
在 SSE 流解析中，如果某一行 JSON 解析失败，直接跳过。这在 API 返回了非 JSON 内容（如 HTML 错误页面、负载均衡器的 502 页面）时，会导致：
- 不报错
- 返回空字符串或部分字符串
- 上层调用者无法区分"API 返回了空内容"和"API 返回了错误页面"

**风险评级**: **低风险**

**建议修复**:
增加连续 JSON 解析失败的计数器，超过阈值（如 3 次）则抛出异常，让外层重试逻辑接管。

---

#### 2.1.5 中风险：无请求级超时熔断

**文件路径**: `core/provider.py`
**行号**: 88-91

```python
resp = self.session.post(
    url,
    json=payload,
    stream=True,
    timeout=self.timeout,
)
```

**问题描述**:
`timeout=180` 是单次请求的超时，但 `generate()` 方法没有总耗时限制。如果 API 在每次重试时都恰好耗时 179 秒后超时，三次重试将耗时 537 秒 + 7 秒退避 = 544 秒。上层（如 Web 端的 HTTP 请求）通常会在 30-60 秒后断开连接，导致用户看到超时错误，而 Provider 层仍在重试。

**风险评级**: **中风险**

**建议修复**:
在 `generate()` 入口记录 `deadline = time.time() + max_total_time`，每次重试前检查是否已超时。

---

### 2.2 ToolAgent 层重试机制（core/tool_agent.py）

#### 2.2.1 高风险：run_with_request 的重试逻辑存在语义混淆

**文件路径**: `core/tool_agent.py`
**行号**: 142-224

```python
def run_with_request(self, tool_request: str, max_retries: int = 3) -> ToolAgentResult:
    ...
    last_failure = None
    for attempt in range(1, max_retries + 1):
        if attempt > 1:
            logger.info(f"[tool_agent] retry {attempt}/{max_retries}")
            messages = [...]  # 重建 messages，包含 last_failure

        resp = self._provider.generate(messages, stream=False, max_tokens=512,
                                      response_format=json_schema)
        cleaned, calls = parse_tool_calls(resp)
        if not calls:
            logger.debug("[tool_agent] no tool calls parsed from response")
            continue

        ...  # 执行工具

        if result.any_success:
            break

        last_failure = "; ".join(
            r["output"][:100] for r in results if not r["success"]
        )
```

**问题描述**:
`run_with_request` 的"重试"语义模糊，存在三个层面的问题：

1. **重试触发条件不明确**: 重试在两种情况下触发：
   - `parse_tool_calls()` 返回空（LLM 没有输出工具调用）
   - 所有工具执行都失败（`not result.any_success`）
   但第一种情况（空 calls）只是 `continue`，没有记录 `last_failure`，导致下一次重试的 prompt 中 `last_failure` 仍然是上一次工具执行失败的旧值，信息不准确。

2. **LLM 输出空 calls 时无限循环风险**: 如果 LLM 连续 3 次都输出空 calls（不输出任何工具调用），`run_with_request` 会执行 3 次 `generate()` 但都无实际工具调用，最终返回一个空的 `ToolAgentResult`。此时 `MessageHandler` 中的 `tool_result.any_success` 为 False，会触发 in-round retry，但问题根源（LLM 不输出工具调用）并未解决。

3. **last_failure 信息截断**: `last_failure` 只取前 100 字符，对于复杂的工具错误（如网页返回的 HTML 错误页面），100 字符可能不足以让 LLM 理解失败原因。

**风险评级**: **高风险**

**建议修复**:
- 区分"解析失败"和"工具执行失败"两种重试场景
- 对解析失败的情况也记录失败信息（如"LLM 未输出有效的工具调用格式"）
- 增加 `last_failure` 长度限制到 500 字符
- 考虑在解析失败时向 LLM 提供更明确的格式指导

---

#### 2.2.2 高风险：嵌套重试导致总尝试次数可能远超预期

**文件路径**: `core/tool_agent.py` + `core/message_handler.py`

**问题描述**:
重试机制在三个层级嵌套：

1. **Provider 层**: `generate()` 内部 3 次重试
2. **ToolAgent.run_with_request()**: 最多 3 次 attempt
3. **MessageHandler.handle_message()**: 最多 3 轮 round，每轮内部最多 3 次 in-round retry

理论最大 API 调用次数 = 3 (Provider) x 3 (ToolAgent) x 3 (round) x 3 (in-round) = **81 次 API 调用**。

但实际上 `MessageHandler` 的 in-round retry 调用的是 `run_with_request`，而 `run_with_request` 内部已经做了 3 次 attempt。所以实际是：
- 每轮：1 次 `run_with_request`（内部最多 3 次 API 调用）
- in-round retry：再调用 `run_with_request`（内部最多 3 次 API 调用），最多 2 次
- 所以每轮最多 9 次 API 调用
- 3 轮最多 27 次 API 调用
- 每次 API 调用 Provider 层最多 3 次重试
- **总计最多 81 次 HTTP 请求**

在 API 按量计费或有限速的场景下，这可能导致：
- 费用爆炸
- 触发更严格的 rate limit
- 用户体验极差（等待数分钟）

**风险评级**: **高风险**

**建议修复**:
- 明确各层级的职责边界：Provider 负责网络级重试，ToolAgent 负责 LLM 输出质量重试，MessageHandler 负责策略级重试
- 在 ToolAgent 或 MessageHandler 中增加全局计数器，限制单次用户消息的总 API 调用次数（如最多 10 次）
- 或者取消 MessageHandler 的 in-round retry，将重试完全交给 `run_with_request` 内部处理

---

#### 2.2.3 中风险：ToolAttemptTracker 的 can_start_new_round 逻辑存在边界错误

**文件路径**: `core/tool_agent.py`
**行号**: 48-66

```python
@dataclass
class ToolAttemptTracker:
    round_number: int = 0
    retry_count: int = 0
    total_attempts: int = 0
    failure_log: list[dict] = field(default_factory=list)

    @property
    def can_retry_in_round(self) -> bool:
        return self.retry_count < 3

    @property
    def can_start_new_round(self) -> bool:
        return self.round_number < 3 and self.total_attempts < 9

    @property
    def is_exhausted(self) -> bool:
        return self.total_attempts >= 9
```

**问题描述**:
1. `can_start_new_round` 检查 `round_number < 3`，但 `round_number` 在 `MessageHandler` 中从 0 开始，第1轮结束后变为1。实际上最多允许 3 轮（round_number = 1, 2, 3），但 `round_number < 3` 只允许 round_number = 1, 2，即最多 2 轮新 round。这与注释"3 rounds x 3 retries = max 9 attempts"不完全一致。
2. `total_attempts < 9` 的限制在 `MessageHandler` 中并未严格执行。`MessageHandler` 每轮调用 `run_with_request` 时，`tracker.total_attempts += 1`，但 `run_with_request` 内部的 3 次 attempt 并不增加 `total_attempts`。
3. `is_exhausted` 基于 `total_attempts >= 9`，但如果 `run_with_request` 内部已经消耗了 3 次 attempt，`total_attempts` 只增加了 1，导致实际尝试次数可能远超 9 次而 `is_exhausted` 仍为 False。

**风险评级**: **中风险**

**建议修复**:
- 统一"attempt"的定义：是 API 调用次数还是 `run_with_request` 调用次数
- 在 `run_with_request` 返回时，将内部实际消耗的 attempt 数回传给 tracker
- 或者简化设计，取消 ToolAttemptTracker 的复杂状态，改用简单的全局计数器

---

#### 2.2.4 中风险：run_with_request 重试时不保留对话上下文

**文件路径**: `core/tool_agent.py`
**行号**: 169-179

```python
for attempt in range(1, max_retries + 1):
    if attempt > 1:
        messages = [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": (
                f"Agent 1 的内驱推理请求：\n{tool_request}\n\n"
                f"之前的尝试失败了（{last_failure}）。"
                "请调整方式后重新输出 JSON 格式的工具调用。"
            )},
        ]
```

**问题描述**:
每次重试都完全重建 `messages`，丢弃了之前 attempt 中 LLM 的响应和工具执行结果。这意味着：
- LLM 无法从之前的错误中学习（如"上次我搜索了 A，发现不对，这次应该搜索 B"）
- 如果第一次 attempt 中部分工具成功、部分失败，第二次 attempt 会完全重来
- 与 `run()` 方法中的 ReAct 循环（保留完整对话历史）不一致

**风险评级**: **中风险**

**建议修复**:
保留重试间的对话上下文，仅在最后追加失败信息和重试指示：
```python
if attempt > 1:
    messages.append({"role": "assistant", "content": resp})
    messages.append({"role": "user", "content": f"之前的尝试失败了（{last_failure}）。请调整方式后重试。"})
```

---

#### 2.2.5 低风险：ToolCallRecord 未记录 arguments

**文件路径**: `core/tool_agent.py`
**行号**: 116-122, 193-200

```python
record = ToolCallRecord(
    name=r["name"],
    arguments={},  # 始终为空！
    success=r["success"],
    output=r["output"][:3000],
)
```

**问题描述**:
`arguments` 字段始终被设置为空字典 `{}`，但实际工具调用的参数（如搜索关键词、URL）对于故障排查和审计非常重要。在重试场景中，如果不知道每次 attempt 使用了什么参数，无法判断是参数问题还是工具本身的问题。

**风险评级**: **低风险**

**建议修复**:
```python
record = ToolCallRecord(
    name=r["name"],
    arguments=call.get("arguments", {}),  # 从原始调用中保留参数
    success=r["success"],
    output=r["output"][:3000],
)
```

---

### 2.3 MessageHandler 层重试机制（core/message_handler.py）

#### 2.3.1 高风险：handle_message 中的 in-round retry 与 run_with_request 内部重试重复

**文件路径**: `core/message_handler.py`
**行号**: 98-141

```python
while round_num < MAX_AGENT2_ROUNDS and drive_result.needs_external_tools:
    round_num += 1
    ...
    tracker = ToolAttemptTracker()
    tool_result = self._tool_agent.run_with_request(request_text)
    tracker.total_attempts += 1
    track_failures(tracker, tool_result)

    # In-round retries on failure
    while tracker.can_retry_in_round and not tool_result.any_success:
        tracker.retry_count += 1
        logger.info(f"[msg] agent2: retry {tracker.retry_count}/3")
        tool_result = self._tool_agent.run_with_request(request_text)
        tracker.total_attempts += 1
        track_failures(tracker, tool_result)
```

**问题描述**:
这是 2.2.2 中描述的问题的具体实现。`run_with_request` 内部已经有最多 3 次 attempt，而 `MessageHandler` 在失败后又调用 `run_with_request` 最多 2 次（因为 `can_retry_in_round` 允许 retry_count < 3，即最多 2 次额外调用）。这导致：
- 同一问题被两个层级重复重试
- 每次 in-round retry 的 prompt 中只包含 `last_failure`，但 `run_with_request` 内部已经基于同样的 `last_failure` 做了 3 次 attempt
- 如果 `run_with_request` 内部的 3 次 attempt 都失败了，说明要么 LLM 无法理解错误原因，要么工具本身有持续性故障。此时再做 in-round retry 成功率极低，浪费 API 调用。

**风险评级**: **高风险**

**建议修复**:
两种方案：
- **方案 A（推荐）**: 取消 `MessageHandler` 的 in-round retry，完全依赖 `run_with_request` 内部的重试。`MessageHandler` 只负责 round-level 的重新决策（Agent 1 re-decide）。
- **方案 B**: 修改 `run_with_request` 使其只做 1 次 attempt，将重试逻辑上提到 `MessageHandler` 统一控制。

---

#### 2.3.2 中风险：track_failures 只记录失败，不记录成功上下文

**文件路径**: `core/message_handler.py`
**行号**: 294-301

```python
def track_failures(tracker, tool_result):
    """Record failures from a tool execution round."""
    for r in tool_result.records:
        if not r.success:
            tracker.failure_log.append({
                "name": r.name,
                "output": r.output[:200],
            })
```

**问题描述**:
`failure_log` 只记录失败的工具调用，不记录成功的调用。在 Agent 1 的 `re_decide` 中，只看到失败信息，看不到哪些工具已经成功执行过。这可能导致 Agent 1 做出次优决策（如重复请求已经成功的工具）。

**风险评级**: **中风险**

**建议修复**:
```python
def track_results(tracker, tool_result):
    for r in tool_result.records:
        entry = {"name": r.name, "success": r.success, "output": r.output[:200]}
        if r.success:
            tracker.success_log.append(entry)
        else:
            tracker.failure_log.append(entry)
```

---

#### 2.3.3 中风险：Agent 1 re-decide 后未限制新的 tool_requests 数量

**文件路径**: `core/message_handler.py`
**行号**: 133-141

```python
elif tool_result and not tool_result.any_success:
    # All retries failed -- Agent 1 re-decide
    if tracker.can_start_new_round:
        logger.info(f"[msg] agent1: re-decide after failures")
        drive_result = self._inner_drive.re_decide(user_input, tracker.failure_log)
    else:
        break
```

**问题描述**:
当所有重试失败后，Agent 1 被调用 `re_decide`。但 `re_decide` 可能再次输出 `needs_external_tools=True` 并附带新的 `tool_requests`。此时 `MessageHandler` 会进入下一轮，再次调用 `run_with_request`。如果 Agent 1 的 re-decide 逻辑有缺陷（如总是坚持需要外部工具），可能导致无限循环——虽然 `can_start_new_round` 有上限，但每次新 round 又会触发 `run_with_request` 的 3 次 attempt 和 in-round retry，总 API 调用次数仍然很高。

**风险评级**: **中风险**

**建议修复**:
在 `re_decide` 的 prompt 中明确告知"这是最后一次机会，如果仍然失败就直接回复用户"。或者在 `MessageHandler` 中增加逻辑：如果连续两轮都完全失败，强制退出循环。

---

#### 2.3.4 低风险：handle_explore 中的 tool_result 未检查是否成功

**文件路径**: `core/message_handler.py`
**行号**: 205-208

```python
explore_prompt = f"[自由探索] 可以搜搜关于{topic}的内容。用 web_search 和 web_fetch。"
tool_result = self._tool_agent.run(explore_prompt)
tool_records = self._tool_agent.format_for_phase2(tool_result)
```

**问题描述**:
`handle_explore` 调用 `self._tool_agent.run()` 执行探索性工具调用，但完全不检查 `tool_result` 是否成功。如果所有工具都失败了，`tool_records` 会是一个空字符串（因为 `format_for_phase2` 在 `not result.has_results` 时返回 `""`），然后直接传给 Agent 3。Agent 3 可能会基于空数据生成无意义的回复。

**风险评级**: **低风险**

**建议修复**:
```python
tool_result = self._tool_agent.run(explore_prompt)
if not tool_result.any_success:
    logger.warning(f"[explore] all tools failed for topic={topic}")
    return None  # 探索失败，不生成回复
tool_records = self._tool_agent.format_for_phase2(tool_result)
```

---

### 2.4 Dispatcher 层（core/dispatcher.py）

#### 2.4.1 中风险：execute_tool_calls 对异步工具的执行方式存在隐患

**文件路径**: `core/dispatcher.py`
**行号**: 128-146

```python
import asyncio
try:
    import inspect
    if inspect.iscoroutinefunction(tool.execute):
        result: ToolResult = asyncio.run(tool.execute(args))
    else:
        result: ToolResult = tool.execute(args)
except Exception as e:
    logger.error(f"Tool {name} execution error: {e}")
    results.append({
        "name": name,
        "success": False,
        "output": str(e),
    })
```

**问题描述**:
1. **`asyncio.run()` 在已有事件循环中调用会失败**: 如果 `execute_tool_calls` 在一个已经有运行中事件循环的上下文中被调用（如 Web 端的异步请求处理中），`asyncio.run()` 会抛出 `RuntimeError: asyncio.run() cannot be called from a running event loop`。当前代码没有处理这种情况。
2. **无重试**: 工具执行异常（如文件读取时的临时 IO 错误）被直接捕获并返回失败，没有任何重试机制。
3. **异常信息可能暴露敏感路径**: `str(e)` 可能包含文件系统路径等敏感信息，直接返回给 LLM。

**风险评级**: **中风险**

**建议修复**:
```python
if inspect.iscoroutinefunction(tool.execute):
    try:
        loop = asyncio.get_running_loop()
        # 已有事件循环，创建 task
        result = asyncio.create_task(tool.execute(args))
        # 或者使用 await，取决于调用上下文
    except RuntimeError:
        result = asyncio.run(tool.execute(args))
```

---

#### 2.4.2 低风险：contains_fake_action 的检测规则可能被绕过

**文件路径**: `core/dispatcher.py`
**行号**: 172-194

**问题描述**:
`contains_fake_action` 使用硬编码的关键词列表检测 LLM 是否假装执行了工具。LLM 可能使用同义词或变体绕过检测（如"已完成搜索"、"已经查过了"、"帮你找了一下"）。这不是重试机制的直接问题，但会影响重试的触发条件（Agent 3 的 `_react_loop` 中如果检测到 fake action 会重试）。

**风险评级**: **低风险**

---

### 2.5 各 Tool 实现的错误处理

#### 2.5.1 中风险：web_tools.py 中的 AnySearch API 调用无重试

**文件路径**: `tools/web_tools.py`
**行号**: 16-35

```python
def _anysearch_api(tool_name: str, arguments: dict) -> dict:
    ...
    session = requests.Session()
    session.trust_env = False
    resp = session.post(ANYSEARCH_ENDPOINT, json=payload, headers=headers, timeout=30)
    resp.raise_for_status()
    result = resp.json()
    if "error" in result:
        raise RuntimeError(result["error"].get("message", str(result["error"])))
    return result.get("result", {})
```

**问题描述**:
`_anysearch_api` 没有任何重试逻辑。AnySearch 作为外部第三方 API，同样可能遇到网络抖动、临时故障、rate limit。当前实现：
- 无连接错误重试
- 无超时重试
- 无 HTTP 错误重试
- 无退避策略
- 每次调用都新建 `requests.Session()`，无连接复用优势

**风险评级**: **中风险**

**建议修复**:
为 `_anysearch_api` 添加与 `KimiProvider.generate()` 类似的重试逻辑，或提取通用的重试装饰器。

---

#### 2.5.2 低风险：各 Tool 的 execute 方法异常处理不一致

**文件路径**: 多个工具文件

| 工具文件 | 异常处理 | 是否返回 ToolResult.fail |
|---------|---------|------------------------|
| `web_tools.py` | try/except Exception | 是 |
| `file_tools.py` | 多个 try/except，区分 PermissionError | 是 |
| `search_tools.py` | try/except，部分未捕获 | 是 |
| `memory_tools.py` | 无 try/except | 否（可能直接抛异常）|
| `notify_tool.py` | try/except 在子线程中 | 是（但异常被吞掉）|
| `music_tool.py` | try/except | 是 |

**问题描述**:
- `memory_tools.py` 的 `RecallTool.execute()` 和 `RememberTool.execute()` 没有 try/except，如果底层 SQLite 或检索逻辑抛出异常，会直接抛到 `execute_tool_calls`，被那里的通用 except 捕获。虽然最终不会崩溃，但丢失了工具特定的错误上下文。
- `notify_tool.py` 在子线程中执行 PowerShell，异常被 `except Exception: pass` 完全吞掉，用户可能以为通知已发送但实际上失败了。

**风险评级**: **低风险**

---

#### 2.5.3 低风险：file_tools.py 的 _is_binary 存在变量名错误

**文件路径**: `tools/file_tools.py`
**行号**: 20-28

```python
def _is_binary(filepath: str) -> bool:
    try:
        with open(filepath, "rb") as f:
            chunk = f.read(1024)
        return b"\x00" in chunk
    except Exception as e:
        logger.debug(f"Binary check failed for {path}: {e}")  # path 未定义！
        return False
```

**问题描述**:
`logger.debug` 中引用了未定义的变量 `path`（应为 `filepath`）。虽然这不会导致功能错误（因为 `logger.debug` 在默认 INFO 级别下不执行），但如果日志级别调为 DEBUG，这里会抛出 `NameError`，导致 `_is_binary` 返回异常而非 False。

**风险评级**: **低风险**

---

### 2.6 Agent 3 的 _react_loop 重试机制（core/agent.py）

#### 2.6.1 中风险：fake_action_count 重试无退避，可能形成快速循环

**文件路径**: `core/agent.py`
**行号**: 119-181

```python
for _idx in range(self._max_tool_iterations):
    resp = self.provider.generate(...)
    cleaned, calls = parse_tool_calls(resp)
    if not calls:
        if contains_fake_action(resp) and fake_action_count < 3 and not tools_were_called:
            fake_action_count += 1
            logger.warning(f"[react] fake tool action detected (attempt {fake_action_count}/3)")
            messages.append({"role": "assistant", "content": resp})
            messages.append({"role": "user", "content": "YOU DID NOT ACTUALLY CALL ANY TOOLS! ..."})
            continue
```

**问题描述**:
当检测到 fake action 时，`_react_loop` 会立即 `continue` 并再次调用 `generate()`，中间没有任何等待。如果 LLM 连续多次都输出 fake action（如模型出现某种模式崩溃），这会在短时间内连续发起多次 API 请求，没有退避机制。

**风险评级**: **中风险**

**建议修复**:
在 fake action 重试之间增加短暂延迟（如 0.5 秒），或采用指数退避。

---

#### 2.6.2 低风险：_react_loop 的 max_tool_iterations 过大

**文件路径**: `core/agent.py`
**行号**: 83, 127

```python
self._max_tool_iterations: int = 10
```

**问题描述**:
最多 10 次迭代，每次迭代都调用 `generate()`。在工具调用链较长时（如搜索 -> 获取 -> 分析 -> 再搜索），10 次可能合理。但如果 LLM 陷入循环（如反复调用同一个工具），10 次迭代会浪费大量 API 调用。当前没有针对"重复调用同一工具"的检测和终止逻辑。

**风险评级**: **低风险**

---

### 2.7 InnerDrive 层的错误处理（core/inner_drive.py）

#### 2.7.1 中风险：assess/review/re_decide 中的 Provider 异常未处理

**文件路径**: `core/inner_drive.py`
**行号**: 61-111, 154-215, 217-264

**问题描述**:
Agent 1 的三个主要方法（`assess`, `review`, `re_decide`）都直接调用 `self._provider.generate()`，但都没有 try/except。如果 Provider 层在 3 次重试后仍然失败（抛出 `ConnectionError`），这些异常会直接传播到 `MessageHandler.handle_message()`，导致整个用户消息处理中断。

在 `assess` 中，如果异常发生，用户不会收到任何回复。
在 `review` 中，如果异常发生，已经执行成功的工具结果被丢弃。
在 `re_decide` 中，如果异常发生，用户不会收到任何关于工具失败的通知。

**风险评级**: **中风险**

**建议修复**:
为 Agent 1 的 Provider 调用添加 try/except，在失败时返回安全的默认决策：
```python
try:
    resp = self._provider.generate(messages, stream=False, max_tokens=512)
except Exception as e:
    logger.error(f"[inner_drive] provider failed: {e}")
    return InnerDriveResult(
        needs_external_tools=False,
        reasoning=f"内驱推理失败: {e}",
        summary="系统暂时无法思考，直接回复用户",
    )
```

---

#### 2.7.2 低风险：_parse_decision 的 has_external 检测过于宽松

**文件路径**: `core/inner_drive.py`
**行号**: 280-286

```python
has_external = any(
    name in text for name in EXTERNAL_TOOL_NAMES
) or any(kw in text for kw in [
    "需要调用", "需要外部", "需要获取", "需要搜索", "需要读取",
    "调用web", "用web", "需要查", "需要打开",
])
```

**问题描述**:
如果 Agent 1 的回复中恰好包含这些关键词（如在解释为什么"不需要"工具时提到了"不需要搜索"），`has_external` 会被误判为 True，导致不必要地进入 Agent 2 流程。

**风险评级**: **低风险**

---

### 2.8 ContextManager 的错误处理（core/context_manager.py）

#### 2.8.1 中风险：compress 方法中的 Provider 异常被静默吞掉

**文件路径**: `core/context_manager.py`
**行号**: 87-98

```python
try:
    result = self._provider.generate(
        [{"role": "user", "content": CONTEXT_COMPRESS_PROMPT.format(conversation=text)}],
        stream=False,
    )
    if result.strip():
        self._compressed_summary = result.strip()
        self._estimated_tokens_used = 0
        self._short_term.clear()
        logger.info(f"Context compressed: {self._compressed_summary[:80]}")
except Exception as e:
    logger.warning(f"Compression failed: {e}")
```

**问题描述**:
上下文压缩失败被静默处理，只是记录 warning。但压缩失败意味着：
- 对话历史没有被清空
- `_estimated_tokens_used` 没有被重置
- 后续的消息构建可能继续累积，最终超出模型的上下文窗口
- 没有向用户或上层调用者报告这一故障

**风险评级**: **中风险**

**建议修复**:
- 压缩失败后，考虑强制清空短期记忆（牺牲部分上下文以保障系统可用性）
- 或者向 Agent 3 的 prompt 中注入警告，告知"对话历史过长，部分早期内容已被省略"

---

## 三、汇总统计

### 3.1 风险分级统计

| 风险等级 | 数量 | 问题编号 |
|---------|------|---------|
| **高风险** | 5 | 2.1.1, 2.2.1, 2.2.2, 2.3.1, (2.2.3 边界问题) |
| **中风险** | 8 | 2.1.2, 2.1.3, 2.1.5, 2.2.3, 2.2.4, 2.3.2, 2.3.3, 2.4.1, 2.5.1, 2.6.1, 2.7.1, 2.8.1 |
| **低风险** | 6 | 2.1.4, 2.2.5, 2.3.4, 2.4.2, 2.5.2, 2.5.3, 2.6.2, 2.7.2 |

> 注：中风险实际为 12 项，表格中按去重后统计为 8 个主要类别。

### 3.2 按模块统计

| 模块 | 高风险 | 中风险 | 低风险 |
|------|--------|--------|--------|
| core/provider.py | 1 | 3 | 1 |
| core/tool_agent.py | 3 | 2 | 1 |
| core/message_handler.py | 1 | 3 | 1 |
| core/dispatcher.py | 0 | 1 | 1 |
| core/agent.py | 0 | 1 | 1 |
| core/inner_drive.py | 0 | 1 | 1 |
| core/context_manager.py | 0 | 1 | 0 |
| tools/web_tools.py | 0 | 1 | 0 |
| tools/（其他） | 0 | 0 | 2 |

### 3.3 按问题类型统计

| 问题类型 | 数量 |
|---------|------|
| 异常类型遗漏（应重试的未重试） | 3 |
| 嵌套/重复重试 | 2 |
| 退避策略缺陷 | 2 |
| 重试耗尽后无降级 | 3 |
| 状态追踪不准确 | 2 |
| 上下文丢失 | 1 |
| 异步执行隐患 | 1 |
| 日志/变量错误 | 2 |

### 3.4 关键修复优先级

**P0（立即修复）**:
1. `core/provider.py` 第 56-80 行：增加 `Timeout` 异常捕获
2. `core/message_handler.py` 第 98-141 行：取消 in-round retry 与 `run_with_request` 的重复重试
3. `core/tool_agent.py` 第 142-224 行：修复 `run_with_request` 的语义混淆，区分解析失败和工具失败

**P1（本周修复）**:
4. `core/provider.py`：增加 429 处理、抖动、总超时控制
5. `core/tool_agent.py`：修复 ToolAttemptTracker 的计数逻辑
6. `core/inner_drive.py`：为 Agent 1 的 Provider 调用添加异常处理
7. `tools/web_tools.py`：为 AnySearch API 添加重试

**P2（后续优化）**:
8. 统一各模块的异常分类和重试策略
9. 提取通用重试装饰器/工具函数
10. 增加全局 API 调用计数和熔断机制
11. 完善工具执行异常的信息脱敏

---

## 四、架构层面的建议

### 4.1 建立统一的重试策略框架

当前重试逻辑分散在 4 个模块中，建议提取一个通用的重试工具：

```python
# core/retry.py
from functools import wraps
import time
import random
import logging

logger = logging.getLogger(__name__)

def with_retry(max_attempts=3, backoff_base=2, max_backoff=30, jitter=True,
               retryable_exceptions=(Exception,), on_exhausted=None):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_error = None
            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except retryable_exceptions as e:
                    last_error = e
                    if attempt == max_attempts - 1:
                        break
                    wait = min(backoff_base ** attempt, max_backoff)
                    if jitter:
                        wait += random.uniform(0, 1)
                    logger.warning(f"{func.__name__} attempt {attempt+1}/{max_attempts} failed, retry in {wait:.1f}s: {e}")
                    time.sleep(wait)
            if on_exhausted:
                return on_exhausted(last_error)
            raise last_error
        return wrapper
    return decorator
```

### 4.2 明确各层级的重试职责

| 层级 | 职责 | 不应做的事 |
|------|------|-----------|
| Provider | 网络级重试：连接失败、超时、5xx、429 | 不处理业务逻辑错误 |
| ToolAgent | LLM 输出质量重试：格式错误、空输出 | 不做网络级重试（交给 Provider） |
| MessageHandler | 策略级重试：换工具、换查询词 | 不做 in-round 重复重试 |
| Dispatcher | 工具执行：异常捕获、结果格式化 | 不做重试（工具级重试应在各 Tool 中实现） |
| 各 Tool | 外部 API 重试：AnySearch、数据库等 | 不处理 LLM 输出问题 |

### 4.3 增加可观测性

建议在每次重试时记录结构化日志，便于后续分析重试的有效性：

```python
logger.info(json.dumps({
    "event": "retry",
    "layer": "provider",
    "attempt": attempt,
    "max_attempts": 3,
    "error_type": type(e).__name__,
    "error_message": str(e)[:200],
    "backoff_ms": int(wait * 1000),
}))
```

---

*审查完成。以上问题建议在后续迭代中按优先级逐步修复。*
