# 第5轮审查：性能与可扩展性 —— 并发处理专项报告

**审查日期**: 2026-05-31  
**审查范围**: Web端并发模型、SessionManager锁策略、数据库并发访问、Provider并发安全性、asyncio/threading选择、run_in_executor使用、事件循环嵌套、全局状态并发影响  
**审查文件**: `web/server.py`, `web/session.py`, `core/provider.py`, `storage/database.py`, `core/dispatcher.py`, `core/agent.py`, `core/inner_drive.py`, `core/tool_agent.py`, `storage/repository.py`, `memory/short_term.py`, `memory/long_term.py`, `memory/retrieval.py`, `memory/consolidation.py`, `core/personality.py`, `core/message_handler.py`, `tools/traits.py`, `tools/web_tools.py`, `tools/file_tools.py`, `tools/notify_tool.py`, `tools/music_tool.py`, `tools/search_tools.py`, `tools/memory_tools.py`, `config.py`, `core/context_manager.py`, `core/sleep_manager.py`, `core/proactivity.py`, `models/personality.py`, `web_main.py`

---

# 概述

AI Friend 项目采用 FastAPI + uvicorn 作为 Web 服务端框架，核心 AI 处理逻辑基于同步代码（三层 Agent 架构），通过 `asyncio.run_in_executor()` 将阻塞调用委托给线程池执行。数据持久化使用 aiosqlite（SQLite 的异步包装），短期记忆使用线程锁保护的 `deque`，长期记忆通过 `Repository` 的同步兼容层桥接异步数据库操作。

本次审查发现 **3 个高危风险**、**6 个中危风险**、**8 个低危风险**，以及若干可优化项。核心问题集中在：

1. **事件循环嵌套与线程池滥用**：同步代码在异步环境中运行时，多处存在嵌套事件循环风险，且每次调用都创建新的线程池，导致线程资源泄漏和性能急剧下降。
2. **全局共享状态缺乏隔离**：`SessionManager` 使用 `threading.Lock` 而非 `asyncio.Lock`，在异步上下文中无法正确保护共享状态；`personality.json` 文件被多个会话并发读写，存在数据损坏风险。
3. **数据库连接单点瓶颈**：所有会话共享单个 `aiosqlite` 连接，虽然启用了 WAL 模式，但全局 `asyncio.Lock` 导致所有数据库操作串行化，成为系统吞吐量瓶颈。
4. **Provider 非线程安全**：`requests.Session` 在 `KimiProvider` 中被多个线程共享，虽然 `requests.Session` 本身线程安全，但流式回调 `on_token` 和重试逻辑中的 `time.sleep()` 会阻塞线程池中的工作线程。
5. **WebSocket 连接管理缺陷**：`session_manager.remove()` 在 WebSocket 断开时被调用，但无法区分"客户端刷新"和"真正断开"，导致会话状态被过早清除；`get_active_ws()` 返回的 WebSocket 对象可能被并发关闭。

---

# 详细发现

## 1. Web端并发模型（FastAPI + uvicorn）

### 1.1 uvicorn 默认单进程模式 —— 中危

**文件**: `web_main.py` 第 26-32 行

```python
uvicorn.run(
    "web.server:app",
    host=host,
    port=port,
    reload=False,
    log_level="info",
)
```

**问题描述**: `uvicorn.run()` 未设置 `workers` 参数，默认以单进程模式运行。这意味着所有请求（包括 WebSocket 连接、REST API 调用、主动行为循环）都在同一个 Python 进程中处理，受 GIL（全局解释器锁）限制，无法利用多核 CPU。当并发用户数增加时，CPU 密集型操作（如 LLM 响应处理、嵌入计算）会阻塞整个事件循环，导致所有连接的响应延迟增加。

**风险评级**: 中危  
**影响**: 单进程模式下，系统最大吞吐量受限于单个 CPU 核心。在 4 核服务器上，理论 CPU 利用率上限为 25%。  
**建议**: 生产环境应配置多工作进程，例如 `workers=4`（通常设置为 `CPU 核心数 * 2 + 1`）。但需注意多进程模式下会话状态不能存储在内存中（当前 `SessionManager._sessions` 是进程内字典），需要引入 Redis 等外部状态存储。

---

### 1.2 WebSocket 与 REST API 共享同一事件循环 —— 低危

**文件**: `web/server.py` 第 39-54 行（REST）和第 199-249 行（WebSocket）

**问题描述**: FastAPI 的 REST 端点 `/api/chat` 和 WebSocket 端点 `/ws` 运行在同一个事件循环中。REST 端点通过 `run_in_executor` 将同步的 `agent.process_message()` 委托给线程池，而 WebSocket 的主动行为循环 `_proactive_loop` 也使用 `run_in_executor` 执行同步代码。两者共享同一个默认线程池（`loop.run_in_executor(None, ...)` 使用 `ThreadPoolExecutor` 的默认实例）。

**风险评级**: 低危  
**影响**: 当多个用户同时发起请求时，线程池中的线程可能被耗尽（默认最大线程数取决于实现，但通常不会无限增长）。新的请求需要等待线程释放，导致延迟增加。此外，WebSocket 的主动行为循环每 5-30 秒唤醒一次检查状态，这些周期性任务也会占用线程池资源。  
**建议**: 为不同类型的任务创建独立的 `ThreadPoolExecutor`：
- 一个用于用户请求处理（高优先级，线程数较少）
- 一个用于主动行为循环（低优先级，线程数较多）
- 一个用于后台任务（如记忆整合、嵌入计算）

```python
# 在 lifespan 中初始化
request_executor = concurrent.futures.ThreadPoolExecutor(max_workers=10, thread_name_prefix="request")
proactive_executor = concurrent.futures.ThreadPoolExecutor(max_workers=20, thread_name_prefix="proactive")
background_executor = concurrent.futures.ThreadPoolExecutor(max_workers=5, thread_name_prefix="bg")
```

---

### 1.3 WebSocket 消息处理未设置并发限制 —— 中危

**文件**: `web/server.py` 第 223-234 行

```python
elif msg_type == "message":
    content = data.get("content", "").strip()
    if not content:
        continue
    logger.info(f"[ws] message session={session_id} len={len(content)}")
    if not session_id:
        session_id = "default"
    _, agent = session_manager.get_or_create(session_id)
    agent.agent.last_activity_time = time.time()
    loop = asyncio.get_event_loop()
    response = await loop.run_in_executor(None, agent.process_message, content)
    await _send_segments(websocket, agent, response, agent.emotion)
```

**问题描述**: 当用户通过 WebSocket 快速发送多条消息时，每条消息都会触发一个独立的 `run_in_executor` 调用。由于 `agent.process_message()` 不是原子操作，且 `Agent` 实例不是线程安全的，并发执行会导致：
1. `turn_count` 竞争条件：两个请求同时读取和递增 `turn_count`，导致计数错误。
2. `short_term` 记忆竞争：`ConversationBuffer.add_turn()` 虽然有锁保护，但 `Agent._react_loop()` 中的多轮工具调用和记忆更新不是原子操作。
3. `personality.json` 并发写入：`process_message()` 最终会调用 `personality.save()`，多个线程同时写入同一文件会导致数据损坏。

**风险评级**: 中危  
**影响**: 在高并发场景下（如用户快速点击发送按钮、或网络延迟导致消息堆积），同一会话的多个请求会交错执行，导致对话历史混乱、情绪状态不一致、文件写入损坏。  
**建议**: 为每个 `WebAgent` 实例添加一个 `asyncio.Lock`，确保同一会话的消息处理串行化：

```python
class WebAgent:
    def __init__(self, ...):
        self._message_lock = asyncio.Lock()  # 每个会话一个锁

# 在 server.py 中
async with agent._message_lock:
    response = await loop.run_in_executor(None, agent.process_message, content)
```

---

## 2. SessionManager 的锁策略

### 2.1 使用 threading.Lock 而非 asyncio.Lock —— 高危

**文件**: `web/session.py` 第 129 行、第 137-144 行

```python
from threading import Lock

class SessionManager:
    def __init__(self, config: Config):
        ...
        self._lock = Lock()

    def get_or_create(self, session_id: Optional[str] = None) -> tuple[str, WebAgent]:
        with self._lock:
            sid = session_id or uuid.uuid4().hex[:12]
            if sid not in self._sessions:
                logger.info(f"[session] create: {sid}")
                self._sessions[sid] = WebAgent(self.config, self.db, self.repo)
            else:
                logger.debug(f"[session] restore: {sid}")
            return sid, self._sessions[sid]
```

**问题描述**: `SessionManager` 使用 `threading.Lock` 保护 `_sessions` 字典。然而，`get_or_create()` 和 `remove()` 等方法是同步函数，它们被异步代码（`web/server.py` 中的 `chat_api()` 和 `websocket_endpoint()`）直接调用。在 asyncio 环境中，同步锁虽然能阻止多个线程同时进入临界区，但**无法阻止同一个线程中的多个协程交错执行**。由于 Python 的 asyncio 是单线程事件循环，多个协程可能在同一个 OS 线程中运行，`threading.Lock` 在这种情况下无法提供有效的并发保护。

具体来说，当两个 WebSocket 连接同时请求 `get_or_create("session_1")` 时：
1. 协程 A 获取锁，创建 `WebAgent` 实例（这是一个同步操作，可能触发 `WebAgent.__init__` 中的数据库查询和 LLM 调用）。
2. 协程 A 在 `WebAgent.__init__` 中调用 `repo.get_recent_turns_sync(30)`，这会通过 `_run_sync()` 创建一个新的线程池来执行异步数据库查询。
3. 在协程 A 阻塞于线程池等待期间，事件循环可以调度协程 B 执行。
4. 协程 B 也调用 `get_or_create("session_1")`，此时 `threading.Lock` 已经被协程 A 持有（因为协程 A 还在同一个 OS 线程中，只是让出了事件循环控制权），所以协程 B 会阻塞等待锁释放。

等等，实际上 `threading.Lock` 在同一线程中是**可重入**的吗？不，`threading.Lock` 不是可重入锁（`threading.RLock` 才是），但它在同一线程中如果已经被持有，再次 `acquire()` 会阻塞。然而，由于 asyncio 的协程切换发生在 `await` 点，而 `with self._lock:` 不是 `await`，所以协程 A 在获取锁后不会被协程 B 抢占，直到协程 A 执行完整个 `with` 块。但问题是 `get_or_create()` 内部的 `WebAgent.__init__` 会调用同步阻塞操作（如 `repo.get_recent_turns_sync()`），这些操作通过 `_run_sync()` 创建线程池并阻塞当前线程。在阻塞期间，事件循环无法运行其他协程，所以实际上这里并没有真正的并发问题——但性能极差。

更关键的是，`SessionManager` 的锁策略在**多工作进程**模式下完全失效。如果使用 `uvicorn` 的多进程模式，每个进程有自己的 `SessionManager` 实例和锁，进程间没有同步机制，导致同一个 `session_id` 可能在多个进程中创建多个 `WebAgent` 实例。

**风险评级**: 高危  
**影响**: 
- 单进程模式下：`threading.Lock` 虽然能阻止协程并发，但导致事件循环阻塞，降低并发处理能力。
- 多进程模式下：锁完全失效，同一 session 被多个进程创建，状态分裂。
- `remove()` 方法中取消 proactive task 的操作（`task.cancel()`）不是线程安全的，可能在任务执行中途取消，导致状态不一致。

**建议**: 
1. 将 `SessionManager` 的所有方法改为 `async def`，使用 `asyncio.Lock`。
2. `WebAgent` 的初始化也应改为异步，避免在同步 `__init__` 中执行阻塞操作。
3. 如果必须保持同步接口，应使用 `asyncio.Lock` 并在异步方法中调用：

```python
class SessionManager:
    def __init__(self, config: Config):
        self._lock = asyncio.Lock()  # 改为 asyncio.Lock

    async def get_or_create(self, session_id: Optional[str] = None) -> tuple[str, WebAgent]:
        async with self._lock:
            sid = session_id or uuid.uuid4().hex[:12]
            if sid not in self._sessions:
                self._sessions[sid] = await WebAgent.create(self.config, self.db, self.repo)
            return sid, self._sessions[sid]
```

---

### 2.2 会话清理策略过于激进 —— 中危

**文件**: `web/server.py` 第 247-249 行

```python
finally:
    if session_id:
        session_manager.remove(session_id)
```

**问题描述**: 当 WebSocket 连接断开时（无论是客户端正常关闭、网络超时、还是页面刷新），`finally` 块都会调用 `session_manager.remove(session_id)`。这会立即：
1. 从 `_sessions` 中移除 `WebAgent` 实例（丢失会话状态）。
2. 取消 proactive task（如果正在执行中）。
3. 从 `_active_ws` 中移除 WebSocket 引用。

**风险评级**: 中危  
**影响**: 
- 用户刷新页面后，之前的对话历史、情绪状态、记忆上下文全部丢失（虽然数据库中保存了长期记忆，但短期记忆和当前情绪状态丢失）。
- 如果 proactive task 正在执行 LLM 调用，取消任务会导致 `asyncio.CancelledError` 在 `run_in_executor` 的线程中传播，可能留下未清理的资源。
- `remove()` 中的 `task.cancel()` 只是向 asyncio task 发送取消信号，但 `run_in_executor` 中的线程池线程不会立即响应取消，可能继续执行阻塞的 LLM 调用。

**建议**: 
1. 区分"临时断开"和"永久关闭"：可以设置一个延迟清理机制，在 WebSocket 断开后保留会话状态 5-10 分钟，如果用户在此期间重新连接，则恢复原有会话。
2. 使用 `asyncio.shield()` 保护关键操作，避免在清理时被取消。
3. 在 `remove()` 中优雅地等待 proactive task 完成当前迭代：

```python
async def remove(self, session_id: str) -> None:
    async with self._lock:
        agent = self._sessions.pop(session_id, None)
        task = self._proactive_tasks.pop(session_id, None)
        if task:
            task.cancel()
            try:
                await asyncio.wait_for(asyncio.shield(task), timeout=5.0)
            except (asyncio.CancelledError, asyncio.TimeoutError):
                pass
        self._active_ws.pop(session_id, None)
```

---

### 2.3 cleanup_old 方法未实际调用 —— 低危

**文件**: `web/session.py` 第 169-174 行

```python
def cleanup_old(self, max_sessions: int = 50) -> None:
    with self._lock:
        while len(self._sessions) > max_sessions:
            oldest = next(iter(self._sessions))
            self._sessions.pop(oldest)
            logger.info(f"Session evicted: {oldest}")
```

**问题描述**: `cleanup_old()` 方法定义了会话数量上限（默认 50），但在整个代码库中没有任何地方调用此方法。这意味着如果服务器长时间运行且不断有新会话创建（例如每个匿名用户访问都创建新会话），内存中的 `_sessions` 字典会无限增长，最终导致内存耗尽（OOM）。

**风险评级**: 低危  
**影响**: 在长期运行的生产环境中，内存泄漏可能导致服务器崩溃。虽然每次 WebSocket 断开时会调用 `remove()`，但如果用户不使用 WebSocket 而只使用 REST API（`/api/chat`），则不会自动清理会话。  
**建议**: 
1. 在 `SessionManager` 中添加定时清理任务，例如每 5 分钟检查一次：

```python
async def _cleanup_loop(self):
    while True:
        await asyncio.sleep(300)
        self.cleanup_old()
```
2. 为每个会话添加 `last_access_time` 时间戳，清理时优先移除最久未访问的会话，而不是简单地按字典顺序移除（Python 3.7+ 字典保持插入顺序，但这不是可靠的 LRU 策略）。
3. 考虑使用 `collections.OrderedDict` 或 `functools.lru_cache` 实现真正的 LRU 淘汰。

---

## 3. 数据库连接的并发访问

### 3.1 全局单连接 + 全局锁导致串行化 —— 高危

**文件**: `storage/database.py` 第 11-39 行

```python
class Database:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._lock = asyncio.Lock()
        self.conn: aiosqlite.Connection | None = None

    async def open(self) -> None:
        os.makedirs(os.path.dirname(self.db_path) or ".", exist_ok=True)
        self.conn = await aiosqlite.connect(self.db_path)
        self.conn.row_factory = aiosqlite.Row
        await self.conn.execute("PRAGMA journal_mode=WAL")
        await self.conn.execute("PRAGMA foreign_keys=ON")
        ...

    @asynccontextmanager
    async def cursor(self):
        if self.conn is None:
            raise RuntimeError("Database not opened.")
        async with self._lock:
            c = await self.conn.cursor()
            try:
                yield c
                await self.conn.commit()
            except aiosqlite.Error:
                await self.conn.rollback()
                raise
            finally:
                await c.close()
```

**问题描述**: `Database` 类维护单个 `aiosqlite.Connection` 实例，并通过全局 `asyncio.Lock` 保护所有数据库操作。这意味着：
1. **所有数据库操作完全串行化**：即使多个会话同时发起请求，它们的数据库操作也必须排队执行。SQLite 本身支持多读取并发（在 WAL 模式下），但全局锁强制所有操作（包括读操作）串行化，严重限制了并发性能。
2. **长时间操作阻塞其他请求**：LLM 调用、嵌入计算等操作不发生在数据库层，但记忆整合（`MemoryConsolidator.consolidate()`）会执行多次数据库写入，每次写入都持有全局锁。如果一个会话正在进行记忆整合，其他会话的所有数据库操作都必须等待。
3. **连接池缺失**：没有使用连接池，所有会话共享一个连接。虽然 SQLite 是文件级数据库，但 `aiosqlite` 支持通过 `aiosqlite.connect()` 创建多个连接（每个连接有自己的事务上下文）。使用连接池可以显著提高读取并发度。

**风险评级**: 高危  
**影响**: 
- 系统最大数据库并发度为 1，成为整个系统的瓶颈。
- 在 10 个并发用户场景下，如果每个请求平均触发 5 次数据库操作（短期记忆读取、长期记忆检索、对话轮次写入、事实提取写入、关系更新），且每次操作平均耗时 10ms，则总排队时间为 `10 * 5 * 10ms = 500ms`。加上 LLM 调用时间（通常 2-10 秒），实际感知延迟可能达到数秒。
- WAL 模式的优势被全局锁完全抵消。

**建议**: 
1. **移除全局锁，使用连接级事务隔离**：SQLite 的 WAL 模式天然支持一个写事务和多个读事务并发。将锁粒度从全局降低到事务级别：

```python
class Database:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._pool = None  # 连接池

    async def open(self):
        # 创建连接池（aiosqlite 原生不支持连接池，可用 asyncpg-style 或简单封装）
        self._pool = [await aiosqlite.connect(self.db_path) for _ in range(5)]
        for conn in self._pool:
            conn.row_factory = aiosqlite.Row
            await conn.execute("PRAGMA journal_mode=WAL")
            await conn.execute("PRAGMA foreign_keys=ON")

    @asynccontextmanager
    async def cursor(self):
        conn = self._pool.pop()  # 简单轮询
        try:
            c = await conn.cursor()
            try:
                yield c
                await conn.commit()
            except aiosqlite.Error:
                await conn.rollback()
                raise
            finally:
                await c.close()
        finally:
            self._pool.append(conn)
```

2. **读写分离**：读操作（如 `get_recent_turns`、`search_facts`）不需要事务锁，可以直接使用连接；写操作（如 `insert_turn`、`upsert_fact`）使用事务。
3. **批量操作优化**：`MemoryConsolidator` 中的多次独立写入应合并为一次事务，减少锁持有时间。

---

### 3.2 Repository 同步包装层的线程池滥用 —— 高危

**文件**: `storage/repository.py` 第 13-21 行

```python
def _run_sync(coro):
    """Run coroutine in a thread-safe way for sync callers."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return pool.submit(asyncio.run, coro).result()
```

**问题描述**: `_run_sync()` 是 `Repository` 所有同步方法的底层实现。当从异步代码中调用同步方法时（这是当前架构的主要路径），它会：
1. 检测到当前有运行中的事件循环（`asyncio.get_running_loop()`）。
2. 创建一个**新的** `ThreadPoolExecutor`（每次调用都创建！）。
3. 在线程池中调用 `asyncio.run(coro)`，这会在新线程中创建**新的事件循环**并运行协程。
4. 通过 `.result()` 阻塞等待结果。

这带来了多个严重问题：
- **线程池泄漏**：每次数据库调用都创建一个新的 `ThreadPoolExecutor`，虽然 `with` 语句会关闭它，但线程的创建和销毁开销很大（通常数毫秒到数十毫秒）。在高并发场景下，这会迅速耗尽系统线程资源。
- **事件循环嵌套**：`asyncio.run()` 要求当前线程没有运行中的事件循环，但由于我们在新线程中调用它，这本身没问题。然而，如果协程内部再次调用 `_run_sync()`（虽然当前代码中没有直接递归，但间接递归是可能的），会导致嵌套事件循环错误。
- **上下文丢失**：在新线程中运行协程时，`contextvars` 的上下文会丢失，导致日志上下文、请求 ID 等追踪信息中断。
- **性能极差**：一个简单的数据库查询（通常 < 1ms）因为线程创建和事件循环启动，可能额外消耗 5-20ms。

**文件**: `memory/long_term.py` 第 17-26 行使用了完全相同的 `_run_sync` 实现。

**风险评级**: 高危  
**影响**: 
- 每个 LLM 请求触发 10-20 次数据库操作（短期记忆读取、长期记忆检索、事实存储、经验存储、反思存储、关系更新、对话轮次写入等），每次操作都创建新线程池。
- 假设每次 `_run_sync` 创建线程池开销为 10ms，一个请求的数据库开销就达到 100-200ms，且随并发数线性增长。
- 在 100 QPS 场景下，每秒创建 1000-2000 个线程池，系统会在数秒内崩溃。

**建议**: 
1. **彻底重构为全异步架构**：将 `LongTermMemory`、`Repository` 的所有同步方法移除，上层调用者（`Agent`、`MessageHandler`、`MemoryConsolidator`）全部使用 `await`。
2. **如果必须保留同步接口，使用线程安全的单例线程池**：

```python
# 全局线程池，只创建一次
_DB_EXECUTOR = concurrent.futures.ThreadPoolExecutor(max_workers=20, thread_name_prefix="db")

def _run_sync(coro):
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    # 使用全局线程池，避免重复创建
    future = asyncio.run_coroutine_threadsafe(coro, loop)
    return future.result()
```

但更好的做法是直接让调用者使用 `await`：

```python
# 在 Agent 中
async def process_message_async(self, user_input: str, on_token=None) -> str:
    await self.short_term.add_turn_async("user", user_input)
    mem_ctx = await self.retriever.retrieve_for_query_async(user_input)
    ...
```

---

### 3.3 get_connection() 方法绕过锁保护 —— 中危

**文件**: `storage/database.py` 第 41-45 行

```python
def get_connection(self):
    """Return connection for direct use (bulk operations). Caller must manage locking."""
    if self.conn is None:
        raise RuntimeError("Database not opened.")
    return self.conn
```

**问题描述**: `get_connection()` 返回原始连接对象，绕过 `cursor()` 上下文管理器的锁保护。注释明确说明"调用者必须自行管理锁"，但这是一个极易被误用的接口。

**文件**: `memory/consolidation.py` 第 262-263 行使用了此方法：

```python
with self.ltm.repo.db.get_connection() as conn:
    rows = conn.execute(...).fetchall()
```

**风险评级**: 中危  
**影响**: `consolidation.py` 中的 `_embed_new_items()` 直接使用 `get_connection()` 执行查询和更新。虽然当前代码中 `with self.ltm.repo.db.get_connection() as conn:` 的用法在语法上正确（`aiosqlite.Connection` 支持上下文管理器），但它没有获取 `Database._lock`。如果此时另一个协程通过 `cursor()` 执行操作，两者会竞争同一个连接对象，可能导致：
- SQLite 的 "database is locked" 错误（如果连接被并发使用）。
- 事务状态混乱（一个协程在另一个协程的事务中间执行查询）。
- 数据不一致（读取到未提交的数据）。

**建议**: 
1. 移除 `get_connection()` 方法，强制所有数据库操作通过 `cursor()` 上下文管理器。
2. 如果确实需要批量操作，提供一个显式的批量操作接口：

```python
@asynccontextmanager
async def bulk_cursor(self):
    async with self._lock:
        c = await self.conn.cursor()
        try:
            yield c
            await self.conn.commit()
        except:
            await self.conn.rollback()
            raise
        finally:
            await c.close()
```

---

## 4. Provider.generate 的并发安全性

### 4.1 requests.Session 共享与流式回调竞争 —— 中危

**文件**: `core/provider.py` 第 11-134 行

```python
class KimiProvider:
    def __init__(self, endpoint: str, api_key: str, model: str, ...):
        self.session = requests.Session()
        self.session.trust_env = False
        self.session.headers.update({...})

    def generate(self, messages: list[dict], stream: bool = True,
                 on_token: Optional[callable] = None, ...) -> str:
        ...
        resp = self.session.post(url, json=payload, stream=True, timeout=self.timeout)
        ...
        if not stream:
            ...
        full_response = []
        for line in resp.iter_lines(decode_unicode=True):
            ...
            if token and on_token:
                on_token(token)
            full_response.append(token)
        ...
```

**问题描述**: `KimiProvider` 实例被多个 `WebAgent` 共享（实际上每个 `WebAgent` 创建自己的 `KimiProvider`，但 `SessionManager` 中的多个会话可能并发调用各自的 `KimiProvider`）。`requests.Session` 本身是线程安全的（底层使用 `urllib3` 的连接池），但存在以下问题：

1. **流式回调 `on_token` 的线程安全性**：`on_token` 回调函数在 `run_in_executor` 的线程池中执行（因为 `generate()` 是同步方法）。如果 `on_token` 修改了共享状态（如 WebSocket 发送），需要确保线程安全。当前代码中 `WebAgent.set_on_token()` 设置的回调是 `server.py` 中的闭包，该闭包通过 `websocket.send_text()` 发送数据。但 `websocket.send_text()` 是异步方法，在同步线程中不能直接调用。

**文件**: `web/server.py` 中没有直接设置 `on_token` 回调，但 `_send_segments()` 函数在 `run_in_executor` 返回后手动分段发送。如果未来启用流式传输，`on_token` 回调需要在同步线程中调用异步的 `websocket.send_text()`，这会导致事件循环嵌套错误。

2. **`time.sleep()` 阻塞线程池**：重试逻辑中使用 `time.sleep(wait)`（第 64、71、77 行），这会阻塞 `run_in_executor` 中的工作线程。在高并发场景下，大量线程被 `sleep` 占用，导致线程池耗尽。

3. **超时处理不足**：`timeout=self.timeout`（默认 180 秒）是请求总超时。如果 API 服务器响应缓慢，一个请求可能占用连接池中的连接长达 3 分钟，影响其他请求。

**风险评级**: 中危  
**影响**: 
- 流式回调如果实现不当，会导致 `RuntimeError: no running event loop` 或事件循环嵌套错误。
- `time.sleep()` 阻塞线程池，降低系统并发处理能力。
- 长超时可能导致连接池耗尽（`requests.Session` 默认连接池大小为 10）。

**建议**: 
1. **使用异步 HTTP 客户端**：将 `KimiProvider` 重构为使用 `httpx.AsyncClient` 或 `aiohttp`，彻底消除 `run_in_executor` 和线程池问题：

```python
import httpx

class KimiProvider:
    def __init__(self, ...):
        self.client = httpx.AsyncClient(
            base_url=endpoint,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=httpx.Timeout(180.0),
            trust_env=False,
        )

    async def generate(self, messages, stream=True, on_token=None, ...):
        async with self.client.stream("POST", "/v1/chat/completions", json=payload) as resp:
            async for line in resp.aiter_lines():
                ...
                if token and on_token:
                    await on_token(token)  # 异步回调
```

2. **使用 `asyncio.sleep()` 替代 `time.sleep()`**：如果保持同步架构，至少将重试等待改为 `asyncio.sleep()`（需要在异步上下文中调用）。
3. **增加连接池大小**：如果继续使用 `requests.Session`，增加连接池大小：

```python
from requests.adapters import HTTPAdapter
self.session.mount("https://", HTTPAdapter(pool_connections=20, pool_maxsize=50))
```

---

### 4.2 Provider 实例未共享导致连接池浪费 —— 低危

**文件**: `web/session.py` 第 40-46 行

```python
self.provider = KimiProvider(
    endpoint=config.api_endpoint, api_key=config.api_key,
    model=config.api_model, temperature=config.temperature,
    max_tokens=config.max_tokens,
    thinking=config.thinking, reasoning_effort=config.reasoning_effort,
    timeout=config.api_timeout,
)
```

**问题描述**: 每个 `WebAgent` 实例都创建独立的 `KimiProvider`，进而创建独立的 `requests.Session`。`requests.Session` 维护独立的连接池，多个 Session 之间不共享连接。这意味着如果有 50 个活跃会话，系统会维护 50 个独立的 HTTP 连接池，每个池默认最多 10 个连接，总计可能建立 500 个 TCP 连接。

**风险评级**: 低危  
**影响**: 连接数过多可能导致：
- 操作系统文件描述符耗尽（Linux 默认限制 1024，Windows 也有类似限制）。
- API 服务端连接数压力增大。
- 内存占用增加（每个 Session 和连接池都有开销）。

**建议**: 在 `SessionManager` 级别创建共享的 `KimiProvider` 实例，所有 `WebAgent` 共用同一个 Provider：

```python
class SessionManager:
    async def open(self):
        self.db = Database(self.config.db_path)
        await self.db.open()
        self.repo = Repository(self.db)
        self.provider = KimiProvider(...)  # 共享 Provider

class WebAgent:
    def __init__(self, config, db, repo, provider):
        self.provider = provider  # 使用共享实例
```

---

## 5. asyncio vs threading 的选择

### 5.1 混合架构导致复杂度爆炸 —— 中危

**问题描述**: 项目采用了"asyncio 外壳 + 同步内核"的混合架构：
- **异步层**: FastAPI 端点、WebSocket 处理、数据库连接（aiosqlite）。
- **同步层**: Agent 核心逻辑（`Agent.process_message()`、`InnerDriveAgent.assess()`、`ToolAgent.run()`）、LLM 调用（`KimiProvider.generate()`）、记忆操作（`LongTermMemory` 的同步包装）。

这种架构的问题：
1. **代码可读性差**：开发者需要同时理解 asyncio 和 threading 的语义，以及它们之间的交互规则。
2. **调试困难**：当出现问题时，堆栈跟踪会跨越 asyncio 和 threading 边界，难以定位根因。
3. **性能损失**：`run_in_executor` 涉及线程上下文切换、GIL 竞争、数据序列化等开销。
4. **资源管理复杂**：线程池的生命周期管理、异常传播、取消信号传递都比纯异步代码复杂得多。

**风险评级**: 中危  
**影响**: 开发和维护成本增加，性能无法达到理论最优，且容易引入难以复现的并发 bug。  
**建议**: 制定明确的迁移路线图，逐步将核心逻辑重构为全异步：

**阶段 1**（短期）: 将 `KimiProvider` 改为 `httpx.AsyncClient`，这是影响最大的瓶颈。
**阶段 2**（中期）: 将 `LongTermMemory` 和 `Repository` 的同步包装移除，上层调用者改为 `await`。
**阶段 3**（长期）: 将 `Agent`、`InnerDriveAgent`、`ToolAgent` 的核心循环改为异步。

---

### 5.2 threading.Lock 在 ConversationBuffer 中的正确使用 —— 低危（正面发现）

**文件**: `memory/short_term.py` 第 14-84 行

```python
@dataclass
class ConversationBuffer:
    maxlen: int = 20
    _turns: deque = field(default_factory=lambda: deque())
    _next_id: int = 0
    _lock: threading.Lock = field(default_factory=threading.Lock)

    def add_turn(self, role: str, content: str, metadata: Optional[dict] = None) -> Turn:
        turn = Turn(...)
        with self._lock:
            self._next_id += 1
            self._turns.append(turn)
        ...
```

**分析**: `ConversationBuffer` 使用 `threading.Lock` 保护内部状态。由于 `ConversationBuffer` 的操作（`add_turn`、`get_recent` 等）都是快速的原子操作（不涉及 I/O），且它们被 `run_in_executor` 的线程池调用，所以 `threading.Lock` 在这里是**正确且合适**的选择。`threading.Lock` 对于纯 CPU/内存操作比 `asyncio.Lock` 更高效（无需事件循环调度开销）。

**风险评级**: 低危（正面发现，无需修改）  
**建议**: 保持不变，但确保 `ConversationBuffer` 的所有方法都保持快速执行（不引入 I/O 操作）。

---

## 6. run_in_executor 的使用

### 6.1 多处使用默认线程池且无上限 —— 中危

**文件**: `web/server.py` 中的多处调用

```python
# 第 150-151 行
loop = asyncio.get_event_loop()
await loop.run_in_executor(None, ag._generate_dream)

# 第 169-170 行
intent = await loop.run_in_executor(None, ag.decide_proactive_action, idle)

# 第 174-175 行
response = await loop.run_in_executor(None, agent.process_explore_with_intent, intent)

# 第 178-179 行
response = await loop.run_in_executor(None, agent.process_proactive_with_intent, intent)

# 第 233 行
response = await loop.run_in_executor(None, agent.process_message, content)
```

**问题描述**: 所有 `run_in_executor` 调用都使用 `None` 作为 executor 参数，这意味着它们使用事件循环的**默认线程池**。默认线程池的大小为 `min(32, os.cpu_count() + 4)`，虽然有一定上限，但所有类型的任务（用户请求、主动行为、梦境生成）都挤在同一个池中。

更严重的问题是，`run_in_executor(None, ...)` 的默认线程池在 asyncio 中是被延迟创建的，且其生命周期与事件循环绑定。但在某些实现中，如果线程池中的线程被长时间阻塞（如 LLM 调用耗时 10 秒），新任务会持续创建新线程，直到达到上限。一旦达到上限，后续任务必须排队等待。

**风险评级**: 中危  
**影响**: 
- 一个慢请求（如 LLM 调用超时）会占用线程池中的线程，导致其他请求等待。
- 主动行为循环的周期性任务（每 5-30 秒一次）持续占用线程池资源，挤压用户请求的可用线程。
- 无法为不同类型的任务设置不同的优先级和资源配额。

**建议**: 如 1.2 节所述，创建多个独立的 `ThreadPoolExecutor`，并在 `lifespan` 中管理它们的生命周期：

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.request_executor = ThreadPoolExecutor(max_workers=10)
    app.state.proactive_executor = ThreadPoolExecutor(max_workers=20)
    await session_manager.open()
    yield
    app.state.request_executor.shutdown(wait=True)
    app.state.proactive_executor.shutdown(wait=True)
    logger.info("Server shutting down...")

# 使用时
response = await loop.run_in_executor(app.state.request_executor, agent.process_message, content)
```

---

### 6.2 run_in_executor 中调用 asyncio.run 导致嵌套事件循环 —— 高危

**文件**: `storage/repository.py` 第 13-21 行（已在 3.2 节详细分析）

```python
def _run_sync(coro):
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return pool.submit(asyncio.run, coro).result()
```

**问题描述**: 这是整个系统中最危险的并发代码。`pool.submit(asyncio.run, coro)` 在新线程中调用 `asyncio.run()`，而 `asyncio.run()` 会创建新的事件循环并运行协程。如果协程内部再次触发 `_run_sync()`（例如 `LongTermMemory.store_fact()` 调用 `repo.insert_turn_sync()`，而 `insert_turn_sync` 内部又调用了其他同步方法），虽然当前代码中没有直接递归，但这种模式极易在未来修改中引入嵌套事件循环。

更隐蔽的问题是，`asyncio.run()` 在 Python 3.11+ 中会自动关闭事件循环并清理资源，但如果协程中有未完成的任务或注册的回调，可能会导致 `RuntimeError` 或资源泄漏。

**风险评级**: 高危  
**影响**: 系统随时可能因为代码路径的变化而触发嵌套事件循环错误，导致请求失败或服务崩溃。  
**建议**: 立即重构为全异步架构，彻底移除 `_run_sync` 和 `asyncio.run` 的嵌套使用。

---

## 7. 事件循环嵌套问题

### 7.1 asyncio.run 在工具执行中的潜在嵌套 —— 中危

**文件**: `core/dispatcher.py` 第 128-134 行

```python
def execute_tool_calls(tool_registry: ToolRegistry, calls: list[dict]) -> list[dict]:
    ...
    for call in calls:
        ...
        import asyncio
        try:
            import inspect
            if inspect.iscoroutinefunction(tool.execute):
                result: ToolResult = asyncio.run(tool.execute(args))
            else:
                result: ToolResult = tool.execute(args)
            ...
```

**问题描述**: `execute_tool_calls()` 是一个同步函数。当工具的执行方法是异步的（`inspect.iscoroutinefunction(tool.execute)` 为 `True`），它调用 `asyncio.run(tool.execute(args))`。`asyncio.run()` 要求当前线程没有运行中的事件循环。

**问题场景**: 
1. 如果 `execute_tool_calls()` 被 `run_in_executor` 的线程调用（这是当前的主要路径），线程中没有事件循环，`asyncio.run()` 可以正常工作。
2. 但如果未来某个代码路径直接在事件循环中调用 `execute_tool_calls()`（例如从异步的 Agent 核心中调用），`asyncio.run()` 会抛出 `RuntimeError: asyncio.run() cannot be called from a running event loop`。

**风险评级**: 中危  
**影响**: 当前代码路径下不会触发，但这是一个架构层面的隐患。随着代码演进，异步和同步边界可能变得模糊，导致难以预料的错误。  
**建议**: 
1. 将 `execute_tool_calls()` 改为 `async def`，统一使用 `await tool.execute(args)`。
2. 或者，如果必须保持同步接口，使用 `asyncio.get_event_loop().run_until_complete()` 替代 `asyncio.run()`（但这仍然要求在非事件循环线程中调用）。
3. 最佳方案：将工具层全部改为异步，`Tool.execute()` 统一为 `async def`。

---

### 7.2 WebSocket 的 proactive_loop 中 get_event_loop() 的线程安全性 —— 低危

**文件**: `web/server.py` 第 150、166 行

```python
loop = asyncio.get_event_loop()
await loop.run_in_executor(None, ag._generate_dream)

loop = asyncio.get_event_loop()
intent = await loop.run_in_executor(None, ag.decide_proactive_action, idle)
```

**问题描述**: `asyncio.get_event_loop()` 在 Python 3.10+ 中已被标记为弃用，因为它在线程中没有事件循环时会自动创建一个新的事件循环，这可能导致意外行为。在 `_proactive_loop` 中（这是一个协程，运行在事件循环中），`get_event_loop()` 返回当前事件循环是正确的。但如果 `get_event_loop()` 被 `run_in_executor` 的线程调用，行为就不确定了。

**风险评级**: 低危  
**影响**: 当前代码路径下没有问题，但 `asyncio.get_event_loop()` 的语义在 Python 未来版本中可能变化。  
**建议**: 使用 `asyncio.get_running_loop()` 替代 `asyncio.get_event_loop()`，前者明确要求在协程上下文中调用，如果不在事件循环中会立即抛出 `RuntimeError`，更安全：

```python
loop = asyncio.get_running_loop()
await loop.run_in_executor(None, ag._generate_dream)
```

---

## 8. 全局状态的并发影响

### 8.1 personality.json 文件并发写入 —— 中危

**文件**: `core/personality.py` 第 113-116 行

```python
def save(self, path: str) -> None:
    logger.info(f"[personality] saved to: {path}")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
```

**问题描述**: `Personality.save()` 被 `WebAgent.process_message()`（第 88 行）、`process_proactive()`（第 96 行）、`process_explore()`（第 101 行）在每个请求结束时调用。如果多个会话共享同一个 `personality.json` 文件（当前 `SessionManager` 为每个 `WebAgent` 传入相同的 `config.personality_file`），或者同一个会话的多个并发请求同时写入文件，会导致：
1. **数据竞争**：两个线程同时打开文件写入，后写入的覆盖先写入的，导致数据丢失。
2. **文件损坏**：如果写入过程中进程崩溃，文件可能处于半写状态，导致 JSON 解析失败。
3. **I/O 瓶颈**：频繁的磁盘写入（每个请求一次）在高并发下成为瓶颈。

**文件**: `web/session.py` 第 141 行

```python
self._sessions[sid] = WebAgent(self.config, self.db, self.repo)
```

每个 `WebAgent` 创建自己的 `Personality` 实例，但它们都指向同一个文件 `personality.json`。

**风险评级**: 中危  
**影响**: 
- 多会话共享同一个 personality 文件时，情绪状态会被最后一个写入的会话覆盖，导致情绪状态在不同会话间"跳跃"。
- 文件损坏后，下次启动时 `Personality.load()` 会回退到默认配置，丢失用户定制的性格设置。

**建议**: 
1. **每个会话独立的 personality 文件**：将 personality 文件路径改为按 session 隔离，例如 `personality_{session_id}.json`。
2. **写入时加锁**：使用文件锁（`fcntl` 在 Linux 上，`msvcrt` 或 `portalocker` 在 Windows 上）保护写入操作。
3. **原子写入**：先写入临时文件，再重命名，避免半写状态：

```python
import os
import tempfile

def save(self, path: str) -> None:
    dir_name = os.path.dirname(os.path.abspath(path)) or "."
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=dir_name, delete=False, suffix=".tmp") as f:
        json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
        temp_path = f.name
    os.replace(temp_path, path)  # 原子重命名
```

4. **批量写入**：不要每个请求都写入文件，可以设置一个脏标记，每隔 N 秒或 N 个请求批量写入一次。

---

### 8.2 全局配置对象被多个会话共享 —— 低危

**文件**: `web/session.py` 第 28-30 行

```python
class WebAgent:
    def __init__(self, config: Config, db: Database, repo: Repository):
        self.config = config
```

**问题描述**: `Config` 对象被所有 `WebAgent` 实例共享。虽然 `Config` 是一个 dataclass，且当前代码中没有在运行时修改配置的场景，但如果未来某个工具或 Agent 逻辑修改了 `config` 的属性（如动态调整 `temperature`），这会影响到所有会话。

**风险评级**: 低危  
**影响**: 当前代码路径下没有问题，但这是一个潜在的架构隐患。  
**建议**: 在 `WebAgent` 初始化时深拷贝 `Config` 对象，确保每个会话有独立的配置副本：

```python
import copy

class WebAgent:
    def __init__(self, config: Config, db: Database, repo: Repository):
        self.config = copy.deepcopy(config)
```

---

### 8.3 ToolRegistry 实例共享但非线程安全 —— 低危

**文件**: `web/session.py` 第 61-71 行

```python
registry = ToolRegistry()
registry.register(RecallTool(self.retriever, self.ltm))
registry.register(RememberTool(self.ltm))
...
self.tool_registry = registry
```

**问题描述**: 每个 `WebAgent` 创建自己的 `ToolRegistry` 实例，但某些工具（如 `RecallTool`、`RememberTool`）内部引用了共享的 `LongTermMemory` 和 `MemoryRetriever`。`ToolRegistry` 本身只是一个字典包装，没有锁保护。虽然当前代码中不会在运行时动态注册/注销工具，但如果未来添加动态工具管理功能，会面临并发问题。

**风险评级**: 低危  
**影响**: 当前代码路径下没有问题。  
**建议**: 如果 `ToolRegistry` 需要支持动态修改，添加 `threading.Lock` 或 `asyncio.Lock` 保护。当前可以保持现状，但在文档中注明 `ToolRegistry` 不是线程安全的。

---

### 8.4 全局 _TOKENIZER 缓存无锁竞争 —— 低危

**文件**: `core/context_manager.py` 第 10-24 行

```python
_TOKENIZER = None
_TOKENIZER_ENCODING = "cl100k_base"

def _get_tokenizer():
    global _TOKENIZER
    if _TOKENIZER is None:
        try:
            import tiktoken
            _TOKENIZER = tiktoken.get_encoding(_TOKENIZER_ENCODING)
        except (ImportError, Exception):
            _TOKENIZER = False
    return _TOKENIZER
```

**问题描述**: `_get_tokenizer()` 使用全局变量缓存 tokenizer 实例。虽然 Python 的全局变量赋值是原子的，但 `tiktoken.get_encoding()` 的初始化可能涉及文件 I/O 和复杂对象创建。如果多个线程同时调用 `_get_tokenizer()` 且 `_TOKENIZER` 为 `None`，可能同时执行初始化逻辑。虽然这不会导致崩溃（只是浪费一些资源），但可能触发 `tiktoken` 的内部文件竞争。

**风险评级**: 低危  
**影响**: 极小，仅在启动阶段可能发生。  
**建议**: 使用 `threading.Lock` 保护初始化，或使用 `functools.lru_cache`：

```python
import functools

@functools.lru_cache(maxsize=1)
def _get_tokenizer():
    try:
        import tiktoken
        return tiktoken.get_encoding(_TOKENIZER_ENCODING)
    except (ImportError, Exception):
        return False
```

---

### 8.5 sleep_state 文件并发读写 —— 低危

**文件**: `core/sleep_manager.py` 第 25-38 行

```python
def _load_sleep_state(self) -> bool:
    try:
        with open(self._sleep_state_file) as f:
            return f.read().strip() == "1"
    except Exception as e:
        logger.warning(f"Failed to read sleep state: {e}")
        return False

def _save_sleep_state(self) -> None:
    try:
        with open(self._sleep_state_file, "w") as f:
            f.write("1" if self._sleeping else "0")
    except Exception as e:
        logger.warning(f"Failed to save sleep state: {e}")
```

**问题描述**: `SleepManager` 的睡眠状态持久化到文件中。每个 `WebAgent` 创建自己的 `SleepManager` 实例，但它们可能指向同一个 `.sleep_state` 文件（因为路径基于 `config.personality_file` 的目录）。多个会话并发读写此文件可能导致状态不一致。

**风险评级**: 低危  
**影响**: 睡眠状态只是一个辅助功能，不一致不会导致严重问题。  
**建议**: 为每个会话使用独立的睡眠状态文件，或将会话级别的状态存储在数据库中而非文件系统。

---

## 9. 其他并发相关发现

### 9.1 WebSocket 的 _send_segments 未处理发送异常 —— 低危

**文件**: `web/server.py` 第 116-127 行

```python
async def _send_segments(websocket: WebSocket, agent, response: str, emotion: str):
    segments = _split_segments(response)
    for i, seg in enumerate(segments):
        if i > 0:
            await asyncio.sleep(_calc_delay(emotion, len(seg)))
        await websocket.send_text(json.dumps({...}))
    await websocket.send_text(json.dumps({...}))
```

**问题描述**: `_send_segments` 在发送过程中如果 WebSocket 连接断开，`websocket.send_text()` 会抛出异常。当前代码中没有捕获这个异常，异常会向上传播到 `websocket_endpoint` 的 `try-except` 块中。虽然最终会被捕获，但在发送过程中如果连接断开，后续的分段消息会丢失。

**风险评级**: 低危  
**影响**: 用户体验问题：如果用户在 AI 回复过程中断开连接，重新连接后只能看到部分回复。  
**建议**: 在 `_send_segments` 中捕获发送异常并优雅处理：

```python
async def _send_segments(websocket: WebSocket, agent, response: str, emotion: str):
    segments = _split_segments(response)
    for i, seg in enumerate(segments):
        if i > 0:
            await asyncio.sleep(_calc_delay(emotion, len(seg)))
        try:
            await websocket.send_text(json.dumps({"type": "segment", "content": seg}, ensure_ascii=False))
        except (WebSocketDisconnect, RuntimeError):
            logger.debug("WebSocket closed during segment send")
            return
    try:
        await websocket.send_text(json.dumps({"type": "done", ...}, ensure_ascii=False))
    except (WebSocketDisconnect, RuntimeError):
        pass
```

---

### 9.2 proactive_loop 中的竞争条件 —— 低危

**文件**: `web/server.py` 第 130-196 行

```python
async def _proactive_loop(websocket: WebSocket, session_id: str):
    ...
    active_ws = session_manager.get_active_ws(session_id) or websocket
    _, agent = session_manager.get_or_create(session_id)
    ...
```

**问题描述**: `_proactive_loop` 每次循环都调用 `get_active_ws()` 和 `get_or_create()` 获取最新的 WebSocket 和 Agent。但这两个操作不是原子的，在它们之间可能发生：
1. 用户断开连接，`remove()` 被调用，会话被清除。
2. 用户重新连接，新的 `WebAgent` 被创建。
3. `proactive_loop` 继续执行，但持有的是旧的 Agent 引用。

虽然 `get_active_ws()` 返回的是新的 WebSocket，但 `agent` 变量是循环开始时获取的，如果会话被重建，`agent` 可能指向已废弃的实例。

**风险评级**: 低危  
**影响**: 在极端情况下（用户快速断开重连），主动行为可能发送到错误的 WebSocket 或使用旧的 Agent 状态。  
**建议**: 在 `_proactive_loop` 中定期检查会话是否仍然有效：

```python
async def _proactive_loop(websocket: WebSocket, session_id: str):
    while True:
        if session_manager.get_active_ws(session_id) != websocket:
            logger.info("WebSocket replaced, exiting proactive loop")
            break
        _, agent = session_manager.get_or_create(session_id)
        ...
```

---

### 9.3 random 模块的线程安全性 —— 低危

**文件**: 多处使用 `random.random()`、`random.choice()`、`random.sample()`、`random.uniform()`

**问题描述**: Python 的 `random` 模块使用全局的 `random.Random` 实例，该实例不是线程安全的。虽然 `random` 模块的底层实现（Mersenne Twister）在 CPython 中由于 GIL 的存在，实际上在大多数操作中是"足够安全"的（因为字节码执行是原子的），但在极端高并发场景下，两个线程同时修改随机状态可能导致：
- 生成的随机数序列质量下降（统计偏差）。
- 极少数情况下的状态损坏（理论上可能，实际极难触发）。

**风险评级**: 低危  
**影响**: 对于 AI 朋友的随机延迟、话题选择等场景，随机数质量的轻微下降不会导致功能问题。  
**建议**: 如果对随机数质量有严格要求，可以为每个线程创建独立的 `random.Random` 实例：

```python
import threading

_thread_local = threading.local()

def _get_random():
    if not hasattr(_thread_local, 'rng'):
        _thread_local.rng = random.Random()
    return _thread_local.rng

# 使用
_get_random().uniform(0.8, 1.3)
```

---

### 9.4 NotifyTool 的 threading.Thread 创建 —— 低危

**文件**: `tools/notify_tool.py` 第 47-67 行

```python
def execute(self, args: dict[str, Any]) -> ToolResult:
    ...
    import subprocess, threading

    def _show():
        ...
        subprocess.run(['powershell', '-NoProfile', '-Command', ps], capture_output=True, timeout=10)

    threading.Thread(target=_show, daemon=True).start()
    ...
```

**问题描述**: `NotifyTool` 每次执行都创建一个新的守护线程来显示 Windows 通知。虽然守护线程在进程结束时会自动终止，但频繁的线程创建（如果 AI 频繁调用通知工具）会带来开销。

**风险评级**: 低危  
**影响**: 通知工具调用频率很低（通常由用户显式请求），所以实际影响很小。  
**建议**: 如果通知调用频率增加，可以使用线程池或 `asyncio.to_thread()`（Python 3.9+）来复用线程。

---

# 汇总统计

## 风险统计

| 风险等级 | 数量 | 占比 |
|---------|------|------|
| 高危    | 3    | 17.6% |
| 中危    | 6    | 35.3% |
| 低危    | 8    | 47.1% |
| **总计** | **17** | **100%** |

## 按类别统计

| 类别 | 风险数 | 最高等级 |
|------|--------|---------|
| 数据库并发访问 | 3 | 高危 |
| SessionManager 锁策略 | 3 | 高危 |
| run_in_executor 使用 | 2 | 高危 |
| Provider 并发安全 | 2 | 中危 |
| 全局状态并发 | 5 | 中危 |
| WebSocket 连接管理 | 2 | 中危 |
| asyncio vs threading | 1 | 中危 |
| 事件循环嵌套 | 2 | 中危 |
| Web 端并发模型 | 2 | 中危 |
| 其他 | 1 | 低危 |

## 关键文件风险分布

| 文件 | 风险数 | 涉及问题 |
|------|--------|---------|
| `storage/repository.py` | 2 | 线程池滥用、同步包装层 |
| `storage/database.py` | 2 | 全局锁、get_connection 绕过锁 |
| `web/session.py` | 3 | threading.Lock、会话清理、Provider 未共享 |
| `web/server.py` | 4 | WebSocket 并发限制、run_in_executor、proactive_loop 竞争 |
| `core/provider.py` | 2 | Session 共享、time.sleep 阻塞 |
| `core/dispatcher.py` | 1 | asyncio.run 嵌套 |
| `core/personality.py` | 1 | 文件并发写入 |
| `memory/long_term.py` | 1 | _run_sync 重复实现 |
| `memory/consolidation.py` | 1 | get_connection 绕过锁 |

## 优先修复建议

### P0（立即修复）
1. **重构 `_run_sync()` 消除线程池滥用**：`storage/repository.py` 和 `memory/long_term.py` 中的 `_run_sync()` 每次调用都创建新线程池，应立即改为全局线程池或全异步架构。
2. **移除数据库全局锁**：`storage/database.py` 中的 `asyncio.Lock` 强制所有数据库操作串行化，应改为连接池或事务级锁。
3. **为 personality.json 添加原子写入和会话隔离**：避免多会话并发写入导致的数据损坏。

### P1（短期修复，1-2 周）
4. **将 SessionManager 的锁改为 asyncio.Lock**：确保异步环境中的正确并发保护。
5. **为每个 WebAgent 添加消息处理锁**：防止同一会话的并发消息处理导致状态混乱。
6. **使用异步 HTTP 客户端替代 requests**：将 `KimiProvider` 改为 `httpx.AsyncClient`，消除线程池瓶颈。
7. **配置 uvicorn 多工作进程 + 外部状态存储**：生产环境应使用多进程模式，并将会话状态存储在 Redis 等外部存储中。

### P2（中期优化，1 个月）
8. **全异步架构迁移**：逐步将 `Agent`、`InnerDriveAgent`、`ToolAgent` 的核心逻辑改为异步。
9. **独立线程池管理**：为用户请求、主动行为、后台任务创建独立的 `ThreadPoolExecutor`。
10. **会话延迟清理机制**：WebSocket 断开后保留会话状态一段时间，支持页面刷新后的状态恢复。
11. **数据库连接池**：实现 `aiosqlite` 的连接池，支持真正的读写并发。

### P3（长期改进）
12. **性能监控和限流**：添加请求队列长度、线程池利用率、数据库锁等待时间等指标监控。
13. **负载测试**：使用 `locust` 或 `k6` 进行并发压力测试，验证修复效果。
14. **代码审查自动化**：引入 `ruff`、`mypy` 等工具，检测潜在的并发问题（如 `asyncio.run` 在协程中的使用）。

---

*报告生成时间: 2026-05-31*  
*审查人: Claude Code*  
*关联里程碑: #127-#132（数据质量）、#125（内驱力 + 主动行为）*
