# 第1轮代码审查：模型定义层（models/）深度审查报告

**审查日期**：2026-05-31
**审查范围**：`models/personality.py`、`models/conversation.py`、`models/memory.py`、`models/__init__.py`
**审查人**：AI 代码审查专家
**关联测试**：`tests/test_emotional_state.py`（38 用例）、`tests/test_personality_core.py`

---

## 1. 概述

AI Friend 项目的模型定义层位于 `models/` 目录下，共 4 个文件（含空 `__init__.py`），承担了情绪状态、人格配置、对话轮次、记忆实体四大核心数据结构的定义职责。整体采用 Python `dataclass` 实现，风格简洁，但在数据验证、序列化健壮性、类型安全、架构边界等方面存在多处需要关注的问题。

本次审查的核心发现可归纳为以下几点：

1. **EmotionalState 是设计最复杂的模型**，实现了 VAD（Valence-Arousal-Dominance 的简化版，实际为 VA 二维）+ 8 种 Plutchik 基本情绪 + resentment（怨恨）+ emotion_events（情绪事件记忆）的复合情感系统，并内置了交叉调制（cross-modulation）、衰减（decay）、主导情绪判定（dominant_emotion）等行为逻辑。该模型混合了"数据结构"与"业务逻辑"两种职责，虽然简化了调用方代码，但也带来了单元测试复杂度和可维护性问题。

2. **PersonalityConfig 的 traits 字段在序列化/反序列化过程中存在类型不一致风险**：`to_dict()` 将 `list[Trait]` 转换为 `dict[str, float]`，而 `from_dict()` 需要处理反向转换，但两者均未对 Trait.value 进行范围校验（0.0~1.0）。

3. **Memory 相关模型（UserFact、Experience、Reflection）极为轻量**，几乎仅为纯数据结构，缺乏字段级验证，且与数据库 schema 的映射关系散落在 `storage/repository.py` 中，存在 schema 变更时不同步的风险。

4. **Conversation 模型（Turn、MemoryContext）同样轻量**，但 `Turn.timestamp` 使用 `datetime.now()` 作为默认值，存在可序列化性问题；`MemoryContext` 的 `relationship` 字段使用硬编码的默认值，缺乏与数据库的联动机制。

5. **序列化/反序列化整体缺乏版本控制机制**，所有 `from_dict()` 方法均为"尽力而为"的字段过滤模式，无法优雅处理字段重命名、类型变更、结构迁移等演化场景。

6. **`models/__init__.py` 完全为空**，未导出任何公共符号，导致调用方需要写冗长的 `from models.personality import ...` 导入语句，且无法通过 `models.Xxx` 访问类型。

7. **数据验证几乎完全缺失**：所有模型字段均为无约束的原始类型，`float` 字段没有范围限制，`str` 字段没有长度限制，`list[dict]` 类型的 `emotion_events` 没有结构约束。虽然当前由调用方保证输入合法性，但在长期运行、多模块协作、外部输入（如从 JSON 文件恢复状态）的场景下，脏数据可能悄然流入系统。

---

## 2. 详细发现

### 2.1 models/personality.py

#### 2.1.1 EmotionalState：数据结构 vs 业务逻辑的耦合

**文件路径**：`D:\桌面\编程作品\AI朋友\models\personality.py`
**涉及行号**：34~287

`EmotionalState` 是一个 `@dataclass`，但内部包含了大量业务方法：

- `dominant_emotion`（property，第 72~130 行）
- `_cross_modulate()`（第 132~173 行）
- `shift()`（第 175~208 行）
- `decay()`（第 210~237 行）
- `record_emotion_event()`（第 239~262 行）
- `get_recent_emotion_events()`（第 264~269 行）
- `apply_mood_shift()`（第 271~274 行）
- `to_dict()` / `from_dict()`（第 276~286 行）

**分析**：

从领域驱动设计（DDD）的角度看，`EmotionalState` 已经不是一个单纯的"值对象"或"数据传输对象"，而是一个具有完整行为逻辑的"领域模型"。这种设计的好处是调用方（如 `core/personality.py` 中的 `Personality` 类）可以直接调用 `emotion.shift()`、`emotion.decay()`，无需了解情感计算的内部细节。但坏处也很明显：

- **单元测试负担重**：`tests/test_emotional_state.py` 需要覆盖 shift、decay、cross-modulate、dominant emotion、serialization、event recording 六大类行为，共 38 个用例。如果未来情感模型升级（例如引入更多维度、更复杂的神经网络模型），这些测试用例的维护成本会线性增长。
- **与 PersonalityConfig 的职责边界模糊**：`PersonalityConfig` 提供的是"静态人格配置"（如 traits、speaking_style），而 `EmotionalState` 提供的是"动态情绪状态"。但 `EmotionalState` 的 baseline 和 decay_rate 实际上是由 `PersonalityConfig` 在初始化时注入的（见 `core/personality.py` 第 15~19 行），这意味着 EmotionalState 的"默认值"在运行时会被覆盖，其内部默认值（如 `baseline_valence=0.4`）的实际作用仅限于独立测试场景。
- **可替换性差**：如果未来需要将情感计算引擎替换为基于 LLM 的情感分析（如调用外部 API 获取情绪标签），当前设计需要将整个 `EmotionalState` 类重写，而不是仅替换一个策略接口。

**建议**：

- **短期**：保持现状，但将 `_cross_modulate()` 的调制参数（如 `anger_joy_suppress = min(0.95, a * 0.6 + r * 0.3)` 中的 0.95、0.6、0.3 等魔法数字）提取为类常量或配置项，便于调参和 A/B 测试。
- **中期**：考虑将情感计算逻辑（shift、decay、cross-modulate）抽取为 `EmotionEngine` 策略类，`EmotionalState` 仅保留纯数据结构。这样可以在不修改状态模型的情况下，更换不同的情感计算算法。
- **长期**：如果情感模型复杂度继续增长，建议引入独立的情感推理服务（或至少一个独立的模块 `core/emotion_engine.py`），将 `models/personality.py` 中的行为方法迁移过去。

#### 2.1.2 dominant_emotion 判定逻辑存在潜在歧义

**文件路径**：`D:\桌面\编程作品\AI朋友\models\personality.py`
**涉及行号**：72~130

`dominant_emotion` property 的判定逻辑分为两个阶段：

1. **VAD-based 映射**（第 78~90 行）：根据 valence 和 arousal 的组合，生成 "excited"、"content"、"engaged"、"anxious"、"melancholy"、"frustrated" 等标签。
2. **Primary emotion 阈值判定**（第 93~108 行）：根据 joy、trust、fear 等 8 个维度的绝对值是否超过阈值（0.6 或 0.7），生成 "joyful"、"trusting"、"afraid" 等标签。

两个阶段的结果被合并到一个 `scores` 字典中，然后经过 valence-based bias 调整后取最大值。

**问题**：

- **阈值不一致**：joy/trust/surprise/anticipation 的阈值是 0.7，而 fear/sadness/anger/disgust 的阈值是 0.6。这种不对称设计可能是出于"负面情绪更容易被感知"的心理学直觉，但代码中没有任何注释解释这一设计决策。未来维护者可能会误以为这是笔误。
- **VAD-based 标签与 Primary emotion 标签的命名空间存在语义重叠**：例如 VAD-based 的 "frustrated"（沮丧）与 Primary emotion 的 "angry"（愤怒）在情感语义上接近，但它们的触发条件和得分计算方式完全不同。如果某个状态下两者同时被触发，最终的 dominant emotion 取决于 bias 调整后的得分，而这一过程对调用方（如 prompt 构建器）是不透明的。
- **"engaged" 的判定条件过于宽泛**：`if v > 0 and 0.4 <= a <= 0.6: scores["engaged"] = v`，只要 valence 为正、arousal 在中等范围即可触发。这意味着即使 joy=0.1、trust=0.1（几乎所有情绪维度都很低），只要 valence=0.1、arousal=0.5，就会被判定为 "engaged"。这在某些场景下可能不符合直觉。
- **缺少 "disgusted" 在 emotion_desc 中的映射**：`prompts/system.py` 第 280~295 行的 `emotion_desc` 字典中包含了 "disgusted"，但 `dominant_emotion` 返回的 "disgusted" 仅在 disgust > 0.6 时触发。如果 disgust=0.55 且 valence=-0.5，可能返回 "frustrated" 或 "melancholy"，而 prompt 构建器不会收到 "disgusted" 标签。这种不一致可能导致 AI 的"内心状态"与"外在表现"出现偏差。

**建议**：

- 在 `dominant_emotion` 的 docstring 中明确说明阈值不对称的设计理由。
- 考虑将 VAD-based 标签和 Primary emotion 标签的得分归一化到同一尺度，或引入权重配置项。
- 在 `prompts/system.py` 中增加对 "disgusted" 的行为描述（目前 emotion_behavior 字典中缺少该条目，第 310~318 行）。

#### 2.1.3 _cross_modulate() 的副作用顺序敏感

**文件路径**：`D:\桌面\编程作品\AI朋友\models\personality.py`
**涉及行号**：132~173

`_cross_modulate()` 方法按固定顺序执行多组情绪间的相互抑制/促进：

1. Anger suppresses joy and trust（第 148~151 行）
2. Sadness dampens joy and anticipation（第 154~155 行）
3. Joy counters anger and sadness（第 158~160 行）
4. Trust/Fear mutual suppression（第 163~164 行）
5. Disgust suppresses joy and trust（第 167~168 行）
6. Resentment caps joy ceiling（第 171~173 行）

**问题**：

- **顺序依赖性**：joy 在第 1 步被 anger 抑制后，第 3 步又用被抑制后的 joy 值去 counter anger。如果交换第 1 步和第 3 的顺序，结果会不同。当前顺序是"先抑制、后反击"，这隐含了一种"负面情绪优先"的假设，但代码中没有注释说明。
- **joy 被多次修改**：joy 在第 1 步（anger）、第 2 步（sadness）、第 3 步（joy counter 的副作用，实际上 joy 不直接修改自身，但 anger/sadness 的减少会间接影响后续步骤）、第 5 步（disgust）、第 6 步（resentment cap）共被修改 5 次。这种"链式副作用"使得调试非常困难。
- **没有收敛性保证**：`_cross_modulate()` 只执行一次，没有迭代到稳定状态。如果某次 shift 后 anger 和 joy 都处于高位，一次 cross-modulate 可能无法达到"合理"的平衡状态。

**建议**：

- 在方法 docstring 中明确说明各步骤的执行顺序及其设计理由。
- 考虑引入迭代收敛机制（如最多 3 次迭代，直到各维度变化量小于某个阈值），或至少在一次单元测试中验证"极端值输入下的输出合理性"。
- 将各步骤的抑制系数（如 0.6、0.4、0.5 等）提取为命名常量。

#### 2.1.4 shift() 中的 primary_deltas 字段名校验过于宽松

**文件路径**：`D:\桌面\编程作品\AI朋友\models\personality.py`
**涉及行号**：186~191

```python
if primary_deltas:
    for key, delta in primary_deltas.items():
        if hasattr(self, key):
            current = getattr(self, key)
            new_val = current + delta * inertia_factor
            setattr(self, key, max(0.0, min(1.0, new_val)))
```

**问题**：

- `hasattr(self, key)` 会匹配任何属性，包括 `valence`、`arousal`、`baseline_valence`、`history`、`to_dict` 等方法。如果调用方误传了 `{"to_dict": 0.5}`，虽然不会直接破坏对象（因为 `to_dict` 是 bound method，current = <bound method ...>，new_val 会是一个非法值，最终被 clamp 到 0.0 或 1.0，然后 `setattr(self, "to_dict", 0.0)` 会覆盖方法），但这是一种严重的安全隐患。
- 更严重的是，如果传入 `{"decay_rate": 0.5}`，会静默修改 EmotionalState 的衰减率，而调用方可能完全没有意识到这一点。

**建议**：

- 将 `hasattr(self, key)` 改为白名单校验：`if key in {"joy", "trust", "fear", "surprise", "sadness", "anticipation", "anger", "disgust"}`。
- 或者，在 `shift()` 的签名中将 `primary_deltas` 的类型从 `dict[str, float]` 改为更严格的 `dict[Literal["joy", "trust", ...], float]`（Python 3.8+ 可用 `typing.Literal`）。

#### 2.1.5 decay() 中的 target 值硬编码

**文件路径**：`D:\桌面\编程作品\AI朋友\models\personality.py`
**涉及行号**：225~226

```python
target = 0.5 if key in ("joy", "trust", "anticipation") else 0.1
```

**问题**：

- joy、trust、anticipation 的衰减目标是 0.5，其余是 0.1。这隐含了"积极情绪的基线更高"的假设，但同样没有注释说明。
- 这些 target 值与 `PersonalityConfig.emotional_baseline` 中的 valence/arousal 没有关联。如果用户通过配置文件将 baseline_valence 设为 0.8（非常乐观的人格），decay 后 joy 仍然向 0.5 衰减，而不是向更高的值衰减。这可能导致"人格配置"与"情绪衰减"之间的不一致。

**建议**：

- 将 target 值与 `baseline_valence` 关联，或至少允许通过 `PersonalityConfig` 配置各情绪的基线目标值。
- 在代码中添加注释，解释为什么积极情绪和消极情绪的衰减目标不同。

#### 2.1.6 emotion_events 的类型过于松散

**文件路径**：`D:\桌面\编程作品\AI朋友\models\personality.py`
**涉及行号**：67、239~269

`emotion_events: list[dict] = field(default_factory=list)`

**问题**：

- `list[dict]` 是 Python 中最松散的类型之一。每个 event dict 的结构由 `record_emotion_event()` 方法隐式定义（第 251~257 行）：`{"timestamp": float, "trigger": str, "primary_emotion": str, "intensity": float, "context": str}`。
- 没有结构验证：如果调用方直接修改 `emotion_events`（如从 JSON 恢复时），可能传入缺少 `timestamp` 或 `primary_emotion` 的字典，后续 `get_recent_emotion_events()` 中的 `e.get("resolved", False)` 虽然不会崩溃，但可能导致语义错误。
- `resolved` 字段从未被设置：`record_emotion_event()` 创建的 event 不包含 `resolved` 字段，而 `get_recent_emotion_events(unresolved_only=True)` 会过滤掉 `resolved=True` 的事件。这意味着目前所有事件都被视为"未解决"，该过滤逻辑实际上没有起到作用。如果未来需要实现"情绪事件解决"机制，需要额外的方法（如 `resolve_emotion_event()`），但目前不存在。

**建议**：

- 将 emotion event 定义为独立的 `@dataclass`：
  ```python
  @dataclass
  class EmotionEvent:
      timestamp: float
      trigger: str
      primary_emotion: str
      intensity: float
      context: str = ""
      resolved: bool = False
  ```
- 在 `EmotionalState` 中将 `emotion_events: list[dict]` 改为 `emotion_events: list[EmotionEvent]`。
- 提供 `resolve_emotion_event(index: int)` 或 `resolve_by_trigger(trigger: str)` 方法，使 `unresolved_only` 参数真正有意义。

#### 2.1.7 to_dict() 包含计算属性，from_dict() 未处理

**文件路径**：`D:\桌面\编程作品\AI朋友\models\personality.py`
**涉及行号**：276~286

```python
def to_dict(self) -> dict:
    result = asdict(self)
    result["dominant_emotion"] = self.dominant_emotion
    return result

@classmethod
def from_dict(cls, d: dict) -> "EmotionalState":
    field_names = set(cls.__dataclass_fields__)
    filtered = {k: v for k, v in d.items() if k in field_names}
    return cls(**filtered)
```

**问题**：

- `to_dict()` 在 `asdict()` 的结果中额外添加了 `"dominant_emotion"`，但 `from_dict()` 会将其过滤掉（因为 `dominant_emotion` 不是 dataclass field）。这导致 round-trip 后 `dominant_emotion` 丢失，虽然它是一个 property，可以重新计算，但调用方如果直接比较 `to_dict()` 和 `from_dict().to_dict()` 的结果，会发现两者不一致。
- `from_dict()` 使用 `cls(**filtered)` 构造对象，如果 `d` 中缺少某些字段（如 `history`），会使用 dataclass 的默认值。但如果 `d` 中的 `history` 是字符串（旧版本格式），`cls(**filtered)` 会直接抛出 `TypeError`，因为 `history` 的类型注解是 `list[str]`。

**建议**：

- 在 `from_dict()` 中增加对 `history` 等关键字段的类型转换逻辑：
  ```python
  if "history" in filtered and isinstance(filtered["history"], str):
      filtered["history"] = [filtered["history"]]
  ```
- 或者，引入版本号机制：`to_dict()` 输出 `"__version__": 1`，`from_dict()` 根据版本号选择不同的解析逻辑。

#### 2.1.8 PersonalityConfig 的 traits 序列化/反序列化不对称

**文件路径**：`D:\桌面\编程作品\AI朋友\models\personality.py`
**涉及行号**：289~322

```python
class PersonalityConfig:
    traits: list[Trait] = field(default_factory=lambda: [...])
    ...
    def to_dict(self) -> dict:
        d = asdict(self)
        d["traits"] = {t["name"]: t["value"] for t in d["traits"]}
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "PersonalityConfig":
        if "traits" in d and isinstance(d["traits"], dict):
            d["traits"] = [Trait(k, v) for k, v in d["traits"].items()]
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})
```

**问题**：

- `to_dict()` 将 traits 从 `list[Trait]` 转换为 `dict[str, float]`，而 `from_dict()` 需要处理反向转换。这种不对称性意味着 `PersonalityConfig` 的 JSON 表示与 Python 对象的内部结构不一致。
- `Trait` 的 `value` 字段没有范围校验：`Trait("empathy", 999.0)` 是合法的，但后续 `core/personality.py` 中的 `estimate_emotional_impact()` 会将该值作为乘数使用（第 49~53 行：`dv *= 1.5`、`primary_deltas[k] *= t.value`），可能导致极端的 emotional shift。
- `from_dict()` 的过滤逻辑 `if k in cls.__dataclass_fields__` 会静默丢弃未知字段，这在向后兼容时是有用的，但也可能掩盖配置错误（如用户写错了字段名，却没有任何警告）。

**建议**：

- 在 `Trait.__post_init__()` 中增加 `value` 的范围校验：
  ```python
  def __post_init__(self):
      if not 0.0 <= self.value <= 1.0:
          raise ValueError(f"Trait value must be in [0.0, 1.0], got {self.value}")
  ```
- 在 `from_dict()` 中增加对未知字段的日志警告（至少在使用 `logging` 记录 warn 级别日志）。
- 考虑统一 traits 的序列化格式：要么始终用 `list[dict]`（`[{"name": "empathy", "value": 0.8}]`），要么始终用 `dict[str, float]`（`{"empathy": 0.8}`），避免来回转换。

#### 2.1.9 PersonalityConfig 缺少验证和约束

**文件路径**：`D:\桌面\编程作品\AI朋友\models\personality.py`
**涉及行号**：289~310

`PersonalityConfig` 的所有字段均为原始类型，没有任何验证：

- `name: str = "Luna"` — 可为空字符串，可为任意长度。
- `speaking_style: str = "warm, conversational, poetic"` — 同上。
- `backstory: str = ...` — 同上。
- `interests: list[str] = ...` — 列表中可包含空字符串或重复项。
- `emotional_baseline: dict = ...` — 字典结构完全无约束，可为 `{"valence": "high"}` 或缺少 `arousal` 键。
- `emotional_decay_rate: float = 0.05` — 可为负数、可为 100.0。
- `first_run_greeting: str = ""` — 同上。

**问题**：

- 在 `core/personality.py` 第 16~18 行，`Personality.__init__()` 直接从 `emotional_baseline` 字典中 `get("valence", 0.4)` 和 `get("arousal", 0.3)`。如果 `emotional_baseline` 是 `{"valence": "invalid"}`，`get()` 会返回字符串 `"invalid"`，然后 `baseline_valence="invalid"` 会被传入 `EmotionalState`，而 `EmotionalState.valence` 的注解是 `float`。虽然 Python 是动态类型，不会立即报错，但后续任何数学运算（如 `self.valence + delta_v`）都会抛出 `TypeError`。

**建议**：

- 在 `PersonalityConfig` 中增加 `__post_init__()` 验证：
  ```python
  def __post_init__(self):
      if not isinstance(self.name, str) or not self.name.strip():
          raise ValueError("name must be a non-empty string")
      if not 0.0 <= self.emotional_decay_rate <= 1.0:
          raise ValueError("emotional_decay_rate must be in [0.0, 1.0]")
      baseline = self.emotional_baseline
      if not isinstance(baseline, dict):
          raise ValueError("emotional_baseline must be a dict")
      for key in ("valence", "arousal"):
          if key in baseline and not isinstance(baseline[key], (int, float)):
              raise ValueError(f"emotional_baseline.{key} must be numeric")
  ```

### 2.2 models/conversation.py

#### 2.2.1 Turn.timestamp 的默认值使用 datetime.now()，存在序列化问题

**文件路径**：`D:\桌面\编程作品\AI朋友\models\conversation.py`
**涉及行号**：8~14

```python
@dataclass
class Turn:
    turn_id: int
    role: str          # "user" or "assistant"
    content: str
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: dict = field(default_factory=dict)
```

**问题**：

- `datetime` 对象不能直接 JSON 序列化。如果调用方尝试 `json.dumps(turn.__dict__)`，会抛出 `TypeError: Object of type datetime is not JSON serializable`。
- 当前代码中，`Turn` 对象主要在内存中流转（`memory/short_term.py` 的 `ConversationBuffer`），尚未发现直接序列化 `Turn` 的场景。但 `storage/repository.py` 的 `insert_turn()`（第 218~226 行）将 turn 拆分为 `turn_number`、`role`、`content`、`emotional_state` 存入数据库，没有存储 `timestamp` 和 `metadata`。这意味着 `Turn` 的完整状态无法持久化，从数据库恢复时只能得到不完整的 `Turn`。

**建议**：

- 为 `Turn` 增加 `to_dict()` 和 `from_dict()` 方法，并在 `to_dict()` 中将 `timestamp` 转换为 ISO 8601 字符串（`timestamp.isoformat()`）。
- 或者，在数据库 schema 中增加 `created_at` 和 `metadata` 列，使 `Turn` 可以完整持久化。
- 至少应在 `Turn` 的 docstring 中说明其序列化限制。

#### 2.2.2 Turn.role 没有枚举约束

**文件路径**：`D:\桌面\编程作品\AI朋友\models\conversation.py`
**涉及行号**：10~11

```python
role: str          # "user" or "assistant"
```

**问题**：

- `role` 仅为 `str` 类型，没有使用 `Literal["user", "assistant"]` 或枚举类。调用方可能传入 `"system"`、`"bot"`、甚至 `"user "`（带空格），导致下游逻辑（如 `ConversationBuffer.format_for_prompt()` 第 56 行：`label = "你" if t.role == "assistant" else "用户"`）出现意外行为。

**建议**：

- 将 `role` 的类型改为 `Literal["user", "assistant"]`（Python 3.8+）。
- 或在 `__post_init__()` 中校验：`if self.role not in ("user", "assistant"): raise ValueError(...)`。

#### 2.2.3 MemoryContext 的 relationship 字段与数据库 schema 不同步

**文件路径**：`D:\桌面\编程作品\AI朋友\models\conversation.py`
**涉及行号**：18~24

```python
@dataclass
class MemoryContext:
    facts: list[UserFact] = field(default_factory=list)
    experiences: list[Experience] = field(default_factory=list)
    reflections: list[Reflection] = field(default_factory=list)
    relationship: dict[str, float] = field(default_factory=lambda: {
        "trust": 0.3, "familiarity": 0.3, "intimacy": 0.3, "playfulness": 0.3,
    })
```

**问题**：

- `relationship` 的默认值包含 4 个维度（trust、familiarity、intimacy、playfulness），但 `storage/repository.py` 的 `get_all_relationships()`（第 201~204 行）从 `relationship_metrics` 表中动态查询，返回的维度可能多于或少于 4 个。如果数据库中缺少某个维度，`MemoryContext` 的默认值会填补缺失值，但调用方（如 `prompts/system.py` 第 358~365 行）可能会错误地认为该维度存在且有值。
- 更严重的是，`relationship_metrics` 表中的值与 `MemoryContext` 的默认值之间没有同步机制。如果数据库中的值被修改（如通过 `upsert_relationship()`），但 `MemoryContext` 是在查询之前创建的缓存对象，调用方可能使用过期的默认值。

**建议**：

- 将 `MemoryContext` 的 `relationship` 字段默认值设为 `{}`（空字典），强制要求调用方从数据库查询后填充。
- 或者，在 `MemoryContext` 中增加一个类方法 `from_repository(repo: Repository)`，统一封装查询逻辑。
- 定义 `RelationshipMetrics` 枚举或常量，明确支持的维度列表，避免数据库和代码中的维度不一致。

#### 2.2.4 MemoryContext 缺少元数据字段

**文件路径**：`D:\桌面\编程作品\AI朋友\models\conversation.py`
**涉及行号**：18~24

**问题**：

- `MemoryContext` 仅包含 facts、experiences、reflections、relationship 四个字段，缺少以下可能有用的元数据：
  - `retrieval_query`：本次检索使用的原始查询文本，便于调试和日志分析。
  - `retrieval_timestamp`：检索时间，便于判断缓存是否过期。
  - `source_info`：各记忆项的来源信息（如 facts 来自 keyword search 还是 semantic search）。
- 当前 `memory/retrieval.py` 的 `retrieve_for_query()`（第 27~69 行）在构建 `MemoryContext` 时，没有传递任何检索元数据，导致后续分析（如"为什么 AI 引用了这条记忆？"）非常困难。

**建议**：

- 在 `MemoryContext` 中增加 `metadata: dict = field(default_factory=dict)` 字段，用于存储检索相关的元数据。
- 在 `MemoryRetriever.retrieve_for_query()` 中填充 `metadata`，如 `{"query": query, "keywords": keywords, "semantic_enabled": bool(self._embed)}`。

### 2.3 models/memory.py

#### 2.3.1 UserFact 的字段缺乏验证

**文件路径**：`D:\桌面\编程作品\AI朋友\models\memory.py`
**涉及行号**：5~18

```python
@dataclass
class UserFact:
    id: Optional[int] = None
    category: str = ""
    fact_key: str = ""
    fact_value: str = ""
    confidence: float = 1.0
    importance: float = 0.5
    source_turn: Optional[int] = None
    created_at: str = ""
    updated_at: str = ""
    recall_count: int = 0
    is_active: bool = True
    composite_score: float = 1.0
```

**问题**：

- `confidence`、`importance`、`composite_score` 均为 `float`，但没有任何范围约束。`confidence` 理论上应在 [0.0, 1.0] 范围内，但代码中允许 `confidence=999.0`。
- `category`、`fact_key`、`fact_value` 均为 `str`，但允许空字符串。`storage/repository.py` 的 `upsert_fact()`（第 34~67 行）在数据库层面使用 `(category, fact_key)` 作为唯一索引，如果两者均为空字符串，会导致唯一索引冲突或语义不明的记录。
- `created_at` 和 `updated_at` 使用 `str` 而非 `datetime`，虽然便于与 SQLite 的文本类型兼容，但失去了日期运算能力。
- `recall_count` 为 `int`，但允许负数。

**建议**：

- 增加 `__post_init__()` 校验：
  ```python
  def __post_init__(self):
      if self.confidence is not None and not 0.0 <= self.confidence <= 1.0:
          raise ValueError("confidence must be in [0.0, 1.0]")
      if self.importance is not None and not 0.0 <= self.importance <= 1.0:
          raise ValueError("importance must be in [0.0, 1.0]")
      if self.recall_count < 0:
          raise ValueError("recall_count must be non-negative")
  ```
- 考虑将 `created_at`/`updated_at` 改为 `datetime` 类型，并在与数据库交互时进行格式转换。

#### 2.3.2 Experience 的 tags 字段类型注解与默认值类型不一致

**文件路径**：`D:\桌面\编程作品\AI朋友\models\memory.py`
**涉及行号**：22~34

```python
@dataclass
class Experience:
    id: Optional[int] = None
    summary: str = ""
    emotional_tone: str = "neutral"
    significance: float = 0.5
    importance: float = 0.5
    tags: list[str] = field(default_factory=list)
    ...
```

**问题**：

- `tags: list[str]` 的类型注解在 Python 3.9+ 中是合法的，但如果使用 Python 3.8，需要 `from typing import List`。当前项目未声明最低 Python 版本要求，但 `requirements.txt` 和 `pyproject.toml`（如果存在）应明确说明。
- `emotional_tone` 的默认值为 `"neutral"`，但 `storage/repository.py` 的 `_row_to_experience()`（第 309~319 行）直接从数据库读取字符串，不做任何校验。如果数据库中存储了 `"joyful"` 以外的任意字符串（如 `"happy"`、`"excited"`），模型层不会报错，但 `prompts/system.py` 的 `emotion_desc` 字典可能无法匹配，导致 prompt 中显示"平静"（默认值）。

**建议**：

- 定义 `EmotionalTone` 枚举或 `Literal` 类型，限制 `emotional_tone` 的取值范围。
- 在 `Experience.__post_init__()` 中校验 `emotional_tone` 是否在允许的值列表中。

#### 2.3.3 Reflection 的 related_experience_ids 字段缺少外键语义

**文件路径**：`D:\桌面\编程作品\AI朋友\models\memory.py`
**涉及行号**：38~44

```python
@dataclass
class Reflection:
    id: Optional[int] = None
    content: str = ""
    insight_type: str = ""
    related_experience_ids: list[int] = field(default_factory=list)
    significance: float = 0.5
    created_at: str = ""
```

**问题**：

- `related_experience_ids` 表示该反思关联的体验 ID 列表，但模型层没有提供任何方法来验证这些 ID 是否存在于数据库中。
- 如果某个 Experience 被删除（或软删除，`is_archived=True`），Reflection 中仍然保留其 ID，形成"悬空引用"。
- `insight_type` 同样没有约束，可为任意字符串。

**建议**：

- 在 `storage/repository.py` 中增加 `get_reflections_with_valid_experiences()` 等方法，在查询时过滤掉悬空引用。
- 或，在 `Reflection` 中增加 `validate_related_ids(repo: Repository)` 方法，但这种方法会引入模型层对存储层的依赖，违反依赖方向。更好的做法是在服务层（如 `memory/consolidation.py`）进行验证。
- 定义 `InsightType` 枚举，限制 `insight_type` 的取值。

#### 2.3.4 三个 Memory 模型均未实现 to_dict/from_dict

**文件路径**：`D:\桌面\编程作品\AI朋友\models\memory.py`
**涉及行号**：5~44

**问题**：

- `UserFact`、`Experience`、`Reflection` 均未实现 `to_dict()` 和 `from_dict()` 方法，而 `EmotionalState` 和 `PersonalityConfig` 均有。这种不一致导致调用方在需要序列化记忆对象时，必须直接使用 `dataclasses.asdict()` 或手动构造字典。
- `dataclasses.asdict()` 是递归的，如果未来 `UserFact` 中嵌入了复杂对象（如 `datetime`），会导致序列化失败。

**建议**：

- 为三个 Memory 模型统一增加 `to_dict()` 和 `from_dict()` 方法，处理日期格式、枚举值等转换逻辑。
- 或者，创建一个统一的 `SerializableDataclass` 基类，提供默认的 `to_dict()`/`from_dict()` 实现，并允许子类覆盖。

### 2.4 models/__init__.py

#### 2.4.1 完全为空，未导出公共符号

**文件路径**：`D:\桌面\编程作品\AI朋友\models\__init__.py`
**涉及行号**：1（空文件）

**问题**：

- `models/__init__.py` 是一个空文件（0 字节），没有导出任何符号。这意味着调用方必须写：
  ```python
  from models.personality import EmotionalState, PersonalityConfig
  from models.conversation import Turn, MemoryContext
  from models.memory import UserFact, Experience, Reflection
  ```
  而不是更简洁的：
  ```python
  from models import EmotionalState, PersonalityConfig, Turn, MemoryContext, UserFact, Experience, Reflection
  ```
- 空 `__init__.py` 也失去了对模块公共 API 的集中管控能力。如果未来某个模型类被重命名或移动，所有调用方都需要修改导入语句，而无法通过在 `__init__.py` 中设置别名来平滑迁移。

**建议**：

- 在 `models/__init__.py` 中显式导出所有公共符号：
  ```python
  from models.personality import Trait, EmotionalState, PersonalityConfig
  from models.conversation import Turn, MemoryContext
  from models.memory import UserFact, Experience, Reflection

  __all__ = [
      "Trait", "EmotionalState", "PersonalityConfig",
      "Turn", "MemoryContext",
      "UserFact", "Experience", "Reflection",
  ]
  ```

### 2.5 跨文件架构问题

#### 2.5.1 模型层与存储层的循环依赖风险

**文件路径**：多个文件

**分析**：

- `models/conversation.py` 第 5 行：`from models.memory import UserFact, Experience, Reflection`
- `memory/long_term.py` 第 5~7 行：`from models.memory import ...; from models.conversation import MemoryContext`
- `storage/repository.py` 第 7 行：`from models.memory import UserFact, Experience, Reflection`

当前依赖关系是健康的：模型层不依赖任何上层模块，存储层和记忆层依赖模型层。但需要警惕的是，如果未来在 `models/memory.py` 中引入 `from storage.repository import Repository`（例如为了在模型中增加验证方法），会立即形成循环依赖。

**建议**：

- 在 `models/` 目录的 README 或代码注释中明确声明"模型层不得依赖任何上层模块"的原则。
- 如果确实需要在模型中进行数据库相关的验证，应通过"依赖注入"或"服务层"模式实现，而不是直接在模型中导入 Repository。

#### 2.5.2 模型层与 Prompt 层的隐式契约

**文件路径**：`models/personality.py`、`prompts/system.py`

**分析**：

- `prompts/system.py` 第 280~295 行的 `emotion_desc` 字典和 `emotion_behavior` 字典（第 309~318 行）与 `models/personality.py` 中 `dominant_emotion` 返回的字符串值存在隐式契约。
- 如果 `dominant_emotion` 新增了一个情绪标签（如 "bored"），但 `prompts/system.py` 没有同步更新，`emotion_desc.get(emotion.dominant_emotion, "平静")` 会回退到 "平静"，导致 AI 的"内心情绪"与"外在表现"不一致。
- 这种契约是跨文件的、隐式的、没有编译期检查的。

**建议**：

- 在 `models/personality.py` 中定义 `DOMINANT_EMOTIONS: set[str]` 常量，包含所有可能的 dominant emotion 返回值。
- 在 `prompts/system.py` 的单元测试中，验证 `emotion_desc.keys()` 和 `emotion_behavior.keys()` 是否覆盖 `DOMINANT_EMOTIONS`。
- 或者，将 `emotion_desc` 和 `emotion_behavior` 的定义迁移到 `models/personality.py` 中，作为 `EmotionalState` 的类属性，使情绪标签、描述、行为建议三者集中管理。

#### 2.5.3 时间类型不一致

**文件路径**：多个文件

**分析**：

- `models/personality.py` 第 252 行：`"timestamp": time.time()`（float，Unix 时间戳）
- `models/conversation.py` 第 13 行：`timestamp: datetime = field(default_factory=datetime.now)`（datetime 对象）
- `models/memory.py` 第 14、31、44 行：`created_at: str = ""`、`updated_at: str = ""`、`created_at: str = ""`（字符串）
- `storage/repository.py` 第 222 行：`INSERT INTO conversation_turns ...` 使用 SQLite 的默认时间（未显式传入 timestamp）

项目中同时存在三种时间表示方式：`float`（Unix 时间戳）、`datetime`（Python 对象）、`str`（ISO 8601 或数据库返回的字符串）。这种不一致增加了序列化、比较、时区处理的复杂度。

**建议**：

- 统一使用 `datetime` 对象作为模型层的内部表示。
- 在序列化（`to_dict()`、数据库存储）时统一转换为 ISO 8601 字符串（`datetime.isoformat()`）。
- 在反序列化（`from_dict()`、数据库读取）时统一从字符串解析为 `datetime` 对象（`datetime.fromisoformat()`）。
- 特别注意时区问题：当前所有时间均为本地时间，没有时区信息。如果未来需要支持多用户或多地区部署，应引入 `datetime.timezone.utc`。

#### 2.5.4 浮点数精度与比较问题

**文件路径**：`models/personality.py`
**涉及行号**：多处

**分析**：

- `EmotionalState` 中大量使用 `float` 进行相等比较和阈值判断，例如：
  - 第 194 行：`if self.anger > 0.6:`
  - 第 234 行：`if self.resentment > 0.001:`
  - 第 122 行：`elif self.valence < -0.2 and k in positive_emotions:`
- 浮点数在多次运算后可能产生精度漂移。例如，如果 `self.resentment` 经过 100 次 decay 后从 0.5 衰减到 `0.0009999999999`，第 234 行的判断会失败， resentment 停止衰减，形成一个极小的"残余怨恨"。

**建议**：

- 对于"是否接近零"的判断，使用 epsilon 比较：
  ```python
  if self.resentment > 1e-9:
      self.resentment = max(0.0, self.resentment * (1.0 - RESENTMENT_DECAY))
  ```
- 或者，在 decay 后直接截断：`self.resentment = round(self.resentment, 6)`。

#### 2.5.5 默认值与运行时值的冲突

**文件路径**：`models/personality.py`
**涉及行号**：36~70

**分析**：

`EmotionalState` 的默认值如下：

```python
valence: float = 0.4
arousal: float = 0.3
baseline_valence: float = 0.4
baseline_arousal: float = 0.3
joy: float = 0.5
trust: float = 0.5
fear: float = 0.1
surprise: float = 0.2
sadness: float = 0.1
anticipation: float = 0.4
anger: float = 0.1
disgust: float = 0.1
```

但 `core/personality.py` 第 15~19 行在初始化时会覆盖 baseline：

```python
self.emotion = emotion or EmotionalState(
    baseline_valence=config.emotional_baseline.get("valence", 0.4),
    baseline_arousal=config.emotional_baseline.get("arousal", 0.3),
    decay_rate=config.emotional_decay_rate,
)
```

这意味着 `EmotionalState` 的默认值实际上只在两种场景下生效：
1. 独立测试（如 `tests/test_emotional_state.py` 中的 `_make_default_state()`）。
2. `from_dict()` 反序列化时缺少某些字段。

**问题**：

- 默认值与 `PersonalityConfig` 的默认值之间存在隐式同步关系。如果修改了 `PersonalityConfig.emotional_baseline`，但忘记修改 `EmotionalState` 的默认值，会导致测试与生产环境的行为不一致。
- `joy=0.5`、`trust=0.5` 等 primary emotion 的默认值与 `baseline_valence=0.4` 之间没有明确的数学关系。如果 baseline_valence 被配置为 0.8（非常乐观），joy 的初始值仍然是 0.5，这显得不合理。

**建议**：

- 在 `PersonalityConfig` 中增加 `primary_emotion_baselines: dict[str, float]` 配置项，允许用户自定义各情绪的基线。
- 或，在 `EmotionalState.__init__` 中根据 `baseline_valence` 自动推导 primary emotion 的初始值（如 `joy = 0.3 + baseline_valence * 0.4`）。
- 至少应在文档中说明默认值的设计依据。

---

## 3. 汇总统计

### 3.1 问题分类统计

| 类别 | 数量 | 说明 |
|------|------|------|
| **数据验证缺失** | 8 | 所有模型字段均无范围/类型/结构校验 |
| **序列化健壮性** | 6 | to_dict/from_dict 不完整、类型不一致、缺少版本控制 |
| **架构设计** | 5 | 职责耦合、隐式契约、循环依赖风险、时间类型不一致 |
| **可维护性** | 4 | 魔法数字、顺序依赖、缺少注释、空 __init__.py |
| **潜在运行时错误** | 3 | hasattr 安全隐患、浮点精度、默认值冲突 |

### 3.2 风险评级

| 风险项 | 评级 | 位置 | 说明 |
|--------|------|------|------|
| shift() 的 hasattr 校验 | **P0-严重** | `models/personality.py:188` | 可覆盖任意属性，包括方法，存在安全和稳定性风险 |
| emotion_events 类型松散 | **P1-高** | `models/personality.py:67` | list[dict] 无结构约束，易导致数据腐败 |
| 模型层无字段验证 | **P1-高** | 全部模型文件 | 脏数据可静默流入系统，引发级联错误 |
| dominant_emotion 阈值不对称 | **P2-中** | `models/personality.py:93~108` | 可能导致情绪判定偏差，影响 AI 表现 |
| _cross_modulate 顺序依赖 | **P2-中** | `models/personality.py:132~173` | 调试困难，行为不透明 |
| 时间类型不一致 | **P2-中** | 跨文件 | 增加序列化和比较复杂度 |
| __init__.py 为空 | **P3-低** | `models/__init__.py` | 影响导入便利性，无运行时风险 |
| Turn 缺少序列化方法 | **P3-低** | `models/conversation.py:8~14` | 当前未直接序列化，但未来扩展受限 |

### 3.3 测试覆盖评估

| 模型 | 测试文件 | 用例数 | 覆盖度 | 缺口 |
|------|----------|--------|--------|------|
| EmotionalState | `tests/test_emotional_state.py` | 38 | 中高 | 缺少 `_cross_modulate` 的极端值测试、`hasattr` 安全测试、浮点精度测试 |
| PersonalityConfig | `tests/test_personality_core.py` | 间接 | 低 | 缺少 `to_dict`/`from_dict` 的边界测试、traits 范围校验测试 |
| UserFact/Experience/Reflection | 无 | 0 | 无 | 完全缺少单元测试 |
| Turn/MemoryContext | 无 | 0 | 无 | 完全缺少单元测试 |

### 3.4 修复优先级建议

**第一优先级（立即修复）**：
1. 修复 `shift()` 中的 `hasattr` 安全隐患，改为白名单校验。
2. 为所有 `float` 字段增加范围校验（至少在校验路径上，如 `__post_init__`）。
3. 将 `emotion_events` 从 `list[dict]` 重构为 `list[EmotionEvent]`。

**第二优先级（近期修复）**：
4. 统一时间类型表示（全部使用 `datetime` + ISO 8601 序列化）。
5. 为 `models/__init__.py` 添加公共符号导出。
6. 为 `UserFact`、`Experience`、`Reflection` 增加 `to_dict()`/`from_dict()`。
7. 在 `dominant_emotion` 和 `_cross_modulate` 中添加详细注释，解释设计决策。

**第三优先级（长期优化）**：
8. 将 `EmotionalState` 中的行为方法（shift、decay、cross-modulate）抽取为独立的 `EmotionEngine` 策略类。
9. 引入模型序列化版本控制机制。
10. 为 `MemoryContext` 增加检索元数据字段。
11. 建立 `dominant_emotion` 返回值与 `prompts/system.py` 中情绪描述的自动化一致性检查。

---

## 4. 附录：关键代码引用

### A.1 EmotionalState.shift() 的安全隐患

```python
# models/personality.py:186~191
if primary_deltas:
    for key, delta in primary_deltas.items():
        if hasattr(self, key):          # <-- 安全隐患：可匹配任意属性
            current = getattr(self, key)
            new_val = current + delta * inertia_factor
            setattr(self, key, max(0.0, min(1.0, new_val)))
```

### A.2 PersonalityConfig traits 序列化不对称

```python
# models/personality.py:313~322
def to_dict(self) -> dict:
    d = asdict(self)
    d["traits"] = {t["name"]: t["value"] for t in d["traits"]}   # list -> dict
    return d

@classmethod
def from_dict(cls, d: dict) -> "PersonalityConfig":
    if "traits" in d and isinstance(d["traits"], dict):
        d["traits"] = [Trait(k, v) for k, v in d["traits"].items()]   # dict -> list
    return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})
```

### A.3 MemoryContext 的 relationship 默认值

```python
# models/conversation.py:22~24
relationship: dict[str, float] = field(default_factory=lambda: {
    "trust": 0.3, "familiarity": 0.3, "intimacy": 0.3, "playfulness": 0.3,
})
```

### A.4 Repository 中 Turn 的持久化缺失

```python
# storage/repository.py:218~226
async def insert_turn(self, turn_number: int, role: str, content: str,
                      emotional_state: Optional[str] = None) -> int:
    async with self.db.cursor() as c:
        await c.execute("""
            INSERT INTO conversation_turns (turn_number, role, content, emotional_state)
            VALUES (?, ?, ?, ?)
        """, (turn_number, role, content, emotional_state))
        return c.lastrowid
# 注意：Turn.timestamp 和 Turn.metadata 未被存储
```

---

*本报告基于对 `models/` 目录下全部源文件及其上下游调用关系的静态分析生成。建议结合动态测试（如压力测试、边界值测试）进一步验证发现的问题。*
