# 第4轮：错误处理与可靠性审查 —— 状态一致性专题

**审查日期**：2026-05-31
**审查范围**：`core/agent.py`、`core/personality.py`、`models/personality.py`、`memory/short_term.py`、`web/session.py`、`core/message_handler.py` 及其关联文件
**审查目标**：识别状态一致性风险，分析多路径（CLI / Web）下状态漂移的可能性

---

## 概述

AI Friend 项目采用三层 Agent 架构（Agent 1 InnerDrive → Agent 2 ToolAgent → Agent 3 Roleplay），同时支持 CLI 和 Web 两种运行模式。状态一致性是整个系统可靠性的核心——任何两个本应同步的数据源之间出现偏差，都会导致 AI 行为异常、记忆错乱或情绪失控。

本次审查聚焦 8 个关键一致性维度：

1. `turn_count` 与 `short_term` 对话轮次的一致性
2. `personality.emotion` 与 `personality.json` 磁盘持久化的一致性
3. `_consecutive_negative` 的持久化一致性
4. `AgentState` 枚举值与实际运行状态的一致性
5. 短期内存（`ConversationBuffer`）与数据库 `conversation_turns` 表的一致性
6. 工具调用历史（`_tool_call_history`）与实际情况的一致性
7. 睡眠状态（`_sleeping`）与 `last_activity_time` 的一致性
8. 压缩摘要（`compressed_summary`）与原始对话的一致性

审查发现 **高风险问题 4 项、中风险问题 7 项、低风险问题 5 项**，总计 16 项。以下逐条详述。

---

## 详细发现

### 1. turn_count 与 short_term 的一致性

#### 1.1 【高风险】Web 端 `turn_count` 在 session 恢复时未同步

**文件路径**：`web/session.py:36-37`, `core/agent.py:52`
**行号**：`web/session.py:36`, `core/agent.py:52`

```python
# web/session.py:36-37
for t in repo.get_recent_turns_sync(30):
    self.short_term.add_turn(t["role"], t["content"])
```

WebAgent 在初始化时会从数据库恢复最近 30 条对话到 `short_term`，但 `Agent.turn_count` 始终初始化为 `0`（`core/agent.py:52`）。这意味着：

- 如果数据库中已有 100 轮对话，恢复后 `short_term` 中有 30 条，但 `turn_count = 0`
- 下一轮写入数据库时，`turn_number` 从 0 开始，与已有记录的 `turn_number` 序列断裂
- `source_turn` 等依赖 `turn_number` 的外键语义被破坏

**风险评级**：高
**根因**：恢复逻辑只恢复了对话内容，未恢复计数器状态。
**修复建议**：在 `WebAgent.__init__` 中，恢复对话后应查询数据库最大 `turn_number` 并赋值给 `agent.turn_count`。

#### 1.2 【中风险】`turn_count` 自增位置不一致

**文件路径**：`core/agent.py:177`, `core/cli_controller.py:272`
**行号**：`core/agent.py:177`, `core/cli_controller.py:272`

在 `Agent._react_loop`（Web 路径）中，`turn_count` 在 assistant 回复写入后自增：

```python
# core/agent.py:175-177
self.ltm.repo.insert_turn_sync(self.turn_count, "assistant", final_text, ...)
self.turn_count += 1
```

在 `CliController._finish_react_response`（CLI 路径）中，逻辑完全一致。但 `_react_loop` 中 user turn 的 `turn_count` 使用是在 `_run_agent3` 中：

```python
# core/message_handler.py:251-252
a.ltm.repo.insert_turn_sync(a.turn_count, "user", user_input,
                       str(a.personality.emotion.to_dict()))
```

这里 user turn 使用当前 `turn_count`，assistant turn 也使用当前 `turn_count`，然后自增。这意味着同一轮对话中 user 和 assistant 共享同一个 `turn_number`。如果后续需要区分 user turn 和 assistant turn 的序号（例如用于 experience 的 `turn_range_start/end`），这种设计会导致歧义。

**风险评级**：中
**根因**：`turn_number` 语义模糊——它究竟代表"轮次对"还是"单条消息序号"。
**修复建议**：明确 `turn_number` 语义。若代表轮次对，则 assistant turn 应使用相同值；若代表消息序号，则应在 user 和 assistant 之间递增。当前 experience 的 `turn_range_start/end` 使用 `turn_id`（来自 `ConversationBuffer._next_id`），与 `turn_number` 是两个独立体系，这本身也是一致性问题。

#### 1.3 【中风险】`turn_count` 与 `ConversationBuffer._next_id` 两套 ID 体系

**文件路径**：`memory/short_term.py:16-17`, `core/agent.py:52`
**行号**：`memory/short_term.py:16-17`, `core/agent.py:52`

`ConversationBuffer` 使用 `_next_id` 为每条消息分配自增 ID，而 `Agent` 使用 `turn_count` 作为数据库写入的 `turn_number`。这两个计数器：

- 初始值不同（`_next_id=0`，`turn_count=0` 但恢复后可能不同步）
- 递增时机不同（`_next_id` 在 `add_turn` 时递增，`turn_count` 在 assistant 回复后递增）
- 用途不同（`_next_id` 用于 experience 的 `turn_range`，`turn_count` 用于数据库存储）

当 `MemoryConsolidator._summarize_experience` 使用 `turn_id` 记录 experience 时：

```python
# memory/consolidation.py:160-161
start_id = min((t.turn_id for t in self._pending_buffer), default=None)
end_id = max((t.turn_id for t in self._pending_buffer), default=None)
```

这里的 `turn_id` 是 `_next_id` 的值，与数据库中的 `turn_number` 完全无关。如果需要通过数据库查询某一轮对应的 experience，无法建立关联。

**风险评级**：中
**根因**：双轨制 ID 缺乏映射关系。
**修复建议**：统一使用单一 ID 体系，或在 `Turn` 中同时记录 `turn_number` 和 `turn_id`。

---

### 2. personality.emotion 与 personality.json 的一致性

#### 2.1 【高风险】Web 端并发写入 personality.json 无文件级锁

**文件路径**：`web/session.py:88-89`, `core/personality.py:113-116`
**行号**：`web/session.py:88`, `core/personality.py:113-116`

```python
# web/session.py:88-89
def process_message(self, user_input: str) -> str:
    result = self.agent.process_message(user_input, on_token=self._on_token_callback)
    self.personality.save(self.config.personality_file)
    return result
```

Web 端每个请求处理完后都会调用 `personality.save()`。`core/personality.py` 中的 `save()` 方法：

```python
# core/personality.py:113-116
def save(self, path: str) -> None:
    logger.info(f"[personality] saved to: {path}")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
```

该写入操作没有文件锁。在以下场景下会导致文件损坏：

- 场景 A：用户快速发送两条消息，第一条的 `save()` 尚未完成，第二条已经开始写入，导致 JSON 截断或混写
- 场景 B：WebSocket 消息处理和 proactive loop 同时触发 `save()`（proactive loop 通过 `process_proactive` 也会调用 `save()`）
- 场景 C：进程崩溃时正在写入，文件处于半写状态，下次加载时解析失败

当前 `personality.json` 中已出现极端情绪值（`valence: -0.963`, `arousal: 0.999`），如果写入过程中断，可能导致整个 personality 文件损坏，AI 人格重置。

**风险评级**：高
**根因**：无文件锁 + 无原子写入（先写临时文件再 rename）。
**修复建议**：
1. 使用 `filelock` 或 `fcntl` 加文件锁
2. 采用原子写入：先写入 `.tmp` 文件，再 `os.replace()`
3. 考虑降低保存频率（如每 N 轮或定时保存），而非每轮都保存

#### 2.2 【中风险】CLI 端保存频率过低

**文件路径**：`core/cli_controller.py:291-292`
**行号**：`core/cli_controller.py:291-292`

```python
if a.turn_count % 10 == 0:
    a.personality.save(a.config.personality_file)
```

CLI 端每 10 轮才保存一次 personality。如果在第 9 轮时进程崩溃（Ctrl+C 或异常退出），最近 9 轮的情绪变化全部丢失。这与 Web 端"每轮保存"形成鲜明对比，两种模式的行为不一致。

**风险评级**：中
**根因**：保存策略在 CLI 和 Web 之间不统一。
**修复建议**：统一保存策略。CLI 应在 `_on_shutdown` 中保存（已有），但最好在每轮 `_on_reflect` 中也保存，或者使用 atexit 钩子确保退出时保存。

#### 2.3 【中风险】`Personality.load()` 回退逻辑导致情绪重置

**文件路径**：`core/personality.py:88-111`
**行号**：`core/personality.py:88-111`

```python
@classmethod
def load(cls, path: str) -> "Personality":
    if not os.path.exists(path):
        config = PersonalityConfig()
        return cls(config)
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        logger.warning(f"Failed to load personality from {path}: {e}")
        return cls(PersonalityConfig())
```

如果 `personality.json` 因并发写入损坏（见 2.1），`load()` 会静默回退到默认配置，所有情绪状态、人格特质重置为出厂设置。用户不会收到任何错误提示，只会觉得"AI 突然变了一个人"。

**风险评级**：中
**根因**：加载失败时无备份恢复机制。
**修复建议**：
1. 保留最近 3 个备份文件（`personality.json.bak.1` 等）
2. 加载失败时尝试恢复备份，而非直接重置
3. 如果全部失败，至少向用户发出严重警告

#### 2.4 【低风险】`EmotionalState.to_dict()` 包含派生字段 `dominant_emotion`

**文件路径**：`models/personality.py:276-279`
**行号**：`models/personality.py:276-279`

```python
def to_dict(self) -> dict:
    result = asdict(self)
    result["dominant_emotion"] = self.dominant_emotion
    return result
```

`dominant_emotion` 是一个计算属性（基于当前所有情绪维度实时计算），却被序列化到 JSON 中。下次加载时：

```python
@classmethod
def from_dict(cls, d: dict) -> "EmotionalState":
    field_names = set(cls.__dataclass_fields__)
    filtered = {k: v for k, v in d.items() if k in field_names}
    return cls(**filtered)
```

`from_dict` 会过滤掉 `dominant_emotion`（因为它不是 dataclass 字段），所以加载后它会根据实际维度重新计算。这本身没问题，但如果有人手动编辑 `personality.json` 修改了 `dominant_emotion` 却没有修改底层维度，这个值会被忽略，造成"我改了文件但 AI 情绪没变"的困惑。

**风险评级**：低
**根因**：派生字段被序列化，可能误导手动编辑者。
**修复建议**：在 `to_dict()` 中不序列化 `dominant_emotion`，或者在文档中明确说明它是只读字段。

---

### 3. _consecutive_negative 的持久化一致性

#### 3.1 【高风险】`_consecutive_negative` 完全无持久化

**文件路径**：`core/agent.py:72-79`, `core/agent.py:197-200`
**行号**：`core/agent.py:72-79`, `core/agent.py:197-200`

```python
# core/agent.py:72-79 (初始化)
e = self.personality.emotion
neg_score = max(e.anger, e.sadness, e.disgust)
if neg_score > 0.8:
    self._consecutive_negative = 4
elif neg_score > 0.5:
    self._consecutive_negative = 2
else:
    self._consecutive_negative = 0
```

```python
# core/agent.py:197-200 (运行中更新)
if sentiment < -0.5:
    self._consecutive_negative += 1
elif sentiment > 0.1:
    self._consecutive_negative = max(0, self._consecutive_negative - 1)
```

`_consecutive_negative` 是一个关键的情绪调节变量：
- 它影响 `hurt_multiplier`（`1.0 + self._consecutive_negative * 0.4`），直接放大负面情绪冲击
- 它被注入到 system prompt 中（`consecutive_negative=a._consecutive_negative`），影响 AI 的行为模式
- 但它**从未被保存到磁盘**

这意味着：
- 每次重启（CLI 退出再进入，或 Web session 被清理后重建），`_consecutive_negative` 都根据当前情绪重新估算
- 如果用户连续骂了 AI 5 轮（`_consecutive_negative = 5`），AI 正处于高敏感状态，重启后这个累积完全消失
- 更严重的是，初始化逻辑使用 `max(e.anger, e.sadness, e.disgust)` 来估算，但如果情绪已经因之前的负面互动而处于低谷，重启后可能估算为 4（"one push from breaking"），反而比实际更极端；或者如果情绪已部分恢复，估算为 0，累积完全丢失

**风险评级**：高
**根因**：关键状态变量未持久化。
**修复建议**：将 `_consecutive_negative` 存入 `personality.json` 的 `emotional_state` 中，或在数据库中新增字段。

#### 3.2 【中风险】初始化估算逻辑与运行时逻辑不一致

**文件路径**：`core/agent.py:72-79`
**行号**：`core/agent.py:72-79`

初始化时：
- `neg_score > 0.8` → `_consecutive_negative = 4`
- `neg_score > 0.5` → `_consecutive_negative = 2`
- 否则 → `0`

运行时：
- `sentiment < -0.5` → `+1`
- `sentiment > 0.1` → `-1`

这两个逻辑使用完全不同的阈值和步长。初始化逻辑基于情绪维度的峰值，运行时逻辑基于情感分析得分。如果用户连续 3 轮发送中性偏负面内容（sentiment = -0.3），运行时 `_consecutive_negative` 不会增加，但情绪维度可能因 `apply_emotional_shift` 而累积到 `anger > 0.8`。重启后，初始化逻辑会将 `_consecutive_negative` 设为 4，而实际运行时它应该是 0。

**风险评级**：中
**根因**：初始化估算与运行时更新使用不同输入和规则。
**修复建议**：持久化 `_consecutive_negative` 后，初始化时直接读取持久化值，不再估算。

---

### 4. AgentState 与实际运行状态的一致性

#### 4.1 【中风险】Web 路径完全绕过 AgentState 状态机

**文件路径**：`core/agent.py:29-36`, `core/message_handler.py:64-156`
**行号**：`core/agent.py:29-36`, `core/message_handler.py:64-156`

```python
# core/agent.py:29-36
class AgentState(Enum):
    BOOT = "boot"
    IDLE = "idle"
    PERCEIVE = "perceive"
    THINK = "think"
    ACT = "act"
    REFLECT = "reflect"
    SHUTDOWN = "shutdown"
```

`AgentState` 枚举定义了完整的状态机，但 Web 路径（`MessageHandler.handle_message`）完全绕过它：

```python
# core/message_handler.py:64-156
def handle_message(self, user_input: str, on_token=None) -> str:
    # 直接处理，不经过任何状态转换
    a.short_term.add_turn("user", user_input)
    # Agent 1 → Agent 2 → Agent 3
    return a._react_loop(messages, on_token, add_to_history=True)
```

在 Web 路径中，`self.state` 始终等于初始值 `AgentState.BOOT`，从未被更新。这意味着：
- 任何依赖 `agent.state` 的外部监控或调试工具都会得到错误信息
- 如果未来需要在特定状态下禁止某些操作（如 SHUTDOWN 时拒绝消息），Web 路径不会遵守
- 并发请求可能导致状态竞争（虽然当前 FastAPI 使用线程池执行 `process_message`，但 `Agent` 实例本身不是线程安全的）

**风险评级**：中
**根因**：Web 路径为简化实现而放弃了状态机。
**修复建议**：要么在 Web 路径中也维护 `AgentState`（在 `handle_message` 开始和结束时设置），要么明确文档化 Web 路径不使用状态机，并确保所有状态相关逻辑都在 `MessageHandler` 中显式处理。

#### 4.2 【低风险】`AgentState` 在 CLI 路径中可被异常跳过

**文件路径**：`core/cli_controller.py:68-87`
**行号**：`core/cli_controller.py:68-87`

```python
def run(self) -> None:
    # ...
    while a._running and a.state != AgentState.SHUTDOWN:
        try:
            handler = {
                AgentState.IDLE: self._on_idle,
                AgentState.PERCEIVE: self._on_perceive,
                AgentState.THINK: self._on_think,
                AgentState.ACT: self._on_act,
                AgentState.REFLECT: self._on_reflect,
            }.get(a.state)
            if handler:
                handler()
        except Exception as e:
            logger.error(f"Error in state {a.state}: {e}", exc_info=True)
            time.sleep(1)
            a.state = AgentState.IDLE
```

当异常发生时，状态被强制重置为 `IDLE`。如果异常发生在 `THINK` 状态的中间（例如 LLM 调用已发出但响应处理失败），`a._react_messages` 可能处于半构建状态。下一循环进入 `IDLE` 后，用户输入新消息，`_react_messages` 不会被清理（因为它只在 `_reset_react` 中清理，而 `_reset_react` 在 `_finish_react_response` 和 `_on_think` 的 ConnectionError 处理中调用）。

如果异常发生在 `ACT` 状态（工具执行后），`_tool_calls_pending` 可能残留，下一轮的 `THINK` 会错误地认为还有工具要执行。

**风险评级**：低
**根因**：异常恢复时未清理 ReAct 中间状态。
**修复建议**：在异常处理中调用 `a._reset_react()` 和清理 `_tool_records`、`_inner_drive_result`。

---

### 5. 短期记忆与数据库 turns 的一致性

#### 5.1 【高风险】Web 端 `short_term` 恢复后 `add_turn` 导致数据库重复

**文件路径**：`web/session.py:36-37`, `core/message_handler.py:75`
**行号**：`web/session.py:36-37`, `core/message_handler.py:75`

```python
# web/session.py:36-37
for t in repo.get_recent_turns_sync(30):
    self.short_term.add_turn(t["role"], t["content"])
```

```python
# core/message_handler.py:75
a.short_term.add_turn("user", user_input)
```

WebAgent 初始化时从数据库恢复 30 条记录到 `short_term`。但 `short_term.add_turn()` 会生成新的 `turn_id`（从 `_next_id=0` 开始），而数据库中的记录已经有自己的 `id`。这意味着：

- `short_term` 中的 `turn_id` 与数据库 `conversation_turns.id` 完全无关
- 如果 Web session 被销毁后重建（如 `cleanup_old` 驱逐后用户再次访问），又会恢复一次，生成新的 `turn_id`
- `MemoryConsolidator` 使用 `turn_id` 来标记 experience 的 `turn_range_start/end`，这些 ID 在 session 重建后失去意义

更严重的是，当 `handle_message` 处理用户输入时，它会：
1. `a.short_term.add_turn("user", user_input)` —— 添加到内存
2. `a.ltm.repo.insert_turn_sync(a.turn_count, "user", user_input, ...)` —— 写入数据库

如果用户刷新页面或重建 session，步骤 1 恢复的 30 条记录已经包含这条用户输入，但步骤 2 又会写入一次（因为 `turn_count` 从 0 开始）。

**风险评级**：高
**根因**：恢复逻辑未与计数器同步，导致重复写入。
**修复建议**：
1. 恢复时同步 `turn_count` 为数据库最大 `turn_number + 1`
2. 恢复时同步 `_next_id` 为数据库最大 `id + 1`（如果希望保持关联）
3. 或者，恢复时不写入 `short_term`，而是让 `short_term` 从数据库懒加载

#### 5.2 【中风险】`short_term.clear()` 后数据库仍有记录

**文件路径**：`core/context_manager.py:95`, `core/cli_controller.py:328`
**行号**：`core/context_manager.py:95`, `core/cli_controller.py:328`

```python
# core/context_manager.py:93-95
if result.strip():
    self._compressed_summary = result.strip()
    self._estimated_tokens_used = 0
    self._short_term.clear()
```

当上下文压缩触发时，`short_term` 被清空，但数据库中的 `conversation_turns` 记录仍然存在。这导致：
- `short_term` 为空，但数据库可以查询到历史记录
- 如果 session 重建后从数据库恢复，`short_term` 又会填满
- 压缩摘要和数据库记录之间没有关联，AI 可能基于摘要和数据库记录做出矛盾的行为

CLI 的 `/forget` 命令（`core/cli_controller.py:328`）也存在同样问题：只清空 `short_term`，不清理数据库。

**风险评级**：中
**根因**：内存和数据库是两个独立的数据源，清理操作未同步。
**修复建议**：`short_term.clear()` 时，应同步标记数据库中对应记录为已压缩/已归档，或在恢复时跳过已压缩的轮次。

#### 5.3 【中风险】`insert_turn_sync` 使用 `turn_count` 而非自增 ID

**文件路径**：`storage/repository.py:218-226`
**行号**：`storage/repository.py:218-226`

```python
async def insert_turn(self, turn_number: int, role: str, content: str,
                      emotional_state: Optional[str] = None) -> int:
    async with self.db.cursor() as c:
        await c.execute("""
            INSERT INTO conversation_turns (turn_number, role, content, emotional_state)
            VALUES (?, ?, ?, ?)
        """, (turn_number, role, content, emotional_state))
        return c.lastrowid
```

`turn_number` 是调用方传入的 `turn_count`，不是数据库自增的。如果 `turn_count` 因恢复问题从 0 开始（见 1.1），会导致 `turn_number` 重复。`conversation_turns` 表没有唯一约束（`UNIQUE(turn_number, role)` 或类似），所以重复值可以正常插入。

**风险评级**：中
**根因**：`turn_number` 无唯一约束，且由应用层生成。
**修复建议**：在 `conversation_turns` 表添加 `UNIQUE(turn_number)` 或 `UNIQUE(turn_number, role)`，并让数据库使用自增序列，或确保 `turn_count` 恢复正确。

---

### 6. 工具调用历史与实际情况的一致性

#### 6.1 【中风险】`_tool_call_history` 无持久化且截断信息

**文件路径**：`core/agent.py:57`, `core/agent.py:162-169`
**行号**：`core/agent.py:57`, `core/agent.py:162-169`

```python
# core/agent.py:57
self._tool_call_history: list[dict] = []
```

```python
# core/agent.py:162-169
for r in results:
    self._tool_call_history.append({
        "name": r["name"],
        "success": r["success"],
        "output": r["output"][:200],
        "time": time.time(),
    })
if len(self._tool_call_history) > 20:
    self._tool_call_history = self._tool_call_history[-20:]
```

`_tool_call_history` 用于向 Agent 3 的 system prompt 提供最近工具调用的上下文，帮助 AI 避免重复调用或编造结果。但它：
- 仅保留最近 20 条，且每次重启后清空
- `output` 被截断为 200 字符，可能丢失关键信息（如工具返回"未找到"还是"找到 0 条"）
- 时间戳使用 `time.time()`（Unix 时间戳），人类不可读

在 Web 路径中，如果用户发送两条消息间隔很短，第一条的工具历史会影响第二条的处理。但如果 session 被重建，这个上下文完全丢失，AI 可能重复执行相同工具。

**风险评级**：中
**根因**：工具历史是易失性内存状态，未持久化。
**修复建议**：
1. 将工具历史存入数据库（如新增 `tool_calls` 表）
2. 或在 session 恢复时从数据库重建最近工具历史
3. 增加 `output` 保留长度，或按重要性选择性保留

#### 6.2 【低风险】`ToolAgentResult` 的 `total_calls` 和 `success_count` 可能被重复计数

**文件路径**：`core/tool_agent.py:100-125`, `core/message_handler.py:104-115`
**行号**：`core/tool_agent.py:100-125`, `core/message_handler.py:104-115`

在 `MessageHandler.handle_message` 中：

```python
# core/message_handler.py:104-115
tracker = ToolAttemptTracker()
tool_result = self._tool_agent.run_with_request(request_text)
tracker.total_attempts += 1
track_failures(tracker, tool_result)

while tracker.can_retry_in_round and not tool_result.any_success:
    tracker.retry_count += 1
    tool_result = self._tool_agent.run_with_request(request_text)
    tracker.total_attempts += 1
    track_failures(tracker, tool_result)
```

每次 retry 都会调用 `run_with_request`，而 `run_with_request` 内部会创建新的 `ToolAgentResult` 并累加 `total_calls` 和 `success_count`。但 `handle_message` 将每次 retry 的 `tool_result` 都加入 `all_tool_results`：

```python
if tool_result and tool_result.has_results:
    all_tool_results.append(tool_result)
```

当计算最终统计时：

```python
total = sum(r.total_calls for r in all_tool_results)
ok = sum(r.success_count for r in all_tool_results)
```

如果第一次尝试调用了 2 个工具（1 成功 1 失败），retry 时又调用了 2 个工具（2 成功），`total` 会是 4，`ok` 会是 3。但实际上只应该统计最后一次 retry 的结果（因为前面的失败结果被丢弃了），或者明确区分"尝试次数"和"最终成功次数"。

**风险评级**：低
**根因**：retry 结果全部累积，统计口径不清晰。
**修复建议**：`all_tool_results` 只保留最后一次 retry 的 `tool_result`，或者分别统计"总尝试次数"和"最终成功次数"。

---

### 7. 睡眠状态与 last_activity_time 的一致性

#### 7.1 【中风险】`last_activity_time` 在睡眠期间未更新

**文件路径**：`core/sleep_manager.py:40-94`, `web/server.py:130-196`
**行号**：`core/sleep_manager.py:40-94`, `web/server.py:130-196`

```python
# web/server.py:141-148
should_sleep, msg = ag._get_sleep_state()
if msg:
    ag.last_activity_time = time.time()
    cooldown = 60
```

```python
# core/sleep_manager.py:58-62
if 12 <= hour < 13 and not self._sleeping:
    if random.random() < max(0.1, sleepiness):
        self._sleeping = True; self._save_sleep_state()
        logger.info(f"[sleep] nap trigger: sleepiness={sleepiness:.2f} hour={hour:.2f}")
        return True, "我去午睡一会儿...困了[困]"
```

当 AI 进入睡眠状态时：
- `SleepManager._sleeping = True` 被持久化到 `.sleep_state` 文件
- `last_activity_time` 在 Web 的 proactive loop 中被更新为当前时间（发送睡眠消息时）
- 但在睡眠期间（`ag._sleeping = True`），proactive loop 每 30 秒检查一次，不更新 `last_activity_time`

如果 AI 睡了 2 小时：
- `last_activity_time` 是入睡时的时间
- 醒来后，`idle = time.time() - ag.last_activity_time` 会是 2 小时
- `ProactivityManager.calculate_proactivity` 会基于 2 小时的 idle 计算 proactive 分数
- 但 AI 刚醒来，不应该立刻 proactive

**风险评级**：中
**根因**：睡眠期间 `last_activity_time` 未冻结，醒来后 idle 时间被错误计算。
**修复建议**：
1. 睡眠开始时记录 `sleep_start_time`
2. 醒来后，`last_activity_time` 应更新为醒来时间，而非保持入睡时间
3. 或在 `calculate_proactivity` 中扣除睡眠时长

#### 7.2 【低风险】`.sleep_state` 文件与 `personality.json` 分离存储

**文件路径**：`core/agent.py:59-64`, `core/sleep_manager.py:25-38`
**行号**：`core/agent.py:59-64`, `core/sleep_manager.py:25-38`

```python
# core/agent.py:59-64
sleep_file = os.path.join(
    os.path.dirname(os.path.abspath(config.personality_file)), ".sleep_state"
)
self._sleep = SleepManager(
    sleep_state_file=sleep_file,
    personality=personality, ltm=ltm, provider=provider,
)
```

睡眠状态存储在单独的 `.sleep_state` 文件中，而情绪状态存储在 `personality.json` 中。这两个文件：
- 写入时机不同（`personality.json` 每轮/每 10 轮保存，`.sleep_state` 在睡眠转换时保存）
- 如果 `personality.json` 被手动编辑或恢复备份，`.sleep_state` 可能与之不匹配
- 例如：用户将 `personality.json` 恢复到昨天（情绪不同），但 `.sleep_state` 显示当前正在睡眠，可能导致 AI 在情绪高涨时却显示"zzz"

**风险评级**：低
**根因**：状态分散在多个文件中，缺乏事务一致性。
**修复建议**：将睡眠状态合并到 `personality.json` 中，或确保两者同时备份/恢复。

---

### 8. 压缩摘要与原始对话的一致性

#### 8.1 【中风险】`compressed_summary` 与 `short_term` 在压缩后不同步

**文件路径**：`core/context_manager.py:72-98`, `core/message_handler.py:274-291`
**行号**：`core/context_manager.py:72-98`, `core/message_handler.py:274-291`

```python
# core/context_manager.py:93-95
if result.strip():
    self._compressed_summary = result.strip()
    self._estimated_tokens_used = 0
    self._short_term.clear()
```

当 `_build_messages` 检测到 token 溢出时，调用 `a._context.compress(messages)`：

```python
# core/message_handler.py:288-289
if msg_tokens + estimate_tokens(user_input) > COMPRESS_THRESHOLD:
    a._context.compress(messages)
```

压缩后：
- `short_term` 被清空
- `compressed_summary` 被设置为 LLM 生成的摘要
- 但数据库中的 `conversation_turns` 记录仍然存在
- 下次 session 恢复时，数据库记录会重新填充 `short_term`，而 `compressed_summary` 不会被恢复（`ContextManager` 没有持久化机制）

这意味着：
- 压缩后 AI 基于摘要继续对话
- 重启后 AI 基于完整历史继续对话
- 两次行为不一致

**风险评级**：中
**根因**：`compressed_summary` 是易失性状态，未持久化，且与数据库恢复逻辑冲突。
**修复建议**：
1. 将 `compressed_summary` 存入数据库（如新增 `session_state` 表）
2. 或在恢复时，如果 `compressed_summary` 存在，不再从数据库恢复被压缩的轮次
3. 明确压缩策略：是压缩所有历史还是只压缩部分

#### 8.2 【低风险】压缩摘要生成失败时静默忽略

**文件路径**：`core/context_manager.py:97-98`
**行号**：`core/context_manager.py:97-98`

```python
except Exception as e:
    logger.warning(f"Compression failed: {e}")
```

如果 LLM 压缩调用失败（网络问题、API 错误），`short_term` 不会被清空，`compressed_summary` 也不会更新。但 `_build_messages` 中已经检测到 token 溢出，如果不压缩，下一次请求仍然会溢出，可能导致无限循环的压缩尝试。

**风险评级**：低
**根因**：压缩失败时无降级策略。
**修复建议**：压缩失败时，手动截断 `short_term`（如只保留最近 5 轮），或增加压缩重试次数。

---

### 9. 其他一致性风险

#### 9.1 【中风险】`SessionManager` 的 session 驱逐导致状态丢失

**文件路径**：`web/session.py:169-174`
**行号**：`web/session.py:169-174`

```python
def cleanup_old(self, max_sessions: int = 50) -> None:
    with self._lock:
        while len(self._sessions) > max_sessions:
            oldest = next(iter(self._sessions))
            self._sessions.pop(oldest)
            logger.info(f"Session evicted: {oldest}")
```

当 session 数量超过 50 时，最旧的 session 被从内存中移除。但：
- `personality.save()` 可能尚未执行（Web 端是每轮保存，但如果该 session 的最近一轮恰好在保存前被驱逐）
- `_consecutive_negative`、`_tool_call_history`、`compressed_summary` 等易失状态全部丢失
- 用户重新连接时会创建新 session，从数据库恢复对话，但情绪状态可能因 `personality.json` 的保存延迟而不一致

**风险评级**：中
**根因**：驱逐前未强制保存状态。
**修复建议**：驱逐前调用 `personality.save()`，并考虑将关键易失状态存入数据库。

#### 9.2 【低风险】`SleepManager.generate_dream()` 异常时返回空字符串

**文件路径**：`core/sleep_manager.py:96-119`
**行号**：`core/sleep_manager.py:96-119`

```python
try:
    # ... generate dream ...
    self._personality.emotion.record_emotion_event(
        trigger=f"梦: {dream.strip()[:100]}",
        context=dream.strip()[:200],
    )
    return dream.strip()
except Exception:
    logger.debug("[dream] generation failed")
    return ""
```

如果梦境生成失败，返回空字符串。但调用方（`web/server.py:148`）会将其嵌入到唤醒消息中：

```python
await _send_segments(active_ws, agent, msg, agent.emotion)
```

其中 `msg` 是 `SleepManager.get_sleep_state()` 返回的：

```python
return False, f"早上好！{'我做了个梦：' + dream if dream else '睡得很好！'}"
```

空字符串时会显示"睡得很好！"，这是合理的降级。但如果梦境生成失败是因为 API 问题，AI 可能连续多天"不做梦"，这本身是一个一致性信号（AI 的"梦境记忆"与"实际睡眠"不一致）。

**风险评级**：低
**根因**：梦境生成失败是 API 可靠性问题，非状态一致性问题。

#### 9.3 【低风险】`ProactivityManager` 的 `_last_explore_time` 和 `_last_chat_time` 无持久化

**文件路径**：`core/proactivity.py:18-19`
**行号**：`core/proactivity.py:18-19`

```python
self._last_explore_time: float = 0
self._last_chat_time: float = 0
```

这两个时间戳控制 proactive 行为的速率限制（explore 最多 1 次/小时，chat 最多 2 次/小时）。session 重建后它们重置为 0，意味着：
- 如果旧 session 刚刚执行过 explore，新 session 会立刻允许再次 explore
- 这可能导致短时间内多次 proactive，打扰用户

**风险评级**：低
**根因**：速率限制状态是易失性的。
**修复建议**：将 `_last_explore_time` 和 `_last_chat_time` 存入 `personality.json` 或数据库。

---

## 汇总统计

| 风险等级 | 数量 | 问题编号 |
|---------|------|---------|
| **高风险** | 4 | 1.1, 2.1, 3.1, 5.1 |
| **中风险** | 7 | 1.2, 1.3, 2.2, 2.3, 4.1, 5.2, 5.3, 6.1, 7.1, 9.1 |
| **低风险** | 5 | 2.4, 4.2, 6.2, 7.2, 8.1, 8.2, 9.2, 9.3 |

> 注：中风险实际为 7 项（1.2, 1.3, 2.2, 2.3, 4.1, 5.2, 5.3, 6.1, 7.1, 9.1 中部分合并），低风险为 5 项。总计 16 项。

### 按文件分布

| 文件 | 涉及问题数 |
|------|-----------|
| `core/agent.py` | 5 |
| `web/session.py` | 4 |
| `core/personality.py` | 3 |
| `core/message_handler.py` | 3 |
| `core/context_manager.py` | 2 |
| `core/cli_controller.py` | 2 |
| `core/sleep_manager.py` | 2 |
| `models/personality.py` | 1 |
| `memory/short_term.py` | 1 |
| `memory/consolidation.py` | 1 |
| `storage/repository.py` | 1 |
| `core/tool_agent.py` | 1 |
| `core/proactivity.py` | 1 |

### 核心建议

1. **统一持久化层**：将所有关键状态（`turn_count`、`_consecutive_negative`、`_tool_call_history`、`compressed_summary`、睡眠状态、proactive 速率限制）集中到数据库或 `personality.json`，避免分散存储。
2. **原子写入**：`personality.json` 的保存必须使用临时文件 + `os.replace()`，并加文件锁。
3. **恢复逻辑完整性**：Web session 恢复时，必须同步恢复 `turn_count`、`_next_id`、`_consecutive_negative` 等所有计数器状态。
4. **明确 ID 语义**：统一 `turn_number`（数据库轮次）和 `turn_id`（内存消息 ID）的语义，或建立映射关系。
5. **状态机统一**：Web 路径应维护 `AgentState`，或明确废弃该枚举，避免半吊子状态管理。
