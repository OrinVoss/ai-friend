# AI Friend 三层 Agent 架构深度代码审查报告

**审查日期**: 2026-05-31  
**审查范围**: core/agent.py, core/inner_drive.py, core/tool_agent.py, core/message_handler.py, core/dispatcher.py 及关联模块  
**审查人**: Claude Code (Sonnet 4.6)  
**项目路径**: `D:\桌面\编程作品\AI朋友`

---

## 1. 概述

AI Friend 项目采用三层 Agent 架构：

```
Agent 1 (InnerDrive)  →  Agent 2 (ToolAgent)  →  Agent 3 (Roleplay/ReAct)
   内驱推理+决策            外部工具执行+重试           情感表达+最终回复
```

本次审查覆盖 5 个核心文件，总计约 1100 行代码，同时涉及 `core/cli_controller.py`、`core/context_manager.py`、`core/provider.py`、`tools/traits.py`、`memory/` 等关联模块。审查发现该架构在概念设计上较为清晰，但在实现层面存在大量职责模糊、循环控制漏洞、错误处理缺失、重复代码和隐式耦合问题。整体风险评级为 **中高风险**，其中数据流断裂、无限循环隐患和状态管理混乱是最突出的三大问题。

---

## 2. 详细发现

### 2.1 Agent 1/2/3 职责分离 — 概念清晰，实现模糊

#### 2.1.1 Agent 1 (InnerDriveAgent) 的职责边界

**文件**: `core/inner_drive.py`

Agent 1 的设计目标是"自主推理 + 记忆检索 + 缺口决策"，输出自然语言工具请求给 Agent 2。其 `assess()` 方法（第61-111行）确实遵循了这一设计：

- 构建 prompt → 调用 LLM → `parse_tool_calls()` 解析内部工具(recall/remember) → 执行内部工具 → 再次调用 LLM 获取决策
- 当没有工具调用时，调用 `_parse_decision()` 返回 `InnerDriveResult`

**问题**: Agent 1 在 `assess()` 中直接调用了 `execute_tool_calls()`（第99行），而 `execute_tool_calls()` 位于 `core/dispatcher.py`，是一个通用执行器，不区分内部/外部工具。这意味着 Agent 1 的 ReAct 循环中如果 LLM 错误地输出了外部工具（如 `web_fetch`），`execute_tool_calls()` 会直接执行它，绕过 Agent 2 的 retry 机制和结果格式化。

**行号引用**:
```python
# core/inner_drive.py:64
from core.dispatcher import parse_tool_calls, execute_tool_calls
# core/inner_drive.py:99
results = execute_tool_calls(self._full_registry, calls)
```

这里传入的是 `self._full_registry`，包含所有工具。虽然 prompt 会引导 LLM 只调用 recall/remember，但没有任何运行时防护。建议将 Agent 1 的内部工具循环限制在只含 recall/remember 的 registry 上。

#### 2.1.2 Agent 2 (ToolAgent) 的职责边界

**文件**: `core/tool_agent.py`

Agent 2 的设计目标是"纯工具调用，无情感、无记忆"。`run()` 方法（第82-140行）和 `run_with_request()` 方法（第142-224行）确实没有注入 personality 或 emotion。

**问题 1**: `run_with_request()` 的 retry 逻辑存在严重缺陷。它声称"Retries up to max_retries times within a single round"，但实际实现中：

```python
# core/tool_agent.py:169-214
for attempt in range(1, max_retries + 1):
    ...
    resp = self._provider.generate(...)
    cleaned, calls = parse_tool_calls(resp)
    if not calls:
        continue  # 直接进入下一次 retry，但没有记录失败原因到 last_failure
    ...
    if result.any_success:
        break
    last_failure = "..."
```

当 `parse_tool_calls` 返回空 calls 时，`last_failure` 不会被设置，retry 消息中的 `之前的尝试失败了（{last_failure}）` 将显示 `None` 或上一次非空调用的失败信息，造成误导。

**问题 2**: `ToolCallRecord.arguments` 永远为空字典。`execute_tool_calls` 返回的 `results` 中没有保留原始 arguments，导致 Agent 3 无法知道工具具体使用了什么参数。

```python
# core/tool_agent.py:116-120
record = ToolCallRecord(
    name=r["name"],
    arguments={},  # 永远是空！
    success=r["success"],
    output=r["output"][:3000],
)
```

#### 2.1.3 Agent 3 (Roleplay/ReAct) 的职责边界

**文件**: `core/agent.py`

Agent 3 通过 `_react_loop()` 方法（第119-181行）实现，这是一个 ReAct 循环：LLM 生成 → 解析工具调用 → 执行 → 将结果注入 messages → 再次生成。

**问题**: Agent 3 的 ReAct 循环与 Agent 1 的 ReAct 循环在概念上是同构的，但实现上完全独立。Agent 1 的循环在 `inner_drive.py` 中，Agent 3 的循环在 `agent.py` 中，两者都调用 `parse_tool_calls` 和 `execute_tool_calls`，但错误处理、日志记录、状态管理各不相同。这是典型的"重复实现"反模式。

更关键的是，Agent 3 的 `_react_loop()` 被 `MessageHandler._run_agent3()` 调用时，传入的 `tool_registry` 是 `phase2_registry`（只含 recall/remember），这意味着 Agent 3 在表达阶段只能调用内部记忆工具，不能调用外部工具。这与 CLI 路径（`cli_controller.py`）不一致——CLI 路径中 Agent 3 在 `_on_act()` 阶段可以调用外部工具（通过 `a._tool_registry`），只是在 Phase 1 已运行外部工具时会限制为内部工具。

**行号引用**:
```python
# core/message_handler.py:270
phase2_registry = self._make_internal_registry() if tool_records else None
# core/message_handler.py:271-272
return a._react_loop(messages, on_token, add_to_history=True,
                    tool_registry=phase2_registry)
```

这种不一致意味着 Web 路径和 CLI 路径的 Agent 3 行为不同：Web 路径的 Agent 3 永远无法在表达阶段调用 web_fetch 等外部工具，而 CLI 路径可以（如果 Agent 1 没有请求外部工具的话）。

---

### 2.2 数据流检查 — Agent 1 决策 → Agent 2 执行 → Agent 3 表达

#### 2.2.1 正常路径数据流

**文件**: `core/message_handler.py:64-156`

`handle_message()` 方法实现了三层 Agent 的编排：

1. Agent 1 `assess()` 返回 `drive_result`
2. 若 `needs_external_tools` 为 True，进入 Agent 2 多轮循环
3. Agent 2 `run_with_request()` 执行工具
4. Agent 1 `review()` 或 `re_decide()` 审查结果
5. 最终进入 Agent 3 `_run_agent3()`

**问题 1**: Agent 2 的结果在传递给 Agent 3 时，`tool_result` 参数是最后一轮的 `tool_result`，而不是所有轮次的 `all_tool_results`。虽然 `tool_records` 是合并后的，但 `_run_agent3()` 的签名接收的是单个 `tool_result`：

```python
# core/message_handler.py:156
return self._run_agent3(user_input, drive_result, tool_result, on_token=on_token)
```

而 `_run_agent3()` 中：
```python
# core/message_handler.py:255
tool_records = self._tool_agent.format_for_phase2(tool_result) if tool_result else ""
```

这里 `tool_result` 是最后一轮的 Agent 2 结果，不是 `all_tool_results`。虽然 `tool_records` 在前面已经合并构建（第144-149行），但 `_run_agent3()` 又重新从 `tool_result` 格式化，这会导致：
- 如果最后一轮 `tool_result` 为空或失败，但前面轮次有成功结果，`tool_records` 会错误地显示为空
- `all_tool_results` 的合并结果在 `_run_agent3()` 中被忽略

**行号引用**: `core/message_handler.py:143-156`

**问题 2**: Agent 1 的 `review()` 和 `re_decide()` 方法内部也执行了内部工具调用（recall/remember），但这些调用的结果不会被传递给 Agent 3。Agent 1 在 review 过程中获取的新记忆对 Agent 3 是不可见的，因为 Agent 3 的 prompt 使用的是 `a.retriever.retrieve_for_query(user_input)` 重新检索的记忆，而不是 Agent 1 review 时的上下文。

**行号引用**:
```python
# core/message_handler.py:127-130
drive_result = self._inner_drive.review(
    user_input, combined_records,
    round_num=round_num, max_rounds=MAX_AGENT2_ROUNDS,
)
# core/message_handler.py:249
mem_ctx = a.retriever.retrieve_for_query(user_input)  # 重新检索，不是 Agent 1 review 时的上下文
```

#### 2.2.2 CLI 路径的数据流

**文件**: `core/cli_controller.py`

CLI 路径使用状态机（BOOT → IDLE → PERCEIVE → THINK → ACT → REFLECT），与 Web 路径的 `MessageHandler` 完全不同。

**问题**: CLI 路径中 Agent 1 的决策结果 `_inner_drive_result` 在 `_on_think()` 中直接使用，但 Agent 2 只执行一轮（没有 Agent 1 review 的多轮循环）。这意味着 CLI 路径缺少 Web 路径中的"Agent 1 审查 → 多轮 Agent 2"机制，两层路径的功能不一致。

**行号引用**:
```python
# core/cli_controller.py:148-157
if drive_result and drive_result.needs_external_tools and not is_proactive:
    self._ensure_tool_agent()
    tool_result = self._tool_agent.run_with_request(
        drive_result.tool_requests[0].description
        if drive_result.tool_requests else user_message
    )
    if tool_result.has_results:
        self._tool_records = self._tool_agent.format_for_phase2(tool_result)
```

没有 `while` 循环，没有 `review()` 或 `re_decide()`。

---

### 2.3 状态管理与循环控制

#### 2.3.1 无限循环风险

**文件**: `core/agent.py:127`

`_react_loop()` 使用 `for _idx in range(self._max_tool_iterations)`（默认10次），但循环内部没有检查 `_idx` 是否达到上限后的退出逻辑——循环正常结束时会执行 `final_text = ""`，然后进入后续处理。这本身没问题，但：

**问题**: 如果 LLM 每次都输出工具调用，但工具执行总是失败，循环会耗尽 10 次迭代，最终 `final_text` 为空字符串。此时：

```python
# core/agent.py:172-181
if final_text:
    if add_to_history:
        self.short_term.add_turn("assistant", final_text)
    ...
if not skip_post_process:
    self._process_emotion()
return final_text
```

`final_text` 为空时，不会添加到短期记忆，不会增加 `turn_count`，但 `_process_emotion()` 仍然会被调用。`_process_emotion()` 会尝试分析最后一条用户消息的情绪，这是合理的。但用户会收到空回复，体验很差。

更严重的是，CLI 路径中的 `_on_act()`（`core/cli_controller.py:238-261`）有额外的检查：

```python
if a._react_iteration > a._max_tool_iterations:
    if a.ui:
        a.ui.display.print_system("工具调用次数已达上限")
    self._finish_react_response()
    return
```

但 `_max_tool_iterations` 在 `Agent.__init__()` 中定义为 10，而 `_react_iteration` 在 `_on_think()` 中递增。问题在于 `_on_think()` 和 `_on_act()` 的交互：`_react_iteration` 在 `_on_think()` 中递增（第233行），在 `_on_act()` 中检查（第243行）。如果 `_react_iteration` 在 `_on_think()` 中已经达到 10，然后进入 `_on_act()` 发现工具调用，会触发上限检查。但 `_react_iteration` 从 0 开始，第一次 `_on_think()` 后变为 1，第一次 `_on_act()` 检查 `1 > 10` 为 False。第 10 次 `_on_think()` 后变为 10，第 10 次 `_on_act()` 检查 `10 > 10` 仍为 False。只有第 11 次才会触发。这意味着实际上允许了 11 次迭代，而不是 10 次。

#### 2.3.2 Agent 1 的 max_iterations 与 Agent 3 的 max_tool_iterations 混淆

Agent 1 (`inner_drive.py`) 和 Agent 3 (`agent.py`) 都有 `max_iterations` 参数，但含义不同：
- Agent 1: `max_iterations=5` 是 ReAct 内部工具循环的最大次数
- Agent 3: `_max_tool_iterations=10` 是 ReAct 表达阶段工具循环的最大次数

两者没有关联，但命名相似，容易混淆。更关键的是，Agent 1 的 `assess()` 在达到 `max_iterations` 后返回默认的 `InnerDriveResult(needs_external_tools=False)`，这个默认行为是静默的，可能导致应该调用工具的情况被忽略。

**行号引用**:
```python
# core/inner_drive.py:105-111
logger.warning("[inner_drive] max iterations, defaulting to no tools")
return InnerDriveResult(
    needs_external_tools=False,
    reasoning="达到最大迭代次数，默认不需要外部工具",
    summary="",
)
```

#### 2.3.3 ToolAttemptTracker 的状态管理缺陷

**文件**: `core/tool_agent.py:48-67`

```python
@dataclass
class ToolAttemptTracker:
    round_number: int = 0
    retry_count: int = 0
    total_attempts: int = 0
    failure_log: list[dict] = field(default_factory=list)

    @property
    def can_retry_in_round(self) -> bool:
        return self.retry_count < 3

    @property
    def can_start_new_round(self) -> bool:
        return self.round_number < 3 and self.total_attempts < 9

    @property
    def is_exhausted(self) -> bool:
        return self.total_attempts >= 9
```

**问题 1**: `round_number` 在 `MessageHandler` 中从未被递增。`handle_message()` 中的 `round_num` 是局部变量，与 `ToolAttemptTracker.round_number` 无关。`tracker.round_number` 永远是 0，所以 `can_start_new_round` 永远返回 `total_attempts < 9`。

**问题 2**: `MessageHandler.handle_message()` 中创建了新的 `ToolAttemptTracker` 每个 Agent 2 round，而不是跨 round 共享：

```python
# core/message_handler.py:104
tracker = ToolAttemptTracker()
```

这意味着"3 rounds x 3 retries = max 9 attempts"的设计意图完全没有实现。每个 round 都有独立的 tracker，每个 tracker 的 retry_count 独立计算。

**问题 3**: `can_start_new_round` 检查 `round_number < 3`，但 `MessageHandler` 中的 `MAX_AGENT2_ROUNDS = 3`，round 编号从 1 开始。如果 tracker 的 round_number 被正确设置，第 3 个 round 时 `round_number < 3` 为 False，无法开始新 round。但如前所述，round_number 永远是 0，所以这个检查实际上无效。

---

### 2.4 错误处理与重试机制

#### 2.4.1 Provider 层的重试

**文件**: `core/provider.py:57-80`

`KimiProvider.generate()` 实现了 3 次重试，退避策略为 `2^attempt` 秒。处理了 `ConnectionError`、`HTTPError`（5xx 才重试）、`ChunkedEncodingError`、`StreamConsumedError`。

**问题**: 没有处理 `ReadTimeout` 或 `ConnectTimeout`。如果 API 响应极慢，`requests` 会抛出 `requests.exceptions.ReadTimeout`，这不在捕获列表中，会直接向上传播，导致整个对话中断。

**问题**: `HTTPError` 处理中，如果状态码 >= 500 会重试，但如果 API 返回 429 (Too Many Requests) 或 503 (Service Unavailable) 且带有 `Retry-After` 头，当前实现忽略了这个头，使用固定的指数退避。

#### 2.4.2 Agent 2 层的重试

**文件**: `core/tool_agent.py:142-224`

`run_with_request()` 实现了 max_retries 次重试，但如前所述，当 `parse_tool_calls` 返回空时，`last_failure` 不会被更新，导致 retry prompt 信息不准确。

更严重的问题是：Agent 2 的 retry 只针对"工具调用解析失败"或"工具执行失败"，但不处理 Provider 调用本身的异常。如果 `self._provider.generate()` 抛出异常（如 `ConnectionError`），整个 `run_with_request()` 会崩溃，异常向上传播到 `MessageHandler.handle_message()`，但 `handle_message()` 没有 try-except 包裹 Agent 2 调用：

```python
# core/message_handler.py:105
tool_result = self._tool_agent.run_with_request(request_text)
```

这行代码没有 try-except，如果 Provider 异常，整个消息处理会崩溃。

#### 2.4.3 Agent 1 层的重试

**文件**: `core/inner_drive.py:217-264`

`re_decide()` 方法在 Agent 2 全部失败后调用，但同样没有 try-except 包裹 Provider 调用。

#### 2.4.4 工具执行层的错误处理

**文件**: `core/dispatcher.py:109-150`

`execute_tool_calls()` 对每个工具的执行包裹了 try-except：

```python
import asyncio
try:
    import inspect
    if inspect.iscoroutinefunction(tool.execute):
        result: ToolResult = asyncio.run(tool.execute(args))
    else:
        result: ToolResult = tool.execute(args)
    ...
except Exception as e:
    logger.error(f"Tool {name} execution error: {e}")
    results.append({...})
```

**严重问题**: 在循环内部调用 `asyncio.run()`。如果 `execute_tool_calls` 本身已经在异步上下文中被调用（虽然当前没有这种情况），`asyncio.run()` 会抛出 `RuntimeError: asyncio.run() cannot be called from a running event loop`。更关键的是，`asyncio.run()` 会创建和销毁事件循环，这在循环中多次调用是昂贵的，且在某些环境下（如 Jupyter、某些 Web 框架）会失败。

**问题**: `import asyncio` 和 `import inspect` 放在函数内部循环中，虽然 Python 的 import 有缓存，但代码风格极差，应该移到模块顶部。

---

### 2.5 parse_tool_calls 的三层解析逻辑

**文件**: `core/dispatcher.py:16-79`

三层解析逻辑设计如下：
1. Tier 1: Structured JSON with "calls" array
2. Tier 2: Legacy XML `<tool_call>` tags
3. Tier 3: Bare JSON object fallback

#### 2.5.1 Tier 1 的问题

`_try_structured_json()`（第82-106行）检查 `obj.get("calls")` 是否为 list。但 `ToolRegistry.to_json_schema()` 返回的是 `{"type": "json_object"}`，没有定义具体的 schema 结构。这意味着 LLM 可能输出任意 JSON，不一定包含 "calls" 字段。

**行号引用**:
```python
# tools/traits.py:93-95
def to_json_schema(self, names=None):
    return {
        "type": "json_object",
    }
```

这个 schema 实际上没有约束任何结构，完全依赖 prompt 中的示例来引导 LLM 输出正确格式。如果 LLM 输出 `{"tool": "web_fetch", "arguments": {"url": "..."}}`（单层对象），Tier 1 会忽略它，Tier 3 才会捕获它。

#### 2.5.2 Tier 2 的问题

XML 解析使用正则表达式 `re.compile(r'<tool_call>(.*?)</tool_call>', re.DOTALL)`。如果 LLM 输出嵌套的 `<tool_call>` 标签（虽然不太可能），或者标签内有 JSON 包含字符串 `</tool_call>`，正则匹配会出错。

更严重的是，Tier 2 解析后，`cleaned` 文本是移除所有 `<tool_call>` 块后的剩余文本。但如果 LLM 在 `<tool_call>` 之外还有有用的自然语言说明，这些说明会被保留在 `cleaned` 中传递给 Agent 3。这在某些情况下是合理的，但如果 LLM 在 `<tool_call>` 之前输出了大量的思考过程（除了 `<think>` 块），这些思考过程会污染 Agent 3 的输入。

#### 2.5.3 Tier 3 的问题

Bare JSON fallback 检查 `obj.get("name") or obj.get("tool", "")`，如果 name 存在则构造 calls。但 Tier 3 没有检查 `arguments` 是否为 dict 的类型安全（Tier 2 有 `if not isinstance(arguments, dict): arguments = {}`）。

**行号引用**:
```python
# core/dispatcher.py:72-74
name = obj.get("name") or obj.get("tool", "")
if name:
    args = _normalize_args(obj.get("arguments", {}))
```

如果 `arguments` 是字符串或 list，`_normalize_args` 会崩溃，因为它期望 dict：

```python
# core/dispatcher.py:197-212
def _normalize_args(args: dict) -> dict:
    result = dict(args)  # 如果 args 不是 dict，这里会 TypeError
```

#### 2.5.4 整体问题

三层解析之间没有优先级冲突解决机制。例如，如果 LLM 同时输出了 JSON 对象和 XML 标签（某些模型可能会这样），Tier 1 会优先捕获 JSON，但 XML 中的工具调用会被忽略。这在多工具调用场景中可能导致工具丢失。

---

### 2.6 contains_fake_action 的检测逻辑

**文件**: `core/dispatcher.py:172-194`

```python
def contains_fake_action(text: str) -> bool:
    completion_keywords = ["已发送", "已通知", "已经为你", "已经为您", ...]
    if any(kw in text for kw in completion_keywords):
        return True

    narrative_patterns = [
        "调用web_fetch", "调用read_file", ...,
        "读取你给的链接", "读取了那个网页", ...,
        "搜索了一下", "搜了一下", "搜索了",
        ...
    ]
    return any(p in text for p in narrative_patterns)
```

#### 2.6.1 误报风险

`contains_fake_action` 在 `_react_loop()` 中被调用时，有一个 `tools_were_called` 标志来避免误报：

```python
# core/agent.py:139
if contains_fake_action(resp) and fake_action_count < 3 and not tools_were_called:
```

这意味着只有在"本轮 ReAct 循环中还没有执行过真实工具"时才会检测假动作。这是一个好的设计，但 `tools_were_called` 只在 `_react_loop()` 中设置，在 CLI 路径的 `_on_act()` 中没有对应的检查：

```python
# core/cli_controller.py:258
if all(not r["success"] for r in results) and contains_fake_action(a.current_response):
```

这里检查的是"所有工具都失败"且"包含假动作描述"。但如果 Agent 3 在描述之前成功调用的工具结果（如"工具返回了..."），`contains_fake_action` 会匹配 `"工具返回"` 等模式，导致误报。

#### 2.6.2 漏报风险

检测词表是硬编码的中文关键词，如果 LLM 用其他方式描述工具调用（如"我已经查过了"、"我帮你搜索了"、"fetch 了网页"），这些不会被捕获。特别是 `"fetch 了网页"`、`"read 了文件"` 等中英混合表达不在列表中。

#### 2.6.3 没有上下文感知

`contains_fake_action` 是纯文本匹配，不考虑上下文。如果用户在输入中提到了"已发送"（如"我已经发送了文件"），Agent 3 的回复中引用用户的话时包含这个词，会被误检为假动作。虽然 `_react_loop()` 中检查的是 assistant 的 `resp`，不是 user 输入，但如果 Agent 3 在回复中复述用户的话，仍然可能触发。

---

### 2.7 架构问题与耦合

#### 2.7.1 Web 路径与 CLI 路径的代码重复

Web 路径使用 `MessageHandler`，CLI 路径使用 `CliController`，两者实现了相似但不同的三层 Agent 逻辑：

| 功能 | Web (MessageHandler) | CLI (CliController) |
|------|----------------------|---------------------|
| Agent 1 assess | 有 | 有 |
| Agent 2 多轮 review | 有 | 无 |
| Agent 2 retry | 有 | 无（Agent 2 内部有） |
| Agent 3 ReAct | `_react_loop()` | `_on_think()` + `_on_act()` |
| 工具结果注入 | `_run_agent3()` | `_on_think()` |
| 情绪处理 | `_process_emotion()` | `_on_reflect()` |

这种重复意味着任何对三层 Agent 逻辑的修改都需要在两个地方同步更新，维护成本极高。

#### 2.7.2 MessageHandler 与 CliController 的重复实现

两个类都有：
- `_ensure_inner_drive()` / `_ensure_tool_agent()`
- `_make_internal_registry()`
- `a` property

`MessageHandler` 和 `CliController` 各自维护独立的 `_inner_drive` 和 `_tool_agent` 实例。虽然它们共享同一个 `Agent` 实例，但 InnerDriveAgent 和 ToolAgent 被创建了两次（Web 路径一次，CLI 路径一次）。InnerDriveAgent 和 ToolAgent 本身是无状态的（除了配置参数），所以功能上没问题，但资源上浪费了。

#### 2.7.3 Agent 对 MessageHandler 和 CliController 的隐式依赖

`Agent` 类在 `__init__` 中同时创建了 `CliController` 和 `MessageHandler`：

```python
# core/agent.py:87-88
self._cli = CliController(self)
self._messages = MessageHandler(self)
```

这意味着即使只使用 Web 模式，`CliController` 仍然会被实例化；即使只使用 CLI 模式，`MessageHandler` 仍然会被实例化。虽然它们都是轻量级的（lazy init 内部 agent），但这种设计违反了"按需创建"原则。

#### 2.7.4 `track_failures` 作为模块级函数

**文件**: `core/message_handler.py:294-301`

```python
def track_failures(tracker, tool_result):
    for r in tool_result.records:
        if not r.success:
            tracker.failure_log.append({
                "name": r.name,
                "output": r.output[:200],
            })
```

这是一个模块级函数，但只被 `MessageHandler.handle_message()` 使用。它应该作为 `MessageHandler` 的方法或 `ToolAttemptTracker` 的方法。更关键的是，它只记录 `tool_result.records` 中的失败，但如果 `tool_result` 本身为空（没有工具被调用），`failure_log` 不会被更新，而调用方可能期望记录"没有工具被调用"作为一种失败。

---

### 2.8 逻辑缺陷

#### 2.8.1 `_build_messages` 中的 token 估算错误

**文件**: `core/message_handler.py:274-291`

```python
def _build_messages(self, sys_prompt: str, user_input: str | None) -> list[dict]:
    messages = [{"role": "system", "content": sys_prompt}]
    overflow = False
    for t in a.short_term.get_all_reversed():
        role = "assistant" if t.role == "assistant" else "user"
        if estimate_tokens(" ".join(m["content"][:200] for m in messages[-5:] if m["role"] != "system")) + estimate_tokens(t.content) > COMPRESS_THRESHOLD:
            overflow = True
            break
        messages.insert(1, {"role": role, "content": t.content})
```

**问题 1**: `messages[-5:]` 在循环初期可能包含 system prompt 和少量消息，但 `estimate_tokens` 的计算逻辑是每次只检查最近 5 条消息 + 当前 turn 的 token 数，而不是所有已插入消息的 token 总数。这意味着如果对话历史很长，但最近 5 条很短，循环会继续插入旧消息，导致总 token 数远超 `COMPRESS_THRESHOLD`。

**问题 2**: `messages.insert(1, ...)` 将消息插入到 system prompt 之后，但遍历顺序是 `get_all_reversed()`（最新的在前），所以插入后 messages 的顺序是：`[system, oldest, ..., newest]`。这与正常的对话顺序相反。虽然 LLM 通常不严格依赖消息顺序，但这仍然是一个潜在问题。

**问题 3**: 当 `overflow` 为 True 时，插入 `[对话历史摘要]`，但没有清除已经插入的部分消息。如果循环在第 10 条消息时 overflow，前 9 条消息仍然保留在 messages 中，加上摘要，总长度仍然可能超过阈值。

#### 2.8.2 `ContextManager.compress()` 的副作用

**文件**: `core/context_manager.py:62-98`

`compress()` 方法会调用 `self._short_term.clear()`（第95行），清空整个短期记忆缓冲区。这意味着压缩后，所有短期记忆丢失，只剩下压缩摘要。如果压缩失败（异常），`self._compressing` 标志会被重置，但短期记忆已经被清空。

更严重的是，`compress()` 在 `_build_messages()` 中被调用：

```python
# core/message_handler.py:288-289
if msg_tokens + estimate_tokens(user_input) > COMPRESS_THRESHOLD:
    a._context.compress(messages)
```

这里传入的 `messages` 是已经构建好的列表（包含 system prompt 和部分历史），`compress()` 内部遍历这个列表生成摘要，然后清空 `short_term`。但 `messages` 列表本身没有被修改，仍然包含所有历史消息。所以压缩的实际效果是：保留了 `messages` 中的消息（因为它们是局部变量），但清空了 `short_term`（全局状态）。这导致短期记忆和 messages 列表不同步。

#### 2.8.3 `SleepManager` 的竞态条件

**文件**: `core/sleep_manager.py`

`is_sleeping` 是一个 property，返回 `self._sleeping`。但 `_sleeping` 在 `get_sleep_state()` 中可能被修改（第60、68、78、89行）。如果 Web 路径的多个并发请求同时调用 `get_sleep_state()`，可能出现竞态条件。虽然当前代码中没有显式的并发处理，但 Web 服务器（FastAPI/Starlette）是异步的，多个请求可能交错执行。

#### 2.8.4 `ProactivityManager.check_rate_limit` 的副作用

**文件**: `core/proactivity.py:94-115`

`check_rate_limit` 在检查通过时会更新 `_last_explore_time` 或 `_last_chat_time`。这是一个副作用——查询操作修改了状态。如果调用方先 `check_rate_limit("chat")` 检查，然后根据结果决定是否执行，这个设计没问题。但如果调用方在决策前多次检查（如先检查 explore，再检查 chat），第一次检查就会更新时间，影响后续检查。

#### 2.8.5 `MemoryConsolidator` 中 `analyze_sentiment` 的异常处理

**文件**: `memory/consolidation.py:83-96`

```python
def analyze_sentiment(self, text: str) -> tuple[float, bool, float]:
    try:
        prompt = EMOTION_ANALYSIS_PROMPT.format(text=text)
        result = self.llm(prompt, temperature=0.2)
        data = json.loads(result.strip())
        return (
            float(data.get("sentiment", 0)),
            bool(data.get("personal_sharing", False)),
            float(data.get("topic_energy", 0.5)),
        )
    except Exception as e:
        logger.warning(f"Sentiment analysis failed: {e}")
        return 0.0, False, 0.5
```

如果 `self.llm()` 返回的 JSON 中 `sentiment` 是字符串 `"0.5"`，`float()` 可以正常转换。但如果 `sentiment` 是 `"high"` 或其他非数字字符串，`float()` 会抛出 `ValueError`，被外层 `except Exception` 捕获，返回默认值。这隐藏了数据格式问题，且每次都会触发日志警告，可能产生大量日志。

---

### 2.9 其他代码质量问题

#### 2.9.1 重复的外部工具名称列表

`EXTERNAL_TOOL_NAMES` 在 `core/inner_drive.py`（第17-20行）和 `core/tool_agent.py`（第15-18行）中各定义了一次。这是一个明显的 DRY 违反。

#### 2.9.2 `ToolRegistry.to_json_schema()` 返回无效 schema

**文件**: `tools/traits.py:82-95`

```python
def to_json_schema(self, names=None):
    tool_names = []
    for spec in self.list_specs():
        if names is not None and spec.name not in names:
            continue
        tool_names.append(spec.name)

    return {
        "type": "json_object",
    }
```

`tool_names` 被计算但从未使用。返回的 schema 只是 `{"type": "json_object"}`，没有描述期望的 JSON 结构。对于 DeepSeek API，`json_object` 类型只保证输出是有效 JSON，但不约束字段。这导致 Tier 1 解析经常失败，回退到 Tier 2/3。

#### 2.9.3 `LongTermMemory` 的同步包装器效率问题

**文件**: `memory/long_term.py:18-27`

```python
@staticmethod
def _run_sync(coro):
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return pool.submit(asyncio.run, coro).result()
```

每次同步调用都创建一个新的 `ThreadPoolExecutor`。如果短时间内有大量同步调用（如检索记忆时），会创建大量线程池，性能极差。应该使用模块级或类级的共享线程池。

#### 2.9.4 `ConversationBuffer` 的 `_next_id` 不持久化

**文件**: `memory/short_term.py:16-17`

```python
_next_id: int = 0
```

`turn_id` 在程序重启后从 0 开始，但长期记忆中的 `source_turn` 可能引用之前的 turn ID。这会导致 turn ID 冲突或无法正确关联。

---

## 3. 风险评级与建议

### 3.1 风险评级汇总

| 风险项 | 严重等级 | 影响范围 | 文件位置 |
|--------|---------|---------|---------|
| Agent 1 可绕过 Agent 2 直接执行外部工具 | **高** | 工具执行、数据安全 | `core/inner_drive.py:99` |
| Agent 2 retry 逻辑缺陷（last_failure 未更新） | **高** | 工具调用成功率 | `core/tool_agent.py:169-186` |
| MessageHandler 中 Agent 2 结果传递错误 | **高** | 数据流断裂、回复质量 | `core/message_handler.py:143-156` |
| `execute_tool_calls` 中 `asyncio.run()` 循环调用 | **高** | 稳定性、性能、兼容性 | `core/dispatcher.py:128-133` |
| ToolAttemptTracker 状态管理完全失效 | **中** | 重试机制、循环控制 | `core/message_handler.py:104` |
| Web/CLI 路径功能不一致 | **中** | 可维护性、用户体验 | `core/message_handler.py` vs `core/cli_controller.py` |
| `_build_messages` token 估算错误 | **中** | 上下文窗口溢出、API 成本 | `core/message_handler.py:274-291` |
| `ContextManager.compress()` 清空短期记忆副作用 | **中** | 记忆丢失、状态不一致 | `core/context_manager.py:95` |
| `contains_fake_action` 误报/漏报 | **低** | 用户体验、循环效率 | `core/dispatcher.py:172-194` |
| `ToolCallRecord.arguments` 永远为空 | **低** | 可观测性、调试 | `core/tool_agent.py:119` |
| `EXTERNAL_TOOL_NAMES` 重复定义 | **低** | 可维护性 | `core/inner_drive.py` / `core/tool_agent.py` |
| `to_json_schema()` 返回无效 schema | **低** | 结构化输出可靠性 | `tools/traits.py:82-95` |

### 3.2 具体修复建议

#### 建议 1: 为 Agent 1 创建隔离的内部工具 Registry

```python
# core/inner_drive.py
from tools.traits import ToolRegistry

def _make_internal_registry(self):
    r = ToolRegistry()
    for name in ("recall", "remember"):
        tool = self._full_registry.get(name)
        if tool:
            r.register(tool)
    return r

# 在 assess() 中使用内部 registry
internal_registry = self._make_internal_registry()
results = execute_tool_calls(internal_registry, calls)
```

#### 建议 2: 修复 Agent 2 的 retry 逻辑

```python
# core/tool_agent.py:run_with_request()
for attempt in range(1, max_retries + 1):
    ...
    cleaned, calls = parse_tool_calls(resp)
    if not calls:
        last_failure = "未能解析出工具调用，请确保输出有效的 JSON 或 <tool_call> 标签"
        continue
    ...
```

#### 建议 3: 修复 MessageHandler 中的结果传递

```python
# core/message_handler.py:handle_message()
# 将 tool_records（已合并）传递给 _run_agent3，而不是让 _run_agent3 重新格式化
def _run_agent3(self, user_input, drive_result, tool_records_text: str = "", on_token=None):
    ...
    # 直接使用传入的 tool_records_text，不要重新从 tool_result 格式化
```

#### 建议 4: 修复 ToolAttemptTracker 的使用

```python
# core/message_handler.py:handle_message()
tracker = ToolAttemptTracker()
tracker.round_number = round_num  # 同步 round 编号

# 或者更好的设计：将 tracker 的 round/ retry 逻辑合并到 MessageHandler 中，
# 移除 ToolAttemptTracker 类，因为它当前完全没有正确工作。
```

#### 建议 5: 统一 Web 和 CLI 路径

将三层 Agent 的核心编排逻辑提取到一个独立的 `AgentOrchestrator` 类中，`MessageHandler` 和 `CliController` 只负责输入输出适配（Web 的 HTTP 请求/响应 vs CLI 的 stdin/stdout）。

#### 建议 6: 修复 `execute_tool_calls` 的异步处理

```python
# core/dispatcher.py 模块顶部
import asyncio
import inspect

# 在模块级别获取或创建事件循环
def _run_async(coro):
    try:
        loop = asyncio.get_running_loop()
        # 如果已经在事件循环中，使用 asyncio.create_task 或 asyncio.run_coroutine_threadsafe
        # 具体取决于调用上下文
    except RuntimeError:
        return asyncio.run(coro)
```

或者，更简单的方案：要求所有工具的 `execute()` 方法都是同步的，由工具内部自行管理异步操作（如使用 `requests` 而不是 `aiohttp`）。

#### 建议 7: 修复 `_build_messages` 的 token 计算

```python
def _build_messages(self, sys_prompt: str, user_input: str | None) -> list[dict]:
    messages = [{"role": "system", "content": sys_prompt}]
    total_tokens = estimate_tokens(sys_prompt)
    for t in a.short_term.get_all_reversed():
        role = "assistant" if t.role == "assistant" else "user"
        turn_tokens = estimate_tokens(t.content)
        if total_tokens + turn_tokens > COMPRESS_THRESHOLD:
            messages.insert(1, {"role": "system", "content": f"[对话历史摘要] {a._context.compressed_summary}"})
            break
        messages.insert(1, {"role": role, "content": t.content})
        total_tokens += turn_tokens
    ...
```

#### 建议 8: 修复 `ContextManager.compress()` 的副作用

在 `compress()` 中不要自动清空 `short_term`，或者至少在清空前确认压缩成功。更好的设计是：压缩成功后，将 `messages` 列表截断为只保留 system prompt 和摘要。

#### 建议 9: 完善 `contains_fake_action`

- 增加更多变体匹配（如"fetch 了网页"、"read 了文件"）
- 考虑使用更智能的检测方式，如检查文本中是否同时包含工具名称和完成态动词
- 在 CLI 路径中也引入 `tools_were_called` 标志

#### 建议 10: 修复 `ToolRegistry.to_json_schema()`

返回一个真正的 JSON Schema，描述期望的 `calls` 数组结构：

```python
def to_json_schema(self, names=None):
    tools = []
    for spec in self.list_specs():
        if names is not None and spec.name not in names:
            continue
        tools.append({
            "name": spec.name,
            "description": spec.description,
            "parameters": spec.parameters,
        })
    return {
        "type": "json_object",
        "schema": {
            "type": "object",
            "properties": {
                "calls": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string", "enum": [t["name"] for t in tools]},
                            "arguments": {"type": "object"},
                        },
                        "required": ["name", "arguments"],
                    },
                },
            },
            "required": ["calls"],
        },
    }
```

（注意：DeepSeek 的 `json_object` 模式可能不支持完整的 JSON Schema 验证，需要测试确认。）

---

## 4. 汇总统计

### 4.1 代码规模

| 文件 | 行数 | 类/函数数 |
|------|------|----------|
| core/agent.py | 253 | 1 类 / 15+ 方法 |
| core/inner_drive.py | 376 | 4 类 / 10+ 方法 |
| core/tool_agent.py | 259 | 4 类 / 4 方法 |
| core/message_handler.py | 302 | 1 类 / 8 方法 |
| core/dispatcher.py | 213 | 6 函数 |
| **合计** | **~1403** | **10+ 类 / 40+ 方法** |

### 4.2 问题统计

| 类别 | 数量 | 高优先级 | 中优先级 | 低优先级 |
|------|------|---------|---------|---------|
| 职责分离问题 | 4 | 1 | 2 | 1 |
| 数据流问题 | 3 | 2 | 1 | 0 |
| 循环控制问题 | 4 | 1 | 2 | 1 |
| 错误处理问题 | 5 | 2 | 2 | 1 |
| 解析逻辑问题 | 4 | 1 | 2 | 1 |
| 假动作检测问题 | 3 | 0 | 1 | 2 |
| 架构耦合问题 | 5 | 0 | 3 | 2 |
| 逻辑缺陷 | 5 | 0 | 3 | 2 |
| 代码质量问题 | 4 | 0 | 1 | 3 |
| **合计** | **37** | **7** | **17** | **13** |

### 4.3 关键结论

1. **三层 Agent 的概念设计是合理的**，但实现层面的职责边界模糊，特别是 Agent 1 可以直接执行外部工具、Agent 3 在 Web/CLI 路径中的工具权限不一致。

2. **数据流存在断裂风险**，Agent 2 的多轮结果在传递给 Agent 3 时可能丢失，Agent 1 review 过程中获取的新记忆对 Agent 3 不可见。

3. **循环控制存在多处漏洞**，ToolAttemptTracker 完全失效、max_iterations 的边界条件错误、Agent 1 达到上限后的默认行为可能错误地跳过工具调用。

4. **错误处理不完整**，Provider 层的 timeout 未处理、Agent 2 层的 Provider 异常未捕获、`asyncio.run()` 的循环调用可能导致运行时错误。

5. **Web 路径和 CLI 路径的重复实现**是最突出的架构债务，建议尽快提取统一的编排层。

6. **整体风险评级：中高风险**。建议优先修复高优先级问题（Agent 1 工具隔离、Agent 2 retry 逻辑、结果传递、asyncio.run），然后逐步处理中优先级问题（tracker 状态、token 估算、路径统一）。

---

*报告生成时间: 2026-05-31*  
*审查范围: core/agent.py, core/inner_drive.py, core/tool_agent.py, core/message_handler.py, core/dispatcher.py 及关联模块*
