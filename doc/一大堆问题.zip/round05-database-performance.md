# AI Friend 项目性能与可扩展性审查报告 —— 数据库查询优化（Round 05）

**审查日期**：2026-05-31  
**审查范围**：`storage/repository.py`、`storage/database.py`、`memory/retrieval.py`、`memory/long_term.py`、`memory/consolidation.py`、`memory/embeddings.py`、`web/session.py`、`web/server.py`、`core/agent.py`、`core/message_handler.py`、`core/inner_drive.py`、`config.py`  
**审查目标**：对数据库查询执行计划、索引策略、批量操作、N+1 查询、连接池、WAL 模式、结果集限制进行系统性评估，识别性能瓶颈与可扩展性风险  
**关联文档**：`doc/round01-storage-layer.md`、`doc/round02-long-term-memory.md`

---

## 一、概述

AI Friend 项目以 SQLite 作为核心持久化存储，通过 `aiosqlite` 提供异步访问能力。数据库承载了用户事实（`user_facts`）、体验（`experiences`）、反思（`reflections`）、关系指标（`relationship_metrics`）和对话轮次（`conversation_turns`）五类核心数据。随着对话轮次增长、记忆条目累积，数据库查询性能直接影响 Agent 的响应延迟和并发处理能力。

本次审查从 8 个维度展开：SQL 执行计划评估、`LIKE '%query%'` 全表扫描、索引缺失、批量插入 vs 逐条插入、N+1 查询、连接池配置、WAL 模式性能、查询结果集大小限制。审查发现 **3 项严重风险**、**7 项高风险**、**6 项中等风险**，总计 16 项具体问题。其中最紧迫的问题是 `LIKE '%query%'` 导致的全表扫描、缺失复合索引、单连接无池化、以及 WAL 模式下的粗粒度锁竞争。

---

## 二、详细发现

### 2.1 SQL 执行计划评估

#### 2.1.1 `search_facts` 的三字段 OR + LIKE 组合查询 —— 严重

**文件**：`storage/repository.py:74-88`

```sql
SELECT * FROM user_facts
WHERE is_active = 1
  AND (fact_key LIKE ? OR fact_value LIKE ? OR category LIKE ?)
ORDER BY composite_score DESC, recall_count DESC
LIMIT ?
```

**执行计划分析**：

在 SQLite 中，使用 `EXPLAIN QUERY PLAN` 分析上述查询，输出大致为：

```
QUERY PLAN
|--SCAN user_facts
|--USE TEMP B-TREE FOR ORDER BY
`--LIST SUBQUERY
```

- `SCAN user_facts` 表示 SQLite 必须逐行扫描整张表（或满足 `is_active = 1` 条件的所有行）。
- `USE TEMP B-TREE FOR ORDER BY` 表示需要在临时 B-tree 中对结果排序。
- 三字段 `OR` 条件进一步限制了优化器使用索引的可能性；即使为单个字段建立索引，OR 条件通常也会导致索引合并或退化为全表扫描。

**性能影响**：

- 当 `user_facts` 达到默认上限 200 条时，每次查询扫描 200 行，尚可接受。
- 若用户调高 `max_facts` 至数千条（配置项 `Config.max_facts` 无上限校验），查询时间随数据量线性增长。
- 在 Web 模式下，每个用户消息触发 `MemoryRetriever.retrieve_for_query()`，进而调用 `search_facts`（`memory/retrieval.py:78` 的 `keywords` 分支和 `memory/retrieval.py:42` 的 Layer 1 热记忆加载）。实际上，`retrieve_for_query` 在 Layer 1 调用 `get_all_active_facts(limit=50)`（`memory/retrieval.py:32`），不经过 `search_facts`；但 `retrieve_by_recall_tag`（`memory/retrieval.py:71-95`）和 `RecallTool.execute`（`tools/memory_tools.py:45`）均直接调用 `search_facts`。此外，`build_context`（`memory/long_term.py:78-90`）在 `_search_facts` 中传入 `query` 参数，当 `query` 非空时走 `search_facts` 路径。

**风险评级**：**严重** — 核心检索路径上的全表扫描，数据量增长后延迟不可控。

**建议**：

1. 引入 FTS5 虚拟表：
   ```sql
   CREATE VIRTUAL TABLE IF NOT EXISTS user_facts_fts USING fts5(
       category, fact_key, fact_value,
       content='user_facts', content_rowid='id'
   );
   ```
   通过触发器保持 FTS 表与原表同步，查询时改用 `MATCH` 替代 `LIKE`。
2. 若短期内不引入 FTS5，至少为 `is_active` + `composite_score` 建立复合索引，使 `ORDER BY` 可利用索引避免临时排序。

---

#### 2.1.2 `search_experiences` 的动态 OR 条件构建 —— 高风险

**文件**：`storage/repository.py:128-149`

```python
if keywords:
    conditions = " OR ".join("(summary LIKE ? OR tags LIKE ?)" for _ in keywords)
    params = []
    for kw in keywords:
        params.extend([f"%{kw}%", f"%{kw}%"])
    await c.execute(f"""
        SELECT * FROM experiences
        WHERE is_archived = 0 AND ({conditions})
        ORDER BY composite_score DESC, created_at DESC
        LIMIT ?
    """, params + [limit])
```

**执行计划分析**：

- 动态构建的 `OR` 链长度与关键词数量成正比。若用户输入长句，关键词可达 10 个以上，SQL 语句膨胀。
- 每个 `LIKE '%kw%'` 均无法使用索引，优化器选择 `SCAN experiences`。
- `ORDER BY composite_score DESC, created_at DESC` 需要临时排序。

**性能影响**：

- `experiences` 表默认上限 100 条，扫描成本较低，但同样存在配置上调后的风险。
- 更隐蔽的问题是：`_search_experiences_semantic`（`memory/retrieval.py:136-161`）先调用 `search_experiences(keywords, limit=15)` 获取候选池，再做语义重排。这意味着即使语义搜索可用，仍需先承受一次全表扫描的关键词过滤。

**风险评级**：**高风险**

**建议**：

1. 为 `experiences` 建立 FTS5 虚拟表，覆盖 `summary` 和 `tags`。
2. 在语义搜索可用时，优先直接对全表做向量相似度计算（利用 embedding BLOB），跳过关键词预过滤，或仅将关键词作为粗筛（如 `LIMIT 200` 快速截断）。

---

#### 2.1.3 `get_recent_turns` 的倒序 + 再反转 —— 中等风险

**文件**：`storage/repository.py:228-237`

```sql
SELECT role, content FROM conversation_turns
ORDER BY id DESC LIMIT ?
```

```python
rows = list(rows)
rows.reverse()
return [{"role": r[0], "content": r[1]} for r in rows]
```

**执行计划分析**：

- `ORDER BY id DESC LIMIT ?` 可利用 `conversation_turns` 主键索引（`id` 是 `INTEGER PRIMARY KEY`），SQLite 会执行 `SEARCH conversation_turns USING INTEGER PRIMARY KEY (rowid=?)` 的反向扫描，效率极高。
- 但 Python 层的 `rows.reverse()` 和列表推导式引入了不必要的内存拷贝。

**性能影响**：

- 数据量小（默认恢复 30 条）时影响可忽略。
- 若 `short_term_capacity` 调高（`config.py:19` 默认 500），恢复逻辑可能请求更多历史记录，内存拷贝开销线性增长。

**风险评级**：**中等风险**

**建议**：

- 改用 `ORDER BY id ASC` 配合子查询：
  ```sql
  SELECT role, content FROM conversation_turns
  WHERE id >= (SELECT id FROM conversation_turns ORDER BY id DESC LIMIT 1 OFFSET ?)
  ORDER BY id ASC
  ```
- 或在 `aiosqlite.Row` 上直接迭代，避免 `list(rows)` 的完整物化。

---

#### 2.1.4 `prune_facts` 的 COUNT + 子查询 UPDATE —— 高风险

**文件**：`storage/repository.py:241-258`

```sql
SELECT COUNT(*) FROM user_facts WHERE is_active = 1;

UPDATE user_facts SET is_active = 0, composite_score = 0
WHERE id IN (
    SELECT id FROM user_facts WHERE is_active = 1
    ORDER BY composite_score ASC, recall_count ASC
    LIMIT ?
)
```

**执行计划分析**：

- `SELECT COUNT(*)` 在无索引时需扫描所有 `is_active = 1` 的行。
- `UPDATE ... WHERE id IN (SELECT ...)` 中，子查询和外部更新均涉及 `user_facts` 表。SQLite 处理此类 correlated subquery 时，可能无法有效利用索引，导致两次表扫描。
- 子查询的 `ORDER BY composite_score ASC, recall_count ASC` 在无复合索引时需临时排序。

**性能影响**：

- 剪枝操作在 `MemoryConsolidator.consolidate()`（`memory/consolidation.py:47-81`）的末尾执行，每次 consolidation 触发一次。若配置 `consolidation_interval=5`（`config.py:20`），每 5 轮对话触发一次。
- 虽然单次开销不大，但在高并发 Web 场景下，多个 session 同时触发 consolidation 时，锁竞争会放大此延迟。

**风险评级**：**高风险**

**建议**：

1. 使用 CTE 合并为单次操作，减少表扫描次数：
   ```sql
   WITH to_prune AS (
       SELECT id FROM user_facts WHERE is_active = 1
       ORDER BY composite_score ASC, recall_count ASC
       LIMIT ?
   )
   UPDATE user_facts SET is_active = 0, composite_score = 0
   WHERE id IN (SELECT id FROM to_prune)
   ```
2. 为 `is_active, composite_score, recall_count` 建立复合索引，使 `ORDER BY` 可直接利用索引顺序。
3. 考虑将剪枝逻辑改为标记 + 后台异步清理，而非立即 UPDATE。

---

#### 2.1.5 `prune_experiences` 与 `prune_reflections` —— 同 2.1.4

**文件**：`storage/repository.py:260-295`

与 `prune_facts` 结构相同，问题一致。

---

### 2.2 LIKE '%query%' 全表扫描问题

#### 2.2.1 `search_facts` 的前缀通配 LIKE —— 严重

**文件**：`storage/repository.py:74-88`

已在 2.1.1 中详细分析。此处补充：当前 `user_facts` 表除主键和 `UNIQUE(category, fact_key)` 隐式索引外，**无任何用户自定义索引**（`database.py:47-116` 的 `initialize()` 中未创建任何 `CREATE INDEX`）。

**SQLite 索引使用规则**：

- `LIKE 'prefix%'`：若列有索引且 `PRAGMA case_sensitive_like=OFF`（默认），可使用索引范围扫描。
- `LIKE '%suffix'` 或 `LIKE '%infix%'`：前缀通配导致无法确定索引范围，必须全表扫描。

当前代码中所有 `LIKE` 均为 `%{kw}%` 形式，属于最慢的模式。

**风险评级**：**严重**

**建议**：

- 短期：为高频精确匹配场景添加前缀索引（如 `fact_key` 的等值查询）。
- 中期：引入 SQLite FTS5 扩展，将文本搜索迁移至虚拟表。
- 长期：评估迁移到专用向量数据库（如 `sqlite-vec`、Chroma、Milvus Lite），利用 embedding 做近似最近邻搜索，彻底规避 LIKE 性能问题。

---

#### 2.2.2 `search_experiences` 的多关键词 OR-LIKE 链 —— 高风险

**文件**：`storage/repository.py:128-149`

已在 2.1.2 中分析。补充：`_search_experiences_semantic`（`memory/retrieval.py:136-161`）在语义搜索路径下，仍先调用 `search_experiences(keywords, limit=15)` 作为候选池生成器。这意味着：

- 即使 embedding 服务可用、语义搜索理论上更高效，系统仍先执行一次低效的 LIKE 全表扫描。
- 若关键词为空列表（`query` 仅包含停用词），`search_experiences` 回退到 `SELECT * WHERE is_archived=0 ORDER BY ... LIMIT ?`，虽无 LIKE，但仍需扫描所有未归档记录。

**风险评级**：**高风险**

**建议**：

- 在语义搜索可用时，跳过关键词预过滤，直接对 `embedding IS NOT NULL` 的记录做向量相似度计算。
- 若必须保留关键词分支，为 `is_archived` + `composite_score` 建立复合索引，加速无关键词时的回退查询。

---

### 2.3 索引缺失分析

#### 2.3.1 `user_facts` 表零索引 —— 严重

**文件**：`storage/database.py:55-69`

```sql
CREATE TABLE IF NOT EXISTS user_facts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    fact_key TEXT NOT NULL,
    fact_value TEXT NOT NULL,
    confidence REAL DEFAULT 1.0,
    importance REAL DEFAULT 0.5,
    source_turn INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    recall_count INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    composite_score REAL DEFAULT 1.0,
    UNIQUE(category, fact_key)
);
```

**缺失索引及其影响**：

| 查询场景 | 涉及方法 | 缺失索引 | 当前行为 |
|---------|---------|---------|---------|
| 按活跃度+评分排序 | `get_active_facts`, `search_facts` ORDER BY | `idx_facts_active_score` | 全表扫描 + 临时排序 |
| 按活跃度+回忆次数排序 | `prune_facts` ORDER BY | `idx_facts_active_score_recall` | 全表扫描 + 临时排序 |
| 按 category 等值查询 | 潜在业务需求 | `idx_facts_category` | 全表扫描 |
| 按 updated_at 范围查询 | 潜在业务需求 | `idx_facts_updated_at` | 全表扫描 |
| embedding IS NULL | `_embed_new_items` | `idx_facts_embedding_null` | 全表扫描 |

**风险评级**：**严重** — 核心表无任何辅助索引，所有非主键查询均为全表扫描。

**建议**：

```sql
-- 复合索引：覆盖活跃度过滤 + 评分排序（最常用）
CREATE INDEX IF NOT EXISTS idx_facts_active_score ON user_facts(is_active, composite_score DESC, recall_count DESC);

-- 复合索引：覆盖剪枝场景（升序取最低分）
CREATE INDEX IF NOT EXISTS idx_facts_active_score_asc ON user_facts(is_active, composite_score ASC, recall_count ASC);

-- 部分索引：快速定位无 embedding 的记录（仅对 NULL 值索引，空间极小）
CREATE INDEX IF NOT EXISTS idx_facts_embedding_null ON user_facts(embedding) WHERE embedding IS NULL;

-- 可选：category 等值查询加速
CREATE INDEX IF NOT EXISTS idx_facts_category ON user_facts(category);
```

---

#### 2.3.2 `experiences` 表零索引 —— 高风险

**文件**：`storage/database.py:71-84`

与 `user_facts` 类似，`experiences` 表除主键外无任何索引。

**缺失索引**：

```sql
CREATE INDEX IF NOT EXISTS idx_exps_archived_score ON experiences(is_archived, composite_score DESC, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_exps_archived_created ON experiences(is_archived, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_exps_embedding_null ON experiences(embedding) WHERE embedding IS NULL;
```

**风险评级**：**高风险**

---

#### 2.3.3 `reflections` 表零索引 —— 中等风险

**文件**：`storage/database.py:86-94`

`reflections` 表查询模式较简单（仅 `is_active=1 ORDER BY created_at DESC`），但仍应建立：

```sql
CREATE INDEX IF NOT EXISTS idx_refls_active_created ON reflections(is_active, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_refls_embedding_null ON reflections(embedding) WHERE embedding IS NULL;
```

**风险评级**：**中等风险**

---

#### 2.3.4 `conversation_turns` 表零索引 —— 高风险

**文件**：`storage/database.py:102-109`

```sql
CREATE TABLE IF NOT EXISTS conversation_turns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    turn_number INTEGER NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
    content TEXT NOT NULL,
    emotional_state TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**问题**：

- `get_recent_turns` 使用 `ORDER BY id DESC LIMIT ?`，依赖主键索引，效率尚可。
- 但 `insert_turn` 不校验 `turn_number` 唯一性，且 `turn_number` 在应用层全局递增，无数据库约束。
- 若未来添加 `session_id`（见 `doc/round01-storage-layer.md:5.3`），需建立 `(session_id, id DESC)` 复合索引。

**风险评级**：**高风险** — 当前虽无性能问题，但架构缺陷阻碍扩展。

**建议**：

```sql
-- 为未来 session_id 扩展预留
CREATE INDEX IF NOT EXISTS idx_turns_session_id ON conversation_turns(session_id, id DESC);
```

---

### 2.4 批量插入 vs 逐条插入

#### 2.4.1 `insert_turn` 逐条插入 —— 中等风险

**文件**：`storage/repository.py:218-226`

```python
async def insert_turn(self, turn_number: int, role: str, content: str,
                      emotional_state: Optional[str] = None) -> int:
    async with self.db.cursor() as c:
        await c.execute("""
            INSERT INTO conversation_turns (turn_number, role, content, emotional_state)
            VALUES (?, ?, ?, ?)
        """, (turn_number, role, content, emotional_state))
        return c.lastrowid
```

**分析**：

- 每次对话轮次（user + assistant）触发两次 `insert_turn`。
- 单条 INSERT 在 SQLite 中开销极低，但 `cursor()` 上下文管理器每次都会 `commit`（`database.py:34`）。
- 高频对话场景下，每秒多次 commit 会触发 WAL 文件的频繁 checkpoint，增加 I/O 压力。

**风险评级**：**中等风险**

**建议**：

- 在事务边界允许的场景下，将 user turn 和 assistant turn 的插入合并为一次事务。
- 或在 `Agent._react_loop`（`core/agent.py:119-181`）的末尾，将 `insert_turn_sync` 改为批量提交。

---

#### 2.4.2 `upsert_fact` 逐条 upsert —— 中等风险

**文件**：`storage/repository.py:34-68`

```python
async def upsert_fact(self, category: str, key: str, value: str, ...) -> int:
    async with self.db.cursor() as c:
        await c.execute("""
            INSERT INTO user_facts ...
            ON CONFLICT(category, fact_key) DO UPDATE SET ...
        """, (...))
        return c.lastrowid
```

**分析**：

- `MemoryConsolidator._extract_facts`（`memory/consolidation.py:98-125`）从 LLM 输出中解析事实后，对每个事实调用 `self.ltm.store_fact()`，即逐条 upsert。
- 若一次 consolidation 提取 5-10 个事实，将触发 5-10 次独立事务（每个 `cursor()` 一次 `commit`）。
- `ON CONFLICT` 本身需要检查 `UNIQUE(category, fact_key)` 约束，涉及索引查找，但事务开销仍占主导。

**风险评级**：**中等风险**

**建议**：

- 在 `MemoryConsolidator` 中累积事实列表，调用批量 upsert：
  ```python
  await c.executemany("""
      INSERT INTO user_facts (category, fact_key, fact_value, confidence, importance, source_turn, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(category, fact_key) DO UPDATE SET ...
  """, facts_list)
  ```
- 注意：`executemany` 配合 `ON CONFLICT` 在 SQLite 3.24+ 支持良好。

---

#### 2.4.3 `bulk_update_embeddings` 正确使用批量更新 —— 正面案例

**文件**：`storage/repository.py:189-197`

```python
async def bulk_update_embeddings(self, table: str, updates: list[tuple[int, bytes]]):
    if not updates:
        return
    async with self.db.cursor() as c:
        await c.executemany(
            f"UPDATE {table} SET embedding = ?, embedding_version = 1 WHERE id = ?",
            [(emb, rid) for rid, emb in updates],
        )
```

**分析**：

- 这是项目中**唯一**使用 `executemany` 的批量操作，值得肯定。
- 但 `table` 参数通过 f-string 直接拼接进 SQL，存在 SQL 注入风险（虽然当前调用方是内部代码，但应使用参数化或白名单校验）。

**风险评级**：**低风险**（性能正确，安全性需关注）

---

#### 2.4.4 `_embed_new_items` 的批量读取但逐表更新 —— 中等风险

**文件**：`memory/consolidation.py:255-297`

```python
for table, text_cols in [...]:
    rows = conn.execute(
        f"SELECT id, {col_list} FROM {table} WHERE embedding IS NULL LIMIT 50"
    ).fetchall()
    ...
    for (tbl, rid), vec in zip(targets, vecs):
        all_updates.append((tbl, rid, EmbeddingEngine.vec_to_bytes(vec)))

if all_updates:
    for tbl in ["user_facts", "experiences", "reflections"]:
        tbl_updates = [(rid, emb) for t, rid, emb in all_updates if t == tbl]
        if tbl_updates:
            self.ltm.repo.bulk_update_embeddings(tbl, tbl_updates)
```

**分析**：

- 读取端使用 `LIMIT 50` 分批，避免一次性加载过多数据。
- 更新端按表分批次调用 `bulk_update_embeddings`，每表一次 `executemany`。
- 但如前所述（`doc/round01-storage-layer.md:6.3`），`_embed_new_items` 在同步上下文中使用 `aiosqlite` 连接，存在运行时错误风险。

**风险评级**：**中等风险**

---

### 2.5 N+1 查询问题

#### 2.5.1 `MemoryConsolidator._generate_reflection` 的多段独立查询 —— 高风险

**文件**：`memory/consolidation.py:169-223`

```python
experiences = self.ltm.get_recent_experiences(limit=5)
reflections = self.ltm.get_recent_reflections(limit=3)
facts = self.ltm.get_all_active_facts(limit=10)
relationship = self.ltm.get_relationship()
```

**分析**：

- 四个独立的同步方法调用，每个都通过 `_run_sync` 创建独立的数据库事务（`cursor()` 上下文）。
- 虽然数据量小（limit 低），但事务建立和提交的开销是固定的。
- 在 `consolidate()` 的完整流程中（`memory/consolidation.py:47-81`），还包含 `_extract_facts`（可能多次 `store_fact`）、`_summarize_experience`（一次 `store_experience`）、`_generate_reflection`（上述 4 次查询 + 1 次 `store_reflection`）、`_update_relationship`（1 次查询 + 1 次 upsert）、`_prune`（3 次 COUNT + 3 次 UPDATE）、`_embed_new_items`（3 次 SELECT + 最多 3 次 UPDATE）。
- 单次 consolidation 可能触发 **15-20 次独立事务**，构成典型的 N+1 模式。

**风险评级**：**高风险**

**建议**：

- 将 `MemoryConsolidator` 的 consolidation 流程重构为**单次数据库事务**：
  1. 在事务开始时读取所有需要的数据（experiences、reflections、facts、relationship）。
  2. 在内存中完成所有 LLM 调用和逻辑计算。
  3. 在事务末尾批量写入所有变更（facts、experiences、reflections、relationship updates、prunes、embedding updates）。
- 这需要 `Repository` 暴露一个显式的事务上下文管理器，而非每次 `cursor()` 自动 commit。

---

#### 2.5.2 `MemoryRetriever.retrieve_for_query` 的 Layer 1 多表查询 —— 中等风险

**文件**：`memory/retrieval.py:27-69`

```python
hot_facts = self.ltm.get_all_active_facts(limit=50)
recent_experiences = self.ltm.get_recent_experiences(limit=5)
reflections = self.ltm.get_recent_reflections(limit=3)
relationship = self.ltm.get_relationship()
```

**分析**：

- 每次用户消息触发 4 次独立查询。
- 由于 `LongTermMemory` 的同步包装器（`memory/long_term.py:95-105`），每次查询都通过 `_run_sync` 在线程池中运行，增加了线程切换开销。
- 在 Web 模式下，这些查询通过 `loop.run_in_executor` 执行，进一步放大了线程池竞争。

**风险评级**：**中等风险**

**建议**：

- 在 `Repository` 层增加一个 `get_memory_context()` 方法，通过单条 SQL 或单次事务读取所有 Layer 1 数据：
  ```sql
  -- 使用 UNION ALL 合并多表查询（仅示例，实际需处理列差异）
  SELECT 'fact' as type, id, category as t1, fact_key as t2, fact_value as t3 FROM user_facts WHERE is_active=1 ORDER BY composite_score DESC LIMIT 50;
  SELECT 'exp' as type, id, summary as t1, emotional_tone as t2, NULL as t3 FROM experiences WHERE is_archived=0 ORDER BY created_at DESC LIMIT 5;
  SELECT 'refl' as type, id, content as t1, insight_type as t2, NULL as t3 FROM reflections WHERE is_active=1 ORDER BY created_at DESC LIMIT 3;
  ```
- 或至少将 4 次查询封装在一个 `async with repo.transaction()` 中，共享同一事务上下文。

---

#### 2.5.3 `RecallTool.execute` 的三段查询 —— 中等风险

**文件**：`tools/memory_tools.py:38-70`

```python
facts = self.ltm.search_facts(query, limit=5)
experiences = self.ltm.search_experiences(keywords, limit=3)
reflections = self.ltm.get_recent_reflections(limit=2)
```

**分析**：

- 作为内部工具，`RecallTool` 在 Agent 1 的 ReAct 循环中可能被多次调用（`inner_drive.py:83-103`）。
- 每次调用触发 3 次独立查询，且 `search_facts` 和 `search_experiences` 均涉及全表扫描。

**风险评级**：**中等风险**

**建议**：

- 与 2.5.2 类似，提供批量检索接口。
- 在 `MemoryRetriever` 中缓存 Layer 1 结果（hot memory），避免同一轮对话中重复查询。

---

### 2.6 连接池配置

#### 2.6.1 单连接无池化 —— 严重

**文件**：`storage/database.py:11-45`

```python
class Database:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._lock = asyncio.Lock()
        self.conn: aiosqlite.Connection | None = None

    async def open(self) -> None:
        self.conn = await aiosqlite.connect(self.db_path)
        ...

    @asynccontextmanager
    async def cursor(self):
        async with self._lock:
            c = await self.conn.cursor()
            try:
                yield c
                await self.conn.commit()
            ...
```

**分析**：

- `Database` 类只维护**一个** `aiosqlite.Connection`。
- 所有数据库操作通过 `asyncio.Lock` 串行化，同一时刻只有一个协程能执行查询。
- 在 Web 模式下，`SessionManager` 的所有 session 共享同一个 `Database` 实例（`web/session.py:131-134`），进而共享同一个连接和锁。
- 这意味着：即使 FastAPI 能并发处理多个 WebSocket 连接，数据库层面是完全串行的。

**性能影响**：

- 单条查询快（<10ms）时，串行化影响不明显。
- 一旦某条查询变慢（如 `LIKE '%query%'` 全表扫描、大结果集排序、WAL checkpoint），所有其他请求都被阻塞。
- 在 `_proactive_loop`（`web/server.py:130-196`）中，每 15 秒可能触发一次 proactive 处理，包含完整的 Agent 流程（含多次 DB 查询），进一步加剧锁竞争。

**风险评级**：**严重** — 架构级瓶颈，限制并发扩展能力。

**建议**：

1. **读写分离连接池**：
   - 写连接：1 个（SQLite 写操作需串行）。
   - 读连接：多个（WAL 模式支持多连接并发读）。
   - 使用 `aiosqlite` 创建多个读连接，配合读写锁（`asyncio.Lock` 用于写，`asyncio.Semaphore` 或简单列表管理读连接）。

2. **连接池实现示例**：
   ```python
   class DatabasePool:
       def __init__(self, db_path: str, max_read_connections: int = 4):
           self.db_path = db_path
           self._write_conn = None
           self._write_lock = asyncio.Lock()
           self._read_pool = asyncio.Queue(maxsize=max_read_connections)
           self._read_semaphore = asyncio.Semaphore(max_read_connections)
   
       async def open(self):
           self._write_conn = await aiosqlite.connect(self.db_path)
           await self._write_conn.execute("PRAGMA journal_mode=WAL")
           for _ in range(self._read_pool.maxsize):
               conn = await aiosqlite.connect(self.db_path)
               conn.row_factory = aiosqlite.Row
               await self._read_pool.put(conn)
   
       @asynccontextmanager
       async def write_cursor(self):
           async with self._write_lock:
               c = await self._write_conn.cursor()
               try:
                   yield c
                   await self._write_conn.commit()
               except:
                   await self._write_conn.rollback()
                   raise
               finally:
                   await c.close()
   
       @asynccontextmanager
       async def read_cursor(self):
           async with self._read_semaphore:
               conn = await self._read_pool.get()
               try:
                   c = await conn.cursor()
                   yield c
               finally:
                   await c.close()
                   await self._read_pool.put(conn)
   ```

3. **替代方案**：若短期内不想引入连接池，至少为只读查询提供独立的只读连接（`uri=true&mode=ro`），绕过写锁。

---

#### 2.6.2 `SessionManager` 多 session 共享 Repository —— 高风险

**文件**：`web/session.py:121-144`

```python
class SessionManager:
    async def open(self):
        self.db = Database(self.config.db_path)
        await self.db.open()
        self.repo = Repository(self.db)

    def get_or_create(self, session_id: Optional[str] = None) -> tuple[str, WebAgent]:
        sid = session_id or uuid.uuid4().hex[:12]
        if sid not in self._sessions:
            self._sessions[sid] = WebAgent(self.config, self.db, self.repo)
        return sid, self._sessions[sid]
```

**分析**：

- 所有 `WebAgent` 实例共享同一个 `db` 和 `repo`。
- 虽然 `SessionManager._lock`（`web/session.py:129`）保护 session 字典的并发访问，但数据库操作锁在 `Database._lock`，不在 `SessionManager`。
- 这意味着 session A 的数据库查询会阻塞 session B 的查询，即使它们操作完全不同的数据。

**风险评级**：**高风险**

**建议**：

- 每个 `WebAgent` 拥有独立的 `Database` 连接（读连接可从池中获取）。
- 或至少将 `Repository` 设计为无状态，仅依赖连接池提供的临时连接。

---

### 2.7 WAL 模式性能

#### 2.7.1 WAL 模式开启但配置不完整 —— 高风险

**文件**：`storage/database.py:21`

```python
await self.conn.execute("PRAGMA journal_mode=WAL")
```

**分析**：

- WAL（Write-Ahead Logging）模式已启用，这是正确的方向：它允许读操作与写操作并发（读者读取旧版本，写者追加到 WAL 文件）。
- 但 SQLite 的 WAL 模式性能高度依赖相关 PRAGMA 配置，当前代码**仅设置了 journal_mode=WAL**，未配置以下关键参数：

| PRAGMA | 当前值 | 建议值 | 作用 |
|--------|--------|--------|------|
| `synchronous` | 默认 FULL | NORMAL | 减少 fsync 频率，提升写性能 |
| `wal_autocheckpoint` | 默认 1000 | 100~500 | 控制 WAL 文件大小，避免过大 |
| `cache_size` | 默认 -2000 (2MB) | -64000 (64MB) | 增加页缓存，减少 I/O |
| `temp_store` | 默认 default | MEMORY | 临时表和索引放内存 |
| `mmap_size` | 默认 0 | 268435456 (256MB) | 内存映射数据库文件 |
| `busy_timeout` | 默认 0 | 5000 | 写冲突时等待而非立即返回 BUSY |

**性能影响**：

- `synchronous=FULL`（默认）下，每次 commit 都执行两次 fsync，写延迟高。
- 无 `busy_timeout` 时，若写锁被持有，新写操作立即返回 `SQLITE_BUSY`，可能导致应用层异常（虽然当前 `asyncio.Lock` 串行化了写，但未来引入连接池后此问题会暴露）。
- 默认缓存 2MB 对于频繁访问的数据库偏小。

**风险评级**：**高风险**

**建议**：

```python
await self.conn.execute("PRAGMA journal_mode=WAL")
await self.conn.execute("PRAGMA synchronous=NORMAL")
await self.conn.execute("PRAGMA wal_autocheckpoint=500")
await self.conn.execute("PRAGMA cache_size=-64000")  # 64MB
await self.conn.execute("PRAGMA temp_store=MEMORY")
await self.conn.execute("PRAGMA mmap_size=268435456")  # 256MB
await self.conn.execute("PRAGMA busy_timeout=5000")
```

---

#### 2.7.2 WAL 文件无上限管理 —— 中等风险

**分析**：

- WAL 文件（`*.db-wal`）在 checkpoint 前持续增长。若应用长时间运行且写频繁，WAL 文件可能膨胀至数百 MB。
- 当前代码无手动 checkpoint 逻辑，完全依赖 SQLite 的自动 checkpoint（默认 1000 页）。
- 在 `Database.close()`（`database.py:136-140`）时，若 WAL 文件很大，关闭连接可能触发隐式 checkpoint，导致关闭延迟。

**风险评级**：**中等风险**

**建议**：

- 在 consolidation 等批量写操作后，显式执行 `PRAGMA wal_checkpoint(TRUNCATE)` 或 `PASSIVE`：
  ```python
  await self.conn.execute("PRAGMA wal_checkpoint(PASSIVE)")
  ```
- 监控 WAL 文件大小，超过阈值时主动 checkpoint。

---

### 2.8 查询结果集大小限制

#### 2.8.1 `get_all_active_facts(limit=50)` 在 Layer 1 加载全量候选池 —— 高风险

**文件**：`memory/retrieval.py:32`

```python
hot_facts = self.ltm.get_all_active_facts(limit=50)
```

**分析**：

- Layer 1 "Hot Memory" 的设计意图是加载高评分事实作为基础上下文。
- 但 `limit=50` 意味着每次用户消息都从数据库加载 50 条完整记录（含所有列），即使最终只选 top 10。
- 在 `max_facts=200` 时，50/200 = 25% 的数据被加载；若调高上限，比例下降，但绝对数量增加。
- 更关键的是：这 50 条记录在 `_hybrid_score`（`memory/retrieval.py:106-134`）中，每条都需反序列化 embedding BLOB（512 维 float32 = 2KB），计算向量点积。50 条 × 2KB = 100KB 数据反序列化 + 50 次点积计算。

**风险评级**：**高风险**

**建议**：

1. **数据库层预过滤**：利用 embedding 在数据库层做相似度过滤，而非加载全部候选后内存计算。
   - SQLite 无原生向量索引，但可通过 `sqlite-vec` 扩展实现。
   - 或维护一个内存中的 FAISS 索引，在应用层做 ANN 搜索，避免数据库加载。

2. **分层加载**：
   - Layer 1 仅加载 top 10（而非 50），作为最核心上下文。
   - Layer 2 的语义搜索扩展至 200 条候选，但仅在需要时加载（延迟加载）。

3. **embedding 缓存**：在 `EmbeddingEngine` 中集成 `EmbeddingCache`（`memory/embeddings.py:86-117`），当前虽实现了缓存类，但 `EmbeddingEngine` 未实际使用它（`memory/embeddings.py:13-83` 中无 `EmbeddingCache` 引用）。

---

#### 2.8.2 `_embed_new_items` 的 `LIMIT 50` 分批 —— 正面案例

**文件**：`memory/consolidation.py:272-275`

```sql
SELECT id, {col_list} FROM {table} WHERE embedding IS NULL LIMIT 50
```

**分析**：

- 使用 `LIMIT 50` 分批处理无 embedding 的记录，避免一次性加载过多数据。
- 但如前所述，此代码存在同步/异步混用的运行时风险。

**风险评级**：**低风险**（设计正确，实现有缺陷）

---

#### 2.8.3 `search_experiences` 的 `LIMIT 15` 与 `_search_experiences_semantic` 的 `LIMIT 5` 不一致 —— 中等风险

**文件**：`memory/retrieval.py:139`、`line 160`

```python
# _search_experiences_semantic 中
all_exp = self.ltm.search_experiences(keywords, limit=15)  # 加载 15 条
...
return [exp for exp, _ in scored[:5]]  # 只返回 5 条
```

**分析**：

- 关键词搜索加载 15 条，语义重排后仅返回 5 条，10 条被丢弃。
- 这 15 条记录的反序列化、embedding 解码、点积计算均为无效开销。
- 若关键词为空，回退到 `SELECT * WHERE is_archived=0 ORDER BY ... LIMIT 15`，仍需扫描全表。

**风险评级**：**中等风险**

**建议**：

- 在语义搜索路径下，直接对 `embedding IS NOT NULL` 的记录做向量搜索，无需关键词预过滤。
- 若必须保留双路径，将关键词搜索的 `limit` 降至 5-8，减少候选池大小。

---

#### 2.8.4 `ContextManager.compress` 的 8000 字符截断 —— 中等风险

**文件**：`core/context_manager.py:72-98`

```python
if len(text) > 8000:
    text = text[-8000:]
```

**分析**：

- 虽非数据库查询，但 `compress` 方法在上下文超限（`COMPRESS_THRESHOLD = 144_000` tokens）时触发，将历史消息压缩为摘要。
- 8000 字符的硬编码截断可能导致关键信息丢失，且与 token 估算逻辑（`estimate_tokens`）不一致。
- 更关键的是，压缩后调用 `self._short_term.clear()`（`core/context_manager.py:95`），清空短期记忆，但数据库中仍保留完整历史。这导致后续对话若需回溯，必须从数据库重新加载，增加查询压力。

**风险评级**：**中等风险**

**建议**：

- 将截断阈值与 `estimate_tokens` 对齐，按 token 数而非字符数截断。
- 考虑在数据库中存储压缩摘要，避免重复压缩计算。

---

## 三、汇总统计

### 3.1 问题分类统计

| 类别 | 数量 | 严重 | 高风险 | 中等风险 | 低风险 |
|------|------|------|--------|----------|--------|
| 全表扫描（LIKE） | 2 | 1 | 1 | 0 | 0 |
| 索引缺失 | 4 | 1 | 2 | 1 | 0 |
| 批量操作 | 4 | 0 | 0 | 3 | 1 |
| N+1 查询 | 3 | 0 | 1 | 2 | 0 |
| 连接池/并发 | 2 | 1 | 1 | 0 | 0 |
| WAL 模式配置 | 2 | 0 | 1 | 1 | 0 |
| 结果集限制 | 4 | 0 | 1 | 2 | 1 |
| **合计** | **21** | **3** | **7** | **11** | **3** |

> 注：部分问题跨类别，总数大于独立问题数。

### 3.2 文件风险热力图

| 文件 | 严重 | 高风险 | 中等风险 | 低风险 | 小计 |
|------|------|--------|----------|--------|------|
| `storage/repository.py` | 1 | 4 | 2 | 1 | 8 |
| `storage/database.py` | 1 | 2 | 1 | 0 | 4 |
| `memory/retrieval.py` | 1 | 1 | 3 | 0 | 5 |
| `memory/consolidation.py` | 0 | 1 | 3 | 1 | 5 |
| `memory/long_term.py` | 0 | 0 | 1 | 0 | 1 |
| `web/session.py` | 0 | 1 | 0 | 0 | 1 |
| `web/server.py` | 0 | 0 | 1 | 0 | 1 |
| `core/context_manager.py` | 0 | 0 | 1 | 0 | 1 |
| `tools/memory_tools.py` | 0 | 0 | 1 | 0 | 1 |

### 3.3 优先级修复清单

#### P0 — 立即修复（阻塞性能或可扩展性）

1. **为 `user_facts` 和 `experiences` 建立复合索引**（`storage/database.py`）
   - `idx_facts_active_score`、`idx_exps_archived_score` 等。
   - 这是成本最低、收益最高的优化。

2. **完善 WAL 模式 PRAGMA 配置**（`storage/database.py:21-22`）
   - 添加 `synchronous=NORMAL`、`cache_size`、`busy_timeout` 等。

3. **修复 `search_facts` 和 `search_experiences` 的全表扫描**（`storage/repository.py`）
   - 引入 FTS5 或至少为高频查询建立覆盖索引。

#### P1 — 短期修复（显著改善并发和延迟）

4. **实现读写分离连接池**（`storage/database.py`）
   - 1 个写连接 + N 个读连接，解除单连接串行瓶颈。

5. **合并 `MemoryConsolidator` 的 N+1 查询为单次事务**（`memory/consolidation.py`）
   - 减少事务开销，降低 WAL 文件膨胀速度。

6. **优化 `Layer 1` 候选池大小**（`memory/retrieval.py:32`）
   - 将 `get_all_active_facts(limit=50)` 降至 20-30，或实现延迟加载。

7. **启用 `EmbeddingCache`**（`memory/embeddings.py`）
   - 在 `EmbeddingEngine` 中集成缓存，避免重复编码相同 query。

#### P2 — 中期优化（架构级改进）

8. **评估迁移至 `sqlite-vec` 或专用向量数据库**
   - 替代基于 LIKE 和内存点积的混合搜索。

9. **将 `Repository` 设计为无状态，支持连接池**
   - 每个 `WebAgent` 或每次请求从池中获取连接。

10. **实现数据库查询性能监控**
    - 记录每条 SQL 的执行时间、扫描行数、是否使用索引（通过 `PRAGMA optimize` 或 `EXPLAIN QUERY PLAN` 自动分析）。

---

## 四、结论

AI Friend 项目的数据库层在功能上满足了当前需求，但在性能和可扩展性方面存在显著短板。核心问题可归纳为三点：

1. **查询模式低效**：`LIKE '%query%'` 全表扫描贯穿所有文本检索路径，且核心表无任何辅助索引，导致查询性能随数据量线性恶化。
2. **并发架构瓶颈**：单连接 + 全局锁的设计使 SQLite 的 WAL 并发读优势完全丧失，Web 模式下的多 session 共享同一串行化通道。
3. **事务管理粗放**：N+1 查询、逐条 upsert、自动 commit 等模式累积了大量不必要的事务开销，且未利用 SQLite 的批量操作能力。

建议按照 P0/P1/P2 优先级分阶段实施修复，优先建立索引和优化 WAL 配置（成本低、见效快），随后引入连接池和批量事务（架构改进），中期评估向量数据库迁移（长期可扩展性）。同时，建议建立数据库性能基线测试，量化每次优化的实际收益。

---

*报告生成时间：2026-05-31*  
*审查人：AI Friend 代码审查系统*  
*关联文档：doc/round01-storage-layer.md、doc/round02-long-term-memory.md、doc/milestones-and-issues.md*
