# AI Friend 项目数据隐私与隔离安全审查报告（第3轮）

**审查日期**: 2026-05-31
**审查范围**: `web/session.py`, `storage/repository.py`, `storage/database.py`, `memory/long_term.py`, `core/personality.py`, `models/personality.py` 及上下游调用链（`web/server.py`, `core/agent.py`, `core/message_handler.py`, `memory/retrieval.py`, `memory/consolidation.py`, `memory/short_term.py`, `models/conversation.py`, `models/memory.py`）
**审查人**: Claude Code (Sonnet 4.6)
**风险评级定义**:
- **严重（Critical）**: 可导致用户间敏感数据完全互通、大规模隐私泄露、违反 GDPR 等法规
- **高危（High）**: 可导致特定用户数据被其他用户访问、情绪/行为画像交叉污染
- **中危（Medium）**: 可导致有限信息泄露、数据归属模糊、合规风险
- **低危（Low）**: 防御纵深缺失、审计追踪不足、配置不当

---

# 概述

AI Friend 项目采用 Web 端（FastAPI + WebSocket）与 CLI 端双入口架构。Web 端通过 `SessionManager` 管理多用户会话，每个会话持有独立的 `WebAgent` 实例。然而，在数据隔离层面存在**系统性架构缺陷**：所有会话共享同一个 SQLite 数据库实例和同一个 `personality.json` 文件，数据库 Schema 中**没有任何用户或会话标识字段**，导致用户事实、经历、反思、对话历史、关系度量、情绪状态等全部数据在物理层混合存储，逻辑层缺乏隔离屏障。

本次审查聚焦 8 个核心隐私维度，共发现 **28 项安全问题**，其中严重 4 项、高危 8 项、中危 11 项、低危 5 项。

核心风险集中在：
1. **数据库层零隔离**：`user_facts`、`experiences`、`reflections`、`conversation_turns`、`relationship_metrics` 五张核心表均无 `session_id` 或 `user_id` 字段，所有用户数据物理混合。
2. **personality.json 全局共享**：情绪状态、人格配置、情感事件历史被所有会话读写覆盖，形成"情绪传染病"效应。
3. **短期记忆恢复跨会话泄漏**：`WebAgent.__init__` 从数据库恢复最近 30 条对话历史时，不区分会话来源，导致用户 A 的历史对话出现在用户 B 的上下文中。
4. **记忆检索全库暴露**：`MemoryRetriever` 的检索逻辑不附加任何会话过滤，用户 A 查询时可能召回用户 B 的隐私事实。
5. **关系度量全局单一**：`relationship_metrics` 表只有 4 行（trust/familiarity/intimacy/playfulness），所有用户共享同一组关系值。
6. **情绪状态跨会话传染**：一个用户的负面情绪输入会改变全局 personality.json，影响后续所有会话的情绪基线。
7. **主动行为隐私风险**：`ProactivityManager` 和 `SleepManager` 基于全局情绪/关系状态生成主动消息，可能将用户 A 的隐私经历作为对用户 B 的主动话题。
8. **GDPR/合规性全面缺失**：无数据主体标识、无删除权实现、无数据导出机制、无保留期限控制、无同意记录。

---

## 详细发现

### 1. 多用户会话间的数据隔离

#### 1.1 数据库 Schema 完全缺失会话隔离字段（严重）

**文件**: `storage/database.py`
**行号**: 55-109（Schema 定义）

**代码**:
```python
# 第 55-69 行
CREATE TABLE IF NOT EXISTS user_facts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    fact_key TEXT NOT NULL,
    fact_value TEXT NOT NULL,
    confidence REAL DEFAULT 1.0,
    importance REAL DEFAULT 0.5,
    source_turn INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    recall_count INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    composite_score REAL DEFAULT 1.0,
    UNIQUE(category, fact_key)
);

# 第 71-84 行
CREATE TABLE IF NOT EXISTS experiences (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    summary TEXT NOT NULL,
    emotional_tone TEXT,
    significance REAL DEFAULT 0.5,
    importance REAL DEFAULT 0.5,
    tags TEXT DEFAULT '[]',
    turn_range_start INTEGER,
    turn_range_end INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    recall_count INTEGER DEFAULT 0,
    is_archived INTEGER DEFAULT 0,
    composite_score REAL DEFAULT 0.5
);

# 第 86-94 行
CREATE TABLE IF NOT EXISTS reflections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    content TEXT NOT NULL,
    insight_type TEXT,
    related_experience_ids TEXT DEFAULT '[]',
    significance REAL DEFAULT 0.5,
    is_active INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

# 第 96-100 行
CREATE TABLE IF NOT EXISTS relationship_metrics (
    dimension TEXT PRIMARY KEY,
    value REAL DEFAULT 0.3,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

# 第 102-109 行
CREATE TABLE IF NOT EXISTS conversation_turns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    turn_number INTEGER NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
    content TEXT NOT NULL,
    emotional_state TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**分析**:
五张核心数据表（`user_facts`、`experiences`、`reflections`、`relationship_metrics`、`conversation_turns`）中**没有任何字段用于标识数据属于哪个用户会话**。这意味着：

- 用户 A 告诉 AI 的隐私信息（如"我有抑郁症"、"我住在某某小区"）被存储为全局 `user_facts`，用户 B 在后续对话中查询相关话题时，AI 可能召回并引用用户 A 的隐私信息。
- `conversation_turns` 表存储了所有用户的全部对话历史，按 `id` 排序后 `get_recent_turns` 会返回最近 30 条，不论这些对话来自哪个用户。
- `relationship_metrics` 只有 4 行数据，所有用户共享 trust/familiarity/intimacy/playfulness 值。用户 A 与 AI 建立的亲密关系会被用户 B 继承。

**风险评级**: 严重（Critical）
**修复建议**:
1. 在所有核心表中添加 `session_id TEXT NOT NULL` 字段
2. 在 `SessionManager.get_or_create()` 中为每个新会话生成持久化的 `session_id`
3. 所有 Repository 查询方法增加 `WHERE session_id = ?` 过滤条件
4. 考虑增加 `user_id` 层，支持同一用户多设备/多会话场景

---

#### 1.2 SessionManager 会话映射与数据库实例共享（高危）

**文件**: `web/session.py`
**行号**: 121-144

**代码**:
```python
# 第 121-144 行
class SessionManager:
    def __init__(self, config: Config):
        self.config = config
        self.db: Database | None = None
        self.repo: Repository | None = None
        self._sessions: dict[str, WebAgent] = {}
        ...

    async def open(self):
        self.db = Database(self.config.db_path)
        await self.db.open()
        self.repo = Repository(self.db)

    def get_or_create(self, session_id: Optional[str] = None) -> tuple[str, WebAgent]:
        with self._lock:
            sid = session_id or uuid.uuid4().hex[:12]
            if sid not in self._sessions:
                logger.info(f"[session] create: {sid}")
                self._sessions[sid] = WebAgent(self.config, self.db, self.repo)
            else:
                logger.debug(f"[session] restore: {sid}")
            return sid, self._sessions[sid]
```

**分析**:
`SessionManager` 只创建一个 `Database` 和一个 `Repository` 实例，所有 `WebAgent` 共享同一个 `self.db` 和 `self.repo`。虽然 `Database` 使用 `asyncio.Lock` 保证并发安全，但**锁只保护操作原子性，不保护数据隔离性**。所有会话的 SQL 查询都命中同一个物理数据库文件，且查询条件中无会话过滤，导致数据完全互通。

**风险评级**: 高危（High）
**修复建议**:
1. 为每个会话创建独立的 `Repository` 实例（仍共享 `Database` 连接，但查询带 `session_id` 过滤）
2. 或在 `WebAgent` 中注入 `session_id`，所有 LTM 操作自动附加会话过滤

---

#### 1.3 WebAgent 构造时共享 LTM 和 Retriever（高危）

**文件**: `web/session.py`
**行号**: 27-78

**代码**:
```python
# 第 27-78 行
class WebAgent:
    def __init__(self, config: Config, db: Database, repo: Repository):
        self.config = config
        self.db = db
        self.repo = repo
        self.personality = Personality.load(config.personality_file)
        self.ltm = LongTermMemory(repo)          # 共享 repo
        self.short_term = ConversationBuffer(maxlen=config.short_term_capacity)
        ...
        self.retriever = MemoryRetriever(self.ltm, embedding_engine=embed_engine)
        ...
        self.agent = Agent(
            personality=self.personality, provider=self.provider,
            ltm=self.ltm, retriever=self.retriever,
            consolidator=self.consolidator, short_term=self.short_term,
            config=config,
        )
```

**分析**:
每个 `WebAgent` 虽然有自己的 `short_term`（内存中的对话缓冲区），但 `ltm`、`retriever`、`consolidator` 都引用同一个 `repo`。由于 `repo` 的查询方法不带 `session_id` 过滤，**所有 WebAgent 实例实际上共享同一个长期记忆空间**。`ConversationBuffer` 的隔离是虚假的——它只在进程内存中隔离，而持久化层完全混合。

**风险评级**: 高危（High）
**修复建议**:
1. `LongTermMemory` 初始化时接收 `session_id`，所有 `_store_*` 和 `_search_*` 方法自动附加 `session_id`
2. `MemoryRetriever` 初始化时接收 `session_id`，`retrieve_for_query` 只检索当前会话的记忆

---

### 2. personality.json 全局共享的隐私风险

#### 2.1 情绪状态全局持久化与覆盖（严重）

**文件**: `core/personality.py`
**行号**: 113-116

**代码**:
```python
# 第 113-116 行
    def save(self, path: str) -> None:
        logger.info(f"[personality] saved to: {path}")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
```

**文件**: `web/session.py`
**行号**: 84-102

**代码**:
```python
# 第 84-102 行
    def process_message(self, user_input: str) -> str:
        result = self.agent.process_message(
            user_input, on_token=self._on_token_callback,
        )
        self.personality.save(self.config.personality_file)
        return result

    def process_proactive(self, on_token=None, *, intent=None) -> str:
        result = self.agent.process_proactive(
            on_token=on_token or self._on_token_callback,
            intent=intent,
        )
        self.personality.save(self.config.personality_file)
        return result

    def process_explore(self, intent=None) -> str | None:
        result = self.agent.process_explore(intent=intent)
        self.personality.save(self.config.personality_file)
        return result
```

**分析**:
每个 `WebAgent` 在 `__init__` 时从同一个 `personality.json` 加载情绪状态，在处理完每条消息后**将修改后的情绪状态写回同一个文件**。这导致：

1. **写覆盖竞争**：多个会话并发处理消息时，后完成的会话会覆盖先完成会话的情绪写入，导致情绪状态丢失或错乱。
2. **情绪传染病**：用户 A 发送负面消息（如辱骂、抱怨），AI 的 `valence` 下降、`anger` 上升。这个情绪状态被保存到 `personality.json`。随后用户 B 发起会话，加载的却是用户 A 造成的负面情绪状态，AI 可能对用户 B 表现出不应有的冷淡、焦虑或愤怒。
3. **情感画像混合**：`emotion_events` 列表中混合了所有用户的触发事件。从 `personality.json` 中可以看到，emotion_events 包含了"我要听《加州旅馆》"、"你好"、"瞎扯文件内容"等不同用户的输入片段，这些事件在后续被注入 LLM prompt 时，可能泄露给其他用户。

**风险评级**: 严重（Critical）
**修复建议**:
1. **每个会话独立的情绪状态**：将情绪状态从 `personality.json` 分离，按 `session_id` 存储到数据库或独立文件（如 `data/emotions/{session_id}.json`）
2. **人格配置与情绪状态解耦**：`personality.json` 只保存静态人格配置（name, traits, backstory 等），情绪状态作为动态数据按会话隔离
3. 在 `Personality.load/save` 中增加 `session_id` 参数，选择对应的存储路径

---

#### 2.2 情绪事件历史包含用户原始输入片段（高危）

**文件**: `models/personality.py`
**行号**: 239-262

**代码**:
```python
# 第 239-262 行
    def record_emotion_event(self, trigger: str, context: str = "") -> None:
        dom = self.dominant_emotion
        primary_intensity = max(
            self.anger, self.sadness, self.joy, self.fear,
            self.surprise, self.disgust, self.anticipation, self.trust
        )
        if primary_intensity < 0.6:
            return

        event = {
            "timestamp": time.time(),
            "trigger": trigger[:100],
            "primary_emotion": dom,
            "intensity": primary_intensity,
            "context": context[:200],
        }
        self.emotion_events.append(event)
        ...
```

**文件**: `core/agent.py`
**行号**: 212-215

**代码**:
```python
# 第 212-215 行
        self.personality.emotion.record_emotion_event(
            trigger=last_user_turn[:100] if last_user_turn else "",
            context=last_user_turn[:200] if last_user_turn else "",
        )
```

**分析**:
`record_emotion_event` 将用户原始输入的**前 100 字符作为 trigger、前 200 字符作为 context** 存入 `emotion_events`。由于情绪状态全局共享，这些用户输入片段被持久化到 `personality.json` 中。从实际 `personality.json` 中可以看到：

```json
{
  "trigger": "瞎扯，你自己看看我们有什么音乐",
  "context": "瞎扯，你自己看看我们有什么音乐"
}
```

这些片段在后续被注入 LLM prompt 时（通过 `get_recent_emotion_events`），可能被其他用户看到。更严重的是，如果用户输入包含敏感信息（如"我的密码是 xxx"、"我住在 xx 路 xx 号"），且该输入触发了强情绪反应，这段敏感文本将被永久记录并可能泄露。

**风险评级**: 高危（High）
**修复建议**:
1. 情绪事件按会话隔离存储，不进入全局 `personality.json`
2. 对 `trigger` 和 `context` 进行敏感信息检测（如正则匹配密码、地址、身份证号模式），命中则脱敏或拒绝记录
3. 情绪事件保留期限控制（如只保留最近 7 天）

---

#### 2.3 人格配置全局共享（中危）

**文件**: `core/personality.py`
**行号**: 88-111

**分析**:
`Personality.load()` 从单个 `personality.json` 加载人格配置（name, traits, speaking_style, backstory, interests）。虽然人格配置通常可以共享，但如果未来支持用户自定义人格（如用户 A 将 AI 设为"温柔 therapist"，用户 B 将 AI 设为"嘴贫损友"），当前的单文件架构无法支持。目前 `personality.json` 中存储的是"嘴贫损友"风格，所有用户强制共享。

**风险评级**: 中危（Medium）
**修复建议**:
1. 人格配置与情绪状态分离存储
2. 支持按会话或按用户加载不同人格配置

---

### 3. 数据库中 conversation_turns 无 session_id 的问题

#### 3.1 对话历史全局混合存储（严重）

**文件**: `storage/database.py`
**行号**: 102-109

**代码**:
```sql
CREATE TABLE IF NOT EXISTS conversation_turns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    turn_number INTEGER NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
    content TEXT NOT NULL,
    emotional_state TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**分析**:
`conversation_turns` 表没有 `session_id` 字段。所有用户的所有对话按全局 `id` 自增顺序存储。`Repository.get_recent_turns()` 按 `id DESC LIMIT ?` 取最近 N 条，完全不区分用户。

**风险评级**: 严重（Critical）
**修复建议**:
1. 添加 `session_id TEXT NOT NULL` 字段
2. `get_recent_turns` 改为 `WHERE session_id = ? ORDER BY id DESC LIMIT ?`
3. 历史数据迁移：为现有数据分配默认 session_id（如 "legacy"）

---

#### 3.2 短期记忆恢复时的跨会话泄漏（高危）

**文件**: `web/session.py`
**行号**: 35-37

**代码**:
```python
# 第 35-37 行
        # Restore recent conversation from DB (fixes #98)
        for t in repo.get_recent_turns_sync(30):
            self.short_term.add_turn(t["role"], t["content"])
```

**分析**:
`WebAgent.__init__` 在创建新会话时，从数据库恢复最近 30 条对话历史。由于 `get_recent_turns_sync` 不区分 `session_id`，这 30 条对话可能来自**任意用户**。例如：

- 用户 A 刚刚与 AI 讨论了"我的离婚官司进展"
- 用户 B 打开网页，创建新会话
- 用户 B 的 `short_term` 中加载了用户 A 的离婚对话历史
- AI 可能在对用户 B 的第一条回复中引用"你刚才说的离婚的事情"

这是极其严重的隐私泄漏。

**风险评级**: 高危（High）
**修复建议**:
1. 立即在 `get_recent_turns_sync` 中添加 `session_id` 过滤
2. 新会话创建时不自动恢复任何历史对话，或只恢复该 `session_id` 对应的历史
3. 在 `WebAgent.__init__` 中传入 `session_id`，所有数据库操作附加过滤

---

#### 3.3 对话轮次计数器全局共享（中危）

**文件**: `core/agent.py`
**行号**: 52, 175-177

**代码**:
```python
# 第 52 行
        self.turn_count = 0

# 第 175-177 行
            self.ltm.repo.insert_turn_sync(self.turn_count, "assistant", final_text,
                                      str(self.personality.emotion.to_dict()))
            self.turn_count += 1
```

**分析**:
`turn_count` 是每个 `Agent` 实例的内存计数器，从 0 开始。但写入数据库的 `turn_number` 在不同会话间会重复（都从 0 开始）。更严重的是，`source_turn` 字段在 `user_facts` 和 `experiences` 表中引用这个不唯一的 `turn_number`，导致数据归属和审计追踪完全失效。

**风险评级**: 中危（Medium）
**修复建议**:
1. `turn_number` 改为全局唯一或按会话唯一（如 `session_id + turn_number` 复合键）
2. 或弃用 `turn_number` 作为外键引用，改用全局唯一的 `conversation_turns.id`

---

### 4. 用户事实/经历/反思的归属

#### 4.1 user_facts 无用户归属字段（高危）

**文件**: `storage/database.py`
**行号**: 55-69

**分析**:
`user_facts` 表存储"关于用户的事实"（如"最喜欢的食物 = 意大利面"、"职业 = 程序员"），但表中没有 `session_id` 或 `user_id`。`UNIQUE(category, fact_key)` 约束意味着**所有用户共享同一命名空间**。例如：

- 用户 A: `("preference", "最喜欢的食物", "意大利面")`
- 用户 B: `("preference", "最喜欢的食物", "寿司")`

用户 B 的写入会因为 `ON CONFLICT` 逻辑覆盖或合并用户 A 的数据。`upsert_fact` 中的冲突解决策略（`CASE WHEN excluded.confidence >= user_facts.confidence THEN excluded.fact_value ELSE user_facts.fact_value END`）会导致用户间的事实互相覆盖。

**风险评级**: 高危（High）
**修复建议**:
1. 添加 `session_id TEXT NOT NULL` 字段
2. 将 `UNIQUE(category, fact_key)` 改为 `UNIQUE(session_id, category, fact_key)`
3. 所有 `search_facts`、`get_active_facts` 方法增加 `WHERE session_id = ?`

---

#### 4.2 experiences 无用户归属字段（高危）

**文件**: `storage/database.py`
**行号**: 71-84

**分析**:
`experiences` 表存储"共同经历"的摘要（如"一起讨论了哲学问题"、"用户分享了旅行经历"）。这些经历高度个人化，但当前架构下所有用户的经历混合存储。`MemoryRetriever.get_recent_experiences(limit=5)` 会返回最近 5 条经历，不论来自哪个用户。

**风险评级**: 高危（High）
**修复建议**:
1. 添加 `session_id TEXT NOT NULL` 字段
2. 所有 experience 查询方法增加会话过滤

---

#### 4.3 reflections 无用户归属字段（中危）

**文件**: `storage/database.py`
**行号**: 86-94

**分析**:
`reflections` 表存储 AI 对用户的"反思"（如"用户似乎最近压力很大"、"用户对技术话题很感兴趣"）。这些反思基于特定用户的对话历史生成，但当前架构下所有反思混合存储。一个关于用户 A 的反思可能被注入到用户 B 的 prompt 中。

**风险评级**: 中危（Medium）
**修复建议**:
1. 添加 `session_id TEXT NOT NULL` 字段
2. `get_recent_reflections` 增加会话过滤

---

#### 4.4 记忆整合时的归属混乱（中危）

**文件**: `memory/consolidation.py`
**行号**: 98-126, 169-223

**分析**:
`MemoryConsolidator` 在整合记忆时：
1. `_extract_facts`: 从 `pending_buffer` 提取事实并调用 `ltm.store_fact()` —— 事实写入全局表
2. `_summarize_experience`: 生成经历摘要并调用 `ltm.store_experience()` —— 经历写入全局表
3. `_generate_reflection`: 基于 `get_recent_experiences(limit=5)` 和 `get_all_active_facts(limit=10)` 生成反思 —— 这些检索不区分会话，可能基于用户 A 的数据生成关于用户 B 的反思

**风险评级**: 中危（Medium）
**修复建议**:
1. `MemoryConsolidator` 初始化时接收 `session_id`
2. 所有 `ltm.*` 调用自动附加会话过滤

---

### 5. 短期记忆恢复时的隐私泄漏

#### 5.1 新会话继承任意用户的历史对话（高危）

已在 **3.2** 中详细描述。此处补充技术细节：

**文件**: `storage/repository.py`
**行号**: 228-237

**代码**:
```python
# 第 228-237 行
    async def get_recent_turns(self, limit: int = 30) -> list[dict]:
        async with self.db.cursor() as c:
            await c.execute("""
                SELECT role, content FROM conversation_turns
                ORDER BY id DESC LIMIT ?
            """, (limit,))
            rows = await c.fetchall()
        rows = list(rows)
        rows.reverse()
        return [{"role": r[0], "content": r[1]} for r in rows]
```

**分析**:
查询语句 `ORDER BY id DESC LIMIT ?` 没有任何 `WHERE` 条件过滤。在 Web 场景下，如果用户 A 刚刚结束会话，用户 B 创建新会话，用户 B 的 `short_term` 会加载用户 A 的最后几条消息。即使用户 B 提供了不同的 `session_id`，由于数据库层不识别 `session_id`，隔离完全失效。

**风险评级**: 高危（High）
**修复建议**:
同 3.2。

---

#### 5.2 短期记忆缓冲区无加密（低危）

**文件**: `memory/short_term.py`
**行号**: 13-84

**分析**:
`ConversationBuffer` 将对话历史存储在内存中的 `deque`，无加密。在多用户服务器环境中，如果发生内存转储（core dump）或调试访问，所有用户的近期对话内容可能被提取。虽然这是本地部署场景，但如果未来迁移到云服务器或容器环境，此风险会放大。

**风险评级**: 低危（Low）
**修复建议**:
1. 对敏感短期记忆进行内存级加密（如使用 `cryptography.fernet`）
2. 或至少对 `content` 字段进行最小化存储（不保留完整历史超过必要时间）

---

### 6. 情绪状态在会话间的传染

#### 6.1 情绪状态全局读写竞争（严重）

已在 **2.1** 中详细描述。此处补充并发场景分析：

**并发竞争场景**:
```
T1: 用户 A 发送消息 -> WebAgent A 处理 -> 情绪 valence 从 0.4 降至 -0.2
T2: 用户 B 发送消息 -> WebAgent B 处理 -> 情绪 valence 从 0.4 降至 0.1
T3: WebAgent A 保存 personality.json (valence = -0.2)
T4: WebAgent B 保存 personality.json (valence = 0.1)  <-- 覆盖 T3 的写入
```

由于 `Personality.save()` 不是原子操作（先读文件、修改内存、写回文件），且 Python 的 GIL 不保护文件 I/O 的原子性，在并发场景下极易发生写覆盖。虽然 `SessionManager` 使用 `threading.Lock` 保护 `_sessions` 字典，但 `WebAgent.process_message()` 在释放 `SessionManager` 锁之后才调用 `personality.save()`，因此保存操作不在锁保护范围内。

**风险评级**: 严重（Critical）
**修复建议**:
1. 情绪状态按会话隔离，彻底消除竞争条件
2. 如果必须共享全局情绪，使用文件锁（`fcntl` 或 `portalocker`）保护 `personality.save()`

---

#### 6.2 情绪基线（baseline）被全局修改（高危）

**文件**: `models/personality.py`
**行号**: 210-238

**代码**:
```python
# 第 210-238 行
    def decay(self) -> None:
        # Slow decay of baseline toward mood (hours-level)
        self.baseline_valence += (self.mood_valence - self.baseline_valence) * self.mood_decay_rate
        self.baseline_arousal += (self.mood_arousal - self.baseline_arousal) * self.mood_decay_rate
```

**分析**:
`decay()` 方法不仅衰减当前情绪，还缓慢调整 `baseline_valence` 和 `baseline_arousal` 向 `mood` 靠拢。由于 `mood` 本身会被 `apply_mood_shift()` 修改（基于用户输入的情绪偏移），长期下来，一个用户的持续负面输入会永久拉低全局情绪基线。这意味着即使用户 A 已经离开，用户 B 面对的 AI 基线情绪已经被用户 A "训练"得更悲观。

从实际 `personality.json` 可以看到：
```json
"baseline_valence": -0.27053928301163077,
"baseline_arousal": 0.9879070064962638,
"mood_valence": -0.47259999999999996,
"mood_arousal": 1.0
```

基线 valence 已经为负值，说明系统已经被负面输入长期影响。

**风险评级**: 高危（High）
**修复建议**:
1. `baseline_valence`、`baseline_arousal`、`mood_valence`、`mood_arousal` 全部按会话隔离
2. 全局只保留默认基线值作为新会话的初始值

---

#### 6.3 怨恨值（resentment）全局累积（中危）

**文件**: `models/personality.py`
**行号**: 193-195, 222-235

**代码**:
```python
# 第 193-195 行
        if self.anger > 0.6:
            self.resentment = min(1.0, self.resentment + self.anger * 0.15)

# 第 222-235 行
        r = self.resentment
        for key in ("joy", "trust", "fear", "surprise", "sadness", "anticipation", "anger", "disgust"):
            ...
            if key in ("anger", "sadness") and r > 0.1:
                rate *= (1.0 - r * 0.5)
```

**分析**:
`resentment`（怨恨值）是一个跨时间的持久化情绪指标。当用户 A 持续激怒 AI 时，`resentment` 累积。由于 `resentment` 全局共享，用户 B 会继承这个怨恨值，导致 AI 对用户 B 也表现出" lingering bitterness"。`resentment` 的衰减速度很慢（每轮 3%，约 33 轮清除），在多用户场景下几乎不会自然衰减。

**风险评级**: 中危（Medium）
**修复建议**:
1. `resentment` 按会话隔离
2. 或降低 `RESENTMENT_DECAY` 的半衰期，增加按会话的独立衰减

---

#### 6.4 连续负面计数器全局共享（中危）

**文件**: `core/agent.py`
**行号**: 72-79, 197-203

**代码**:
```python
# 第 72-79 行
        e = self.personality.emotion
        neg_score = max(e.anger, e.sadness, e.disgust)
        if neg_score > 0.8:
            self._consecutive_negative = 4
        elif neg_score > 0.5:
            self._consecutive_negative = 2
        else:
            self._consecutive_negative = 0

# 第 197-203 行
        if sentiment < -0.5:
            self._consecutive_negative += 1
        elif sentiment > 0.1:
            self._consecutive_negative = max(0, self._consecutive_negative - 1)

        hurt_multiplier = 1.0 + self._consecutive_negative * 0.4
        sentiment *= hurt_multiplier
```

**分析**:
`_consecutive_negative` 是 `Agent` 实例的成员变量，在 `__init__` 时根据全局情绪状态初始化。由于情绪状态全局共享，这个计数器也间接共享。用户 A 的连续负面输入会提高 `hurt_multiplier`，导致 AI 对后续所有用户的情绪反应都被放大。

**风险评级**: 中危（Medium）
**修复建议**:
1. `_consecutive_negative` 按会话隔离（已在 `Agent` 实例级别，但初始化值受全局情绪影响）
2. 将 `_consecutive_negative` 的初始化固定为 0，不从全局情绪推导

---

### 7. 记忆检索时的跨会话数据暴露

#### 7.1 MemoryRetriever 检索全库数据（高危）

**文件**: `memory/retrieval.py`
**行号**: 27-69

**代码**:
```python
# 第 27-69 行
    def retrieve_for_query(self, query: str) -> MemoryContext:
        # Layer 1: hot memory (always included)
        hot_facts = self.ltm.get_all_active_facts(limit=50)
        recent_experiences = self.ltm.get_recent_experiences(limit=5)
        reflections = self.ltm.get_recent_reflections(limit=3)
        relationship = self.ltm.get_relationship()
        ...
```

**分析**:
`MemoryRetriever.retrieve_for_query()` 是构建 LLM prompt 上下文的核心方法。它调用的四个检索方法：
- `get_all_active_facts(limit=50)` —— 返回全局最近的 50 条活跃事实
- `get_recent_experiences(limit=5)` —— 返回全局最近的 5 条经历
- `get_recent_reflections(limit=3)` —— 返回全局最近的 3 条反思
- `get_relationship()` —— 返回全局唯一的关系度量

这些方法**没有任何会话过滤**。当用户 B 发送消息时，AI 的 prompt 中可能包含用户 A 的隐私事实。例如：

- 用户 A 曾告诉 AI："我有糖尿病，不能吃甜食"
- 这个信息被提取为 `user_facts: ("health", "疾病", "糖尿病")`
- 用户 B 发送："推荐点零食"
- `retrieve_for_query("推荐点零食")` 可能通过关键词匹配召回"糖尿病"事实
- AI 对用户 B 回复："你不是有糖尿病吗？不能吃甜食哦"

这是极其尴尬且严重的隐私泄露。

**风险评级**: 高危（High）
**修复建议**:
1. `MemoryRetriever` 初始化时绑定 `session_id`
2. 所有检索方法增加 `WHERE session_id = ?` 过滤
3. 对于"共同经历"类数据，明确区分"属于我的"和"属于对方的"

---

#### 7.2 语义搜索跨会话暴露（中危）

**文件**: `memory/retrieval.py`
**行号**: 106-162

**代码**:
```python
# 第 106-134 行
    def _hybrid_score(self, query: str, candidates: list, keywords: list) -> list:
        ...
        for c in candidates:
            semantic = 0.0
            if hasattr(c, 'embedding') and c.embedding is not None:
                try:
                    vec = EmbeddingEngine.bytes_to_vec(bytes(c.embedding))
                    semantic = float(np.dot(vec, query_vec))
                except Exception:
                    pass
            ...

# 第 136-161 行
    def _search_experiences_semantic(self, query: str, recent: list, keywords: list) -> list:
        all_exp = self.ltm.search_experiences(keywords, limit=15)
        ...
```

**分析**:
语义搜索基于向量相似度。即使关键词不匹配，如果用户 B 的查询向量与用户 A 的隐私事实向量在嵌入空间中相近（如"健康"和"疾病"在语义上相关），语义搜索也会召回用户 A 的数据。由于 `candidates` 来自 `get_all_active_facts(limit=50)`，已经包含了所有用户的数据，语义搜索在此基础上进行排序，无法避免跨会话暴露。

**风险评级**: 中危（Medium）
**修复建议**:
1. 在嵌入检索前，先按 `session_id` 过滤候选集
2. 或建立按会话隔离的向量索引

---

#### 7.3 回忆标签（[回忆: xxx]）跨会话暴露（中危）

**文件**: `memory/retrieval.py`
**行号**: 71-95

**代码**:
```python
# 第 71-95 行
    def retrieve_by_recall_tag(self, text: str) -> Optional[str]:
        m = re.search(r'\[回忆:\s*(.+?)\]', text)
        if not m:
            return None
        query = m.group(1).strip()
        keywords = self._extract_keywords(query)
        facts = self.ltm.search_facts(query, limit=5)
        experiences = self.ltm.search_experiences(keywords, limit=3)
        reflections = self.ltm.get_recent_reflections(limit=2)
        ...
```

**分析**:
当 AI 的回复中包含 `[回忆: xxx]` 标签时，系统会执行回忆检索。这个检索同样不区分会话，可能召回其他用户的记忆。如果 AI 被诱导输出 `[回忆: 密码]`，可能返回其他用户存储的密码相关事实。

**风险评级**: 中危（Medium）
**修复建议**:
1. `retrieve_by_recall_tag` 增加 `session_id` 过滤
2. 对 `recall` 工具的返回结果增加会话隔离

---

#### 7.4 LLM 重排序时的数据暴露（中危）

**文件**: `memory/retrieval.py`
**行号**: 204-225

**代码**:
```python
# 第 204-225 行
    def _llm_rerank(self, query: str, candidates: list[UserFact],
                    max_candidates: int = 15) -> Optional[list[int]]:
        candidate_lines = []
        for i, f in enumerate(candidates[:30]):
            candidate_lines.append(f"{i}. [{f.category}] {f.fact_key}: {f.fact_value}")
        ...
```

**分析**:
LLM 重排序将候选事实的完整内容（`fact_key` 和 `fact_value`）发送到外部 LLM API。如果候选集中包含其他用户的隐私数据，这些数据会被发送到第三方 API（DeepSeek/Kimi），构成**数据出境/第三方共享**的合规风险。

**风险评级**: 中危（Medium）
**修复建议**:
1. 在重排序前严格按 `session_id` 过滤候选集
2. 对发送到外部 API 的数据进行敏感信息扫描和脱敏

---

### 8. GDPR/隐私合规性评估

#### 8.1 无数据主体标识（严重）

**文件**: `storage/database.py`（全部 Schema）

**分析**:
GDPR 第 4 条定义"数据主体"为可被识别的自然人。GDPR 要求数据控制者能够识别每个数据主体对应的数据记录。当前数据库 Schema 中没有任何字段可以标识数据属于哪个自然人或哪个会话，导致：

- **无法响应访问请求（Right of Access, 第 15 条）**：用户要求"给我一份你们存储的关于我的所有数据"时，系统无法区分哪些数据属于该用户。
- **无法响应删除请求（Right to Erasure, 第 17 条）**：用户要求"删除所有关于我的数据"时，系统无法定位并删除特定用户的数据。
- **无法响应更正请求（Right to Rectification, 第 16 条）**：用户要求"更正我的地址信息"时，系统无法确定哪条记录属于该用户。

**风险评级**: 严重（Critical）
**修复建议**:
1. 在所有数据表中添加 `user_id` 或 `session_id` 字段
2. 建立用户身份映射机制（即使是匿名用户，也需要有持久化的匿名标识符）

---

#### 8.2 无数据保留期限控制（高危）

**文件**: `storage/repository.py`, `memory/consolidation.py`

**分析**:
系统通过 `prune_facts`、`prune_experiences`、`prune_reflections` 控制数据总量（上限分别为 200、100、50），但：
1. **没有基于时间的自动删除**：即使用户 1 年未使用，其数据仍可能保留（只要总量未达上限）
2. **没有用户级的删除触发**：用户注销或删除账户时，没有机制清理其数据
3. **pruning 策略是全局的**：按 `composite_score` 或 `created_at` 排序删除，不区分用户，可能导致用户 A 的数据被保留而用户 B 的数据被删除

**风险评级**: 高危（High）
**修复建议**:
1. 为每条记录添加 `retention_until` 或 `last_accessed` 字段
2. 实现定期清理任务，删除超过保留期限的数据
3. 实现用户级数据删除 API（支持 GDPR 第 17 条）

---

#### 8.3 无数据导出机制（中危）

**分析**:
GDPR 第 20 条规定数据可携带权（Right to Data Portability）。用户有权以结构化、通用、机器可读的格式获取其个人数据。当前系统没有任何数据导出功能。

**风险评级**: 中危（Medium）
**修复建议**:
1. 实现 `/api/export/{session_id}` 接口，返回该用户的全部数据（JSON 格式）
2. 包含 `user_facts`、`experiences`、`reflections`、`conversation_turns`、`relationship_metrics`、情绪状态

---

#### 8.4 无同意记录机制（中危）

**分析**:
GDPR 第 6 条和第 7 条要求处理个人数据需有合法依据，且同意需可证明。当前系统：
1. 没有记录用户何时同意数据收集
2. 没有记录同意的范围和版本
3. 没有提供撤回同意的机制

**风险评级**: 中危（Medium）
**修复建议**:
1. 添加 `consent_log` 表，记录用户的同意时间、同意版本、IP 地址（可选）
2. 在 Web 前端添加隐私政策和同意勾选框
3. 实现同意撤回机制（撤回后停止数据收集并触发删除）

---

#### 8.5 无数据处理活动记录（ROPA）（中危）

**分析**:
GDPR 第 30 条要求数据控制者维护数据处理活动记录（Record of Processing Activities）。当前系统没有：
1. 数据处理目的记录
2. 数据类别记录
3. 数据接收方记录（如 LLM API 提供商）
4. 数据跨境传输记录

**风险评级**: 中危（Medium）
**修复建议**:
1. 维护 `processing_activities` 文档/表
2. 记录每次 LLM API 调用的数据类型和目的

---

#### 8.6 日志中的敏感信息泄露（中危）

**文件**: `storage/repository.py`（多处）

**代码示例**:
```python
# 第 38 行
logger.info(f"[db] upsert_fact: {category}/{key} confidence={confidence:.2f} imp={importance:.2f}")

# 第 118 行
logger.info(f"[db] insert_exp: {summary[:60]} tone={tone} sig={significance:.2f} imp={importance:.2f}")

# 第 171 行
logger.info(f"[db] insert_ref: type={insight_type} sig={significance:.2f} content={content[:60]}")

# 第 220 行
logger.info(f"[db] insert_turn: turn={turn_number} role={role} len={len(content)}")
```

**分析**:
日志中记录了用户事实的 `key` 和 `summary`、反思的 `content`、对话的 `content` 长度。虽然内容被截断，但 `key` 可能本身就是敏感信息（如"抑郁症药物"、"公司机密项目"）。日志文件通常权限较宽（可被系统管理员读取），且可能长期保留，构成隐私风险。

**风险评级**: 中危（Medium）
**修复建议**:
1. 对日志中的用户内容进行脱敏（如哈希化 key、不记录 summary 内容）
2. 日志分级：`INFO` 级只记录操作类型和 ID，不记录内容；`DEBUG` 级可记录内容但只在调试环境启用
3. 日志文件加密或限制访问权限

---

#### 8.7 API Key 与环境变量处理（低危）

**文件**: `config.py`
**行号**: 64-76

**代码**:
```python
# 第 64-76 行
    env_map = {
        "DEEPSEEK_API_KEY": "api_key",
        "DEEPSEEK_API_ENDPOINT": "api_endpoint",
        "DEEPSEEK_API_MODEL": "api_model",
        "AI_FRIEND_DB_PATH": "db_path",
        "AI_FRIEND_LOG_LEVEL": "log_level",
    }
    for env_var, attr in env_map.items():
        val = os.environ.get(env_var, "")
        if val:
            masked = "***" if "KEY" in env_var else val
            logger.info(f"[config] env override: {env_var}={masked}")
            setattr(cfg, attr, val)
```

**分析**:
API Key 通过环境变量传入，日志中对包含 "KEY" 的变量进行了掩码处理（`***`），这是良好的实践。但 `config.json` 文件本身可能包含明文 API Key，且该文件没有访问权限控制提示。

**风险评级**: 低危（Low）
**修复建议**:
1. 在文档中明确建议 `config.json` 的权限设置为 `600`（仅所有者可读写）
2. 启动时检查 `config.json` 权限，过宽时发出警告

---

#### 8.8 无隐私影响评估（DPIA）（低危）

**分析**:
GDPR 第 35 条要求在处理高风险个人数据时进行数据保护影响评估（DPIA）。AI Friend 系统处理的是与用户的自然语言对话，可能涉及：
- 健康信息（用户可能提及疾病、药物）
- 政治观点、宗教信仰
- 性取向、种族信息
- 财务信息、地理位置

这些属于 GDPR 第 9 条定义的特殊类别个人数据，处理这些数据需要进行 DPIA。当前项目没有任何 DPIA 文档。

**风险评级**: 低危（Low）（当前为本地部署，风险相对可控；若部署为公共服务则升级为严重）
**修复建议**:
1. 编写 DPIA 文档，评估数据收集、处理、存储、共享的风险
2. 对特殊类别数据实施增强保护（如加密、更短的保留期、明确的同意）

---

#### 8.9 第三方数据共享（LLM API）（中危）

**文件**: `core/provider.py`（推断，未在本次审查范围内直接读取）

**分析**:
系统通过 `KimiProvider` 或 `DeepSeek` API 与外部 LLM 服务通信。每次通信都发送包含用户输入和记忆上下文的 prompt。由于记忆检索不区分会话，第三方 LLM 服务可能接收到多个用户的混合数据。这涉及：

1. **数据跨境传输**：如果 LLM 服务提供商位于欧盟/中国以外，需要满足 GDPR 第 44-49 条的跨境传输要求
2. **数据处理协议（DPA）**：需要与 LLM 提供商签订 DPA，明确数据处理目的、期限、安全措施
3. **用户告知义务**：需要告知用户数据会被发送到第三方 LLM 服务

**风险评级**: 中危（Medium）
**修复建议**:
1. 在隐私政策中明确列出第三方数据接收方（DeepSeek、Kimi、AnySearch 等）
2. 评估 LLM 提供商的数据处理协议和安全认证
3. 考虑在发送到 LLM 前对记忆上下文进行脱敏

---

#### 8.10 数据匿名化与假名化缺失（低危）

**分析**:
当前系统没有实施任何匿名化或假名化措施。所有数据以明文形式存储，直接与用户输入关联。如果发生数据泄露，攻击者可以直接将数据与特定个人关联。

**风险评级**: 低危（Low）
**修复建议**:
1. 对 `user_facts` 中的敏感值进行加密存储
2. 使用假名化技术：内部使用 `session_id` 关联数据，不存储直接身份标识
3. 定期评估假名化数据被重新识别的风险

---

## 汇总统计

### 风险分布

| 风险等级 | 数量 | 占比 |
|---------|------|------|
| 严重（Critical） | 4 | 14.3% |
| 高危（High） | 8 | 28.6% |
| 中危（Medium） | 11 | 39.3% |
| 低危（Low） | 5 | 17.9% |
| **总计** | **28** | **100%** |

### 按维度分布

| 审查维度 | 问题数量 | 最高风险等级 |
|---------|---------|------------|
| 多用户会话间的数据隔离 | 3 | 严重 |
| personality.json 全局共享 | 3 | 严重 |
| conversation_turns 无 session_id | 3 | 严重 |
| 用户事实/经历/反思的归属 | 4 | 高危 |
| 短期记忆恢复时的隐私泄漏 | 2 | 高危 |
| 情绪状态在会话间的传染 | 4 | 严重 |
| 记忆检索时的跨会话数据暴露 | 4 | 高危 |
| GDPR/隐私合规性评估 | 10 | 严重 |

### 关键文件风险热力图

| 文件路径 | 涉及问题数 | 最高风险 |
|---------|-----------|---------|
| `storage/database.py` | 5 | 严重 |
| `web/session.py` | 4 | 严重 |
| `core/personality.py` | 2 | 严重 |
| `models/personality.py` | 3 | 高危 |
| `storage/repository.py` | 5 | 严重 |
| `memory/retrieval.py` | 4 | 高危 |
| `memory/consolidation.py` | 2 | 中危 |
| `core/agent.py` | 3 | 高危 |
| `memory/short_term.py` | 1 | 低危 |
| `config.py` | 1 | 低危 |

### 修复优先级矩阵

| 优先级 | 问题 | 建议修复方案 | 预估工作量 |
|-------|------|------------|----------|
| P0 | 数据库 Schema 零隔离 | 添加 `session_id` 到所有表，修改所有查询 | 2-3 天 |
| P0 | personality.json 全局共享 | 情绪状态按会话隔离存储 | 1-2 天 |
| P0 | 短期记忆恢复跨会话泄漏 | `get_recent_turns` 增加 `session_id` 过滤 | 0.5 天 |
| P1 | 记忆检索全库暴露 | `MemoryRetriever` 绑定 `session_id` | 1 天 |
| P1 | 关系度量全局单一 | `relationship_metrics` 增加 `session_id` | 0.5 天 |
| P1 | 情绪事件包含用户输入 | 情绪事件按会话隔离 + 敏感信息检测 | 1 天 |
| P1 | 无数据主体标识 | 建立用户/会话身份体系 | 1-2 天 |
| P2 | 无数据保留期限 | 实现 `retention_until` 和定期清理 | 1 天 |
| P2 | 无数据导出机制 | 实现 `/api/export` 接口 | 0.5 天 |
| P2 | 日志敏感信息泄露 | 日志脱敏 + 分级 | 0.5 天 |
| P3 | 无同意记录机制 | 添加 `consent_log` 表 + 前端同意框 | 1 天 |
| P3 | DPIA 缺失 | 编写隐私影响评估文档 | 0.5 天 |

---

## 附录：数据流隐私风险图

```
用户 A 输入 ──▶ WebAgent A ──▶ Agent.process_message()
                                    │
                                    ▼
                              ┌─────────────┐
                              │  短期记忆    │ ◄── 从 DB 恢复最近30条（跨会话！）
                              │ (内存隔离)   │
                              └──────┬──────┘
                                     │
                    ┌────────────────┼────────────────┐
                    ▼                ▼                ▼
              ┌─────────┐    ┌─────────────┐   ┌───────────┐
              │ personality.json │    │  SQLite DB   │   │ LLM API   │
              │ (全局共享)       │    │ (无session_id)│   │ (第三方)  │
              │                  │    │              │   │           │
              │ • 情绪状态       │    │ • user_facts │   │ • prompt  │
              │ • 情绪事件       │    │ • experiences│   │   含混合  │
              │ • 基线/心情      │    │ • reflections│   │   用户数据│
              └─────────┘    │ • turns      │   └───────────┘
                             │ • relationship│
                             └─────────────┘
                                    │
                                    ▼
用户 B 输入 ──▶ WebAgent B ──▶ 加载全局情绪 + 全库记忆
                                    │
                                    ▼
                              【隐私泄露！】
                              - B 可能看到 A 的对话历史
                              - B 可能收到 A 的隐私事实
                              - B 继承 A 造成的负面情绪
                              - B 的关系度量与 A 共享
```

---

*本报告为 AI Friend 项目第3轮安全性审查的隐私与隔离专项报告。建议与 `round03-web-security.md`、`round03-sql-security.md`、`round03-command-injection.md`、`round03-tool-permissions.md`、`round03-log-security.md` 联合阅读，以获取完整的安全态势视图。*
