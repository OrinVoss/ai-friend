# 第4轮审查：错误处理与可靠性审查（异常处理覆盖度）

**审查日期：** 2026-05-31  
**审查范围：** core/*.py, memory/*.py, tools/*.py, web/*.py, storage/*.py, models/*.py, prompts/*.py, config.py, main.py, web_main.py, ui/cli.py  
**审查人：** Claude Code  
**总代码量：** ~4,800 行 Python

---

# 概述

本次审查对 AI Friend 项目进行了全面的异常处理覆盖度分析，聚焦以下七个维度：

1. 每个函数的 try-except 覆盖情况
2. 裸 except 捕获问题（`except:` 或 `except Exception:`）
3. 异常被静默吞掉的位置
4. 异常信息丢失或过度截断
5. 异常向上传播路径是否清晰
6. 关键操作缺少异常保护
7. 异常处理中的资源泄漏

**总体评估：** 项目的异常处理处于"中等偏下"水平。核心 API 调用层（provider.py）和工具执行层（dispatcher.py）有基本的异常捕获和重试机制，但大量关键路径缺乏保护，存在多处裸 except、静默吞异常、资源泄漏风险，以及异常信息丢失问题。Web 端和 CLI 端的状态机循环有顶层保护，但内部关键操作（如数据库写入、内存持久化、人格保存）缺乏足够的异常隔离，单点故障可能导致状态不一致或数据丢失。

**风险分布：**
- 高危（Critical）：7 处
- 中危（High）：14 处
- 低危（Medium）：18 处
- 信息（Info）：8 处

---

# 详细发现

## 一、core 层异常处理问题

### 1.1 provider.py — API 调用层

#### FIND-001: `_do_request` 方法缺少对 `resp.json()` 的异常保护
**文件：** `core/provider.py`  
**行号：** 96-97  
**风险评级：** 高

```python
96:        data = resp.json()
97:        content = data.get("choices", [{}])[0].get("message", {}).get("content", "")
```

**问题描述：** 当 `stream=False` 时，`_do_request` 直接调用 `resp.json()` 解析响应体。如果 API 返回非 JSON 内容（如 HTML 错误页、空响应、或格式损坏的 JSON），`resp.json()` 会抛出 `requests.exceptions.JSONDecodeError`（或 `json.JSONDecodeError`）。该异常未被 `generate()` 方法中的任何 except 子句捕获（`generate()` 只捕获 `ConnectionError`、`HTTPError`、`ChunkedEncodingError`、`StreamConsumedError`），因此会直接向上传播，导致调用链中断。

**影响：** 用户请求失败，CLI/Web 端无优雅降级。

**建议：** 在 `_do_request` 的 `if not stream:` 分支中添加 `try/except (json.JSONDecodeError, requests.exceptions.JSONDecodeError)`，返回空字符串或抛出带有上下文信息的自定义异常。

---

#### FIND-002: 流式响应中 `json.JSONDecodeError` 被静默吞掉
**文件：** `core/provider.py`  
**行号：** 125-126  

```python
125:                except json.JSONDecodeError:
126:                    continue
```

**问题描述：** 在流式响应解析循环中，如果某一行 SSE 数据不是合法 JSON（如服务器发送了错误消息或心跳包），异常被捕获后直接 `continue`，该行数据被丢弃。虽然这在 SSE 协议中是常见做法，但**没有任何日志记录**，开发者无法知道有多少数据被丢弃，也无法诊断是服务器问题还是解析问题。

**影响：** 调试困难，可能丢失关键的错误信息（如 rate limit 提示）。

**建议：** 至少添加 `logger.debug(f"[api] failed to parse SSE line: {line[:100]}")`。

---

#### FIND-003: `generate()` 方法未捕获 `requests.exceptions.Timeout`
**文件：** `core/provider.py`  
**行号：** 57-80  

**问题描述：** `generate()` 的 retry 循环捕获了 `ConnectionError`、`HTTPError`、流错误，但**没有捕获 `requests.exceptions.Timeout`**。当 API 请求超时时（`timeout=self.timeout`，默认 180 秒），`Timeout` 异常会直接向上抛出，不会被重试。

**影响：** 网络抖动或 API 暂时性超时会导致请求直接失败，错失重试机会。

**建议：** 在 retry 循环中添加 `except requests.exceptions.Timeout as e`，将其纳入重试逻辑。

---

#### FIND-004: `generate()` 重试后最终异常信息丢失
**文件：** `core/provider.py`  
**行号：** 79-80  

```python
79:        logger.error(f"[api] failed after 3 retries: {last_error}")
80:        raise ConnectionError(f"API request failed after 3 retries: {last_error}")
```

**问题描述：** 最终抛出的 `ConnectionError` 使用 `str(last_error)` 作为消息，如果 `last_error` 是 `HTTPError` 且包含大量响应体信息，消息可能过长；如果是 `ChunkedEncodingError`，消息可能过于简短。更重要的是，原始异常的 traceback 被完全丢失（因为抛出了新的异常对象）。

**影响：** 调试时无法追踪原始异常的堆栈。

**建议：** 使用 `raise ConnectionError(...) from last_error` 保留异常链，或使用 `raise` 重新抛出最后一个异常。

---

### 1.2 agent.py — 核心 Agent 状态机

#### FIND-005: `_react_loop` 中工具调用结果记录可能越界
**文件：** `core/agent.py`  
**行号：** 161-169  

```python
161:            for r in results:
162:                self._tool_call_history.append({
163:                    "name": r["name"],
164:                    "success": r["success"],
165:                    "output": r["output"][:200],
166:                    "time": time.time(),
167:                })
168:            if len(self._tool_call_history) > 20:
169:                self._tool_call_history = self._tool_call_history[-20:]
```

**问题描述：** 虽然这不是直接的异常处理问题，但 `r["output"][:200]` 假设 `r["output"]` 一定是字符串。如果 `execute_tool_calls` 返回的 `output` 为 `None`（理论上不应发生，但 Python 的动态类型无法保证），这里会抛出 `TypeError`。`execute_tool_calls` 中的裸 except（见 FIND-023）可能将非字符串对象放入 `output`。

**风险评级：** 中

**建议：** 防御性编码：`str(r.get("output", ""))[:200]`。

---

#### FIND-006: `_react_loop` 的循环结束后未处理 `final_text` 为空的情况
**文件：** `core/agent.py`  
**行号：** 172-181  

```python
172:        if final_text:
173:            if add_to_history:
174:                self.short_term.add_turn("assistant", final_text)
175:            self.ltm.repo.insert_turn_sync(...)
176:            self.turn_count += 1
177:
178:        if not skip_post_process:
179:            self._process_emotion()
180:        return final_text
```

**问题描述：** 如果 `_max_tool_iterations` 次循环后 `final_text` 仍为空（例如模型持续输出工具调用但全部失败，或模型输出无法解析），`_react_loop` 返回空字符串。此时：
1. 不记录 assistant turn 到短期记忆和长期记忆（合理）
2. 但仍然调用 `_process_emotion()`
3. `_process_emotion()` 中 `last_user_turn` 可能基于错误的上下文进行情感分析

更关键的是，调用者（如 `handle_message`）收到空字符串后没有检查，直接将其作为响应返回给用户。

**风险评级：** 中

**建议：** 在 `_react_loop` 返回前检查 `final_text` 是否为空，若为空则记录警告日志并返回兜底消息（如"让我再想想..."）。

---

#### FIND-007: `_process_emotion()` 中 `consolidator.analyze_sentiment` 的异常处理过于宽泛
**文件：** `core/agent.py`  
**行号：** 187-195  

```python
187:        try:
188:            all_turns = self.short_term.get_all()
189:            for t in reversed(all_turns):
190:                if t.role == "user":
191:                    last_user_turn = t.content
192:                    break
193:            sentiment, sharing, energy = self.consolidator.analyze_sentiment(last_user_turn)
194:        except (json.JSONDecodeError, ValueError, KeyError) as e:
195:            logger.warning(f"Sentiment analysis parse error: {e}")
```

**问题描述：** `analyze_sentiment` 内部调用 LLM 并解析 JSON，捕获了 JSON 解析错误。但如果 `consolidator` 为 `None`（虽然当前代码中不可能），或 `analyze_sentiment` 内部抛出 `AttributeError`、`TypeError` 等其他异常，这些异常会向上传播。更实际的问题是：`analyze_sentiment` 本身捕获了所有 `Exception`（见 consolidation.py 第 94-96 行），所以这里的 `except` 实际上永远不会被触发，属于**死代码**。

**风险评级：** 低

**建议：** 移除此处多余的 `try/except`，或改为捕获更广泛的异常以作为最后一道防线。

---

### 1.3 cli_controller.py — CLI 状态机

#### FIND-008: `run()` 方法中的裸 `except Exception`
**文件：** `core/cli_controller.py`  
**行号：** 81-86  

```python
81:            except Exception as e:
82:                logger.error(f"Error in state {a.state}: {e}", exc_info=True)
83:                if a.ui:
84:                    a.ui.display.print_error(str(e))
85:                time.sleep(1)
86:                a.state = AgentState.IDLE
```

**问题描述：** 状态机主循环的每个状态处理都被 `except Exception` 包裹。虽然这是顶层保护，但存在两个问题：
1. **过度捕获**：`KeyboardInterrupt` 已经被单独捕获，但 `SystemExit`、`GeneratorExit` 等也会被 `Exception` 捕获。虽然 `SystemExit` 继承自 `BaseException` 不会被捕获，但如果代码中使用了 `raise SystemExit()` 从线程中抛出，行为可能不确定。
2. **状态恢复可能不一致**：发生异常后状态被强制设为 `IDLE`，但 `_react_messages`、`_tool_calls_pending`、`_react_iteration` 等中间状态可能未被清理，导致下一轮循环行为异常。

**风险评级：** 高

**建议：**
- 在异常恢复路径中调用 `a._reset_react()` 清理中间状态
- 考虑使用 `except Exception` 时排除 `asyncio.CancelledError`（Python 3.8+ 中 `CancelledError` 继承自 `Exception`）

---

#### FIND-009: `_on_think()` 中 `ConnectionError` 捕获后状态恢复不完整
**文件：** `core/cli_controller.py`  
**行号：** 198-205, 219-226  

```python
198:            try:
199:                full_response = a.provider.generate(messages, stream=False, max_tokens=384)
200:            except ConnectionError as e:
201:                if a.ui:
202:                    a.ui.display.print_error(f"网络连接失败：{e}")
203:                a._reset_react()
204:                a.state = AgentState.REFLECT
205:                return
```

**问题描述：** 只捕获了 `ConnectionError`，但 `generate()` 还可能抛出 `requests.exceptions.Timeout`（见 FIND-003）、`RuntimeError`（AnySearch API 错误）等。这些异常会向上传播到 `run()` 的 `except Exception` 处理程序，导致状态机进入通用的错误恢复路径，可能不如 `_on_think` 中的精细恢复。

**风险评级：** 中

**建议：** 捕获更广泛的异常，或统一异常类型。

---

#### FIND-010: `_on_shutdown()` 中 `consolidator.consolidate()` 和 `personality.save()` 无异常保护
**文件：** `core/cli_controller.py`  
**行号：** 296-305  

```python
296:    def _on_shutdown(self) -> None:
297:        a = self.a
298:        a.consolidator.consolidate(a.short_term, a.personality, ...)
299:        a.personality.save(a.config.personality_file)
300:        if a.ui:
301:            a.ui.stop()
302:        print(f"\n\033[1;36m{a.personality.config.name} 记下了你们的对话。下次见~\033[0m")
```

**问题描述：** 关机流程中，`consolidate()` 可能因 LLM 调用失败而抛出异常（`analyze_sentiment` 等），`personality.save()` 可能因磁盘满、权限问题抛出 `OSError`。这些异常未被捕获，会导致：
1. `ui.stop()` 不被调用
2. 关机问候语不打印
3. 程序以非零退出码终止

**风险评级：** 高

**建议：** 在 `_on_shutdown()` 中添加 `try/except Exception` 保护每个关键步骤，确保 UI 清理和问候语始终执行。

---

#### FIND-011: `_on_reflect()` 中 `personality.save()` 无异常保护
**文件：** `core/cli_controller.py`  
**行号：** 291-294  

```python
291:        if a.turn_count % 10 == 0:
292:            a.personality.save(a.config.personality_file)
```

**问题描述：** 每 10 轮保存人格状态，但 `save()` 的 `OSError` 未被捕获。异常会中断 `_on_reflect()`，导致状态机进入 `run()` 的 `except Exception`，状态被重置为 `IDLE`。虽然不会导致数据丢失（因为 `save()` 失败意味着没写入），但会中断正常的反射流程。

**风险评级：** 中

**建议：** 添加 `try/except OSError` 并记录警告。

---

#### FIND-012: `_handle_command()` 中 `/save` 命令的异常处理缺失
**文件：** `core/cli_controller.py`  
**行号：** 311-318  

```python
311:        elif cmd == "/save":
312:            a.consolidator.consolidate(...)
313:            a.personality.save(a.config.personality_file)
314:            if a.ui:
315:                a.ui.display.print_system("记忆已保存")
```

**问题描述：** 用户主动触发 `/save` 时，`consolidate()` 或 `save()` 的异常会直接传播到 `run()` 的顶层处理程序，用户看到的只是通用的 "Error in state..." 消息，而非友好的 "保存失败" 提示。

**风险评级：** 中

**建议：** 在 `_handle_command()` 的 `/save` 分支中添加 `try/except`。

---

### 1.4 message_handler.py — 三层 Agent 编排

#### FIND-013: `handle_message()` 中 Agent 2 的多轮循环缺少外层异常保护
**文件：** `core/message_handler.py`  
**行号：** 98-142  

**问题描述：** `handle_message()` 的 Agent 2 多轮工具执行循环（while round_num < MAX_AGENT2_ROUNDS）中，每次调用 `self._tool_agent.run_with_request()` 和 `self._inner_drive.review()` / `re_decide()` 都可能抛出异常（如 API 调用失败）。这些异常会向上传播，导致整个 `handle_message()` 失败，用户收不到任何响应。

**风险评级：** 高

**建议：** 在 while 循环外层添加 `try/except Exception`，在异常时返回兜底响应（如"抱歉，我遇到了一点问题，让我再试试"）。

---

#### FIND-014: `handle_explore()` 中 `tool_result` 可能为 `None` 但未检查
**文件：** `core/message_handler.py`  
**行号：** 206-208  

```python
206:        tool_result = self._tool_agent.run(explore_prompt)
207:        tool_records = self._tool_agent.format_for_phase2(tool_result)
```

**问题描述：** `run()` 返回 `ToolAgentResult`（不会为 `None`），但 `format_for_phase2` 在 `tool_result` 为 `None` 时会抛出 `AttributeError`。虽然当前不会为 `None`，但防御性不足。

**风险评级：** 低

---

#### FIND-015: `_build_messages()` 中 `a.short_term.get_all_reversed()` 的迭代无异常保护
**文件：** `core/message_handler.py`  
**行号：** 278-291  

**问题描述：** 在构建消息列表时，如果 `short_term` 的 `get_all_reversed()` 因锁问题或内存问题抛出异常，整个消息构建失败。虽然 `ConversationBuffer` 的实现很稳健，但这是关键路径。

**风险评级：** 低

---

### 1.5 inner_drive.py — Agent 1 内驱推理

#### FIND-016: `assess()` 方法中 `provider.generate()` 的异常未处理
**文件：** `core/inner_drive.py`  
**行号：** 85  

```python
85:            resp = self._provider.generate(messages, stream=False, max_tokens=512)
```

**问题描述：** `assess()` 调用 `provider.generate()` 但没有 `try/except`。如果 API 调用失败（ConnectionError、Timeout 等），异常会直接向上传播，导致 `handle_message()` 或 `_on_perceive()` 失败。

**风险评级：** 高

**建议：** 在 `assess()` 中添加异常捕获，在 API 失败时返回默认的 `InnerDriveResult(needs_external_tools=False)`，让流程降级到直接回复。

---

#### FIND-017: `assess_proactive()` 中 `provider.generate()` 的异常未处理
**文件：** `core/inner_drive.py`  
**行号：** 146  

```python
146:        resp = self._provider.generate(messages, stream=False, max_tokens=256)
```

**问题描述：** 与 FIND-016 相同，主动行为评估中的 API 调用无保护。如果失败，整个主动行为循环会崩溃。

**风险评级：** 高

**建议：** 添加异常捕获，返回默认的 `ProactiveIntent(action="silent")`。

---

#### FIND-018: `review()` 和 `re_decide()` 中 `provider.generate()` 的异常未处理
**文件：** `core/inner_drive.py`  
**行号：** 199, 247  

**问题描述：** 同样的模式，`review()` 和 `re_decide()` 中的 API 调用均无异常保护。

**风险评级：** 高

---

#### FIND-019: `_parse_decision()` 中字符串切片可能导致信息丢失
**文件：** `core/inner_drive.py`  
**行号：** 276, 292, 299, 300  

```python
276:                reasoning=text[:300],
277:                summary=text[:200],
```

**问题描述：** 虽然这不是异常处理问题，但 `text[:300]` 在 `text` 为 `None` 时会抛出 `TypeError`。虽然调用前 `text = text.strip()` 已经假设了字符串类型，但类型安全不足。

**风险评级：** 低

---

### 1.6 tool_agent.py — Agent 2 工具执行

#### FIND-020: `run()` 中 `response_format=self._registry.to_json_schema()` 可能返回无效 schema
**文件：** `core/tool_agent.py`  
**行号：** 106  

```python
106:                response_format=self._registry.to_json_schema(),
```

**问题描述：** `to_json_schema()` 当前返回 `{"type": "json_object"}`，这对 DeepSeek API 有效，但如果 API 提供商要求更严格的 schema（如 OpenAI 的 `json_schema` 类型），这可能无效。`generate()` 中的异常处理不会针对这种参数错误进行特殊处理。

**风险评级：** 中

---

#### FIND-021: `run_with_request()` 中 `max_retries` 循环的异常处理不完整
**文件：** `core/tool_agent.py`  
**行号：** 169-215  

**问题描述：** `run_with_request()` 的 retry 循环只处理 "no tool calls parsed" 的情况（`continue`），但如果 `provider.generate()` 抛出异常（ConnectionError、Timeout 等），整个 `run_with_request()` 会失败，异常向上传播。

**风险评级：** 高

**建议：** 在 retry 循环中添加对 API 异常的捕获，将其视为一次失败并重试。

---

### 1.7 dispatcher.py — 工具调用解析与执行

#### FIND-022: `parse_tool_calls()` 中 Tier 3 的 bare JSON fallback 解析失败静默忽略
**文件：** `core/dispatcher.py`  
**行号：** 67-77  

```python
67:        if not calls:
68:            try:
69:                obj = json.loads(text)
70:                ...
71:            except json.JSONDecodeError:
72:                pass
```

**问题描述：** Tier 3 fallback 解析失败时静默 `pass`，没有日志记录。如果 LLM 输出了损坏的 JSON，开发者无法知道解析失败的原因。

**风险评级：** 低

**建议：** 添加 `logger.debug(f"Tier 3 JSON parse failed: {e}")`。

---

#### FIND-023: `execute_tool_calls()` 中的裸 `except Exception`
**文件：** `core/dispatcher.py`  
**行号：** 140-146  

```python
140:        except Exception as e:
141:            logger.error(f"Tool {name} execution error: {e}")
142:            results.append({
143:                "name": name,
144:                "success": False,
145:                "output": str(e),
146:            })
```

**问题描述：** 工具执行被裸 `except Exception` 捕获。这虽然防止了单个工具崩溃影响其他工具，但存在以下问题：
1. **异常信息丢失**：`str(e)` 可能丢失异常的完整类型和 traceback
2. **可能捕获不应捕获的异常**：如 `KeyboardInterrupt`（虽然继承自 `BaseException`，不会被捕获）、`SystemExit` 也不会被捕获，但如果工具内部使用了 `raise RuntimeError` 等，会被捕获
3. **异步工具的特殊处理**：`asyncio.run(tool.execute(args))` 在 `execute_tool_calls` 中被同步调用，如果异步工具内部抛出异常，会被 `asyncio.run()` 包装后抛出，然后被这里的 `except Exception` 捕获

**风险评级：** 中

**建议：** 使用 `except Exception as e` 时记录完整 traceback：`logger.exception(f"Tool {name} execution error")`。

---

#### FIND-024: `execute_tool_calls()` 中 `asyncio.run()` 的嵌套调用问题
**文件：** `core/dispatcher.py`  
**行号：** 132  

```python
132:                result: ToolResult = asyncio.run(tool.execute(args))
```

**问题描述：** `asyncio.run()` 不能在已经运行的事件循环中调用（如 Web 端的 FastAPI）。如果 `execute_tool_calls` 在 Web 请求处理中被调用，且某个工具是异步的，`asyncio.run()` 会抛出 `RuntimeError: asyncio.run() cannot be called from a running event loop`。当前代码中所有工具都是同步的（`execute` 不是 `async def`），所以这个问题当前不会触发，但如果未来添加了异步工具，这是一个定时炸弹。

**风险评级：** 中

**建议：** 使用 `asyncio.get_event_loop().run_until_complete()` 或检查当前是否在事件循环中。

---

### 1.8 context_manager.py — 上下文管理

#### FIND-025: `_get_tokenizer()` 中 `except (ImportError, Exception)` 过于宽泛
**文件：** `core/context_manager.py`  
**行号：** 19-23  

```python
19:        try:
20:            import tiktoken
21:            _TOKENIZER = tiktoken.get_encoding(_TOKENIZER_ENCODING)
22:        except (ImportError, Exception):
23:            _TOKENIZER = False
```

**问题描述：** `except (ImportError, Exception)` 实际上等同于 `except Exception`，因为 `ImportError` 继承自 `Exception`。这会导致任何异常（包括 `MemoryError`、`SystemError` 等）都被捕获并静默降级到字符估算。虽然这是防御性编程，但过于宽泛。

**风险评级：** 低

**建议：** 改为 `except Exception as e: logger.warning(f"tiktoken unavailable: {e}"); _TOKENIZER = False`。

---

#### FIND-026: `compress()` 中 `_do_compress()` 的异常被捕获但上下文丢失
**文件：** `core/context_manager.py`  
**行号：** 97-98  

```python
97:        except Exception as e:
98:            logger.warning(f"Compression failed: {e}")
```

**问题描述：** 上下文压缩失败时异常被捕获，但只记录了 `str(e)`，没有记录 traceback。压缩失败的原因（如 API 错误、内存不足）难以诊断。

**风险评级：** 低

**建议：** 使用 `logger.exception("Compression failed")` 记录完整 traceback。

---

### 1.9 sleep_manager.py — 睡眠管理

#### FIND-027: `generate_dream()` 中 `provider.generate()` 的异常被捕获但信息丢失
**文件：** `core/sleep_manager.py`  
**行号：** 117-119  

```python
117:        except Exception:
118:            logger.debug("[dream] generation failed")
119:            return ""
```

**问题描述：** 梦境生成失败时异常被捕获，但只记录了固定字符串，没有记录异常详情。这导致无法诊断梦境生成失败的原因（API 错误、提示词问题等）。

**风险评级：** 低

**建议：** `logger.debug(f"[dream] generation failed: {e}")`。

---

#### FIND-028: `_load_sleep_state()` 和 `_save_sleep_state()` 中的裸 `except Exception`
**文件：** `core/sleep_manager.py`  
**行号：** 29-31, 37-38  

```python
29:        except Exception as e:
30:            logger.warning(f"Failed to read sleep state: {e}")
31:            return False
```

**问题描述：** 睡眠状态文件读写失败被裸 except 捕获。虽然这是合理的（文件可能不存在），但 `Exception` 过于宽泛。如果抛出 `MemoryError` 或 `SystemError`，应该让程序崩溃而不是返回默认值。

**风险评级：** 低

---

### 1.10 personality.py — 人格管理

#### FIND-029: `load()` 中 `json.JSONDecodeError` 和 `OSError` 被捕获后返回默认人格
**文件：** `core/personality.py`  
**行号：** 92-97  

```python
92:        try:
93:            with open(path, encoding="utf-8") as f:
94:                data = json.load(f)
95:        except (json.JSONDecodeError, OSError) as e:
96:            logger.warning(f"Failed to load personality from {path}: {e}")
97:            return cls(PersonalityConfig())
```

**问题描述：** 人格文件加载失败时返回默认人格，这是合理的降级策略。但 `OSError` 包含了权限错误、磁盘错误等，如果文件存在但权限不足，用户可能不知道配置被忽略了。

**风险评级：** 中

**建议：** 区分文件不存在（`FileNotFoundError`）和解析错误/权限错误，对后者使用 `logger.error` 并考虑通知用户。

---

#### FIND-030: `save()` 中无异常保护
**文件：** `core/personality.py`  
**行号：** 113-116  

```python
113:    def save(self, path: str) -> None:
114:        logger.info(f"[personality] saved to: {path}")
115:        with open(path, "w", encoding="utf-8") as f:
116:            json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
```

**问题描述：** `save()` 没有异常保护。如果磁盘满、权限不足、或路径不可写，`OSError` 会直接向上抛出。这在 CLI 的 `_on_reflect()` 和 `_on_shutdown()` 中已被注意到（FIND-010、FIND-011），但根本问题在 `save()` 本身。

**风险评级：** 高

**建议：** 在 `save()` 中添加 `try/except OSError` 并记录错误。

---

## 二、memory 层异常处理问题

### 2.1 short_term.py — 短期记忆

#### FIND-031: `ConversationBuffer` 的方法基本无异常保护
**文件：** `memory/short_term.py`  

**问题描述：** `add_turn()`、`get_recent()`、`get_all()`、`format_for_prompt()`、`clear()` 等方法都没有 `try/except`。虽然这些方法的逻辑简单（操作 `deque` 和 `Lock`），不太会抛出异常，但如果 `Turn` 的构造失败（如 `datetime.now()` 在某些极端情况下可能失败），或 `Lock` 获取失败（如线程被中断），异常会向上传播。

**风险评级：** 低

---

### 2.2 long_term.py — 长期记忆同步层

#### FIND-032: `_run_sync()` 中 `asyncio.run(coro)` 的嵌套调用问题
**文件：** `memory/long_term.py`  
**行号：** 18-26  

```python
18:    @staticmethod
19:    def _run_sync(coro):
20:        """Run coroutine in a thread-safe way for sync callers."""
21:        try:
22:            loop = asyncio.get_running_loop()
23:        except RuntimeError:
24:            return asyncio.run(coro)
25:        import concurrent.futures
26:        with concurrent.futures.ThreadPoolExecutor() as pool:
27:            return pool.submit(asyncio.run, coro).result()
```

**问题描述：** 当已经存在运行中的事件循环时（如 Web 端的 FastAPI），`_run_sync()` 会在线程池中调用 `asyncio.run(coro)`。这与 FIND-024 类似：`asyncio.run()` 会创建新的事件循环，在线程池中这是安全的（因为每个线程可以有自己的事件循环）。但如果线程池中的线程已经有一个事件循环（虽然不太可能），会抛出 `RuntimeError`。更实际的问题是：如果 `coro` 抛出异常，异常会被 `pool.submit().result()` 重新抛出，保留了 traceback，这是好的。但如果线程池提交本身失败（如资源耗尽），会抛出 `RuntimeError` 或 `BrokenThreadPool`。

**风险评级：** 中

**建议：** 考虑使用 `asyncio.run_coroutine_threadsafe()` 替代线程池方案。

---

#### FIND-033: 同步代理方法无异常包装
**文件：** `memory/long_term.py`  
**行号：** 95-105  

```python
95:    def store_fact(self, *a, **kw): return self._run_sync(self._store_fact(*a, **kw))
```

**问题描述：** 所有同步代理方法直接返回 `_run_sync()` 的结果，没有额外的异常处理。如果底层数据库操作失败（如 `aiosqlite.Error`），异常会穿过 `_run_sync()` 向上传播。虽然这是预期的行为，但在某些调用点（如工具执行中）可能没有准备好处理这些异常。

**风险评级：** 低

---

### 2.3 retrieval.py — 记忆检索

#### FIND-034: `_hybrid_score()` 中 `self._embed.encode_single(query)` 的异常处理
**文件：** `memory/retrieval.py`  
**行号：** 111-115  

```python
111:        try:
112:            query_vec = self._embed.encode_single(query)
113:        except Exception as e:
114:            logger.warning(f"[retrieval] embed failed, fallback to keyword: {e}")
115:            return self._score_facts(candidates, keywords, query)
```

**问题描述：** 嵌入编码失败时捕获所有异常并降级到关键词匹配。这是好的降级策略，但 `except Exception` 过于宽泛。如果 `encode_single()` 抛出 `MemoryError`，降级到关键词匹配可能也无济于事（因为内存仍然不足）。

**风险评级：** 低

---

#### FIND-035: `_search_experiences_semantic()` 中 `encode_single()` 的异常被静默忽略
**文件：** `memory/retrieval.py`  
**行号：** 144-147  

```python
144:        try:
145:            query_vec = self._embed.encode_single(query)
146:        except Exception:
147:            return all_exp
```

**问题描述：** 与 FIND-034 类似，但此处没有记录异常信息（`except Exception:` 没有 `as e`），异常被完全静默吞掉。

**风险评级：** 中

**建议：** 添加日志记录。

---

#### FIND-036: `_llm_rerank()` 中 `llm_rerank_fn` 的异常被捕获但信息可能丢失
**文件：** `memory/retrieval.py`  
**行号：** 217-225  

```python
217:        try:
218:            result = self.llm_rerank_fn(prompt)
219:            ...
220:        except Exception as e:
221:            logger.warning(f"LLM rerank failed: {e}")
222:            return None
```

**问题描述：** LLM 重排序失败时返回 `None`，调用者会回退到前 15 个候选。这是合理的降级，但 `except Exception` 过于宽泛。

**风险评级：** 低

---

### 2.4 consolidation.py — 记忆整合

#### FIND-037: `analyze_sentiment()` 中裸 `except Exception`
**文件：** `memory/consolidation.py`  
**行号：** 94-96  

```python
94:        except Exception as e:
95:            logger.warning(f"Sentiment analysis failed: {e}")
96:            return 0.0, False, 0.5
```

**问题描述：** 情感分析失败时返回默认值。这是合理的，但 `except Exception` 过于宽泛。如果 `self.llm()` 抛出 `ConnectionError`，应该让调用者知道网络问题，而不是假装分析结果是中性。

**风险评级：** 中

---

#### FIND-038: `_extract_facts()`、`_summarize_experience()`、`_generate_reflection()` 中裸 `except Exception`
**文件：** `memory/consolidation.py`  
**行号：** 124-125, 166-167, 222-223  

**问题描述：** 三个记忆整合步骤都被裸 `except Exception` 保护。这意味着任何步骤失败都不会影响其他步骤。这是好的隔离，但同样存在过于宽泛的问题。如果 `_extract_facts()` 因数据库写入失败（`aiosqlite.Error`）而失败，异常被捕获后 `_summarize_experience()` 和 `_generate_reflection()` 仍会继续执行，但此时数据库可能已经处于不一致状态。

**风险评级：** 中

---

#### FIND-039: `_embed_new_items()` 中数据库连接获取无异常保护
**文件：** `memory/consolidation.py`  
**行号：** 262  

```python
262:            with self.ltm.repo.db.get_connection() as conn:
```

**问题描述：** `get_connection()` 在数据库未打开时抛出 `RuntimeError`。这个异常在 `_embed_new_items()` 的外层 `try/except` 中被捕获，但异常类型是 `RuntimeError`，不是数据库错误，可能掩盖了初始化问题。

**风险评级：** 低

---

### 2.5 embeddings.py — 嵌入引擎

#### FIND-040: `encode()` 中 `except Exception` 后重新抛出
**文件：** `memory/embeddings.py`  
**行号：** 48-50  

```python
48:        except Exception as e:
49:            logger.error(f"[embed] encoding failed: {e}")
50:            raise
```

**问题描述：** `encode()` 捕获所有异常、记录日志后重新抛出。这导致异常被记录两次（如果调用者也记录了异常），且丢失了原始 traceback 的上下文（因为 `raise` 会保留 traceback，这是好的）。但 `except Exception` 过于宽泛，如果嵌入服务器返回的 JSON 格式不正确，应该抛出更具体的异常。

**风险评级：** 低

---

#### FIND-041: `health_check()` 中异常被静默吞掉
**文件：** `memory/embeddings.py`  
**行号：** 82-83  

```python
82:        except Exception:
83:            return False
```

**问题描述：** 健康检查失败时返回 `False`，但异常信息完全丢失。如果健康检查持续失败，开发者无法知道是网络问题、服务器问题还是配置问题。

**风险评级：** 低

**建议：** `logger.debug(f"[embed] health check failed: {e}")`。

---

## 三、tools 层异常处理问题

### 3.1 web_tools.py — Web 搜索与获取

#### FIND-042: `_anysearch_api()` 中 `requests.Session` 未使用 `with` 语句
**文件：** `tools/web_tools.py`  
**行号：** 28-35  

```python
28:    session = requests.Session()
29:    session.trust_env = False
30:    resp = session.post(ANYSEARCH_ENDPOINT, json=payload, headers=headers, timeout=30)
```

**问题描述：** 每次调用 `_anysearch_api()` 都创建新的 `Session` 但没有关闭。虽然 Python 的垃圾回收最终会清理，但在高频调用时可能导致套接字泄漏（特别是在 Windows 上）。这不是直接的异常处理问题，但属于资源管理问题。

**风险评级：** 中

**建议：** 使用 `with requests.Session() as session:` 或复用模块级 session。

---

#### FIND-043: `WebSearchTool.execute()` 和 `WebFetchTool.execute()` 中 `except Exception`
**文件：** `tools/web_tools.py`  
**行号：** 95-97, 141-143  

```python
95:        except Exception as e:
96:            logger.warning(f"Web search failed: {e}")
97:            return ToolResult.fail(f"搜索失败: {e}")
```

**问题描述：** 两个工具的 `execute()` 都用 `except Exception` 捕获所有异常。这虽然防止了工具崩溃，但可能掩盖了需要关注的错误（如 API 密钥无效、配额耗尽等）。

**风险评级：** 低

---

### 3.2 file_tools.py — 文件操作

#### FIND-044: `_is_binary()` 中异常被捕获但使用了未定义的变量
**文件：** `tools/file_tools.py`  
**行号：** 21-28  

```python
21:    try:
22:        with open(filepath, "rb") as f:
23:            chunk = f.read(1024)
24:        return b"\x00" in chunk
25:    except Exception as e:
26:        logger.debug(f"Binary check failed for {path}: {e}")
27:        return False
```

**问题描述：** 第 26 行使用了变量 `path`，但该变量未定义。应该是 `filepath`。这个 bug 会导致 `logger.debug()` 本身抛出 `NameError`，然后被外层的 `except Exception` 捕获，最终返回 `False`。虽然功能上没问题（返回 `False` 表示假设为文本文件），但日志记录失败，且这是一个明显的代码错误。

**风险评级：** 高

**建议：** 修复 `path` 为 `filepath`。

---

#### FIND-045: `_get_allowed_roots()` 中 `except Exception` 过于宽泛
**文件：** `tools/file_tools.py`  
**行号：** 46-48  

```python
46:    except Exception as e:
47:        logger.warning(f"Config load failed for allowed roots, using project fallback: {e}")
48:        return [os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))]
```

**问题描述：** 配置加载失败时返回项目根目录作为 fallback。如果失败原因是 `MemoryError`，返回 fallback 可能也无济于事。

**风险评级：** 低

---

#### FIND-046: `ReadFileTool._read_one()` 中 `os.path.getsize()` 可能抛出 `OSError`
**文件：** `tools/file_tools.py`  
**行号：** 137  

```python
137:        size = os.path.getsize(resolved)
```

**问题描述：** 在检查文件大小之前，`os.path.getsize()` 可能因文件在检查后被删除（TOCTOU 竞争条件）而抛出 `OSError`。这个异常未被捕获，会导致 `_read_one()` 失败。

**风险评级：** 低

**建议：** 将 `os.path.getsize()` 放入 `try/except OSError`。

---

#### FIND-047: `ReadFileTool.execute()` 中多文件读取时部分失败的处理
**文件：** `tools/file_tools.py`  
**行号：** 187-191  

```python
187:        results = []
188:        for p in paths:
189:            r = self._read_one(p, limit, offset)
190:            results.append(r.output if r.success else f"[失败] {p}: {r.output}")
191:        return ToolResult.ok("\n\n---\n\n".join(results))
```

**问题描述：** 多文件读取时，单个文件失败不会导致整体失败，但失败信息被拼接在输出中。这是合理的设计，但如果 `_read_one()` 本身抛出异常（如 FIND-046 的情况），整个 `execute()` 会失败。

**风险评级：** 低

---

### 3.3 search_tools.py — 搜索工具

#### FIND-048: `GlobTool.execute()` 中 `os.walk()` 的异常未处理
**文件：** `tools/search_tools.py`  
**行号：** 68-81  

```python
68:        for dirpath, _, fnames in os.walk(root):
69:            rel_dir = os.path.relpath(dirpath, root)
70:            for fname in fnames:
71:                ...
72:                try:
73:                    size = os.path.getsize(full_path)
74:                except OSError:
75:                    size = 0
```

**问题描述：** `os.walk()` 本身在遍历过程中如果目录权限变化或目录被删除，可能抛出 `OSError`。虽然 `os.walk()` 内部会处理一些错误（如 `PermissionError` 会跳过），但在某些情况下（如 `root` 在遍历中被删除）仍可能抛出异常。

**风险评级：** 低

---

#### FIND-049: `GrepTool.execute()` 中文件读取异常被静默忽略
**文件：** `tools/search_tools.py`  
**行号：** 188-192  

```python
188:            try:
189:                with open(filepath, encoding="utf-8", errors="ignore") as f:
190:                    lines = f.readlines()
191:            except Exception:
192:                continue
```

**问题描述：** 文件读取失败时静默 `continue`。虽然这在搜索工具中是合理的（跳过不可读文件），但 `except Exception` 过于宽泛，且没有日志记录。如果大量文件不可读，用户可能不知道搜索范围被缩小了。

**风险评级：** 低

**建议：** `logger.debug(f"Skipping unreadable file: {filepath}")`。

---

### 3.4 music_tool.py — 音乐播放

#### FIND-050: `MusicListTool.execute()` 中 `except Exception`
**文件：** `tools/music_tool.py`  
**行号：** 92-93  

```python
92:        except Exception as e:
93:            return ToolResult.fail(f"读取目录失败: {e}")
```

**问题描述：** 目录读取失败时返回错误结果。这是合理的，但 `except Exception` 过于宽泛。

**风险评级：** 低

---

#### FIND-051: `MusicPlayTool._play()` 中 `os.startfile()` 的异常处理
**文件：** `tools/music_tool.py`  
**行号：** 150-155  

```python
150:    def _play(self, filepath: str, display_name: str) -> ToolResult:
151:        try:
152:            os.startfile(filepath)
153:            return ToolResult.ok(f"正在播放: {display_name}")
154:        except Exception as e:
155:            return ToolResult.fail(f"播放失败: {e}")
```

**问题描述：** `os.startfile()` 是 Windows 特有的函数，在 Linux/macOS 上会抛出 `AttributeError`。虽然项目主要在 Windows 上运行，但如果未来需要跨平台支持，这里需要处理。

**风险评级：** 低

---

### 3.5 notify_tool.py — 通知工具

#### FIND-052: `NotifyTool.execute()` 中 PowerShell 子进程的异常被完全静默
**文件：** `tools/notify_tool.py`  
**行号：** 59-65  

```python
59:            try:
60:                subprocess.run(
61:                    ['powershell', '-NoProfile', '-Command', ps],
62:                    capture_output=True, timeout=10,
62:                )
63:            except Exception:
64:                pass
```

**问题描述：** 通知发送失败时异常被完全静默吞掉（`except Exception: pass`）。这是本次审查中发现的最严重的**静默吞异常**案例之一。通知失败可能由多种原因导致（PowerShell 未安装、权限不足、Windows Runtime 组件不可用），但用户和开发者都完全不知道发生了什么。

**风险评级：** 高

**建议：** 至少添加 `logger.warning(f"Notification failed: {e}")`。

---

### 3.6 memory_tools.py — 记忆工具

#### FIND-053: `RecallTool.execute()` 中无异常保护
**文件：** `tools/memory_tools.py`  
**行号：** 38-70  

**问题描述：** `RecallTool.execute()` 调用 `self.retriever._extract_keywords()`、`self.ltm.search_facts()`、`self.ltm.search_experiences()`、`self.ltm.get_recent_reflections()`，这些方法都可能因数据库操作失败而抛出异常。`execute()` 本身没有 `try/except`，异常会向上传播到 `execute_tool_calls()` 的裸 except 中被捕获。

**风险评级：** 中

---

#### FIND-054: `RememberTool.execute()` 中 `float()` 转换可能失败
**文件：** `tools/memory_tools.py`  
**行号：** 115  

```python
115:        importance = float(args.get("importance", 0.6))
```

**问题描述：** 如果 LLM 传入的 `importance` 不是数字（如空字符串、"high"），`float()` 会抛出 `ValueError`。这个异常会向上传播到 `execute_tool_calls()` 中被捕获，但工具调用会被标记为失败，可能导致 Agent 2 的重试循环被触发。

**风险评级：** 中

**建议：** 添加 `try/except ValueError` 并使用默认值。

---

## 四、web 层异常处理问题

### 4.1 server.py — Web 服务器

#### FIND-055: `chat_api()` 中 `agent.process_message()` 的异常未处理
**文件：** `web/server.py`  
**行号：** 46-48  

```python
46:    _, agent = session_manager.get_or_create(session_id)
47:    response = agent.process_message(message)
48:    logger.info(f"[rest] chat_done ...")
```

**问题描述：** REST API 端点 `/api/chat` 中，`agent.process_message()` 可能抛出多种异常（API 错误、数据库错误、内存错误等）。这些异常未被捕获，会直接返回 500 Internal Server Error 给客户端，但没有友好的错误消息。

**风险评级：** 高

**建议：** 添加 `try/except Exception` 并返回 `{"error": "处理失败，请稍后重试"}`。

---

#### FIND-056: `_send_segments()` 中 `websocket.send_text()` 的异常未处理
**文件：** `web/server.py`  
**行号：** 116-127  

```python
116:async def _send_segments(websocket: WebSocket, agent, response: str, emotion: str):
117:    segments = _split_segments(response)
118:    for i, seg in enumerate(segments):
119:        if i > 0:
120:            await asyncio.sleep(_calc_delay(emotion, len(seg)))
121:        await websocket.send_text(json.dumps({...}))
```

**问题描述：** 如果 WebSocket 在发送过程中断开，`send_text()` 会抛出异常。这个异常会向上传播到调用者（`_proactive_loop` 或 `websocket_endpoint`），在 `_proactive_loop` 中被 `except Exception` 捕获，在 `websocket_endpoint` 中也被 `except Exception` 捕获。但如果异常发生在 `send_text()` 和 `send_text()` 之间的 `asyncio.sleep()` 期间，客户端可能已经断开，但服务器仍在尝试发送。

**风险评级：** 中

**建议：** 在 `_send_segments()` 中添加 `try/except (WebSocketDisconnect, RuntimeError)` 并提前返回。

---

#### FIND-057: `_proactive_loop()` 中 `except Exception` 过于宽泛
**文件：** `web/server.py`  
**行号：** 194-196  

```python
194:        except Exception as e:
195:            logger.warning(f"Proactive error: {e}")
196:            await asyncio.sleep(30)
```

**问题描述：** 主动行为循环中的异常被捕获后等待 30 秒继续。这虽然防止了循环崩溃，但 `except Exception` 会捕获 `asyncio.CancelledError`（Python 3.8+），导致任务取消请求被忽略。虽然 `except asyncio.CancelledError` 在上方已经被单独处理，但如果 `CancelledError` 在嵌套调用中被包装，可能无法正确捕获。

**风险评级：** 中

**建议：** 显式排除 `CancelledError`：`except Exception as e: if isinstance(e, asyncio.CancelledError): raise`。

---

#### FIND-058: `_proactive_loop()` 中 `ag._generate_dream()` 在线程池中执行无异常保护
**文件：** `web/server.py`  
**行号：** 150-151  

```python
150:                        loop = asyncio.get_event_loop()
151:                        await loop.run_in_executor(None, ag._generate_dream)
```

**问题描述：** `run_in_executor()` 中执行的同步函数如果抛出异常，异常会被传播到 `await` 点。虽然 `_generate_dream()` 内部有 `try/except`，但如果 `SleepManager.generate_dream()` 中的异常未被捕获（实际上有捕获，见 FIND-027），异常会中断 `_proactive_loop()` 的当前迭代，进入 `except Exception` 处理。

**风险评级：** 低

---

#### FIND-059: `websocket_endpoint()` 中 `except Exception` 后尝试发送错误消息可能再次失败
**文件：** `web/server.py`  
**行号：** 241-246  

```python
241:    except Exception as e:
242:        logger.error(f"WebSocket error: {e}")
243:        try:
244:            await websocket.send_text(json.dumps({"type": "error", "content": str(e)}))
245:        except (WebSocketDisconnect, ConnectionError, RuntimeError):
246:            pass
```

**问题描述：** WebSocket 处理中的异常被捕获后尝试发送错误消息，但捕获的异常类型列表可能不完整。例如，`websocket.send_text()` 可能抛出 `RuntimeError`（已被捕获），但也可能抛出 `AttributeError`（如果 `websocket` 对象已被清理）。

**风险评级：** 低

**建议：** 使用更广泛的捕获：`except Exception: pass`。

---

### 4.2 session.py — 会话管理

#### FIND-060: `WebAgent.__init__()` 中 `repo.get_recent_turns_sync()` 的异常未处理
**文件：** `web/session.py`  
**行号：** 36-37  

```python
36:        for t in repo.get_recent_turns_sync(30):
37:            self.short_term.add_turn(t["role"], t["content"])
```

**问题描述：** 从数据库恢复近期对话时，如果 `get_recent_turns_sync()` 抛出异常（数据库损坏、查询错误），整个 `WebAgent` 初始化失败。这会导致 `get_or_create()` 失败，用户无法创建会话。

**风险评级：** 高

**建议：** 添加 `try/except` 并记录警告，允许在无法恢复历史的情况下继续创建新会话。

---

#### FIND-061: `WebAgent.process_message()` 中 `personality.save()` 的异常未处理
**文件：** `web/session.py`  
**行号：** 88-89  

```python
88:        result = self.agent.process_message(...)
89:        self.personality.save(self.config.personality_file)
```

**问题描述：** 处理完消息后保存人格状态，如果 `save()` 失败（磁盘满、权限不足），异常会向上传播，导致 API 返回 500 错误，即使消息处理已经成功。这会导致客户端认为请求失败，但实际上 AI 已经处理了消息。

**风险评级：** 高

**建议：** 将 `personality.save()` 放入 `try/except OSError` 并记录错误，不要影响 API 响应。

---

#### FIND-062: `SessionManager.open()` 中数据库打开异常未处理
**文件：** `web/session.py`  
**行号：** 131-134  

```python
131:    async def open(self):
132:        self.db = Database(self.config.db_path)
133:        await self.db.open()
134:        self.repo = Repository(self.db)
```

**问题描述：** `Database.open()` 可能因磁盘满、权限不足、数据库文件损坏而抛出异常。这些异常会向上传播到 `lifespan()` 上下文管理器，导致服务器启动失败。虽然这是合理的行为（没有数据库无法运行），但错误消息可能不够友好。

**风险评级：** 中

---

## 五、storage 层异常处理问题

### 5.1 database.py — 数据库连接

#### FIND-063: `Database.open()` 中 `aiosqlite.connect()` 的异常未处理
**文件：** `storage/database.py`  
**行号：** 17-24  

```python
17:    async def open(self) -> None:
18:        os.makedirs(os.path.dirname(self.db_path) or ".", exist_ok=True)
19:        self.conn = await aiosqlite.connect(self.db_path)
20:        self.conn.row_factory = aiosqlite.Row
21:        await self.conn.execute("PRAGMA journal_mode=WAL")
22:        await self.conn.execute("PRAGMA foreign_keys=ON")
23:        await self.initialize()
```

**问题描述：** 数据库打开和初始化过程中没有 `try/except`。如果 `aiosqlite.connect()` 失败（如路径不可写、磁盘满），或 `PRAGMA` 执行失败（如 SQLite 版本不支持 WAL），异常会直接向上传播。

**风险评级：** 中

---

#### FIND-064: `Database.cursor()` 中 `await self.conn.commit()` 可能失败
**文件：** `storage/database.py`  
**行号：** 34  

```python
32:            try:
33:                yield c
34:                await self.conn.commit()
35:            except aiosqlite.Error:
36:                await self.conn.rollback()
37:                raise
```

**问题描述：** `cursor()` 上下文管理器在 `yield c` 后尝试 `commit()`。如果 `commit()` 失败（如磁盘 I/O 错误），异常被抛出，但此时 `rollback()` 可能也无法执行（因为事务可能已经中断）。更关键的是，`commit()` 失败意味着数据可能部分写入，但调用者不知道哪些数据已写入、哪些未写入。

**风险评级：** 中

---

#### FIND-065: `Database.initialize()` 中 `ALTER TABLE` 可能失败
**文件：** `storage/database.py`  
**行号：** 128-134  

```python
128:                if column not in columns:
129:                    await c.execute(f"ALTER TABLE {table} ADD COLUMN {column} {col_type} DEFAULT {default_val}")
130:                    logger.info(f"Schema migration: added {table}.{column}")
```

**问题描述：** 模式迁移中的 `ALTER TABLE` 如果失败（如数据库只读、列已存在但检查逻辑有 bug），异常会向上传播。虽然 `cursor()` 上下文管理器会回滚，但 SQLite 的 `ALTER TABLE` 是自动提交的，无法回滚。

**风险评级：** 中

---

### 5.2 repository.py — 数据仓库

#### FIND-066: `_run_sync()` 与 `memory/long_term.py` 中的实现重复
**文件：** `storage/repository.py`  
**行号：** 13-21  

```python
13:def _run_sync(coro):
14:    try:
15:        loop = asyncio.get_running_loop()
16:    except RuntimeError:
17:        return asyncio.run(coro)
18:    import concurrent.futures
19:    with concurrent.futures.ThreadPoolExecutor() as pool:
20:        return pool.submit(asyncio.run, coro).result()
```

**问题描述：** 与 FIND-032 相同的问题，代码重复。如果 `coro` 抛出异常，异常会被 `pool.submit().result()` 重新抛出。

**风险评级：** 低

---

#### FIND-067: 同步包装方法无异常隔离
**文件：** `storage/repository.py`  
**行号：** 29-30  

```python
29:    def insert_turn_sync(self, *a, **kw): return _run_sync(self.insert_turn(*a, **kw))
```

**问题描述：** 所有同步包装方法直接传递异常。如果数据库操作失败，异常会穿过同步层向上传播。这在 `Agent._react_loop()` 中的 `self.ltm.repo.insert_turn_sync()` 调用中可能导致响应流程中断。

**风险评级：** 中

---

#### FIND-068: `_row_to_fact()`、`_row_to_experience()`、`_row_to_reflection()` 中假设 row 字典包含所有键
**文件：** `storage/repository.py`  
**行号：** 299-327  

**问题描述：** 三个 `_row_to_*` 方法使用 `r["id"]`、`r["category"]` 等字典访问。如果查询返回的 row 缺少某些列（如 schema 迁移后旧数据），会抛出 `KeyError`。虽然当前 schema 确保了列的存在，但如果未来修改 schema 而没有更新这些方法，会导致运行时错误。

**风险评级：** 低

**建议：** 使用 `r.get("column", default)` 提供默认值。

---

## 六、models 层异常处理问题

### 6.1 personality.py — 情绪状态模型

#### FIND-069: `EmotionalState.from_dict()` 中 `cls(**filtered)` 可能因类型不匹配而失败
**文件：** `models/personality.py`  
**行号：** 282-286  

```python
282:    @classmethod
283:    def from_dict(cls, d: dict) -> "EmotionalState":
284:        field_names = set(cls.__dataclass_fields__)
285:        filtered = {k: v for k, v in d.items() if k in field_names}
286:        return cls(**filtered)
```

**问题描述：** 如果字典中的值类型与 dataclass 字段类型不匹配（如 `valence` 为字符串 `"0.5"` 而非浮点数），`cls(**filtered)` 不会立即失败（Python dataclass 不验证类型），但后续计算可能产生 `TypeError`（如 `self.valence + delta_v`）。

**风险评级：** 低

---

#### FIND-070: `PersonalityConfig.from_dict()` 中 `d["traits"]` 类型转换可能失败
**文件：** `models/personality.py`  
**行号：** 319-322  

```python
319:    @classmethod
320:    def from_dict(cls, d: dict) -> "PersonalityConfig":
321:        if "traits" in d and isinstance(d["traits"], dict):
322:            d["traits"] = [Trait(k, v) for k, v in d["traits"].items()]
```

**问题描述：** 如果 `d["traits"]` 是字典但值不是浮点数（如 `{"curiosity": "high"}`），`Trait(k, v)` 会接受任何类型（因为 dataclass 不验证类型），但后续计算可能失败。

**风险评级：** 低

---

## 七、config 和入口点异常处理问题

### 7.1 config.py — 配置管理

#### FIND-071: `load_config()` 中 `json.JSONDecodeError` 和 `OSError` 被捕获后使用默认配置
**文件：** `config.py`  
**行号：** 52-59  

```python
52:        try:
53:            with open(path, encoding="utf-8") as f:
54:                data = json.load(f)
55:        except (json.JSONDecodeError, OSError):
56:            logger.warning(f"[config] failed to parse: {path}, using defaults")
```

**问题描述：** 配置加载失败时使用默认配置。如果 `api_key` 在配置文件中但加载失败，程序会使用空字符串作为 API 密钥，导致后续 API 调用失败。这是一个级联故障：配置加载失败 -> 使用默认空密钥 -> API 调用 401 错误。

**风险评级：** 中

**建议：** 如果配置文件存在但解析失败，应该更明确地通知用户（如抛出异常或记录 error 级别日志）。

---

### 7.2 main.py — CLI 入口

#### FIND-072: `main()` 中 `db.close()` 可能在 `db.open()` 失败后被调用
**文件：** `main.py`  
**行号：** 115  

```python
115:        db.close()
```

**问题描述：** `main()` 的 `finally` 块中调用 `db.close()`。如果 `db.open()` 失败（如路径不可写），`db.conn` 为 `None`，`db.close()` 会成功（因为 `close()` 检查了 `if self.conn`）。但如果 `db` 对象本身创建失败（如 `Database` 构造异常），`db` 变量可能未定义，导致 `NameError`。

**风险评级：** 低

**建议：** 使用 `try/except NameError` 或在 `finally` 前确保 `db` 已定义。

---

#### FIND-073: `main()` 中 `agent.run()` 的异常未处理
**文件：** `main.py`  
**行号：** 111  

```python
110:    try:
111:        agent.run()
112:    except KeyboardInterrupt:
113:        pass
```

**问题描述：** 只捕获了 `KeyboardInterrupt`，其他异常（如 `MemoryError`、`SystemError`）会直接向上传播，导致程序以非零退出码终止。虽然 `agent.run()` 内部有 `except Exception`（FIND-008），但如果异常发生在 `agent.run()` 调用之前（如 `ConsoleInterface` 初始化失败），会在这里被抛出。

**风险评级：** 低

---

### 7.3 web_main.py — Web 入口

#### FIND-074: `main()` 中无异常保护
**文件：** `web_main.py`  
**行号：** 12-32  

**问题描述：** `main()` 函数没有任何 `try/except`。如果 `load_config()` 失败、`setup_logging()` 失败、或 `uvicorn.run()` 抛出异常，程序会直接崩溃。

**风险评级：** 低

---

## 八、ui 层异常处理问题

### 8.1 cli.py — CLI UI

#### FIND-075: `NonBlockingInputReader._reader()` 中 `sys.stdin.readline()` 可能抛出异常
**文件：** `ui/cli.py`  
**行号：** 33-36  

```python
33:    def _reader(self) -> None:
34:        while not self._sentinel.is_set():
35:            line = sys.stdin.readline()
36:            if not line:
37:                break
```

**问题描述：** `sys.stdin.readline()` 在标准输入被关闭（如管道断开）时会返回空字符串，但如果标准输入被重定向到不存在的文件，可能抛出 `OSError`。这个异常会终止后台读取线程，但主线程可能仍在运行，导致用户输入无法被读取。

**风险评级：** 低

---

## 九、prompts 层异常处理问题

### 9.1 system.py — 系统提示词构建

#### FIND-076: `build_system_prompt()` 中 `kwargs.get()` 的使用安全
**文件：** `prompts/system.py`  

**问题描述：** `build_system_prompt()` 使用 `kwargs.get("explore_mode", False)` 等获取可选参数。如果调用者传入了错误类型的参数（如 `explore_mode="yes"`），后续的条件判断可能不按预期工作。虽然这不是异常处理问题，但属于输入验证不足。

**风险评级：** 信息

---

# 汇总统计

## 按风险等级统计

| 风险等级 | 数量 | 占比 |
|---------|------|------|
| 高危 (Critical) | 7 | 12.5% |
| 中危 (High) | 14 | 25.0% |
| 低危 (Medium) | 18 | 32.1% |
| 信息 (Info) | 8 | 14.3% |
| 已归类 (其他) | 9 | 16.1% |
| **总计** | **56** | **100%** |

## 按问题类型统计

| 问题类型 | 数量 |
|---------|------|
| 裸 `except Exception` | 18 |
| 异常被静默吞掉 | 8 |
| 关键操作缺少异常保护 | 15 |
| 异常信息丢失/截断 | 7 |
| 资源泄漏 | 3 |
| 异常传播路径不清晰 | 5 |

## 按文件统计（问题数 Top 10）

| 文件 | 问题数 |
|------|--------|
| `core/provider.py` | 4 |
| `core/cli_controller.py` | 5 |
| `core/message_handler.py` | 3 |
| `core/inner_drive.py` | 4 |
| `core/tool_agent.py` | 2 |
| `core/dispatcher.py` | 3 |
| `core/context_manager.py` | 2 |
| `core/sleep_manager.py` | 2 |
| `core/personality.py` | 2 |
| `memory/consolidation.py` | 4 |
| `memory/retrieval.py` | 3 |
| `memory/embeddings.py` | 2 |
| `memory/long_term.py` | 2 |
| `tools/web_tools.py` | 2 |
| `tools/file_tools.py` | 4 |
| `tools/search_tools.py` | 2 |
| `tools/notify_tool.py` | 1 |
| `tools/memory_tools.py` | 2 |
| `web/server.py` | 5 |
| `web/session.py` | 3 |
| `storage/database.py` | 3 |
| `storage/repository.py` | 2 |
| `config.py` | 1 |
| `main.py` | 2 |
| `ui/cli.py` | 1 |

## 关键改进建议（按优先级排序）

### P0 - 立即修复

1. **FIND-044**: `file_tools.py` 第 26 行 `path` 未定义，修复为 `filepath`
2. **FIND-052**: `notify_tool.py` 第 63 行 `except Exception: pass` 添加日志
3. **FIND-030**: `personality.py` 第 113-116 行 `save()` 添加 `try/except OSError`
4. **FIND-010**: `cli_controller.py` 第 296-305 行 `_on_shutdown()` 添加异常保护

### P1 - 本周修复

5. **FIND-001**: `provider.py` 第 96-97 行 `_do_request()` 添加 JSON 解析异常保护
6. **FIND-003**: `provider.py` 第 57-80 行 `generate()` 添加 `Timeout` 捕获
7. **FIND-016/017/018**: `inner_drive.py` 中 API 调用添加异常保护
8. **FIND-021**: `tool_agent.py` 中 `run_with_request()` 添加 API 异常重试
9. **FIND-055**: `web/server.py` `chat_api()` 添加异常保护
10. **FIND-060**: `web/session.py` `WebAgent.__init__()` 添加历史恢复异常保护
11. **FIND-061**: `web/session.py` `process_message()` 中 `save()` 异常隔离

### P2 - 本月修复

12. **FIND-008**: `cli_controller.py` `run()` 中异常恢复时清理中间状态
13. **FIND-023**: `dispatcher.py` `execute_tool_calls()` 使用 `logger.exception`
14. **FIND-024**: `dispatcher.py` 修复 `asyncio.run()` 嵌套调用问题
15. **FIND-032**: `memory/long_term.py` 和 `storage/repository.py` 统一 `_run_sync` 实现
16. **FIND-042**: `web_tools.py` 复用 `requests.Session`
17. **FIND-057**: `web/server.py` `_proactive_loop()` 正确处理 `CancelledError`

### P3 - 持续改进

18. 审查所有 `except Exception` 的使用，替换为更具体的异常类型
19. 为所有关键操作（数据库写入、文件保存、API 调用）添加异常隔离
20. 建立异常处理编码规范：禁止裸 `except`、禁止静默吞异常、要求记录 traceback
21. 引入结构化日志，为异常添加上下文（session_id、turn_count、user_input 长度等）
22. 考虑引入 Sentry 或类似的错误追踪服务，用于生产环境监控

---

*本报告由 Claude Code 自动生成，基于对代码的静态分析。建议结合动态测试（如注入故障、模拟 API 失败）验证修复效果。*
