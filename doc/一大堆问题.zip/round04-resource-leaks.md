# 第4轮：错误处理与可靠性审查 — 资源泄漏专题

审查日期：2026-05-31
审查范围：core/provider.py, storage/database.py, web/session.py, core/agent.py, memory/embeddings.py, tools/web_tools.py 及关联模块
审查人：Claude Code

---

# 概述

本次审查聚焦 AI Friend 项目在长时间运行场景下的资源泄漏风险。项目采用双入口架构（CLI `main.py` + Web `web_main.py`），核心依赖包括 `requests` HTTP 会话、`aiosqlite` 异步数据库连接、`asyncio` 任务与事件循环、`threading` 锁与线程池，以及大量累积型内存结构（消息历史、工具调用记录、情绪事件等）。

经过对 20+ 个核心文件的逐行分析，共识别出 **23 项资源泄漏或可靠性缺陷**，按风险等级分布如下：

| 风险等级 | 数量 | 说明 |
|---------|------|------|
| 严重 (Critical) | 4 | 可能导致进程崩溃、连接池耗尽、文件描述符耗尽 |
| 高 (High) | 6 | 长期运行下内存/连接持续增长，影响稳定性 |
| 中 (Medium) | 8 | 边界条件下泄漏，或清理逻辑不完整 |
| 低 (Low) | 5 | 代码异味、重复清理、可维护性问题 |

---

# 详细发现

## 一、数据库连接泄漏

### 1.1 [CRITICAL] Web 端 Database 连接永不关闭

- **文件**：`D:\桌面\编程作品\AI朋友\web\session.py`
- **行号**：第 131-134 行（`open()`），第 146-153 行（`remove()`），第 169-174 行（`cleanup_old()`）
- **问题描述**：
  `SessionManager` 在 `open()` 中创建 `Database` 实例并调用 `await db.open()` 建立 `aiosqlite` 连接，但整个代码库中没有任何地方调用 `await db.close()`。`lifespan` 管理器在服务器关闭时仅记录日志，不关闭数据库连接。当 Web 服务器重启或部署新版本时，旧的 SQLite 连接（及 WAL 文件锁）可能残留。
- **风险分析**：
  - SQLite WAL 模式下，未正确关闭的连接可能导致 `-wal` 和 `-shm` 文件永久残留，极端情况下造成数据库损坏。
  - 虽然 `aiosqlite` 在进程退出时会回收连接，但在 Gunicorn/Uvicorn 多 worker 重载场景下，连接泄漏会累积。
- **修复建议**：
  在 `SessionManager` 中增加 `async def close(self)` 方法，在 `web/server.py` 的 `lifespan` 退出时调用：
  ```python
  async def close(self) -> None:
      if self.db:
          await self.db.close()
          self.db = None
  ```
  并在 `lifespan` 的 `finally` 或 `yield` 之后调用 `await session_manager.close()`。

### 1.2 [HIGH] CLI 端 `db.close()` 为同步调用，但 `Database.close()` 是异步的

- **文件**：`D:\桌面\编程作品\AI朋友\main.py`
- **行号**：第 115 行
- **问题描述**：
  `main.py` 的 `finally` 块中直接调用 `db.close()`，但 `Database.close()` 定义为 `async def close(self)`（`storage/database.py` 第 136-140 行）。在同步上下文中调用异步函数不会执行任何清理逻辑，连接实际上未被关闭。
- **风险分析**：
  CLI 模式下每次启动和退出都会留下一个未关闭的连接。虽然 CLI 是单会话进程，但在单元测试或频繁重启的调试场景中，这会累积未释放的文件描述符。
- **修复建议**：
  将 `main.py` 的 `finally` 块改为：
  ```python
  finally:
      await db.close()
  ```
  或确保 `Database` 提供同步关闭的备用方法。

### 1.3 [MEDIUM] `Repository` 同步包装器 `_run_sync` 每次创建新的 `ThreadPoolExecutor`

- **文件**：`D:\桌面\编程作品\AI朋友\storage\repository.py`
- **行号**：第 13-21 行
- **问题描述**：
  `_run_sync` 辅助函数在每次被调用时都新建一个 `concurrent.futures.ThreadPoolExecutor()`，执行完立即销毁。虽然 `with` 语句保证了关闭，但高频调用（如每条消息触发多次数据库操作）会导致线程频繁创建和销毁，产生显著的上下文切换开销。
- **风险分析**：
  - 这不是严格意义上的泄漏，但属于资源使用效率低下。在消息处理高峰期，线程创建开销可能成为瓶颈。
  - 更隐蔽的问题是：如果 `pool.submit(asyncio.run, coro).result()` 内部抛出异常，线程池的清理可能被延迟。
- **修复建议**：
  在 `Repository` 或 `Database` 级别维护一个单例 `ThreadPoolExecutor`，或使用 `asyncio.run_coroutine_threadsafe` 替代 `pool.submit(asyncio.run, ...)`。

### 1.4 [MEDIUM] `LongTermMemory._run_sync` 重复实现相同的线程池模式

- **文件**：`D:\桌面\编程作品\AI朋友\memory\long_term.py`
- **行号**：第 17-26 行
- **问题描述**：
  `LongTermMemory` 独立实现了与 `Repository._run_sync` 完全相同的逻辑。这意味着每次 LTM 的同步代理方法被调用时，都会独立创建一个 `ThreadPoolExecutor`。由于 `Agent` 同时持有 `Repository` 和 `LongTermMemory`，同一次消息处理可能并行触发两个线程池的创建。
- **修复建议**：
  统一使用 `storage.repository._run_sync` 或提取为共享工具函数，并复用同一个线程池实例。

---

## 二、requests.Session 管理

### 2.1 [CRITICAL] `KimiProvider` 的 `requests.Session` 在流式响应中可能泄漏连接

- **文件**：`D:\桌面\编程作品\AI朋友\core\provider.py`
- **行号**：第 25-30 行（Session 创建），第 82-134 行（`_do_request`）
- **问题描述**：
  `KimiProvider` 在 `__init__` 中创建一个 `requests.Session` 并复用。在 `_do_request` 中，流式模式下调用 `resp = self.session.post(..., stream=True)`，然后通过 `resp.iter_lines()` 逐行读取。如果发生以下情况，HTTP 连接可能不会被正确释放回连接池：
  1. `for line in resp.iter_lines()` 循环中发生异常（如 `KeyboardInterrupt`、回调函数 `on_token` 抛出异常）。
  2. 响应在 `[DONE]` 之前被中断，但代码没有调用 `resp.close()`。
  3. `requests` 的 `stream=True` 响应如果没有被完全消费，连接会保持打开状态直到垃圾回收。
- **风险分析**：
  - 在 WebSocket 长连接场景下，如果客户端频繁断开，服务端可能留下大量半开的 HTTP 连接，最终耗尽 `requests` 连接池（默认 10 个连接）。
  - 重试逻辑（第 57-80 行）在 `ConnectionError` 后会等待并重试，但旧的 `resp` 对象如果未被关闭，连接可能仍处于 `CLOSE_WAIT` 状态。
- **修复建议**：
  使用 `with` 语句确保响应对象被关闭：
  ```python
  with self.session.post(url, json=payload, stream=True, timeout=self.timeout) as resp:
      resp.raise_for_status()
      # ... 处理响应
  ```
  或者在整个 `_do_request` 方法中使用 `try/finally: resp.close()`。

### 2.2 [HIGH] `EmbeddingEngine` 的 `requests.Session` 无超时健康检查可能阻塞

- **文件**：`D:\桌面\编程作品\AI朋友\memory\embeddings.py`
- **行号**：第 21-22 行（Session 创建），第 74-83 行（`health_check`）
- **问题描述**：
  `EmbeddingEngine` 同样持有一个长期 `requests.Session`。`health_check()` 方法使用 `timeout=5`，但 `encode()` 方法在 `self._session.post(...)` 时如果嵌入服务器无响应，会阻塞 `timeout` 秒（默认 30 秒）。在 Web 端的 `MemoryConsolidator._embed_new_items()` 中，这个调用发生在同步上下文中（通过 `run_in_executor`），会阻塞一个线程 30 秒。
- **风险分析**：
  - 如果嵌入服务器宕机，每次记忆合并都会阻塞一个线程 30 秒。在高并发下，这会耗尽 `run_in_executor` 的默认线程池。
- **修复建议**：
  确保 `encode()` 的 `timeout` 参数可配置，并在 `health_check()` 失败时跳过编码，避免不必要的阻塞请求。

### 2.3 [HIGH] `tools/web_tools.py` 每次调用都创建新的 `requests.Session`

- **文件**：`D:\桌面\编程作品\AI朋友\tools\web_tools.py`
- **行号**：第 28-29 行
- **问题描述**：
  `_anysearch_api` 函数在每次调用时都创建一个新的 `requests.Session()`，设置 `trust_env=False`，发起 POST 请求，然后函数返回，Session 对象失去引用等待垃圾回收。这完全违背了 `Session` 的连接复用设计目的。
- **风险分析**：
  - 每次 Web 搜索或网页获取都会新建 TCP 连接，产生 TCP 握手开销。
  - 在高频工具调用场景（Agent 2 的多轮重试）下，短时间内可能创建数十个 Session，导致本地端口耗尽（ephemeral port exhaustion）。
  - Session 对象及其底层 `urllib3` 连接池的清理依赖垃圾回收，不可控。
- **修复建议**：
  将 `WebSearchTool` 和 `WebFetchTool` 改为在 `__init__` 中创建 Session，或在模块级别维护一个全局 Session：
  ```python
  _session = requests.Session()
  _session.trust_env = False
  ```

---

## 三、ThreadPoolExecutor 泄漏

### 3.1 [CRITICAL] `web/server.py` 的 `run_in_executor` 使用默认线程池，无上限

- **文件**：`D:\桌面\编程作品\AI朋友\web\server.py`
- **行号**：第 150-151 行（`_generate_dream`），第 166-180 行（proactive action）
- **问题描述**：
  `asyncio.get_event_loop().run_in_executor(None, ...)` 使用事件循环的默认 `ThreadPoolExecutor`。默认线程池的最大线程数取决于 Python 版本（3.8+ 为 `min(32, os.cpu_count() + 4)`）。在以下场景下，线程可能被无限堆积：
  1. `_proactive_loop` 中每 15 秒可能触发一次 `run_in_executor` 调用 `process_proactive_with_intent` 或 `process_explore_with_intent`。
  2. 如果这些同步方法内部触发 LLM 调用（耗时数秒到数十秒），而 proactive loop 继续运行，新的任务会被提交到线程池。
  3. 默认线程池的线程在空闲 60 秒后才会被回收，但在高负载下线程数可能达到上限 32。
- **风险分析**：
  - 当线程池满时，新的 `run_in_executor` 调用会被排队，导致 WebSocket 消息处理延迟。
  - 如果线程池中的线程因 `KimiProvider` 的流式响应阻塞（见 2.1），整个 Web 服务器的响应能力会下降。
- **修复建议**：
  使用自定义的 `ThreadPoolExecutor` 并设置合理的 `max_workers`，在 `SessionManager` 或应用生命周期中统一管理：
  ```python
  executor = concurrent.futures.ThreadPoolExecutor(max_workers=8, thread_name_prefix="agent_worker")
  ```
  并在关闭时调用 `executor.shutdown(wait=True)`。

### 3.2 [HIGH] `SleepManager._generate_dream` 在 `run_in_executor` 中调用 LLM，无超时控制

- **文件**：`D:\桌面\编程作品\AI朋友\web\server.py`
- **行号**：第 150-151 行
- **问题描述**：
  ```python
  loop = asyncio.get_event_loop()
  await loop.run_in_executor(None, ag._generate_dream)
  ```
  `_generate_dream` 内部调用 `self._provider.generate(...)`，这是一个可能耗时数十秒的同步阻塞调用。如果 LLM API 无响应，这个线程会被永久阻塞，占用线程池的一个槽位。
- **修复建议**：
  为 `run_in_executor` 包装 `asyncio.wait_for` 超时，或在 `KimiProvider` 内部确保所有请求都有严格的超时控制。

---

## 四、asyncio.Task 泄漏（Proactive Task）

### 4.1 [CRITICAL] `_proactive_loop` 任务在 WebSocket 断开时可能未被正确取消

- **文件**：`D:\桌面\编程作品\AI朋友\web\server.py`
- **行号**：第 216-217 行（任务创建），第 239-249 行（断开处理）
- **问题描述**：
  ```python
  task = asyncio.create_task(_proactive_loop(websocket, session_id))
  session_manager.register_proactive(session_id, task, websocket)
  ```
  当 WebSocket 断开时，`finally` 块调用 `session_manager.remove(session_id)`，这会取消任务。但存在以下竞态条件：
  1. 如果客户端在 `init` 消息后立即断开，`task` 可能尚未被注册到 `session_manager` 中，`remove()` 找不到任务。
  2. 如果 `register_proactive` 被调用两次（客户端重连），旧任务会被取消，但如果旧任务正在执行 `run_in_executor` 中的同步代码，`task.cancel()` 不会中断线程中的执行。
  3. 被取消的任务如果捕获了 `asyncio.CancelledError` 但没有正确退出，可能变成"僵尸任务"。
- **风险分析**：
  - 已取消但未完成的任务会持续占用事件循环的资源。
  - 如果任务在 `run_in_executor` 中阻塞，取消信号无法传递到线程池线程，导致线程泄漏。
- **修复建议**：
  1. 在 `register_proactive` 中确保旧任务被取消后，等待其完成（`await old_task` 或设置超时）。
  2. 在 `_proactive_loop` 的 `finally` 块中确保清理逻辑被执行。
  3. 考虑使用 `asyncio.shield` 保护关键清理代码。

### 4.2 [HIGH] `_proactive_loop` 中的异常处理过于宽泛，可能吞掉取消信号

- **文件**：`D:\桌面\编程作品\AI朋友\web\server.py`
- **行号**：第 192-196 行
- **问题描述**：
  ```python
  except asyncio.CancelledError:
      break
  except Exception as e:
      logger.warning(f"Proactive error: {e}")
      await asyncio.sleep(30)
  ```
  虽然 `CancelledError` 被正确捕获并 `break`，但如果 `CancelledError` 在 `await asyncio.sleep(15)`（第 191 行）期间被触发，它会正常抛出。问题在于：如果 `CancelledError` 在 `run_in_executor` 返回之前被触发，任务会等待 `run_in_executor` 完成才能处理取消信号。
- **修复建议**：
  将 `run_in_executor` 调用包装在 `asyncio.wait_for` 中，并设置合理的超时（如 60 秒），确保即使同步代码阻塞，任务也能在合理时间内响应取消。

### 4.3 [MEDIUM] `cleanup_old` 驱逐会话时不取消 proactive 任务

- **文件**：`D:\桌面\编程作品\AI朋友\web\session.py`
- **行号**：第 169-174 行
- **问题描述**：
  `SessionManager.cleanup_old()` 在会话数超过 `max_sessions` 时，仅从 `_sessions` 字典中弹出最旧的会话，但没有检查或取消对应的 proactive 任务。被驱逐的会话的 proactive task 会继续在后台运行，尝试向一个可能已被移除的 WebSocket 发送消息。
- **风险分析**：
  - 被驱逐会话的 proactive task 会持续消耗 CPU 和内存。
  - 当 task 尝试 `websocket.send_text()` 时，由于 WebSocket 已断开，会抛出异常并被捕获，进入 30 秒的睡眠，然后再次尝试，形成无限循环。
- **修复建议**：
  在 `cleanup_old()` 中，驱逐会话时应同时调用 `self.remove(oldest)` 以触发完整的清理逻辑，而不是直接 `pop`。

---

## 五、文件句柄泄漏

### 5.1 [HIGH] `Personality.save()` 和 `SleepManager` 的文件操作无异常安全关闭

- **文件**：`D:\桌面\编程作品\AI朋友\core\personality.py`
- **行号**：第 113-116 行
- **问题描述**：
  ```python
  with open(path, "w", encoding="utf-8") as f:
      json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
  ```
  虽然使用了 `with` 语句，但如果 `json.dump` 在写入过程中抛出异常（如磁盘满），文件会被部分写入并截断，但 `with` 会确保关闭。这不是严格泄漏，但属于可靠性问题。
- **文件**：`D:\桌面\编程作品\AI朋友\core\sleep_manager.py`
- **行号**：第 27-28 行，第 35-36 行
- **问题描述**：
  `_load_sleep_state` 和 `_save_sleep_state` 使用 `with open(...)`，但 `_save_sleep_state` 在 `__init__` 中被调用时，如果文件路径所在的目录不存在，会抛出 `FileNotFoundError`，且异常被捕获后仅记录日志，睡眠状态丢失。
- **修复建议**：
  在写入前确保目录存在：`os.makedirs(os.path.dirname(path), exist_ok=True)`。

### 5.2 [MEDIUM] `tools/file_tools.py` 的 `_is_binary` 读取文件后未显式关闭（已自动关闭）

- **文件**：`D:\桌面\编程作品\AI朋友\tools\file_tools.py`
- **行号**：第 23-26 行
- **问题描述**：
  ```python
  with open(filepath, "rb") as f:
      chunk = f.read(1024)
  ```
  实际上使用了 `with`，所以会自动关闭。但第 27 行的日志消息引用了未定义的变量 `path`（应为 `filepath`），这会导致异常信息不准确。
- **修复建议**：
  修正变量名 `path` -> `filepath`。

### 5.3 [MEDIUM] `config.py` 的 `load_config` 文件句柄在 JSON 解析失败时安全，但日志记录器可能在配置加载前未初始化

- **文件**：`D:\桌面\编程作品\AI朋友\config.py`
- **行号**：第 48-78 行
- **问题描述**：
  `load_config` 使用 `with open(...)` 读取配置文件，这是安全的。但如果在 `setup_logging` 之前调用 `load_config`（实际流程中 `setup_logging` 在 `main.py` 第 30 行调用，而 `load_config` 在第 29 行调用），则 `logger.info` 和 `logger.warning` 会使用默认的 `logging` 配置（输出到 stderr），这不是泄漏，但可能导致日志丢失或重复。
- **修复建议**：
  调整 `main.py` 和 `web_main.py` 中的调用顺序：先 `setup_logging`，再 `load_config`。

---

## 六、内存泄漏（SessionManager, _tool_call_history）

### 6.1 [CRITICAL] `SessionManager._sessions` 字典在会话移除后不清除引用，导致 WebAgent 及其所有资源无法释放

- **文件**：`D:\桌面\编程作品\AI朋友\web\session.py`
- **行号**：第 126 行，第 146-153 行
- **问题描述**：
  `SessionManager.remove()` 从 `_sessions` 中 `pop` 会话，但 `WebAgent` 实例持有大量引用：
  - `KimiProvider`（含 `requests.Session`）
  - `LongTermMemory`（含 `Repository` -> `Database`）
  - `ConversationBuffer`（含 `deque`）
  - `MemoryRetriever`（含 `EmbeddingEngine` -> `requests.Session`）
  - `MemoryConsolidator`（含 `EmbeddingEngine` 引用）
  - `Agent`（含 `_tool_call_history`、`_react_messages` 等）
  - `Personality`（含 `EmotionalState`）
  - `ToolRegistry`（含所有工具实例）
  虽然 `pop` 从字典中移除了引用，但如果 `WebAgent` 的某些组件被其他长期存活的对象引用（如 `Database` 和 `Repository` 是 `SessionManager` 级别的单例），`WebAgent` 实例本身会被垃圾回收。但问题在于：`WebAgent` 的 `__init__` 中创建了独立的 `KimiProvider`、`EmbeddingEngine` 等，这些对象在 `WebAgent` 被回收时应该一起被回收。然而，如果 `asyncio.Task` 或 `ThreadPoolExecutor` 中持有对 `WebAgent` 的闭包引用，垃圾回收可能无法及时进行。
- **风险分析**：
  - 在高并发场景下（大量会话创建和断开），如果 `WebAgent` 及其组件不能被及时回收，内存使用会持续上升。
  - 每个 `WebAgent` 实例的 `KimiProvider.session` 和 `EmbeddingEngine._session` 各持有一个 `requests.Session`，每个 Session 的底层连接池占用内存。
- **修复建议**：
  1. 在 `WebAgent` 中增加显式的 `close()` 方法，关闭所有可关闭的资源（Provider Session、Embedding Session 等）。
  2. 在 `SessionManager.remove()` 中调用 `web_agent.close()` 后再 `pop`。
  3. 确保 `asyncio.Task` 和线程池回调中不持有对 `WebAgent` 的强引用。

### 6.2 [HIGH] `Agent._tool_call_history` 无限增长（实际有上限，但设计脆弱）

- **文件**：`D:\桌面\编程作品\AI朋友\core\agent.py`
- **行号**：第 57 行，第 162-169 行
- **问题描述**：
  ```python
  self._tool_call_history: list[dict] = []
  # ...
  if len(self._tool_call_history) > 20:
      self._tool_call_history = self._tool_call_history[-20:]
  ```
  虽然代码通过切片保持了列表长度不超过 20，但每次切片都会创建一个新的列表对象，旧的列表如果仍被某些引用持有（如调试器、日志上下文），会短暂存在两份数据。更严重的问题是：`_tool_call_history` 被注入到系统提示中（`core/message_handler.py` 第 263 行 `tool_call_history=a._tool_call_history`），如果历史记录中的 `output` 字段包含大段文本（虽然被截断到 200 字符），20 条记录就是 4000 字符，这会增加每次 LLM 调用的 token 消耗。
- **修复建议**：
  使用 `collections.deque(maxlen=20)` 替代列表，避免切片创建新对象，并确保内存占用恒定。

### 6.3 [HIGH] `Agent._react_messages` 在 ReAct 循环中持续累积，无清理机制

- **文件**：`D:\桌面\编程作品\AI朋友\core\agent.py`
- **行号**：第 82 行，第 119-181 行（`_react_loop`）
- **问题描述**：
  `_react_loop` 在每次工具调用迭代中都会将 assistant 的响应和 tool results 追加到 `messages` 列表中。虽然单次调用的迭代次数被 `_max_tool_iterations`（默认 10）限制，但如果用户进行大量对话轮次，`_react_messages` 在每次 `_react_loop` 调用后会被 `_reset_react()` 重置。但 `_reset_react()` 仅设置为 `None`，如果之前的列表仍被某些闭包或异常堆栈引用，可能无法立即释放。
- **风险分析**：
  在正常的消息处理流程中这不是严重问题，但如果 `_react_loop` 中发生未捕获的异常（如 `MemoryError`），`_reset_react()` 可能不会被调用，导致 `messages` 列表持续累积。
- **修复建议**：
  在 `_react_loop` 的 `finally` 块中确保 `_reset_react()` 被调用，无论是否发生异常。

### 6.4 [MEDIUM] `MemoryConsolidator._pending_buffer` 在 `consolidate()` 异常时可能丢失数据或重复处理

- **文件**：`D:\桌面\编程作品\AI朋友\memory\consolidation.py`
- **行号**：第 25 行，第 47-80 行
- **问题描述**：
  ```python
  self._pending_buffer.clear()
  ```
  `consolidate()` 在第 80 行清除 pending buffer。如果前面的步骤（如 `_extract_facts`、`_summarize_experience`、`_generate_reflection`）中发生异常，buffer 不会被清除，导致下次调用时重复处理相同的 turns。
- **风险分析**：
  - 重复处理会导致数据库中插入重复的事实、经历和反思。
  - 如果异常频繁发生（如 LLM API 不稳定），pending buffer 会无限增长。
- **修复建议**：
  将 `_pending_buffer.clear()` 放入 `try/finally` 块中，或者使用临时变量保存待处理的 turns，处理成功后再清除原 buffer。

### 6.5 [MEDIUM] `EmotionalState.emotion_events` 列表上限为 20，但事件对象包含大字符串

- **文件**：`D:\桌面\编程作品\AI朋友\models\personality.py`
- **行号**：第 67 行，第 239-262 行
- **问题描述**：
  `emotion_events` 是一个普通列表，上限为 20 个事件。每个事件包含 `trigger`（100 字符）和 `context`（200 字符），总计约 300 字符 * 20 = 6KB。虽然不大，但 `EmotionalState` 被序列化到 `personality.json` 中，每次 `Personality.save()` 都会写入这 20 个事件。如果事件中的字符串包含 Unicode 或特殊字符，JSON 序列化/反序列化的开销会增加。
- **修复建议**：
  使用 `collections.deque(maxlen=20)` 替代列表，避免手动维护 `pop(0)` 的 O(n) 操作。

### 6.6 [LOW] `ConversationBuffer._turns` 的 `deque` 在 `clear()` 后可能保留旧对象的引用

- **文件**：`D:\桌面\编程作品\AI朋友\memory\short_term.py`
- **行号**：第 66-70 行
- **问题描述**：
  `deque.clear()` 会移除所有元素，但 CPython 的实现中，`clear()` 后底层块可能仍保留对部分元素的引用，直到新的元素被追加。这不是标准的内存泄漏，但在极端内存紧张的环境下可能导致旧对象存活时间延长。
- **风险分析**：
  极低。`deque` 的 `clear()` 在 CPython 3.9+ 中已经优化，不会保留引用。
- **修复建议**：
  无需修复，但可考虑在 `clear()` 后显式调用 `gc.collect()`（不推荐，除非有实际证据表明存在问题）。

---

## 七、WebSocket 连接泄漏

### 7.1 [CRITICAL] WebSocket 断开后，`session_manager.remove()` 可能不清理 `_active_ws`

- **文件**：`D:\桌面\编程作品\AI朋友\web\session.py`
- **行号**：第 128 行，第 155-162 行，第 165-167 行
- **问题描述**：
  `register_proactive` 将 WebSocket 存入 `_active_ws[sid]`。当 WebSocket 断开时，`remove()` 会 `pop` 这个 WebSocket。但存在以下问题：
  1. 如果客户端发送 `init` 消息后从未发送其他消息就断开，`session_id` 可能为 `None`，`finally` 块中的 `if session_id:` 判断会跳过 `remove()`。
  2. 如果同一个 session_id 的客户端重连，`register_proactive` 会覆盖 `_active_ws[sid]`，但旧的 WebSocket 对象可能仍被某个异步任务引用。
- **风险分析**：
  - 未清理的 WebSocket 对象会占用内存，且其底层的 TCP 连接可能处于 `CLOSE_WAIT` 状态。
- **修复建议**：
  在 `websocket_endpoint` 中，即使 `session_id` 为 `None`，也应该尝试关闭 WebSocket 连接。

### 7.2 [HIGH] `_proactive_loop` 使用 `session_manager.get_active_ws()` 获取 WebSocket，但可能在发送时 WebSocket 已关闭

- **文件**：`D:\桌面\编程作品\AI朋友\web\server.py`
- **行号**：第 136 行
- **问题描述**：
  ```python
  active_ws = session_manager.get_active_ws(session_id) or websocket
  ```
  `_proactive_loop` 在每次迭代开始时获取当前活跃的 WebSocket。但如果在获取 WebSocket 和实际调用 `await _send_segments()` 之间，客户端断开了连接，WebSocket 会处于关闭状态。`_send_segments` 中的 `await websocket.send_text()` 会抛出异常，虽然被外层捕获，但这意味着 proactive 消息丢失。
- **风险分析**：
  - 这不是资源泄漏，而是消息可靠性问题。但频繁的异常抛出会导致日志膨胀，且每次异常都会创建新的异常对象，增加 GC 压力。
- **修复建议**：
  在 `send_text` 前检查 `websocket.client_state == WebSocketState.CONNECTED`，或捕获 `RuntimeError` 并优雅地跳过发送。

### 7.3 [MEDIUM] WebSocket 的 `receive_text()` 在客户端异常断开时可能抛出未捕获的异常

- **文件**：`D:\桌面\编程作品\AI朋友\web\server.py`
- **行号**：第 207 行
- **问题描述**：
  ```python
  raw = await websocket.receive_text()
  ```
  如果客户端网络异常断开，`receive_text()` 可能抛出 `WebSocketDisconnect` 以外的异常（如 `ConnectionResetError`、`RuntimeError`）。虽然外层的 `except Exception` 会捕获这些异常，但异常对象本身会占用内存，且如果异常频繁发生，可能导致内存碎片。
- **修复建议**：
  显式捕获 `WebSocketDisconnect` 和 `RuntimeError`，对其他异常记录更详细的堆栈信息以便排查。

---

## 八、日志 Handler 重复添加

### 8.1 [HIGH] `core/logging_setup.py` 的 `setup_logging` 每次调用都会向 root logger 添加新的 Handler

- **文件**：`D:\桌面\编程作品\AI朋友\core\logging_setup.py`
- **行号**：第 22-37 行
- **问题描述**：
  ```python
  root = logging.getLogger()
  root.setLevel(...)
  fh = logging.FileHandler(log_file, encoding="utf-8")
  root.addHandler(fh)
  ch = logging.StreamHandler(sys.stderr)
  root.addHandler(ch)
  ```
  `setup_logging` 每次被调用时都会创建新的 `FileHandler` 和 `StreamHandler` 并添加到 root logger。在单元测试中，如果多次调用 `setup_logging`，root logger 会累积多个 handler，导致每条日志被重复写入多次。在 Web 端的 Uvicorn 重载场景下，如果 `setup_logging` 被再次调用，同样会发生重复。
- **风险分析**：
  - 日志文件大小会异常增长，磁盘 I/O 开销增加。
  - 如果 `setup_logging` 被频繁调用（如测试框架中），文件描述符（每个 FileHandler 持有一个打开的文件）会累积，最终达到系统限制。
- **修复建议**：
  在添加 handler 前清除已有的 handler，或使用单例模式确保 `setup_logging` 只执行一次：
  ```python
  if root.handlers:
      return  # 已经初始化过
  ```
  或者更安全的做法：
  ```python
  for h in root.handlers[:]:
      root.removeHandler(h)
      h.close()
  ```

### 8.2 [MEDIUM] `config.py` 的 `load_config` 在 `setup_logging` 之前调用，导致配置加载日志使用默认 handler

- **文件**：`D:\桌面\编程作品\AI朋友\config.py`
- **行号**：第 48-78 行
- **问题描述**：
  `load_config` 中使用 `logger.info` 和 `logger.warning` 记录配置加载信息。但由于 `main.py` 中先调用 `load_config` 再调用 `setup_logging`，这些日志会输出到 Python 的默认 handler（stderr），而不会写入日志文件。
- **风险分析**：
  这不是资源泄漏，但会导致日志分散，不利于问题排查。如果默认 handler 被某些环境配置为输出到文件，还可能导致意外的日志文件创建。
- **修复建议**：
  调整 `main.py` 和 `web_main.py` 的初始化顺序：
  ```python
  setup_logging("INFO")  # 先设置日志
  config = load_config()  # 再加载配置
  ```

---

## 九、其他资源与可靠性问题

### 9.1 [HIGH] `ContextManager.compress()` 在并发调用时可能丢失上下文

- **文件**：`D:\桌面\编程作品\AI朋友\core\context_manager.py`
- **行号**：第 62-70 行
- **问题描述**：
  ```python
  def compress(self, messages: list[dict]) -> None:
      if self._compressing:
          return
      self._compressing = True
      try:
          self._do_compress(messages)
      finally:
          self._compressing = False
  ```
  `_compressing` 是一个简单的布尔标志，没有线程锁保护。在 Web 端，如果两个请求同时触发压缩（虽然不太可能，因为每个会话有独立的 `ContextManager`），但在 CLI 的 proactive 和正常消息处理并发时，可能存在竞态条件。
- **风险分析**：
  - 竞态条件可能导致 `_do_compress` 被跳过，或者 `_compressing` 标志状态不一致。
- **修复建议**：
  使用 `threading.Lock` 保护 `_compressing` 标志的检查和设置。

### 9.2 [MEDIUM] `NotifyTool` 创建的 `subprocess.run` 可能泄漏进程句柄

- **文件**：`D:\桌面\编程作品\AI朋友\tools\notify_tool.py`
- **行号**：第 47-67 行
- **问题描述**：
  `NotifyTool.execute()` 在后台线程中调用 `subprocess.run(['powershell', ...], capture_output=True, timeout=10)`。`subprocess.run` 会等待进程完成，但在后台线程中，如果 PowerShell 进程挂起（如 Windows UI 框架未响应），`timeout=10` 会触发 `subprocess.TimeoutExpired`，但异常被捕获并忽略。挂起的 PowerShell 进程可能变成僵尸进程。
- **风险分析**：
  - 频繁的桌面通知可能导致系统中积累大量 PowerShell 进程。
- **修复建议**：
  使用 `subprocess.Popen` 并显式管理进程生命周期，或在 `subprocess.run` 的 `except` 块中调用 `kill()` 终止超时进程。

### 9.3 [MEDIUM] `MusicPlayTool._play` 使用 `os.startfile()` 无进程跟踪

- **文件**：`D:\桌面\编程作品\AI朋友\tools\music_tool.py`
- **行号**：第 152-153 行
- **问题描述**：
  `os.startfile(filepath)` 会启动系统默认的音乐播放器，但不返回进程句柄。如果用户频繁调用 `music_play`，可能启动多个播放器实例，且无法从代码层面控制或关闭它们。
- **风险分析**：
  - 这不是代码层面的资源泄漏，但属于用户体验和系统资源管理问题。
- **修复建议**：
  考虑使用支持进程跟踪的播放库（如 `pygame.mixer`、`pydub`），或记录已启动的进程以便后续管理。

### 9.4 [LOW] `GrepTool` 和 `GlobTool` 的 `os.walk` 在大目录下可能产生大量临时对象

- **文件**：`D:\桌面\编程作品\AI朋友\tools\search_tools.py`
- **行号**：第 68-81 行（GlobTool），第 168-180 行（GrepTool）
- **问题描述**：
  `os.walk` 会递归遍历目录树，生成大量的字符串对象（路径名）。在非常大的目录（如包含数万文件的 `node_modules`）下，这会短暂占用大量内存。虽然 `GrepTool` 跳过了一些目录（`__pycache__`、`.git` 等），但过滤是在遍历过程中进行的，无法避免 `os.walk` 已经生成的目录列表。
- **修复建议**：
  使用 `pathlib.Path.rglob()` 替代 `os.walk`，或增加更严格的目录过滤（在 `os.walk` 的 `topdown=True` 模式下通过修改 `dirnames` 列表跳过子目录）。

### 9.5 [LOW] `EmbeddingCache` 的 LRU 实现使用 `OrderedDict`，在并发访问时不是线程安全的

- **文件**：`D:\桌面\编程作品\AI朋友\memory\embeddings.py`
- **行号**：第 86-117 行
- **问题描述**：
  `EmbeddingCache` 使用 `OrderedDict` 实现 LRU 缓存，但没有加锁。在 Web 端，多个会话可能并发访问同一个 `EmbeddingEngine`（如果共享实例），导致 `OrderedDict` 的并发修改异常（如 `RuntimeError: OrderedDict mutated during iteration`）。
- **风险分析**：
  - 虽然当前代码中每个 `WebAgent` 创建独立的 `EmbeddingEngine`（`web/session.py` 第 52-55 行），所以并发风险较低。但如果未来改为共享 `EmbeddingEngine`，这个问题会暴露。
- **修复建议**：
  使用 `threading.Lock` 保护 `get()`、`set()` 和 `invalidate()` 方法，或改用 `functools.lru_cache`（如果适用）。

---

# 汇总统计

## 按风险等级汇总

| 序号 | 问题类别 | 风险等级 | 文件 | 行号 | 简要描述 |
|------|---------|---------|------|------|---------|
| 1 | 数据库连接泄漏 | 严重 | web/session.py | 131-134 | Web 端 Database 连接永不关闭 |
| 2 | requests.Session 泄漏 | 严重 | core/provider.py | 82-134 | 流式响应中连接可能未释放 |
| 3 | ThreadPoolExecutor 泄漏 | 严重 | web/server.py | 150-180 | 默认线程池无上限，可能耗尽 |
| 4 | asyncio.Task 泄漏 | 严重 | web/server.py | 216-249 | Proactive task 取消不彻底 |
| 5 | 数据库连接泄漏 | 高 | main.py | 115 | CLI 端异步 close 被同步调用 |
| 6 | requests.Session 泄漏 | 高 | memory/embeddings.py | 21-83 | health_check 阻塞，无超时控制 |
| 7 | requests.Session 泄漏 | 高 | tools/web_tools.py | 28-29 | 每次调用新建 Session |
| 8 | ThreadPoolExecutor 泄漏 | 高 | web/server.py | 150-151 | _generate_dream 无超时 |
| 9 | asyncio.Task 泄漏 | 高 | web/session.py | 169-174 | cleanup_old 不取消 proactive task |
| 10 | 内存泄漏 | 高 | web/session.py | 126,146-153 | WebAgent 资源无显式释放 |
| 11 | 内存泄漏 | 高 | core/agent.py | 57,162-169 | _tool_call_history 使用列表切片 |
| 12 | 数据库连接泄漏 | 中 | storage/repository.py | 13-21 | 每次调用新建 ThreadPoolExecutor |
| 13 | 数据库连接泄漏 | 中 | memory/long_term.py | 17-26 | 重复实现 _run_sync |
| 14 | 文件句柄泄漏 | 中 | core/sleep_manager.py | 27-38 | 目录不存在时文件写入失败 |
| 15 | 文件句柄泄漏 | 中 | tools/file_tools.py | 23-27 | 日志变量名错误 |
| 16 | 内存泄漏 | 中 | core/agent.py | 82,119-181 | _react_messages 异常时未重置 |
| 17 | 内存泄漏 | 中 | memory/consolidation.py | 25,47-80 | pending_buffer 异常时重复处理 |
| 18 | 内存泄漏 | 中 | models/personality.py | 67,239-262 | emotion_events 列表手动维护 |
| 19 | WebSocket 泄漏 | 中 | web/server.py | 207 | receive_text 异常处理过于宽泛 |
| 20 | 日志 Handler 重复 | 高 | core/logging_setup.py | 22-37 | 重复添加 handler |
| 21 | 日志 Handler 重复 | 中 | config.py | 48-78 | 配置加载在日志设置之前 |
| 22 | 其他可靠性 | 中 | core/context_manager.py | 62-70 | compress() 无锁保护 |
| 23 | 其他可靠性 | 中 | tools/notify_tool.py | 47-67 | subprocess 超时进程未终止 |
| 24 | 其他可靠性 | 低 | tools/music_tool.py | 152-153 | os.startfile 无进程跟踪 |
| 25 | 其他可靠性 | 低 | tools/search_tools.py | 68-180 | os.walk 大目录内存开销 |
| 26 | 其他可靠性 | 低 | memory/embeddings.py | 86-117 | EmbeddingCache 非线程安全 |
| 27 | 内存泄漏 | 低 | memory/short_term.py | 66-70 | deque.clear() 可能保留引用 |

## 按文件分布汇总

| 文件 | 严重 | 高 | 中 | 低 | 合计 |
|------|------|------|------|------|------|
| web/server.py | 3 | 2 | 1 | 0 | 6 |
| web/session.py | 1 | 2 | 1 | 0 | 4 |
| core/provider.py | 1 | 0 | 0 | 0 | 1 |
| core/agent.py | 0 | 1 | 1 | 0 | 2 |
| core/logging_setup.py | 0 | 1 | 0 | 0 | 1 |
| core/context_manager.py | 0 | 0 | 1 | 0 | 1 |
| core/sleep_manager.py | 0 | 0 | 1 | 0 | 1 |
| core/personality.py | 0 | 0 | 0 | 0 | 0（仅引用） |
| main.py | 0 | 1 | 0 | 0 | 1 |
| memory/embeddings.py | 0 | 1 | 0 | 1 | 2 |
| memory/consolidation.py | 0 | 0 | 1 | 0 | 1 |
| memory/long_term.py | 0 | 0 | 1 | 0 | 1 |
| memory/short_term.py | 0 | 0 | 0 | 1 | 1 |
| memory/retrieval.py | 0 | 0 | 0 | 0 | 0 |
| storage/database.py | 0 | 0 | 0 | 0 | 0（被调用方问题） |
| storage/repository.py | 0 | 0 | 1 | 0 | 1 |
| tools/web_tools.py | 0 | 1 | 0 | 0 | 1 |
| tools/file_tools.py | 0 | 0 | 1 | 0 | 1 |
| tools/notify_tool.py | 0 | 0 | 1 | 0 | 1 |
| tools/music_tool.py | 0 | 0 | 0 | 1 | 1 |
| tools/search_tools.py | 0 | 0 | 0 | 1 | 1 |
| models/personality.py | 0 | 0 | 1 | 0 | 1 |
| config.py | 0 | 0 | 1 | 0 | 1 |

## 修复优先级建议

### P0（立即修复）
1. **web/server.py**：在 `lifespan` 中关闭 `SessionManager` 的数据库连接。
2. **core/provider.py**：使用 `with` 语句确保 `requests.Response` 被关闭。
3. **tools/web_tools.py**：将 `requests.Session` 改为模块级单例或类实例变量。
4. **web/server.py**：为 `run_in_executor` 使用自定义的、有上限的 `ThreadPoolExecutor`。

### P1（本周修复）
5. **main.py**：将 `db.close()` 改为 `await db.close()`。
6. **core/logging_setup.py**：防止重复添加 handler。
7. **web/session.py**：在 `cleanup_old` 和 `remove` 中确保 `WebAgent` 资源被显式释放。
8. **core/agent.py**：将 `_tool_call_history` 改为 `deque(maxlen=20)`。
9. **web/server.py**：为 `run_in_executor` 调用添加 `asyncio.wait_for` 超时。

### P2（下轮迭代修复）
10. **storage/repository.py** 和 **memory/long_term.py**：统一 `_run_sync` 实现，复用线程池。
11. **memory/consolidation.py**：使用 `try/finally` 保护 `_pending_buffer.clear()`。
12. **models/personality.py**：将 `emotion_events` 改为 `deque(maxlen=20)`。
13. **tools/notify_tool.py**：确保超时进程被终止。
14. **core/context_manager.py**：为 `compress()` 添加线程锁。

---

*本报告由 Claude Code 自动生成，基于对代码的静态分析。建议在实际修复后进行压力测试和内存分析（如使用 `tracemalloc`、`objgraph` 或 `py-spy`）以验证修复效果。*
