# 第2轮代码审查：Agent 状态机数据流与状态转换深度审查

> 审查日期：2026-05-31
> 审查范围：core/agent.py, core/cli_controller.py, ui/cli.py, core/message_handler.py, core/inner_drive.py, core/tool_agent.py, web/server.py, web/session.py
> 审查目标：AgentState（BOOT→IDLE→PERCEIVE→THINK→ACT→REFLECT→SHUTDOWN）完整状态转换路径、数据流、生命周期管理

---

# 概述

AI Friend 项目采用双端架构：CLI 端通过 `CliController.run()` 运行显式状态机循环，Web 端通过 `Agent.process_message()` 走事件驱动的 `_react_loop()`。两套路径共享同一个 `Agent` 实例，但状态机的使用方式截然不同。本次审查发现状态机与 ReAct 循环存在严重的架构耦合问题，状态变量的生命周期管理存在多处不一致，且 Web 端完全绕过了 `AgentState` 枚举定义的状态机语义。

核心发现：
1. **Web 端状态机真空**：Web 端 `process_message()` 完全不使用 `AgentState`，`Agent.state` 字段在 Web 路径下成为"死状态"，永远停留在 `BOOT`（或上次 CLI 运行残留值）。
2. **ReAct 循环嵌套在状态机内部**：`CliController._on_think()` 内部实现了完整的 ReAct 迭代逻辑（THINK→ACT→THINK 内循环），与外层状态机的 THINK/ACT 状态产生语义重叠和混淆。
3. **`_react_messages` 状态泄漏风险**：ReAct 多轮迭代中 `messages` 列表持续增长，但仅在 `_finish_react_response()` 或 `_reset_react()` 时清理，异常路径下可能残留脏数据。
4. **`turn_count` 双路径不同步**：CLI 路径在 `_finish_react_response()` 中 `turn_count += 1`，Web 路径在 `_react_loop()` 中同样 `turn_count += 1`，但 Web 路径还会额外调用 `_process_emotion()`，而 CLI 路径的 `_on_reflect()` 也做情感分析，导致情感处理逻辑分散。
5. **主动对话跳过 PERCEIVE**：CLI  proactive 路径从 IDLE 直接跳转到 THINK（`a.current_input = None`），跳过了 `short_term.add_turn("user", ...)` 和 `ltm.repo.insert_turn_sync(...)`，导致主动对话没有用户输入记录，但后续 `_finish_react_response()` 仍会写入 assistant 回复，造成对话历史中 user/assistant 配对失衡。

---

## 状态转换分析（ASCII 图）

### 2.1 CLI 端完整状态机

```
                              ┌─────────────────────────────────────┐
                              │  异常捕获 (Exception/KeyboardInterrupt)│
                              │  → logger.error + display.print_error  │
                              │  → state = IDLE (sleep 1s)            │
                              └─────────────────────────────────────┘
                                               ▲
                                               │
    ┌─────┐    ┌────────┐    ┌──────────┐    │    ┌────────┐    ┌─────────┐    ┌──────────┐
    │BOOT │───▶│ IDLE   │───▶│ PERCEIVE │────┼───▶│ THINK  │───▶│  ACT    │───▶│ REFLECT  │
    └─────┘    └────────┘    └──────────┘    │    └────────┘    └─────────┘    └──────────┘
       │          ▲  ▲            │           │         ▲            │                │
       │          │  │            │           │         │            │                │
       │          │  └────────────┘           │         └────────────┘                │
       │          │    /exit → SHUTDOWN       │      有 tool_call (ReAct 迭代)         │
       │          │    /save → IDLE           │      _react_iteration > 0             │
       │          │    /forget → IDLE         │                                        │
       │          │    /mood → IDLE           │                                        │
       │          │    /status → IDLE         │                                        │
       │          │    /help → IDLE           │                                        │
       │          │                           │                                        │
       │          │    主动对话触发            │                                        │
       │          │    (idle > threshold)     │                                        │
       │          │    current_input = None   │                                        │
       │          └───────────────────────────┘                                        │
       │                                                                               │
       │    启动流程: ui.start() → display_banner() → greeting → state = IDLE          │
       │                                                                               │
       └───────────────────────────────────────────────────────────────────────────────┘
                                              state = IDLE
```

### 2.2 ReAct 内循环（嵌套在 THINK/ACT 内部）

```
THINK (_on_think)
    │
    ├── 首次迭代 (_react_iteration == 0)
    │   ├── stream=True, max_tokens = _max_tokens_for_emotion()
    │   ├── on_token() 流式打印到终端
    │   └── parse_tool_calls() → cleaned_text + tool_calls
    │
    ├── 后续迭代 (_react_iteration > 0)
    │   ├── stream=False, max_tokens = 384
    │   ├── print_system("思考中... (第N轮)")
    │   └── parse_tool_calls() → cleaned_text + tool_calls
    │
    ├── _react_messages.append({"role": "assistant", "content": full_response})
    ├── _react_iteration += 1
    └── state = ACT
        │
        ▼
ACT (_on_act)
    │
    ├── 有 tool_calls 且 _react_iteration <= _max_tool_iterations (10)
    │   ├── execute_tool_calls(registry, tool_calls)
    │   ├── _react_messages.append({"role": "user", "content": result_text})
    │   └── state = THINK  (返回 THINK 继续迭代)
    │
    ├── 有 tool_calls 但 _react_iteration > _max_tool_iterations
    │   └── _finish_react_response() → state = REFLECT
    │
    └── 无 tool_calls
        └── _finish_react_response() → state = REFLECT
            │
            ├── short_term.add_turn("assistant", current_response)
            ├── ltm.repo.insert_turn_sync(turn_count, "assistant", ...)
            ├── turn_count += 1
            ├── last_activity_time = time.time()
            ├── _reset_react()  (清理 _react_messages, _react_iteration, _tool_calls_pending)
            ├── _tool_records = ""  (CliController 局部)
            ├── _inner_drive_result = None  (CliController 局部)
            └── state = REFLECT
```

### 2.3 Web 端事件驱动路径（无状态机）

```
WebSocket "message"
    │
    ▼
agent.process_message(user_input, on_token)
    │
    ├── MessageHandler.handle_message()
    │   ├── Agent 1: InnerDriveAgent.assess()
    │   ├── (可选) Agent 2: ToolAgent.run_with_request() 多轮
    │   └── Agent 3: _react_loop() 或 _run_agent3()
    │
    └── _react_loop()
        ├── for _idx in range(_max_tool_iterations):
        │   ├── provider.generate(stream=True if _idx==0 else False)
        │   ├── parse_tool_calls()
        │   ├── (可选) contains_fake_action() 检测 → 追加纠正消息
        │   ├── execute_tool_calls()
        │   └── append results to messages
        │
        └── final_text → short_term.add_turn() + ltm.repo.insert_turn_sync()
            └── turn_count += 1
            └── _process_emotion()  (情感分析 + 情绪更新 + 记忆合并)
```

**关键差异**：Web 端完全不触碰 `Agent.state` 字段。`AgentState` 枚举在 Web 路径下是"透明"的。

### 2.4 主动对话路径对比

```
CLI 主动路径 (IDLE → THINK, 跳过 PERCEIVE):
    _on_idle()
        idle_duration > proactive_min_idle
        random.random() < _calculate_proactivity(idle_duration)
        → current_input = None
        → state = THINK

    _on_think()
        is_proactive = (current_input is None)  → True
        → user_message = "[主动开启对话] 主题方向：{topic}"
        → 不执行 Agent 1/Agent 2 (因为 is_proactive)
        → 直接构建 system prompt + messages
        → 进入 ReAct 循环

    _finish_react_response()
        → short_term.add_turn("assistant", ...)
        → ltm.repo.insert_turn_sync(turn_count, "assistant", ...)
        → turn_count += 1
        ⚠️ 注意：没有对应的 user turn 写入！

Web 主动路径 (proactive_loop):
    _proactive_loop()
        → decide_proactive_action(idle)  → ProactiveIntent
        → process_proactive(intent=intent) 或 process_explore(intent=intent)
        → MessageHandler.handle_proactive() / handle_explore()
        → _react_loop(add_to_history=False)
        ⚠️ 注意：add_to_history=False，不写入 short_term
        ⚠️ 但 handle_explore 会调用 _react_loop(add_to_history=False)
```

---

## 详细发现

### 3.1 状态机与 ReAct 循环的架构耦合问题

#### 发现 3.1.1：THINK/ACT 状态语义被 ReAct 内循环吞噬

**文件**：`D:\桌面\编程作品\AI朋友\core\cli_controller.py`
**行号**：137-261

外层状态机的 THINK 和 ACT 状态各只执行一次 `handler()` 调用，但 ReAct 的迭代逻辑在 THINK 中解析 LLM 响应、在 ACT 中执行工具后重新设置 `state = THINK`。这导致外层状态机实际上变成了：

```
IDLE → PERCEIVE → THINK → ACT → THINK → ACT → ... → REFLECT → IDLE
```

外层状态机的 `THINK` 和 `ACT` 状态失去了"单次操作"的语义，变成了 ReAct 迭代的"标签"。这种设计使得：
- 状态转换日志难以阅读（大量重复的 THINK→ACT→THINK 转换）
- 无法在中途安全中断 ReAct 迭代（如用户发送新消息）
- 状态机的可视化/debug 价值被削弱

**风险评级**：中等
**建议**：将 ReAct 迭代完全内聚到 THINK 状态中，ACT 仅作为工具执行后的暂态立即返回 THINK，或引入子状态机（`THINK_REACT_0`, `THINK_REACT_1`...）以区分外层状态和 ReAct 轮次。

#### 发现 3.1.2：Web 端完全绕过 AgentState

**文件**：`D:\桌面\编程作品\AI朋友\core\agent.py`
**行号**：104-111, 225-226

```python
def process_message(self, user_input: str, on_token=None) -> str:
    return self._messages.handle_message(user_input, on_token)

def run(self) -> None:
    self._cli.run()
```

`Agent.run()` 委托给 `CliController.run()`，但 `Agent.process_message()` 被 Web 端直接调用。`Agent.state` 在 `__init__` 中被设为 `AgentState.BOOT`，Web 端从未修改它。

这意味着：
- Web 端无法通过 `Agent.state` 判断当前处理阶段
- 如果未来需要基于状态机的逻辑（如并发请求防护、状态监控），Web 端将完全失效
- `AgentState` 枚举成为 CLI 专用实现细节，而非跨端共享抽象

**风险评级**：高
**建议**：在 `process_message()` 入口显式设置 `self.state = AgentState.PERCEIVE`（或引入 Web 专用状态如 `PROCESSING`），在 `_react_loop()` 结束时设置 `self.state = AgentState.IDLE`。或者，将状态机抽象提取为独立模块，CLI 和 Web 分别实现适配器。

---

### 3.2 状态变量生命周期问题

#### 发现 3.2.1：`_react_messages` 异常路径下不清理

**文件**：`D:\桌面\编程作品\AI朋友\core\cli_controller.py`
**行号**：198-205, 220-226

```python
# THINK 中，ConnectionError 路径
try:
    full_response = a.provider.generate(messages, stream=False, max_tokens=384)
except ConnectionError as e:
    if a.ui:
        a.ui.display.print_error(f"网络连接失败：{e}")
    a._reset_react()
    a.state = AgentState.REFLECT
    return
```

这里在 `ConnectionError` 时调用了 `a._reset_react()`，是正确的。但检查其他异常路径：

- `KeyboardInterrupt`：在 `run()` 的 while 循环中被捕获，设置 `state = SHUTDOWN`，**未调用 `_reset_react()`**
- 通用 `Exception`：在 `run()` 的 while 循环中被捕获，设置 `state = IDLE`，**未调用 `_reset_react()`**
- `parse_tool_calls()` 内部异常：未检查，但如果 `full_response` 包含异常内容导致解析失败，`_react_messages` 已在第235行被 append

**文件**：`D:\桌面\编程作品\AI朋友\core\agent.py`
**行号**：228-231

```python
def _reset_react(self) -> None:
    self._react_messages = None
    self._react_iteration = 0
    self._tool_calls_pending = []
```

`_reset_react()` 清理了三个字段，但 `CliController` 本地的 `_tool_records` 和 `_inner_drive_result` 不在其范围内。在 `run()` 的通用异常处理中：

```python
except Exception as e:
    logger.error(f"Error in state {a.state}: {e}", exc_info=True)
    if a.ui:
        a.ui.display.print_error(str(e))
    time.sleep(1)
    a.state = AgentState.IDLE
```

这里没有清理 `_tool_records` 或 `_inner_drive_result`。如果异常发生在 THINK 阶段（如 LLM 返回格式错误导致 `parse_tool_calls()` 抛出未捕获异常），这些局部变量将残留到下一轮对话，可能导致：
- 下一轮对话错误地使用上一轮的 `_inner_drive_result`
- `_tool_records` 被错误注入到新对话的 messages 中

**风险评级**：高
**建议**：在 `run()` 的通用异常处理中增加 `self._reset_react()` 和本地状态清理；或将 `_tool_records` / `_inner_drive_result` 的生命周期绑定到 `Agent` 实例而非 `CliController`。

#### 发现 3.2.2：`_consecutive_negative` 初始化与持久化不一致

**文件**：`D:\桌面\编程作品\AI朋友\core\agent.py`
**行号**：72-79

```python
e = self.personality.emotion
neg_score = max(e.anger, e.sadness, e.disgust)
if neg_score > 0.8:
    self._consecutive_negative = 4  # one push from breaking
elif neg_score > 0.5:
    self._consecutive_negative = 2
else:
    self._consecutive_negative = 0
```

`_consecutive_negative` 在 `Agent.__init__` 中基于当前情绪初始化，但：
- 它从不被持久化到 `personality.json` 或数据库
- Web 端每次创建新 `WebAgent`（新 session）时重新计算
- CLI 端每次启动 `main.py` 时重新计算

这意味着用户连续5次负面交互触发"破防"后，如果重启程序，`_consecutive_negative` 重置为0，破防状态丢失。

**风险评级**：中等
**建议**：将 `_consecutive_negative` 持久化到 `personality.json` 的 `EmotionalState` 中，或在数据库中增加 `session_state` 表存储跨会话状态。

#### 发现 3.2.3：`turn_count` 在 Web 端 session 重启后不同步

**文件**：`D:\桌面\编程作品\AI朋友\web\session.py`
**行号**：36-37

```python
for t in repo.get_recent_turns_sync(30):
    self.short_term.add_turn(t["role"], t["content"])
```

Web 端恢复最近30轮对话到 `short_term`，但 `Agent.turn_count` 未被恢复：

**文件**：`D:\桌面\编程作品\AI朋友\core\agent.py`
**行号**：52

```python
self.turn_count = 0
```

`turn_count` 在 `Agent.__init__` 中硬编码为 0。这导致：
- `ltm.repo.insert_turn_sync(self.turn_count, ...)` 的 turn 参数从 0 开始，与数据库中已有的 turn 编号冲突
- `turn_count % 10 == 0` 的 personality 保存逻辑被错误触发（可能在第10轮而非预期的第N+10轮）
- `turn_count % 3 == 0` 的 `_process_emotion()` 中记忆合并逻辑也被错误触发

**风险评级**：高
**建议**：从数据库查询最大 turn 编号并恢复 `turn_count`，或从 `repo.get_recent_turns_sync()` 的结果中推导。

#### 发现 3.2.4：`_tool_call_history` 无上限且跨对话累积

**文件**：`D:\桌面\编程作品\AI朋友\core\agent.py`
**行号**：57, 162-169

```python
self._tool_call_history: list[dict] = []  # recent tool call records

# ...
if len(self._tool_call_history) > 20:
    self._tool_call_history = self._tool_call_history[-20:]
```

`_tool_call_history` 在 `Agent.__init__` 中初始化为空列表，Web 端 session 恢复时不会恢复此列表。但：
- CLI 端每次启动也是空列表
- 它在 `_react_loop()` 中被追加，在 `MessageHandler._run_agent3()` 中被注入 prompt
- 没有清理机制（如对话结束后清空）

虽然上限为20条，但它在长会话中会持续累积，且包含的是"最近20次工具调用"而非"当前 ReAct 循环的工具调用"。这可能导致 prompt 中注入不相关的历史工具调用。

**风险评级**：低
**建议**：在 `_reset_react()` 或 `_finish_react_response()` 中清空 `_tool_call_history`，或将其改为"当前 ReAct 循环专用"。

---

### 3.3 数据流断裂与不一致

#### 发现 3.3.1：CLI proactive 路径缺少 user turn 记录

**文件**：`D:\桌面\编程作品\AI朋友\core\cli_controller.py`
**行号**：110-116, 264-277

```python
def _on_idle(self):
    # ...
    if random.random() < a._calculate_proactivity(idle_duration):
        a.current_input = None
        a.state = AgentState.THINK
        return

def _finish_react_response(self):
    if a.current_response:
        a.short_term.add_turn("assistant", a.current_response)
        a.ltm.repo.insert_turn_sync(a.turn_count, "assistant", a.current_response, ...)
        a.turn_count += 1
```

主动对话时：
1. `_on_idle()` 设置 `current_input = None`，跳转到 THINK
2. `_on_think()` 构建 `user_message = "[主动开启对话] 主题方向：..."`，但**不写入 short_term 或 ltm**
3. `_finish_react_response()` 写入 assistant 回复

结果：对话历史中出现 assistant turn 没有对应的 user turn。如果后续检索对话历史，会看到 "assistant: 你好呀！" 前面没有 user 输入，可能导致记忆合并和情感分析时上下文缺失。

**风险评级**：高
**建议**：在 proactive 路径中，将 `[主动开启对话]` 标记作为 user turn 写入 `short_term` 和 `ltm`（即使 `current_input` 为 None），或引入特殊的 `"system"` 角色标记主动触发事件。

#### 发现 3.3.2：Web proactive 路径 `add_to_history=False` 导致记忆黑洞

**文件**：`D:\桌面\编程作品\AI朋友\core\message_handler.py`
**行号**：187, 235-236

```python
def handle_proactive(self, on_token=None, *, intent=None) -> str:
    # ...
    return a._react_loop(messages, on_token, add_to_history=False)

def handle_explore(self, intent=None) -> str | None:
    # ...
    result = a._react_loop(messages, on_token=None, add_to_history=False,
                          tool_registry=phase2_registry)
```

Web 端的主动对话和探索都设置了 `add_to_history=False`，这意味着：
- 主动对话内容完全不进入 `short_term`
- `ltm.repo.insert_turn_sync()` 不会被调用（因为 `_react_loop()` 中 `add_to_history=False` 跳过了这部分）
- 用户后续回复时，检索到的对话历史中没有主动对话的内容

这与 CLI 端 proactive 路径形成对比：CLI 端至少写入了 assistant turn（虽然缺少 user turn）。Web 端则是完全的黑洞。

**风险评级**：高
**建议**：统一 CLI 和 Web 的 proactive 历史记录策略。如果设计意图是"主动对话不进入历史"，应在文档中明确说明，并确保 `short_term` 的检索逻辑不会因缺失上下文而退化。

#### 发现 3.3.3：`_process_emotion()` 在 CLI 和 Web 路径中调用时机不同

**文件**：`D:\桌面\编程作品\AI朋友\core\agent.py`
**行号**：179-181, 183-221

```python
def _react_loop(self, ...):
    # ...
    if not skip_post_process:
        self._process_emotion()
    return final_text
```

Web 端 `process_message()` → `handle_message()` → `_react_loop()` 在每次响应后调用 `_process_emotion()`。

CLI 端 `_on_reflect()` 也做情感分析和记忆合并：

**文件**：`D:\桌面\编程作品\AI朋友\core\cli_controller.py`
**行号**：279-294

```python
def _on_reflect(self):
    ei = abs(a.personality.emotion.valence)
    idle = time.time() - a.last_activity_time
    if a.consolidator.should_consolidate(a.turn_count, ei, idle, a.config):
        a.consolidator.consolidate(...)
    for t in list(a.short_term.get_all())[-2:]:
        a.consolidator.add_pending(t)
    if a.turn_count % 10 == 0:
        a.personality.save(a.config.personality_file)
    a.current_response = ""
    a.state = AgentState.IDLE
```

注意：CLI 端的 `_on_reflect()` **没有调用 `_process_emotion()`**。`_process_emotion()` 中的情感分析（`analyze_sentiment`）、情绪更新（`apply_emotional_shift`）、破防机制（`_consecutive_negative`）在 CLI 路径下完全缺失。

**文件**：`D:\桌面\编程作品\AI朋友\core\agent.py`
**行号**：183-221

`_process_emotion()` 包含：
1. 对用户输入进行情感分析
2. 更新 `_consecutive_negative`
3. 应用情绪偏移（`apply_emotional_shift`）
4. 记录情绪事件（`record_emotion_event`）
5. 每3轮触发记忆合并

这些在 CLI 路径下全部不执行。CLI 端的情绪系统是"死的"——情绪永远不会因用户输入而改变。

**风险评级**：严重
**建议**：在 `CliController._on_reflect()` 中调用 `a._process_emotion()`，或提取统一的后处理函数供 CLI 和 Web 共享。

#### 发现 3.3.4：`current_memory_context` 在 proactive 路径中被覆盖

**文件**：`D:\桌面\编程作品\AI朋友\core\cli_controller.py`
**行号**：128, 144-145

```python
def _on_perceive(self):
    a.current_memory_context = a.retriever.retrieve_for_query(user_input)
    # ...

def _on_think(self):
    is_proactive = a.current_input is None
    if a._react_messages is None:
        if is_proactive:
            a.current_memory_context = a.retriever.retrieve_for_query("")
```

在 proactive 路径中，`current_memory_context` 被 `retrieve_for_query("")` 覆盖。空字符串查询可能返回不相关的记忆（因为检索系统可能将空查询视为"返回所有"或"返回最近"）。

更关键的是，`MessageHandler.handle_proactive()` 也独立调用 `a.retriever.retrieve_for_query(memory_query)`，使用 `intent.topic_hint` 作为查询。Web 端的 proactive 检索质量优于 CLI 端（因为 CLI 端使用空字符串）。

**风险评级**：中等
**建议**：CLI proactive 路径应使用与 Web 端一致的查询策略（如 `_pick_proactive_topic()` 的返回值），而非空字符串。

---

### 3.4 不可达状态与死状态

#### 发现 3.4.1：`AgentState.BOOT` 是瞬态且 CLI 专用

`BOOT` 仅在 `CliController.run()` 开始时设置一次，持续极短（立即调用 `_on_boot()` 后转为 `IDLE`）。Web 端 `Agent.__init__` 也设置 `state = AgentState.BOOT`，但 Web 端从不使用它。

`BOOT` 状态没有独立的处理逻辑（`_on_boot()` 不是通过 handler 字典调用的，而是显式调用），因此严格来说它不是一个"状态"，而是一个初始化标记。

**风险评级**：低
**建议**：将 `BOOT` 从 `AgentState` 中移除，或将其变为 `Agent` 的初始化阶段而非状态机状态。

#### 发现 3.4.2：`SHUTDOWN` 是终止态但无 handler

**文件**：`D:\桌面\编程作品\AI朋友\core\cli_controller.py`
**行号**：68-87

```python
while a._running and a.state != AgentState.SHUTDOWN:
    try:
        handler = {
            AgentState.IDLE: self._on_idle,
            AgentState.PERCEIVE: self._on_perceive,
            AgentState.THINK: self._on_think,
            AgentState.ACT: self._on_act,
            AgentState.REFLECT: self._on_reflect,
        }.get(a.state)
        if handler:
            handler()
```

`SHUTDOWN` 没有 handler，while 循环因 `a.state != AgentState.SHUTDOWN` 为 False 而退出，然后调用 `_on_shutdown()`。这是正确的终止态设计。

但有一个边界情况：如果 `_on_shutdown()` 中发生异常（如 `personality.save()` 失败），程序会崩溃而不会优雅降级。

**风险评级**：低
**建议**：在 `_on_shutdown()` 中增加 try-except 保护，确保即使保存失败也能退出。

#### 发现 3.4.3：`PERCEIVE` 在 proactive 路径下不可达

如 2.4 节所述，CLI proactive 路径从 `IDLE` 直接跳转到 `THINK`，`PERCEIVE` 状态被跳过。这是设计意图（proactive 没有"用户输入"需要感知），但导致：
- `PERCEIVE` 中的 `short_term.add_turn("user", ...)` 未执行
- `PERCEIVE` 中的 `ltm.repo.insert_turn_sync(...)` 未执行
- `PERCEIVE` 中的 `InnerDriveAgent.assess()` 未执行（proactive 路径在 `_on_think()` 中跳过了 Agent 1/Agent 2）

这意味着 proactive 对话完全不经过三层 Agent 架构的 Agent 1 决策层，直接由 `_pick_proactive_topic()` 的随机选择驱动。这与 Web 端 proactive 路径（使用 `InnerDriveAgent.assess_proactive()`）不一致。

**风险评级**：高
**建议**：CLI proactive 路径应调用 `InnerDriveAgent.assess_proactive()`（如 Web 端那样），而非直接跳转到 THINK。

---

### 3.5 并发与线程安全问题

#### 发现 3.5.1：`CliController` 局部状态非线程安全

**文件**：`D:\桌面\编程作品\AI朋友\core\cli_controller.py`
**行号**：19-25

```python
def __init__(self, agent):
    self._agent = agent
    self._tool_agent = None
    self._inner_drive = None
    self._tool_records = ""
    self._inner_drive_result = None
```

`CliController` 的 `_tool_records` 和 `_inner_drive_result` 是实例变量，但 CLI 端是单线程的（主循环），因此没有并发问题。然而，如果未来需要支持多会话 CLI 或多线程 Web 适配器，这些局部状态需要被隔离到每次请求的作用域中。

**风险评级**：低
**建议**：将 `_tool_records` 和 `_inner_drive_result` 改为每次 `run()` 循环的局部变量，或通过 dataclass 封装为 `TurnContext`。

#### 发现 3.5.2：Web 端 `_react_loop()` 无并发防护

**文件**：`D:\桌面\编程作品\AI朋友\web\server.py`
**行号**：233

```python
response = await loop.run_in_executor(None, agent.process_message, content)
```

Web 端在 WebSocket 协程中通过 `run_in_executor` 在线程池中执行 `process_message()`。虽然 `asyncio` 的 `run_in_executor` 每次使用不同线程，但 `Agent` 实例的状态（`_react_messages`, `_react_iteration`, `turn_count` 等）是共享的。

如果用户快速发送两条消息，可能产生竞态条件：
- 消息 A 开始 `_react_loop()`，设置 `_react_messages`
- 消息 B 同时进入 `process_message()`，调用 `_reset_react()` 或覆盖 `_react_messages`
- 消息 A 的 ReAct 迭代使用消息 B 的上下文

虽然 WebSocket 是单连接顺序处理的（`await websocket.receive_text()` 是顺序的），但 REST API (`/api/chat`) 没有这种保证：

**文件**：`D:\桌面\编程作品\AI朋友\web\server.py`
**行号**：40-54

```python
@app.post("/api/chat")
async def chat_api(body: dict):
    _, agent = session_manager.get_or_create(session_id)
    response = agent.process_message(message)
```

REST 端点直接调用 `agent.process_message()`（注意不是 `await loop.run_in_executor`），这在异步事件循环中同步阻塞，但如果并发请求到达，多个请求可能同时修改 `Agent` 状态。

**风险评级**：高
**建议**：为每个请求创建独立的请求上下文（RequestContext），或将 `Agent` 的状态变量改为线程局部存储（`threading.local()`）。

---

### 3.6 工具注册表不一致

#### 发现 3.6.1：CLI 和 Web 的工具注册表构建方式不同

**文件**：`D:\桌面\编程作品\AI朋友\core\cli_controller.py`
**行号**：44-51

```python
def _make_internal_registry(self):
    from tools.traits import ToolRegistry
    r = ToolRegistry()
    for name in ("recall", "remember"):
        tool = self.a._tool_registry.get(name)
        if tool:
            r.register(tool)
    return r
```

**文件**：`D:\桌面\编程作品\AI朋友\core\message_handler.py`
**行号**：55-62

```python
def _make_internal_registry(self):
    from tools.traits import ToolRegistry
    r = ToolRegistry()
    for name in ("recall", "remember"):
        tool = self.a._tool_registry.get(name)
        if tool:
            r.register(tool)
    return r
```

两者代码完全相同，但分别定义在 `CliController` 和 `MessageHandler` 中。这是代码重复，如果未来需要调整内部工具列表（如增加 `forget` 工具），需要修改两处。

**风险评级**：低
**建议**：将 `_make_internal_registry()` 提取到 `Agent` 类或工具模块中作为共享方法。

#### 发现 3.6.2：`ToolAgent` 的注册表过滤逻辑与 `Agent` 主注册表可能不同步

**文件**：`D:\桌面\编程作品\AI朋友\core\tool_agent.py`
**行号**：72-80

```python
def __init__(self, provider, tool_registry: ToolRegistry, max_iterations: int = 5):
    self._provider = provider
    self._full_registry = tool_registry
    self._registry = ToolRegistry()
    for name in EXTERNAL_TOOL_NAMES:
        tool = tool_registry.get(name)
        if tool:
            self._registry.register(tool)
```

`ToolAgent` 从传入的 `tool_registry` 中筛选 `EXTERNAL_TOOL_NAMES`。如果 `Agent._tool_registry` 中缺少某个外部工具（如未注册 `notify`），`ToolAgent` 不会报错，只是静默跳过。

更严重的是，`ToolAgent.run()` 使用 `self._registry.to_json_schema()` 生成 JSON Schema：

**文件**：`D:\桌面\编程作品\AI朋友\core\tool_agent.py`
**行号**：90-107

```python
sys_prompt = build_tool_agent_prompt(self._registry)
json_schema = self._registry.to_json_schema()
resp = self._provider.generate(
    messages,
    stream=False,
    max_tokens=512,
    response_format=json_schema,
)
```

如果 `self._registry` 为空（没有外部工具被注册），`to_json_schema()` 可能返回空 schema 或无效 schema，导致 API 调用失败。

**风险评级**：中等
**建议**：在 `ToolAgent.__init__` 中检查 `self._registry.list_specs()` 是否为空，如果是则抛出异常或禁用 Agent 2 路径。

---

### 3.7 边界条件与防御性编程

#### 发现 3.7.1：`_on_think()` 中 `messages` 构建的 token 估算可能溢出

**文件**：`D:\桌面\编程作品\AI朋友\core\cli_controller.py`
**行号**：169-189

```python
messages = [{"role": "system", "content": sys_prompt}]
a._context.reset_estimate(estimate_tokens(sys_prompt))
for t in a.short_term.get_all_reversed():
    role = "assistant" if t.role == "assistant" else "user"
    msg_tokens = estimate_tokens(t.content)
    if a._context.estimated_tokens + msg_tokens > COMPRESS_THRESHOLD:
        break
    messages.append({"role": role, "content": t.content})
    a._context.add_estimate(msg_tokens)
messages = [messages[0]] + list(reversed(messages[1:]))
```

这里通过 `get_all_reversed()` 逆序遍历，当 token 超过阈值时 `break`。但 `break` 后 `messages` 包含的是"最近的若干条"（逆序），然后被 `reversed()` 恢复为时间顺序。这意味着如果对话历史很长，被截断的位置是"从最早开始保留"，而非"保留最近的"。

实际上，`get_all_reversed()` 返回的是从最新到最旧的顺序，`break` 时保留的是最新的若干条（因为是从新往旧遍历，超过阈值时停止添加更旧的）。`reversed(messages[1:])` 将这些最新的条目恢复为旧→新顺序。这个逻辑是正确的（保留最近的对话），但代码可读性较差，容易误读。

更关键的问题是：如果 `sys_prompt` 本身就超过 `COMPRESS_THRESHOLD`（如工具列表很长），`messages` 将只有 system prompt，且不会触发压缩。后续如果追加 `user_message` 导致溢出，才会调用 `a._context.compress(messages)`。

**风险评级**：低
**建议**：增加注释说明 `get_all_reversed() + break + reversed` 的意图；在 `sys_prompt` 超过阈值时主动触发压缩或截断。

#### 发现 3.7.2：`handle_explore()` 中 `messages.insert(-1, ...)` 的假设脆弱

**文件**：`D:\桌面\编程作品\AI朋友\core\message_handler.py`
**行号**：220-222

```python
messages = self._build_messages(sys_prompt, user_input=None)
if tool_records:
    messages.insert(-1, {"role": "user", "content": tool_records})
```

`_build_messages(sys_prompt, user_input=None)` 在 `user_input=None` 时不会追加最后的 user message，因此 `messages` 的最后一个元素是历史对话中的某条（或 system prompt）。`insert(-1, ...)` 将 tool_records 插入到倒数第二位置。

但如果 `_build_messages` 的实现变化（如总是追加一个占位 user message），`insert(-1, ...)` 的位置将错误。

**风险评级**：低
**建议**：使用明确的索引计算或重构 `_build_messages` 返回"基础 messages + 可选 user_input"，让调用方显式控制插入位置。

#### 发现 3.7.3：`ToolAttemptTracker` 在 `MessageHandler` 中被错误使用

**文件**：`D:\桌面\编程作品\AI朋友\core\message_handler.py`
**行号**：103-115

```python
 tracker = ToolAttemptTracker()
tool_result = self._tool_agent.run_with_request(request_text)
tracker.total_attempts += 1
track_failures(tracker, tool_result)

while tracker.can_retry_in_round and not tool_result.any_success:
    tracker.retry_count += 1
    tool_result = self._tool_agent.run_with_request(request_text)
    tracker.total_attempts += 1
    track_failures(tracker, tool_result)
```

`ToolAttemptTracker` 的设计意图是"3 rounds x 3 retries = 9 attempts"，但 `MessageHandler` 中的使用方式是：
- 每轮创建新的 `tracker = ToolAttemptTracker()`
- 只使用 `can_retry_in_round`（单轮内最多3次重试）
- `can_start_new_round` 和 `is_exhausted` 从未被使用
- `round_number` 从未递增

这意味着 `ToolAttemptTracker` 的跨轮次追踪功能在 `MessageHandler` 中完全未使用。Agent 1 的 `re_decide()` 被调用时，`tracker.failure_log` 只包含当前轮的失败记录，而非全部历史。

**风险评级**：中等
**建议**：要么简化 `ToolAttemptTracker` 为单轮追踪器，要么在 `MessageHandler` 中正确实现跨轮次追踪（将 tracker 提升到 while 循环外部）。

---

### 3.8 状态转换条件完备性检查

#### 3.8.1 完备的状态转换矩阵

| 当前状态 | 触发条件 | 下一状态 | 处理函数 | 风险 |
|---------|---------|---------|---------|------|
| BOOT | 初始化完成 | IDLE | `_on_boot()` | 低 |
| IDLE | 用户输入到达 | PERCEIVE | `_on_idle()` | 低 |
| IDLE | 空闲超时 + 随机命中 | THINK | `_on_idle()` (proactive) | **高** (跳过 PERCEIVE) |
| IDLE | /exit, /quit | SHUTDOWN | `_handle_command()` | 低 |
| IDLE | /save, /mood, /status, /forget, /help | IDLE | `_handle_command()` | 低 |
| PERCEIVE | 命令处理完 | IDLE/SHUTDOWN | `_on_perceive()` | 低 |
| PERCEIVE | 正常输入处理完 | THINK | `_on_perceive()` | 低 |
| THINK | 首次/后续 ReAct 迭代 | ACT | `_on_think()` | 中 |
| THINK | ConnectionError | REFLECT | `_on_think()` | 中 |
| ACT | 有 tool_call 且未超限 | THINK | `_on_act()` | 低 |
| ACT | 有 tool_call 但超限 | REFLECT | `_on_act()` → `_finish_react_response()` | 低 |
| ACT | 无 tool_call | REFLECT | `_on_act()` → `_finish_react_response()` | 低 |
| REFLECT | 反射完成 | IDLE | `_on_reflect()` | **高** (缺少 _process_emotion) |
| *任意* | KeyboardInterrupt | SHUTDOWN | `run()` 循环 | 中 (未清理 react 状态) |
| *任意* | Exception | IDLE | `run()` 循环 | **高** (未清理 react 状态) |

#### 3.8.2 缺失的转换

1. **THINK → IDLE（用户中断）**：没有机制允许用户在 ReAct 迭代中途发送新消息并中断当前处理。`NonBlockingInputReader` 在后台读取输入，但主循环在 THINK/ACT 中阻塞于 LLM API 调用，无法响应新输入。

2. **REFLECT → SHUTDOWN（紧急退出）**：`/exit` 命令在 PERCEIVE 中处理，但如果用户在 REFLECT 阶段输入 `/exit`，它将被 `_on_idle()` 在下一轮读取，而非立即响应。

3. **ACT → ERROR → RECOVERY**：工具执行异常（如 `execute_tool_calls` 中的 `asyncio.run` 失败）没有专门的状态处理，依赖通用异常捕获。

---

## 汇总统计

### 问题统计

| 风险等级 | 数量 | 问题编号 |
|---------|------|---------|
| 严重 | 1 | 3.3.3 (CLI 缺少 _process_emotion) |
| 高 | 6 | 3.1.2 (Web 状态机真空), 3.2.1 (react 状态泄漏), 3.2.3 (turn_count 不同步), 3.3.1 (CLI proactive 缺少 user turn), 3.3.2 (Web proactive 记忆黑洞), 3.5.2 (Web 并发竞态) |
| 中等 | 5 | 3.1.1 (ReAct 吞噬状态语义), 3.2.2 (_consecutive_negative 不持久), 3.3.4 (proactive 记忆上下文覆盖), 3.4.3 (PERCEIVE 不可达), 3.7.3 (ToolAttemptTracker 误用) |
| 低 | 6 | 3.2.4 (_tool_call_history 累积), 3.4.1 (BOOT 瞬态), 3.4.2 (SHUTDOWN 异常), 3.5.1 (局部状态线程安全), 3.6.1 (注册表重复代码), 3.6.2 (空注册表), 3.7.1 (token 估算), 3.7.2 (insert(-1) 脆弱) |

### 关键修复建议优先级

1. **P0 - 立即修复**：
   - 在 `CliController._on_reflect()` 中调用 `a._process_emotion()`（发现 3.3.3）
   - 修复 `turn_count` 恢复逻辑（发现 3.2.3）
   - 在 `run()` 异常处理中清理 ReAct 状态（发现 3.2.1）

2. **P1 - 短期修复**：
   - 统一 CLI 和 Web 的 proactive 历史记录策略（发现 3.3.1, 3.3.2）
   - 为 Web 端引入状态机语义（发现 3.1.2）
   - 为 REST API 增加并发防护（发现 3.5.2）

3. **P2 - 中期优化**：
   - 持久化 `_consecutive_negative`（发现 3.2.2）
   - 重构 ReAct 内循环为子状态机（发现 3.1.1）
   - 统一 `_make_internal_registry()`（发现 3.6.1）
   - 修复 `ToolAttemptTracker` 使用方式（发现 3.7.3）

4. **P3 - 长期改进**：
   - 提取跨端共享的后处理函数
   - 引入请求上下文（RequestContext）隔离每轮状态
   - 增加状态机可视化/监控接口

---

*审查完成。以上分析基于 2026-05-31 的代码快照，涉及文件 8 个，总代码行数约 1500 行。*
