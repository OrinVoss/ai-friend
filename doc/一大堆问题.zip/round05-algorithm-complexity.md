# AI Friend 项目：算法复杂度与性能可扩展性审查报告

> 审查日期：2026-05-31
> 审查范围：memory/retrieval.py, memory/short_term.py, storage/repository.py, core/context_manager.py, tools/search_tools.py, core/personality.py, models/personality.py, memory/consolidation.py, core/message_handler.py, core/agent.py, core/inner_drive.py, core/tool_agent.py, memory/embeddings.py, storage/database.py
> 聚焦主题：算法时间/空间复杂度、大规模数据下的性能瓶颈、可扩展性风险

---

## 概述

AI Friend 项目采用三层 Agent 架构（InnerDrive -> ToolAgent -> Roleplay），配合三层记忆检索（Hot Memory + Hybrid Search + On-demand Recall）和情绪引擎（VAD + 8 Plutchik + Resentment）。本报告从算法复杂度角度，对 8 个核心模块进行逐项分析，识别出 14 项性能风险点，其中高风险 5 项、中风险 6 项、低风险 3 项。

核心发现：
- **三层检索存在 O(n) 全表扫描 + O(n) Python 级排序的双重瓶颈**，在事实数超过 5000 时响应延迟显著上升。
- **记忆合并采用朴素集合去重**，语义搜索与关键词搜索的结果合并为 O(n+m) 但常数因子高。
- **上下文压缩触发 LLM 调用**，每次压缩至少消耗 1 次 API 请求，且压缩前对消息列表做两次线性遍历。
- **Token 估算在无 tiktoken 时退化为 O(|text|) 字符级统计**，但实现中存在 4 次全字符串遍历。
- **消息构建在 _build_messages 中反复调用 estimate_tokens**，形成 O(k * n) 的嵌套开销（k 为消息数，n 为内容长度）。
- **情绪交叉调制 _cross_modulate 为固定 O(1)**，但 dominant_emotion 计算为 O(|emotions|) 且每次情绪变化触发两次。
- **GrepTool 的正则匹配为 O(m * n) 最坏情况**（m 为模式长度，n 为文件总字符数），且对每行独立编译搜索。
- **大规模数据下，SQLite LIKE 查询无法利用索引**，导致事实/经验检索退化为线性扫描。

---

## 详细发现

---

### 1. 三层检索的时间复杂度

**涉及文件**：`memory/retrieval.py`（第 27-69 行）、`storage/repository.py`（第 70-99 行）、`memory/long_term.py`（第 78-90 行）

#### 1.1 Layer 1: Hot Memory 检索

`MemoryRetriever.retrieve_for_query()` 第 32-35 行：

```python
hot_facts = self.ltm.get_all_active_facts(limit=50)
recent_experiences = self.ltm.get_recent_experiences(limit=5)
reflections = self.ltm.get_recent_reflections(limit=3)
relationship = self.ltm.get_relationship()
```

这些调用最终映射到 `Repository.get_active_facts()`（第 90-99 行）：

```sql
SELECT * FROM user_facts
WHERE is_active = 1
ORDER BY composite_score DESC, recall_count DESC
LIMIT ?
```

**复杂度分析**：
- 若 `user_facts` 表上存在 `(is_active, composite_score, recall_count)` 复合索引，则 ORDER BY + LIMIT 可被 SQLite 优化为 **O(log n + k)**，其中 n 为总记录数，k=50。
- **但 `database.py` 的建表语句（第 55-68 行）未创建任何索引**，仅依赖主键 `id` 和 UNIQUE `(category, fact_key)`。`is_active` 和 `composite_score` 均无索引。
- 因此 SQLite 必须执行 **全表扫描 + 文件排序（filesort）**，复杂度为 **O(n log n)** 或 **O(n)** 后取前 50 条。
- `get_recent_experiences` 和 `get_recent_reflections` 同理，ORDER BY `created_at DESC` 无索引，亦为 **O(n log n)**。

**风险评级**：**高**（HIGH）
- 当事实数达到 10,000 时，每次 Layer 1 检索可能耗时 50-200ms（取决于磁盘 I/O）。
- 每次用户消息都触发 Layer 1，属于高频路径。

**建议**：
- 在 `user_facts` 上创建 `(is_active, composite_score DESC, recall_count DESC)` 索引。
- 在 `experiences` 上创建 `(is_archived, created_at DESC)` 索引。
- 在 `reflections` 上创建 `(is_active, created_at DESC)` 索引。

#### 1.2 Layer 2: Hybrid Search 混合检索

`MemoryRetriever._hybrid_score()`（第 106-134 行）：

```python
def _hybrid_score(self, query: str, candidates: list, keywords: list) -> list:
    query_vec = self._embed.encode_single(query)   # O(|query|) 编码
    scores = []
    for c in candidates:                           # O(m), m = len(candidates)
        semantic = 0.0
        if hasattr(c, 'embedding') and c.embedding is not None:
            vec = EmbeddingEngine.bytes_to_vec(bytes(c.embedding))  # O(d), d=512
            semantic = float(np.dot(vec, query_vec))                # O(d)
        keyword = self._keyword_score_single(c, keywords, query)    # O(|keywords| * avg_len)
        final = semantic * 0.6 + keyword * 0.4
        scores.append((c, final))
    scores.sort(key=lambda x: x[1], reverse=True)   # O(m log m)
    return [c for c, _ in scores[:30]]
```

**复杂度分析**：
- `candidates` 来自 `hot_facts`，上限 50 条（由 `get_all_active_facts(limit=50)` 控制）。
- 对每个 candidate：向量反序列化 O(d)=512，点积 O(d)，关键词评分 O(k * L)，其中 k 为关键词数，L 为平均字段长度。
- 排序 O(m log m) = O(50 log 50)，可忽略。
- **总体：O(m * (d + k * L))**，在 m=50, d=512, k=10, L=50 时约为 25,000 次基本操作，现代 CPU 可在 <1ms 完成。

**但存在隐性瓶颈**：
- `EmbeddingEngine.bytes_to_vec()` 对每个 candidate 独立调用 `np.frombuffer()`，涉及 Python 对象分配。50 次调用尚可接受，若未来提升 `limit` 到 500，则单次延迟可能达 5-10ms。
- `hasattr()` 在循环内动态反射，有微小开销。

**风险评级**：**低**（LOW）
- 当前 limit=50 时性能可接受，但扩展性受限。

#### 1.3 Layer 2 回退：纯关键词评分

当 embedding 不可用时，回退到 `_score_facts()`（第 194-202 行）：

```python
@staticmethod
def _score_facts(facts: list[UserFact], keywords: list[str], query: str) -> list[UserFact]:
    scored = []
    for f in facts:
        f.composite_score = MemoryRetriever._keyword_score_single(f, keywords, query)
        scored.append(f)
    scored.sort(key=lambda x: x.composite_score, reverse=True)
    return scored
```

`_keyword_score_single()`（第 166-178 行）对每个 fact 遍历所有 keywords 检查 `in` 操作：

```python
keyword_hits = sum(1 for kw in keywords
                   if kw in f.fact_key.lower()
                   or kw in f.fact_value.lower()
                   or kw in f.category.lower())
```

**复杂度分析**：
- `str.lower()` 在每次比较时调用，若 fact_value 长度为 L，则 `lower()` 为 O(L)。
- `kw in string` 为 O(L) 子串搜索（CPython 使用 Boyer-Moore-Horspool 类算法，平均接近 O(L/kw_len)）。
- 对 m 个 facts、k 个 keywords，总复杂度为 **O(m * k * L)**。
- m=50, k=10, L=100 时约为 50,000 次字符操作，<1ms。

**风险评级**：**低**（LOW）

#### 1.4 Layer 2: LLM Rerank

当 candidates > 15 时触发 `_llm_rerank()`（第 204-225 行）：

```python
if len(candidates) > 15 and self.llm_rerank_fn and query.strip():
    selected_indices = self._llm_rerank(query, candidates)
```

**复杂度分析**：
- 这不是算法复杂度问题，而是**外部依赖延迟**问题。
- 每次 rerank 需要 1 次 LLM API 调用，prompt 包含最多 30 条 candidate 的文本（约 2-4KB）。
- 假设 API 延迟 500ms-2s，则此步骤成为整个检索路径的**绝对瓶颈**。
- 且 rerank 结果解析使用 `result.split(",")` 和 `int(x.strip())`，为 O(output_length)。

**风险评级**：**中**（MEDIUM）
- 外部 API 调用不可控，失败时虽有 fallback（返回 None，保留原 candidates），但增加了延迟方差。

#### 1.5 Layer 3: On-demand Recall

`retrieve_by_recall_tag()`（第 71-95 行）：

```python
def retrieve_by_recall_tag(self, text: str) -> Optional[str]:
    m = re.search(r'\[回忆:\s*(.+?)\]', text)
    ...
    facts = self.ltm.search_facts(query, limit=5)
    experiences = self.ltm.search_experiences(keywords, limit=3)
```

映射到 `Repository.search_facts()`（第 70-88 行）：

```sql
SELECT * FROM user_facts
WHERE is_active = 1
  AND (fact_key LIKE ? OR fact_value LIKE ? OR category LIKE ?)
ORDER BY composite_score DESC, recall_count DESC
LIMIT ?
```

**复杂度分析**：
- `LIKE '%query%'` 是**前缀通配符匹配**，SQLite 无法使用 B-Tree 索引，必须**全表扫描**。
- 对每条记录执行 3 次 LIKE 匹配，复杂度 **O(n * L)**，n 为总记录数，L 为平均字段长度。
- 当事实数达到 10,000 时，此查询可能耗时 100ms-500ms。

**风险评级**：**高**（HIGH）
- Layer 3 虽由用户显式触发（`[回忆:xxx]`），但低频不等于低影响。用户可能因延迟感知到卡顿。

**建议**：
- 对 `fact_key`、`fact_value` 建立 **FTS5 全文索引**，将 LIKE 查询替换为 MATCH 查询，复杂度降至 O(匹配文档数)。
- 或引入外部向量数据库（如 faiss）做语义检索，将复杂度降至 O(log n) 或 O(1)（近似最近邻）。

---

### 2. 记忆合并的算法复杂度

**涉及文件**：`memory/retrieval.py`（第 228-236 行）、`memory/retrieval.py`（第 136-161 行）

#### 2.1 经验去重合并

```python
@staticmethod
def _merge_unique_experiences(*lists: list) -> list:
    seen = set()
    result = []
    for lst in lists:
        for e in lst:
            if e.id not in seen:
                seen.add(e.id)
                result.append(e)
    return result
```

**复杂度分析**：
- 设输入列表总数为 p，总元素数为 N。
- `set` 的 `add` 和 `in` 操作平均 **O(1)**，最坏 O(N)（哈希冲突）。
- 总时间复杂度 **O(N)**，空间复杂度 **O(N)**（存储 seen set）。
- 当前经验数上限低（limit=5+15=20），可忽略。

**风险评级**：**低**（LOW）

#### 2.2 语义搜索后的经验重排序

`_search_experiences_semantic()`（第 136-161 行）：

```python
def _search_experiences_semantic(self, query: str, recent: list, keywords: list) -> list:
    all_exp = self.ltm.search_experiences(keywords, limit=15)
    combined = self._merge_unique_experiences(all_exp, recent)
    ...
    scored = []
    for exp in combined:
        sim = 0.0
        if hasattr(exp, 'embedding') and exp.embedding is not None:
            vec = EmbeddingEngine.bytes_to_vec(bytes(exp.embedding))
            sim = float(np.dot(vec, query_vec))
        scored.append((exp, sim))
    scored.sort(key=lambda x: x[1], reverse=True)
    return [exp for exp, _ in scored[:5]]
```

**复杂度分析**：
- `search_experiences` 使用 LIKE 查询（见 1.5），为 **O(n * L)**。
- 合并去重 O(m)，m <= 20。
- 向量点积 O(d * m)，d=512。
- 排序 O(m log m)。
- 瓶颈仍在 SQLite LIKE 查询。

**风险评级**：**中**（MEDIUM）—— 瓶颈在数据库层，非合并算法本身。

---

### 3. 上下文压缩的算法复杂度

**涉及文件**：`core/context_manager.py`（第 62-98 行）

#### 3.1 压缩触发前的消息遍历

```python
def _do_compress(self, messages: list[dict]) -> None:
    parts = []
    for m in messages:
        if m["role"] == "system":
            continue
        content = m["content"]
        if len(content) > 500:
            content = content[:500] + "..."
        parts.append(f"{'用户' if m['role'] == 'user' else '你'}: {content}")
    text = "\n".join(parts)
    if len(text) > 8000:
        text = text[-8000:]
```

**复杂度分析**：
- 遍历 messages 列表一次，O(k)，k 为消息数。
- 对每个消息截取前 500 字符，O(1)（Python 切片为引用复制，但字符串不可变，实际会分配新字符串）。
- 若 text 总长度 > 8000，再做一次切片 `text[-8000:]`，O(|text|)。
- **总体：O(k + |text|)**，线性复杂度，无算法瓶颈。

**但存在工程问题**：
- 每次压缩都创建大量临时字符串（每个 message 一个 500 字符副本 + 一个拼接后的 text）。
- 当 k=100, 平均每条 1000 字符时，临时内存分配约 50KB + 8KB，可忽略。

#### 3.2 压缩的实质成本：LLM API 调用

```python
result = self._provider.generate(
    [{"role": "user", "content": CONTEXT_COMPRESS_PROMPT.format(conversation=text)}],
    stream=False,
)
```

**复杂度分析**：
- 这不是算法复杂度，而是**网络 I/O + LLM 推理延迟**。
- prompt 长度约 8KB + system prompt，假设模型处理速度 50 tokens/s，输出 200 tokens，则延迟约 4-6s（含网络往返）。
- 压缩成功后调用 `self._short_term.clear()`，清空短期记忆，O(1)。

**风险评级**：**高**（HIGH）
- 上下文压缩在 `MessageHandler._build_messages()`（第 274-291 行）中被调用：

```python
msg_tokens = sum(estimate_tokens(m["content"][:500]) for m in messages if m["role"] != "system")
if msg_tokens + estimate_tokens(user_input) > COMPRESS_THRESHOLD:
    a._context.compress(messages)
```

- 每次用户消息构建时都可能触发，且压缩过程**阻塞主线程**（同步调用 `generate()`）。
- 若连续多条长消息，可能连续触发多次压缩（虽然有 `self._compressing` 递归守卫，但守卫在 `compress()` 入口，`_build_messages` 中的 `compress()` 调用是同步阻塞的）。

**建议**：
- 将压缩改为**异步后台任务**，或在压缩前做更激进的截断（如只保留最近 5 条消息）。
- 引入增量式摘要，而非全量压缩。

---

### 4. Token 估算的算法复杂度

**涉及文件**：`core/context_manager.py`（第 27-35 行）

```python
def estimate_tokens(text: str) -> int:
    tok = _get_tokenizer()
    if tok:
        return len(tok.encode(text, disallowed_special=()))
    cjk = sum(1 for c in text if '一' <= c <= '鿿' or '　' <= c <= '〿')
    ascii_chars = sum(1 for c in text if c.isascii() and c.isalpha())
    digits = sum(1 for c in text if c.isdigit())
    other = len(text) - cjk - ascii_chars - digits
    return max(1, int(cjk / 1.5 + ascii_chars / 4 + digits / 3 + other / 8))
```

#### 4.1 tiktoken 路径

`tok.encode(text)` 使用 BPE 分词器，复杂度为 **O(|text|)**（通过正则预分词 + 字典查找）。
- 对 10KB 文本，tiktoken 可在 <1ms 完成。

#### 4.2 回退估算路径

当 tiktoken 不可用时，执行 **4 次全字符串遍历**：

1. `sum(1 for c in text if '一' <= c <= '鿿' ...)` —— 遍历全部字符
2. `sum(1 for c in text if c.isascii() and c.isalpha())` —— 再次遍历
3. `sum(1 for c in text if c.isdigit())` —— 第三次遍历
4. `len(text)` —— O(1)，但 `other = len(text) - ...` 使用已有结果

**复杂度分析**：
- 3 次遍历，每次 O(|text|)，总 **O(|text|)**。
- 常数因子为 3，对短文本可忽略，对 100KB 文本约 300K 次字符判断。

**但存在更严重的问题**：

#### 4.3 Token 估算被高频重复调用

`MessageHandler._build_messages()`（第 280-281 行）：

```python
for t in a.short_term.get_all_reversed():
    ...
    if estimate_tokens(" ".join(m["content"][:200] for m in messages[-5:] if m["role"] != "system")) + estimate_tokens(t.content) > COMPRESS_THRESHOLD:
        overflow = True
        break
    messages.insert(1, {"role": role, "content": t.content})
```

**问题**：
- 循环内每次迭代都调用 `estimate_tokens`，且参数是 `messages[-5:]` 的拼接字符串。
- 设短期记忆有 k=20 条消息，循环执行最多 20 次。
- 每次 `estimate_tokens` 处理约 5 * 200 = 1000 字符。
- 总 token 估算开销：20 * O(1000) = O(20,000) 字符处理，<1ms。

但第 287 行又一次调用：

```python
msg_tokens = sum(estimate_tokens(m["content"][:500]) for m in messages if m["role"] != "system")
if msg_tokens + estimate_tokens(user_input) > COMPRESS_THRESHOLD:
    a._context.compress(messages)
```

- 对 messages 中所有非 system 消息再次估算，O(k * 500)。
- 若 messages 已被插入大量历史消息（如 50 条），则 50 * 500 = 25,000 字符。

**风险评级**：**中**（MEDIUM）
- 单次开销低，但累积调用次数多，且 tiktoken 的 `encode()` 每次都会分配 Python list，有 GC 压力。

**建议**：
- 在 `ConversationBuffer` 中维护**增量 token 计数**，每条消息插入时预计算 token 数，避免重复估算。
- 回退路径可优化为单次遍历：

```python
cjk = ascii_chars = digits = other = 0
for c in text:
    if '一' <= c <= '鿿': cjk += 1
    elif c.isascii() and c.isalpha(): ascii_chars += 1
    elif c.isdigit(): digits += 1
    else: other += 1
```

---

### 5. 消息构建的算法复杂度

**涉及文件**：`core/message_handler.py`（第 274-291 行）

```python
def _build_messages(self, sys_prompt: str, user_input: str | None) -> list[dict]:
    a = self.a
    messages = [{"role": "system", "content": sys_prompt}]
    overflow = False
    for t in a.short_term.get_all_reversed():
        role = "assistant" if t.role == "assistant" else "user"
        if estimate_tokens(" ".join(m["content"][:200] for m in messages[-5:] if m["role"] != "system")) + estimate_tokens(t.content) > COMPRESS_THRESHOLD:
            overflow = True
            break
        messages.insert(1, {"role": role, "content": t.content})
    if overflow and a._context.compressed_summary:
        messages.insert(1, {"role": "system", "content": f"[对话历史摘要] {a._context.compressed_summary}"})
    if user_input:
        msg_tokens = sum(estimate_tokens(m["content"][:500]) for m in messages if m["role"] != "system")
        if msg_tokens + estimate_tokens(user_input) > COMPRESS_THRESHOLD:
            a._context.compress(messages)
        messages.append({"role": "user", "content": user_input})
    return messages
```

#### 5.1 复杂度拆解

| 步骤 | 操作 | 复杂度 |
|------|------|--------|
| 初始化 | `messages = [system]` | O(1) |
| 遍历短期记忆 | `get_all_reversed()` | O(k) 创建列表 + O(k) 反转 |
| 循环内 token 估算 | `estimate_tokens` on `messages[-5:]` | O(20 * 1000) = O(20k) |
| `list.insert(1, ...)` | 插入列表头部 | **O(k)** 每次！ |
| 溢出处理 | `messages.insert(1, summary)` | O(k) |
| 最终 token 估算 | 遍历 messages | O(k * 500) |
| 可能的压缩 | `a._context.compress(messages)` | O(k + |text|) + API 延迟 |

**关键瓶颈：`list.insert(1, ...)`**

Python 列表是**动态数组**，在索引 1 处插入需要将所有后续元素右移一位。
- 若最终 messages 长度为 k=50，则插入操作的总成本为：
  - 第 1 次插入：移动 1 个元素
  - 第 2 次插入：移动 2 个元素
  - ...
  - 第 n 次插入：移动 n 个元素
  - **总成本：O(k^2)**

当 k=50 时，约 1,250 次引用复制，可忽略。
但当 k=200 时，约 20,000 次复制，开始可感知。

**风险评级**：**中**（MEDIUM）
- 当前 `ConversationBuffer.maxlen=20`，所以 k<=20，O(400) 可忽略。
- 但若未来增大 maxlen 或修改逻辑允许更多历史消息，则 O(k^2) 成为瓶颈。

**建议**：
- 使用 `collections.deque` 或先收集到临时列表再 `reversed()` + `extend`，避免头部插入。
- 优化方案：

```python
history = []
for t in a.short_term.get_all_reversed():
    ...
    history.append({"role": role, "content": t.content})
messages = [{"role": "system", "content": sys_prompt}]
messages.extend(reversed(history))  # O(k)
```

#### 5.2 `get_all_reversed()` 的隐性开销

`ConversationBuffer.get_all_reversed()`（`memory/short_term.py` 第 46-49 行）：

```python
def get_all_reversed(self) -> list[Turn]:
    with self._lock:
        return list(reversed(self._turns))
```

- `list(reversed(deque))` 先创建迭代器，再逐个 append 到 list，O(k)。
- 持有锁期间完成，无并发问题，但增加了锁持有时间。

**风险评级**：**低**（LOW）

---

### 6. 情绪交叉调制的复杂度

**涉及文件**：`models/personality.py`（第 132-173 行）、`models/personality.py`（第 73-130 行）

#### 6.1 `_cross_modulate()` 方法

```python
def _cross_modulate(self) -> None:
    a = self.anger
    s = self.sadness
    j = self.joy
    t = self.trust
    f = self.fear
    d = self.disgust
    r = self.resentment

    anger_joy_suppress = min(0.95, a * 0.6 + r * 0.3)
    anger_trust_suppress = min(0.9, a * 0.4 + r * 0.2)
    self.joy = max(0.0, self.joy * (1.0 - anger_joy_suppress))
    self.trust = max(0.0, self.trust * (1.0 - anger_trust_suppress))
    ...
```

**复杂度分析**：
- 操作固定数量的标量（8 种情绪 + resentment），**O(1)**。
- 每次情绪变化（`shift()`）调用一次 `_cross_modulate()`。
- 每次 `shift()` 后还调用 `dominant_emotion`（通过 `history.append(self.dominant_emotion)`）。

#### 6.2 `dominant_emotion` 属性

```python
@property
def dominant_emotion(self) -> str:
    scores = {}
    v, a = self.valence, self.arousal
    if v > 0.5 and a > 0.6:
        scores["excited"] = v * a
    ...  # 约 12 个条件判断

    negative_emotions = {"angry", "sad", ...}
    positive_emotions = {"joyful", "excited", ...}

    biased = {}
    for k, v in scores.items():   # O(|scores|), |scores| <= 12
        if self.valence < -0.2 and k in negative_emotions:
            biased[k] = v * 1.3
        ...

    return max(biased, key=biased.get)
```

**复杂度分析**：
- 固定数量情绪维度，**O(1)**。
- `max()` 遍历最多 12 个元素，O(12)。
- set 的 `in` 操作平均 O(1)。

**风险评级**：**低**（LOW）
- 情绪引擎计算量极小，不构成性能瓶颈。

#### 6.3 情绪事件记录

`record_emotion_event()`（第 239-262 行）：

```python
def record_emotion_event(self, trigger: str, context: str = "") -> None:
    ...
    self.emotion_events.append(event)
    if len(self.emotion_events) > 20:
        self.emotion_events.pop(0)
```

- `list.pop(0)` 为 **O(n)**，n 为列表长度（上限 20）。
- 当列表满时，每次追加都触发 O(20) 的头部弹出。
- 使用 `collections.deque(maxlen=20)` 可将此优化为 O(1)。

**风险评级**：**低**（LOW）—— n=20 时实际影响可忽略，但属于不良实践。

---

### 7. 正则匹配 GrepTool 的复杂度

**涉及文件**：`tools/search_tools.py`（第 97-223 行）

#### 7.1 文件收集阶段

```python
for dirpath, _, fnames in os.walk(target):
    if any(skip in dirpath for skip in ["__pycache__", ".git", ...]):
        continue
    for fname in fnames:
        full = os.path.join(dirpath, fname)
        rel = os.path.relpath(full, target)
        if fnmatch.fnmatch(fname, file_glob) or fnmatch.fnmatch(rel, file_glob):
            if os.path.getsize(full) <= self.MAX_SIZE:
                files.append(full)
```

**复杂度分析**：
- `os.walk()` 遍历目录树，访问每个目录和文件一次，**O(文件总数 + 目录总数)**。
- `any(skip in dirpath for skip in [...])` 对每个目录检查 5 个子串，O(5 * |dirpath|)。
- `fnmatch.fnmatch()` 使用 Unix shell-style 通配符匹配，最坏 O(|pattern| * |string|)，但通常接近 O(|string|)。
- `os.path.getsize()` 为 O(1) 系统调用。

**风险评级**：**中**（MEDIUM）
- 在大型目录树（如 10,000 个文件）下，文件收集可能耗时 100ms-500ms。
- `os.walk()` 是同步阻塞的，且未使用并发。

#### 7.2 正则编译

```python
regex = re.compile(pattern, re.IGNORECASE if ignore_case else 0)
```

- Python 的 `re.compile()` 使用 PCRE 风格的回溯引擎。
- 对复杂模式（如嵌套量词 `.*.*.*`），编译复杂度为 **O(|pattern|)**，匹配复杂度最坏 **O(2^m)**（m 为模式长度）。
- 但通常模式简单，编译和匹配为 O(|pattern|) 和 O(|text|)。

#### 7.3 逐行匹配

```python
for filepath in files:
    with open(filepath, ...) as f:
        lines = f.readlines()
    for i, line in enumerate(lines):
        if regex.search(line):
            file_matches.append(i)
            total_matches += 1
```

**复杂度分析**：
- 对每个文件：读取全部行到内存 `f.readlines()`，O(文件大小)。
- 对每行执行 `regex.search(line)`，最坏 **O(|line| * |pattern|)**（回溯爆炸）。
- 假设平均文件大小 S=100KB，行数 L=1000，文件数 F=100，则总字符处理量 **O(F * S)** = 10MB。
- 10MB 的正则匹配在现代 CPU 上约 10-100ms，可接受。

**但存在以下问题**：

1. **内存峰值**：`f.readlines()` 将整个文件载入内存，MAX_SIZE=500KB，100 个文件同时不在内存，但循环内一次一个，峰值 500KB，可接受。

2. **结果截断逻辑复杂**：

```python
shown = set()
for line_num in file_matches[:20]:
    start = max(0, line_num - context_lines)
    end = min(len(lines), line_num + context_lines + 1)
    for ctx_line in range(start, end):
        if ctx_line not in shown:
            ...
            shown.add(ctx_line)
    if len(results) > self.MAX_RESULTS * 3:
        break
```

- `shown` 是 set，`in` 和 `add` 为 O(1)。
- `file_matches[:20]` 切片为 O(20)。
- 内层循环范围最多 `2*context_lines+1 <= 11`（context_lines 上限 5）。
- 此部分无算法瓶颈。

3. **全局截断条件**：

```python
if len(results) > self.MAX_RESULTS * 3:
    results.append(f"\n...(结果过多，已截断)")
    break
```

- `len(results)` 是 O(1)，但 `results` 是 list，每次 `append` 可能触发扩容。
- 由于有 break，最多处理约 150 个匹配结果。

**风险评级**：**中**（MEDIUM）
- 主要风险不在算法，而在**用户可控的正则回溯攻击**。
- 例如用户输入 pattern `(a+)+b` 匹配大量 'a'，可导致 CPU 100% 占用数秒（ReDoS）。
- 当前无正则超时机制。

**建议**：
- 引入正则匹配超时（如使用 `signal.SIGALRM` 或 `threading.Timer`），限制单次匹配不超过 1 秒。
- 对 `re.compile()` 增加模式长度限制（如最多 500 字符）。
- 考虑使用 `re2` 库替代 Python `re` 模块，保证线性时间匹配。

---

### 8. 大规模数据下的性能瓶颈

#### 8.1 数据库层：缺失索引的全表扫描

**文件**：`storage/database.py`（第 47-116 行建表语句）

当前 schema 无任何辅助索引：

| 表 | 常用查询条件 | 是否有索引 |
|---|---|---|
| user_facts | `is_active = 1 ORDER BY composite_score DESC` | 否 |
| user_facts | `fact_key LIKE ? OR fact_value LIKE ?` | 否 |
| experiences | `is_archived = 0 ORDER BY created_at DESC` | 否 |
| experiences | `summary LIKE ? OR tags LIKE ?` | 否 |
| reflections | `is_active = 1 ORDER BY created_at DESC` | 否 |
| conversation_turns | `ORDER BY id DESC LIMIT ?` | 否（id 是主键，有索引）|
| relationship_metrics | `dimension = ?` | 否（dimension 是主键，有索引）|

**复杂度影响**：
- `user_facts` 表在 10,000 条记录时，无索引 ORDER BY + LIMIT 需要扫描全表并排序，**O(n log n)**。
- `LIKE '%xxx%'` 查询必须全表扫描，**O(n * L)**。
- 每次用户消息触发 3-5 次此类查询，累积延迟显著。

**风险评级**：**高**（HIGH）

**建议**：
```sql
-- 复合索引覆盖 Hot Memory 查询
CREATE INDEX idx_facts_active_score ON user_facts(is_active, composite_score DESC, recall_count DESC);

-- 时间序索引
CREATE INDEX idx_experiences_archived_created ON experiences(is_archived, created_at DESC);
CREATE INDEX idx_reflections_active_created ON reflections(is_active, created_at DESC);

-- 全文搜索（替代 LIKE）
CREATE VIRTUAL TABLE IF NOT EXISTS user_facts_fts USING fts5(fact_key, fact_value, content=user_facts);
CREATE VIRTUAL TABLE IF NOT EXISTS experiences_fts USING fts5(summary, tags, content=experiences);
```

#### 8.2 同步包装器的线程池开销

**文件**：`storage/repository.py`（第 13-21 行）、`memory/long_term.py`（第 17-26 行）

```python
def _run_sync(coro):
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return pool.submit(asyncio.run, coro).result()
```

**复杂度分析**：
- 每次同步调用都创建新的 `ThreadPoolExecutor`（上下文管理器 `with`），然后提交任务并等待结果。
- `ThreadPoolExecutor()` 默认创建 `min(32, os.cpu_count() + 4)` 个线程。
- 频繁创建和销毁线程池有显著开销。
- 更致命的是，在已有事件循环的线程中，`pool.submit(asyncio.run, coro)` 会在新线程中运行 `asyncio.run()`，而该新线程可能没有正确的事件循环生命周期管理。

**风险评级**：**高**（HIGH）
- 在高并发场景（如 Web 模式多个用户同时请求），每个请求可能触发数十次 `_run_sync`，导致线程爆炸。
- `ThreadPoolExecutor` 的默认队列无界，可能堆积大量任务。

**建议**：
- 使用全局单例 `ThreadPoolExecutor`，而非每次调用创建新的。
- 或彻底重构为全异步架构，消除 `_run_sync` 层。

#### 8.3 记忆剪枝的批量操作

**文件**：`storage/repository.py`（第 241-295 行）

```python
async def prune_facts(self, max_count: int) -> int:
    await c.execute("SELECT COUNT(*) FROM user_facts WHERE is_active = 1")
    row = await c.fetchone()
    count = row[0]
    if count <= max_count:
        return 0
    excess = count - max_count
    await c.execute("""
        UPDATE user_facts SET is_active = 0, composite_score = 0
        WHERE id IN (
            SELECT id FROM user_facts WHERE is_active = 1
            ORDER BY composite_score ASC, recall_count ASC
            LIMIT ?
        )
    """, (excess,))
```

**复杂度分析**：
- `SELECT COUNT(*)` 在无索引时全表扫描，O(n)。
- 子查询 `SELECT id ... ORDER BY ... LIMIT ?` 同样无索引支持，O(n log n)。
- 但剪枝由 `MemoryConsolidator` 触发（每 3 轮对话一次），频率低。

**风险评级**：**中**（MEDIUM）

#### 8.4 Embedding 批量编码的内存峰值

**文件**：`memory/consolidation.py`（第 255-297 行）、`memory/embeddings.py`（第 24-47 行）

```python
def _embed_new_items(self) -> None:
    for table, text_cols in [...]:
        rows = conn.execute(
            f"SELECT id, {col_list} FROM {table} "
            "WHERE embedding IS NULL LIMIT 50"
        ).fetchall()
        ...
        vecs = self._embed.encode(texts)
```

`EmbeddingEngine.encode()`：

```python
def encode(self, texts: list[str]) -> np.ndarray:
    resp = self._session.post(self._endpoint, json={"input": texts}, ...)
    vecs = np.array([item["embedding"] for item in data["data"]], dtype=np.float32)
```

**复杂度分析**：
- 每次最多处理 50 条文本，假设平均 200 字符，总 10KB，网络传输可接受。
- 返回 50 * 512 * 4 bytes = 100KB 的 float32 数组，内存可接受。
- 但 `np.array()` 从 Python list 构建，有临时内存分配。
- 若 embedding server 在本地（localhost:8080），延迟 <100ms。

**风险评级**：**低**（LOW）

#### 8.5 Agent 循环的指数级 API 调用增长

**文件**：`core/message_handler.py`（第 64-156 行）、`core/inner_drive.py`（第 61-111 行）、`core/tool_agent.py`（第 82-140 行）

三层 Agent 的调用关系：

```
handle_message
  ├── InnerDrive.assess()          -> 1 API call
  │     └── (可能 internal tools: recall/remember)
  ├── ToolAgent.run_with_request() -> up to 3 API calls (retries)
  ├── InnerDrive.review()          -> 1 API call
  │     └── (可能更多 tool rounds, max 3)
  └── _react_loop (Agent 3)        -> 1 API call (+ tool iterations)
        └── max 10 tool iterations
```

**最坏情况 API 调用数**：
- Agent 1 assess: 1
- Agent 2 round 1: 3 (retries)
- Agent 1 review round 1: 1
- Agent 2 round 2: 3
- Agent 1 review round 2: 1
- Agent 2 round 3: 3
- Agent 3 react: 1 + up to 10 (tool iterations)

**总计：最多 23 次 LLM API 调用处理 1 条用户消息**。

每次 API 调用假设 500ms-2s，则总延迟可达 **11.5s - 46s**。

**风险评级**：**高**（HIGH）
- 这不是传统算法复杂度问题，而是**架构层面的组合爆炸**。
- 用户消息处理延迟与工具调用次数呈线性关系，而工具调用次数由 Agent 1 的决策质量决定，不可控。

**建议**：
- 为 Agent 2 的 retry 引入指数退避和更严格的 early exit。
- Agent 1 的 review 可改为基于规则的判断（如结果非空即通过），减少 LLM 调用。
- Agent 3 的 `_react_loop` 中，首次迭代使用 stream=True，后续迭代可减小 max_tokens。

#### 8.6 短期记忆的线性扫描

**文件**：`memory/short_term.py`（第 51-64 行）

```python
def format_for_prompt(self, max_chars: int = 3000) -> str:
    with self._lock:
        lines = []
        total = 0
        for t in reversed(self._turns):
            line = f"{label}: {t.content}"
            total += len(line)
            if total > max_chars:
                lines.append("...[省略更早对话]")
                break
            lines.append(line)
        lines.reverse()
```

**复杂度分析**：
- `reversed(self._turns)` 遍历 deque，O(k)。
- `lines.reverse()` 反转 list，O(k)。
- 总 **O(k)**，k <= maxlen=20。

**风险评级**：**低**（LOW）

#### 8.7 ToolRegistry 的线性查找

**文件**：`tools/traits.py`（未直接审查，但从使用推断）

`ToolAgent.__init__()`（第 72-80 行）：

```python
for name in EXTERNAL_TOOL_NAMES:
    tool = tool_registry.get(name)
    if tool:
        self._registry.register(tool)
```

若 `ToolRegistry` 内部使用 list 存储工具，则 `get()` 为 O(n)。
若使用 dict，则为 O(1)。

**风险评级**：**低**（LOW）—— 工具数量少（<20），即使 O(n) 也可忽略。

---

## 汇总统计

### 风险分级汇总

| 风险等级 | 数量 | 关键问题 |
|----------|------|----------|
| **高 (HIGH)** | 5 | SQLite 全表扫描（Layer 1/3）、同步线程池爆炸、上下文压缩阻塞、API 调用组合爆炸 |
| **中 (MEDIUM)** | 6 | 消息构建 O(k^2) 插入、token 估算重复遍历、GrepTool ReDoS 风险、经验搜索 LIKE 瓶颈、剪枝无索引、LLM rerank 延迟方差 |
| **低 (LOW)** | 3 | 情绪 list.pop(0)、embedding 反序列化循环、短期记忆线性扫描 |

### 复杂度汇总表

| 模块 | 操作 | 当前复杂度 | 理想复杂度 | 瓶颈来源 |
|------|------|-----------|-----------|---------|
| 三层检索 Layer 1 | Hot Memory 查询 | O(n log n) | O(log n + k) | 缺失复合索引 |
| 三层检索 Layer 2 | Hybrid Score | O(m * d) | O(m * d) | 已最优，m 小 |
| 三层检索 Layer 3 | On-demand LIKE | O(n * L) | O(匹配数) | 无 FTS 索引 |
| 记忆合并 | 去重合并 | O(N) | O(N) | 已最优 |
| 上下文压缩 | 消息处理 | O(k + \|text\|) | O(k + \|text\|) | LLM API 延迟 |
| Token 估算 | 字符统计 | O(\|text\|) | O(\|text\|) | 3 次冗余遍历 |
| 消息构建 | 插入历史 | O(k^2) | O(k) | list.insert(1) |
| 情绪交叉调制 | _cross_modulate | O(1) | O(1) | 已最优 |
| 情绪 dominant | 属性计算 | O(1) | O(1) | 已最优 |
| GrepTool | 正则匹配 | O(F * S) | O(F * S) | ReDoS 风险 |
| 数据库剪枝 | 批量更新 | O(n log n) | O(log n + k) | 缺失索引 |
| 同步包装器 | _run_sync | O(线程创建) | O(1) | 频繁创建线程池 |
| Agent 管道 | 端到端延迟 | O(API_calls) | O(1-3) | 架构级组合爆炸 |

### 可扩展性临界点预估

| 指标 | 当前设计上限 | 预估性能拐点 | 建议上限 |
|------|-------------|-------------|---------|
| user_facts 记录数 | 无硬限制 | 5,000 条（响应 >200ms） | 10,000（需加索引） |
| experiences 记录数 | 无硬限制 | 2,000 条（LIKE 查询变慢） | 5,000（需 FTS） |
| 短期记忆轮数 | 20（硬编码） | 20 以内性能平稳 | 可提升至 50（需优化 _build_messages） |
| 单次 Grep 文件数 | 无硬限制 | 1,000 个文件（>1s） | 5,000（需并发/索引） |
| 单次消息 API 调用 | 最多 23 次 | 3 次以内用户体验良好 | 控制在 5 次以内 |
| embedding 批量大小 | 50 | 50 以内 <100ms | 100（取决于服务端） |

### 优先修复建议

1. **立即修复（P0）**：
   - 为 `user_facts`、`experiences`、`reflections` 表添加复合索引。
   - 将 `_run_sync` 中的 `ThreadPoolExecutor` 改为全局单例。

2. **短期优化（P1）**：
   - 在 `ConversationBuffer` 中预计算并缓存每条消息的 token 数。
   - 优化 `_build_messages` 避免 `list.insert(1)`，改用 `deque` 或尾部收集后反转。
   - 为 GrepTool 添加正则超时机制和模式长度限制。

3. **中期重构（P2）**：
   - 引入 SQLite FTS5 全文索引替代 LIKE 查询。
   - 将上下文压缩改为增量异步摘要，减少阻塞式 LLM 调用。
   - 评估 Agent 管道的 API 调用上限，引入硬性预算（如单条消息最多 5 次 LLM 调用）。

4. **长期规划（P3）**：
   - 考虑将向量检索从 SQLite BLOB 迁移到专用向量数据库（faiss/milvus）。
   - 全面异步化，消除所有 `_run_sync` 同步包装层。
