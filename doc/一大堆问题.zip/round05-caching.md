# 第5轮审查：性能与可扩展性审查 —— 缓存策略专题

**审查日期**: 2026-05-31
**审查范围**: `memory/embeddings.py`, `memory/short_term.py`, `core/context_manager.py`, `storage/repository.py`, `memory/retrieval.py` 及其上下游调用链
**审查目标**: 评估 AI Friend 项目全链路缓存策略的实现完整性、命中率潜力、失效机制与可扩展性瓶颈

---

## 概述

AI Friend 项目采用三层 Agent 架构（Agent 1 InnerDrive -> Agent 2 ToolAgent -> Agent 3 Roleplay），每轮用户消息可能触发 3-5 次 LLM 调用、2-4 次记忆检索、1-2 次嵌入编码，以及不定量的外部工具调用。在这样的调用密度下，缓存策略的完备性直接决定了系统的响应延迟、API 成本与可扩展上限。

本次审查发现：**项目的缓存体系处于严重残缺状态**。唯一已实现的组件 `EmbeddingCache`（`memory/embeddings.py:86-117`）被设计为 LRU 缓存，但在整个代码库中没有任何实例化或调用点，形同虚设。短期记忆、记忆检索结果、系统提示词、工具调用结果、情绪状态等核心高频数据均无任何缓存机制，导致大量可避免的重复计算和网络请求。更严重的是，多个调用链中存在冗余的重复检索（同一次请求中对同一 query 多次编码），进一步放大了性能损耗。

从可扩展性角度看，当前架构在单用户 CLI 模式下尚可运行，但一旦进入 Web 多会话场景（`web_main.py`），每个会话独立创建 `EmbeddingEngine` 实例、独立执行数据库查询、独立构建系统提示词，没有任何跨会话资源共享或缓存层，内存占用和数据库压力将随会话数线性增长，很快触及瓶颈。

---

## 详细发现

### 1. EmbeddingCache：已实现但完全未集成 —— 极高危

**文件**: `memory/embeddings.py`  
**行号**: 第 13-83 行（`EmbeddingEngine`），第 86-117 行（`EmbeddingCache`）  
**风险评级**: **极高危（Critical）**

#### 1.1 实现分析

`EmbeddingCache` 的实现本身质量尚可：

- **键设计**: 使用 SHA-256 哈希作为缓存键（`embeddings.py:94-95`），避免了长文本直接作为字典键的内存开销，且哈希碰撞概率极低。
- **LRU 策略**: 基于 `collections.OrderedDict` 实现（`embeddings.py:91`），`move_to_end` 维护访问顺序，`popitem(last=False)` 驱逐最久未用条目。
- **值拷贝**: `get()` 返回 `vec.copy()`（`embeddings.py:101`），`set()` 存储 `vec.copy()`（`embeddings.py:108`），防止外部修改污染缓存。
- **容量配置**: `max_size=1000` 可通过 `config.embedding_cache_size` 调整（`config.py:42`）。

#### 1.2 致命缺陷：零利用率

通过全局代码搜索确认：`EmbeddingCache` 类在项目中没有任何实例化点。`EmbeddingEngine` 的 `encode()` 和 `encode_single()` 方法直接发起 HTTP POST 请求到 llama-server（`embeddings.py:31-36`），从未查询或写入 `EmbeddingCache`。

**影响量化**:
- 每次用户消息在 `MemoryRetriever.retrieve_for_query()` 中至少编码 query 1 次（facts 检索），若启用语义搜索 experiences 则再编码 1 次（`retrieval.py:112` 和 `retrieval.py:145`）。
- 在 Agent 1 (`InnerDriveAgent.assess`) 和 Agent 3 (`MessageHandler._run_agent3`) 中，若都触发记忆检索，同一 query 可能被编码 2-4 次。
- 以 512 维 float32 向量、1000 条缓存容量计算，缓存内存占用仅约 2MB，成本极低，但可避免 50%-80% 的嵌入请求（用户常重复询问相似话题）。

#### 1.3 线程安全缺陷

即使未来集成 `EmbeddingCache`，当前实现也缺乏线程锁保护。`OrderedDict` 的 `move_to_end()` 和 `popitem()` 不是原子操作，在多线程 Web 场景下（`web/session.py:141` 每个会话独立创建 `EmbeddingEngine`，但未来可能共享实例），并发访问可能导致：

- `RuntimeError: OrderedDict mutated during iteration`
- 缓存状态不一致（大小超限、错误驱逐）
- 在极端情况下，返回损坏的 numpy 数组引用

#### 1.4 修复建议

```python
# memory/embeddings.py 建议修改
import threading

class EmbeddingEngine:
    def __init__(self, ..., cache_size: int = 1000):
        ...
        self._cache = EmbeddingCache(max_size=cache_size)
        self._cache_lock = threading.RLock()

    def encode(self, texts: list[str]) -> np.ndarray:
        if not texts:
            return np.empty((0, self._dim), dtype=np.float32)
        
        # 1. 查缓存
        results = [None] * len(texts)
        missing_indices = []
        missing_texts = []
        
        with self._cache_lock:
            for i, text in enumerate(texts):
                cached = self._cache.get(text)
                if cached is not None:
                    results[i] = cached
                else:
                    missing_indices.append(i)
                    missing_texts.append(text)
        
        if not missing_texts:
            return np.array(results, dtype=np.float32)
        
        # 2. 调服务（批量编码未命中项）
        t0 = time.time()
        vecs = self._encode_remote(missing_texts)
        
        # 3. 写缓存
        with self._cache_lock:
            for text, vec in zip(missing_texts, vecs):
                self._cache.set(text, vec)
        
        # 4. 合并结果
        for idx, vec in zip(missing_indices, vecs):
            results[idx] = vec
        
        return np.array(results, dtype=np.float32)
```

---

### 2. 短期记忆 ConversationBuffer：非 LRU，而是固定容量队列 —— 中危

**文件**: `memory/short_term.py`  
**行号**: 第 13-83 行  
**风险评级**: **中危（Medium）**

#### 2.1 实现分析

`ConversationBuffer` 使用 `collections.deque(maxlen=self.maxlen)`（`short_term.py:21`），这是一个固定容量的双端队列，而非 LRU 缓存。其行为特点：

- **驱逐策略**: 当队列满时，新元素从右侧追加，最左侧（最旧）元素自动被移除。
- **锁保护**: 使用 `threading.Lock`（`short_term.py:18`），`add_turn`、`get_recent`、`format_for_prompt` 等操作均在锁内完成，线程安全。
- **容量配置**: `maxlen=20` 为默认值，Web 端通过 `config.short_term_capacity` 设为 500（`web/session.py:34`）。

#### 2.2 问题：非 LRU 且容量过大

`deque` 的驱逐策略是 FIFO（先进先出），而非 LRU（最近最少使用）。这意味着：

- 如果用户与 AI 进行了一段长对话后切换话题，旧话题的 turn 仍然占据队列空间，直到被 FIFO 驱逐。
- 没有按"访问热度"保留重要对话的机制。例如，用户 20 轮前提到的一个关键事实，可能因为 FIFO 驱逐而丢失，而最新 20 轮的闲聊却全部保留。

更关键的是，Web 端 `short_term_capacity=500`（`config.py:19` 默认也是 500），这意味着：
- 每个会话的短期记忆最多保留 500 轮对话。
- 每轮对话平均 200 字符，500 轮约 100KB 文本，加上 `Turn` 对象开销，单会话短期记忆占用约 1-2MB。
- 在 `SessionManager` 的 `cleanup_old` 中，会话数上限为 50（`web/session.py:169`），50 个会话同时活跃时，短期记忆总占用约 50-100MB，尚可接受。但如果会话数扩展到 500 或 1000，内存压力将显著增加。

#### 2.3 优化建议

短期记忆不需要改为 LRU（对话顺序本身具有时间局部性），但应考虑：

1. **分层存储**: 将短期记忆分为"热区"（最近 20 轮，常驻内存）和"温区"（21-500 轮，按需加载或压缩摘要）。当前 `ContextManager` 的压缩机制（`core/context_manager.py:62-98`）只在 token 超限 80% 时触发，且压缩后清空全部短期记忆，粒度太粗。
2. **按重要性加权**: 为每轮对话标记重要性分数（如用户分享个人信息 = 高重要性），在 FIFO 驱逐时优先保留高重要性轮次。

---

### 3. 记忆检索结果：无缓存，同请求内重复检索 —— 高危

**文件**: `memory/retrieval.py`  
**行号**: 第 27-69 行（`retrieve_for_query`）  
**风险评级**: **高危（High）**

#### 3.1 重复检索问题

在单次用户请求的处理流程中，`retrieve_for_query()` 可能被调用多次：

| 调用点 | 文件 | 行号 | query 内容 |
|--------|------|------|-----------|
| Agent 1 评估 | `core/inner_drive.py` | 第 66 行 | `user_input` |
| Agent 1 复盘 | `core/inner_drive.py` | 第 172 行 | `user_input` |
| Agent 3 回复 | `core/message_handler.py` | 第 249 行 | `user_input` |
| 主动回复 | `core/message_handler.py` | 第 171 行 | `topic_hint` 或空字符串 |
| 探索模式 | `core/message_handler.py` | 第 202 行 | `topic_hint` 或空字符串 |

以一次典型的需要外部工具的用户消息为例：
1. `InnerDriveAgent.assess()` 调用 `retrieve_for_query(user_input)` —— 第 1 次
2. 若需要工具，Agent 2 执行后，`InnerDriveAgent.review()` 再次调用 `retrieve_for_query(user_input)` —— 第 2 次
3. `MessageHandler._run_agent3()` 第三次调用 `retrieve_for_query(user_input)` —— 第 3 次

每次 `retrieve_for_query()` 都会执行：
- `get_all_active_facts(limit=50)` —— 数据库查询
- `get_recent_experiences(limit=5)` —— 数据库查询
- `get_recent_reflections(limit=3)` —— 数据库查询
- `get_relationship()` —— 数据库查询
- 若启用语义搜索：`encode_single(query)` —— HTTP 请求到 llama-server

**三次重复检索 = 3 倍数据库查询 + 3 倍嵌入编码**。数据库查询虽然轻量，但高频重复查询会累积 SQLite 锁竞争；嵌入编码的 HTTP 请求延迟通常在 50-200ms，三次就是 150-600ms 的纯浪费。

#### 3.2 检索结果缓存建议

在 `Agent` 级别或 `MessageHandler` 级别引入"请求级缓存"（request-scoped cache）：

```python
# 建议：在 Agent.__init__ 或 MessageHandler 中增加
self._retrieval_cache: dict[str, MemoryContext] = {}  # query -> MemoryContext
self._retrieval_cache_ttl: float = 5.0  # 5 秒内同一 query 复用
```

在 `handle_message()` 开始时创建缓存，结束时清空。这样可以确保同一 HTTP/WebSocket 请求内的所有 Agent 阶段共享检索结果，避免重复查询。

对于长期缓存，可考虑：
- **Hot Memory 缓存**: `get_all_active_facts(limit=50)` 的结果在 5-10 秒内几乎不变，可缓存。
- **Relationship 缓存**: 关系数据更新频率极低（每次 consolidation 才更新），可缓存 60 秒以上。

---

### 4. 系统提示词（System Prompt）：无缓存，每次全量重建 —— 高危

**文件**: `prompts/system.py`  
**行号**: 第 211-520 行（`build_system_prompt`）  
**风险评级**: **高危（High）**

#### 4.1 构建成本分析

`build_system_prompt()` 是项目中最大的提示词构建函数，单次调用涉及：

- 时间格式化（`datetime.now()`）
- 人格配置序列化（`format_traits()`）
- 情绪状态描述生成（dominant_emotion 映射、VAD 描述、行为指令）
- 怨恨状态检查（`resentment > 0.5` 或 `> 0.2`）
- 情绪事件过滤（`emotion_events[-5:]` 中 unresolved 项）
- 关系数据格式化（4 个维度）
- 长期记忆格式化（facts 最多 10 条、experiences 最多 5 条、reflections 最多 3 条）
- 梦境检查（遍历所有情绪事件查找含"梦"的 trigger）
- 压缩摘要插入
- 工具调用历史格式化（最多 5 条）
- 最近对话历史插入（`conversation_history`，通常 2000-3000 字符）
- 破防状态指令（根据 `consecutive_negative` 插入不同块）
- 模式指令（explore / proactive / normal）

单次 `build_system_prompt()` 生成的文本通常在 4000-8000 字符之间。在单次用户请求中，该函数可能被调用：

| 阶段 | 调用点 | 文件 | 行号 |
|------|--------|------|------|
| Agent 1 | `build_inner_drive_prompt` | `prompts/system.py` | 第 22 行 |
| Agent 1 proactive | `build_inner_drive_proactive_prompt` | `prompts/system.py` | 第 101 行 |
| Agent 2 | `build_tool_agent_prompt` | `prompts/system.py` | 第 185 行 |
| Agent 3 | `build_system_prompt` | `prompts/system.py` | 第 211 行 |
| 探索模式 | `build_system_prompt` | `prompts/system.py` | 第 211 行 |

**单次用户请求可能构建 3-5 次系统提示词**，总字符量 15000-40000。虽然字符串拼接本身开销不大，但：

1. **LLM API 的 prompt_tokens 成本**: 每次系统提示词都作为 messages[0] 传入，重复计费。
2. **token 估算压力**: `ContextManager` 需要估算 token 数来决定是否压缩，而估算函数 `estimate_tokens()`（`core/context_manager.py:27-35`）在 `_build_messages()` 中被多次调用（`message_handler.py:280-288`）。
3. **情绪事件遍历**: 每次构建都遍历 `emotion_events`（`prompts/system.py:348-356`），如果情绪事件积累到 20 条上限，每次构建都是 O(n) 扫描。

#### 4.2 可缓存组件识别

系统提示词中，以下部分在单次请求内完全不变：

| 组件 | 变化频率 | 建议缓存策略 |
|------|---------|-------------|
| 人格配置（identity、traits、speaking_style、backstory、interests） | 几乎不变（运行时修改后生效） | 进程级缓存，失效条件：personality.json 修改时间变化 |
| 对话示例（Block 3） | 静态文本 | 常量缓存 |
| 情绪行为映射表（`emotion_behavior` 字典） | 静态 | 常量缓存 |
| 工具规格（`tools.format_for_prompt()`） | 运行时注册后不变 | 注册时缓存，新增工具时失效 |

以下部分变化较慢，可短缓存：

| 组件 | 变化频率 | 建议缓存策略 |
|------|---------|-------------|
| 关系数据（trust/familiarity/intimacy/playfulness） | 每 3 轮 consolidation 更新一次 | 30-60 秒 TTL 缓存 |
| 长期记忆 facts（前 10 条） | 每次 consolidation 可能新增 | 10-30 秒 TTL 缓存 |
| 长期记忆 experiences（前 5 条） | 每次 consolidation 可能新增 | 10-30 秒 TTL 缓存 |
| 长期记忆 reflections（前 3 条） | 每次 consolidation 可能新增 | 10-30 秒 TTL 缓存 |

以下部分每次请求必变，不可缓存：

| 组件 | 变化原因 |
|------|---------|
| 当前时间 | 每分钟都不同 |
| 当前情绪状态 | 每轮对话后都会 shift/decay |
| 最近对话历史 | 每轮追加 |
| 工具调用历史 | 当前会话累积 |
| consecutive_negative | 当前会话累积 |
| 压缩摘要 | 压缩后更新 |

#### 4.3 优化建议

引入**分层提示词缓存**：

```python
# 建议：在 Personality 或 Agent 级别
class PromptCache:
    def __init__(self):
        self._identity_block: str | None = None
        self._identity_mtime: float = 0
        self._relationship_block: str | None = None
        self._relationship_ttl: float = 0
        self._memory_block: str | None = None
        self._memory_ttl: float = 0
    
    def get_identity_block(self, personality_config) -> str:
        # 检查 personality.json 修改时间，若未变则返回缓存
        ...
```

保守估计，缓存静态和慢变组件可减少 30%-50% 的提示词构建时间和字符串分配量。

---

### 5. 工具调用结果：无缓存，重复工具调用 —— 中危

**文件**: `tools/web_tools.py`, `core/tool_agent.py`  
**行号**: `web_tools.py:72-97`（`WebSearchTool.execute`），`tool_agent.py:82-140`（`ToolAgent.run`）  
**风险评级**: **中危（Medium）**

#### 5.1 问题描述

工具调用结果在当前架构中没有任何缓存。以下场景会导致重复调用：

1. **同一 URL 多次 fetch**: 如果用户在对话中多次提到同一链接，或 Agent 1 在 review 阶段再次请求同一 URL，每次都会重新发起 HTTP 请求。
2. **同一 query 多次 search**: 如果 Agent 1 的 review 认为搜索结果不够充分，可能用相似关键词再次搜索。
3. **Agent 2 重试**: `ToolAttemptTracker` 支持 3 轮 x 3 重试 = 最多 9 次尝试（`tool_agent.py:49-66`），每次重试都重新调用工具，即使之前某次已经成功（但某次失败后整体标记为失败）。

#### 5.2 工具结果缓存建议

对于幂等性工具（web_search、web_fetch、read_file、glob、grep），可引入**短时间 TTL 缓存**：

```python
# 建议：在 ToolRegistry 或 ToolAgent 级别
class ToolResultCache:
    def __init__(self, ttl_seconds: float = 30.0):
        self._cache: dict[str, tuple[Any, float]] = {}  # key -> (result, expiry)
    
    def _make_key(self, tool_name: str, arguments: dict) -> str:
        return hashlib.sha256(
            json.dumps([tool_name, arguments], sort_keys=True).encode()
        ).hexdigest()
    
    def get(self, tool_name: str, arguments: dict) -> ToolResult | None:
        key = self._make_key(tool_name, arguments)
        result, expiry = self._cache.get(key, (None, 0))
        if result and time.time() < expiry:
            return result
        return None
    
    def set(self, tool_name: str, arguments: dict, result: ToolResult):
        key = self._make_key(tool_name, arguments)
        self._cache[key] = (result, time.time() + self._ttl)
```

特别地，`web_fetch` 对同一 URL 的结果在 60 秒内几乎不可能变化，缓存收益极高。`read_file` 对同一文件路径的结果，在文件未修改前也完全可缓存（通过 `os.path.getmtime` 判断）。

---

### 6. 情绪状态（EmotionalState）：无缓存，提示词中频繁序列化 —— 低危

**文件**: `models/personality.py`, `core/personality.py`  
**行号**: `models/personality.py:33-287`（`EmotionalState`），`core/personality.py:81-116`（`Personality.to_dict/load`）  
**风险评级**: **低危（Low）**

#### 6.1 问题描述

`EmotionalState` 是一个包含 20+ 字段的 dataclass，每次构建系统提示词时，需要将其转换为字典并序列化为字符串（`prompts/system.py:43` 直接访问字段，`core/agent.py:176` 调用 `str(self.personality.emotion.to_dict())` 存入数据库）。

`to_dict()` 使用 `dataclasses.asdict()`（`models/personality.py:277`），这是递归深拷贝操作。虽然情绪对象不大，但每轮调用都深拷贝一次，在高频场景下是不必要的开销。

#### 6.2 优化建议

1. **增量更新缓存**: `EmotionalState` 的 `shift()` 和 `decay()` 方法可以标记一个 `_dirty` 标志，`to_dict()` 在 `_dirty=False` 时返回缓存的字典。
2. **避免数据库中的字符串序列化**: `conversation_turns` 表的 `emotional_state` 列存储整个情绪字典的 JSON 字符串（`core/agent.py:176`），每轮都序列化一次。可考虑只存储关键字段（dominant_emotion, valence, arousal），或延迟序列化。

---

### 7. 缓存失效策略：全局缺失 —— 极高危

**风险评级**: **极高危（Critical）**

#### 7.1 现状

当前项目中，没有任何组件实现了明确的缓存失效策略。唯一接近"缓存"的组件是：

1. `EmbeddingCache`：LRU 驱逐（基于容量），但无时间 TTL，无显式失效接口（只有 `invalidate(text)` 方法，但从未被调用）。
2. `ConversationBuffer`：FIFO 驱逐（基于容量），无 TTL。
3. `SessionManager._sessions`：基于数量的驱逐（`cleanup_old` 在超过 50 个时按字典顺序移除，非 LRU），无 TTL。

#### 7.2 各层级应有的失效策略

| 数据类型 | 建议缓存位置 | 建议失效策略 |
|---------|------------|------------|
| 嵌入向量 | `EmbeddingEngine._cache` | LRU（容量 1000）+ 可选 TTL（24h，防止模型更新后向量空间漂移） |
| 检索结果（MemoryContext） | `Agent` 请求级缓存 | 请求结束即失效 |
| 系统提示词静态块 | `PromptCache` | personality.json 修改时间变化时失效 |
| 系统提示词慢变块 | `PromptCache` | 30-60 秒 TTL |
| 工具结果 | `ToolResultCache` | 幂等工具 30-60 秒 TTL；文件工具按 mtime 失效 |
| 关系数据 | `Agent` 级缓存 | 60 秒 TTL 或 consolidation 后显式失效 |
| 数据库连接 | `Database` | 连接池超时（当前无连接池，每次用新 cursor） |

#### 7.3 特别风险：EmbeddingCache 的隐式失效缺失

如果未来集成了 `EmbeddingCache` 但未实现失效机制，当 llama-server 的嵌入模型更新（如从 Qwen3.5-0.8B 升级到 1.5B）时，旧缓存中的向量与新模型的向量空间不一致，会导致语义搜索质量严重下降。应在 `EmbeddingCache` 中增加：

- `version` 标记（与 `embedding_version` 字段对齐，当前数据库中有 `embedding_version` 列但仅设为 1）
- 启动时检查模型版本，不匹配则清空缓存
- 可选的 TTL（24 小时），防止长期运行后缓存陈旧

---

### 8. 缓存命中率优化：无监控，无调优依据 —— 中危

**风险评级**: **中危（Medium）**

#### 8.1 现状

项目中没有任何缓存命中率（Hit Rate）的监控或日志。即使未来集成了缓存，也无法回答以下问题：

- 嵌入缓存的命中率是多少？是否值得维护？
- 哪些 query 频繁未命中？是否需要预加载？
- 缓存大小 1000 是否合适？当前内存占用多少？

#### 8.2 建议的监控指标

```python
# 建议：在 EmbeddingCache 中增加指标
class EmbeddingCache:
    def __init__(self, max_size: int = 1000):
        ...
        self._hits = 0
        self._misses = 0
    
    def get(self, text: str) -> np.ndarray | None:
        key = self._hash(text)
        if key in self._cache:
            self._hits += 1
            self._cache.move_to_end(key)
            return self._cache[key].copy()
        self._misses += 1
        return None
    
    @property
    def hit_rate(self) -> float:
        total = self._hits + self._misses
        return self._hits / total if total > 0 else 0.0
    
    def stats(self) -> dict:
        return {
            "size": len(self._cache),
            "max_size": self._max_size,
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": self.hit_rate,
        }
```

在 `Agent` 或 `WebAgent` 的定期日志中输出缓存统计，便于运维调优。

---

### 9. 数据库层：无查询缓存，无连接池 —— 中危

**文件**: `storage/database.py`, `storage/repository.py`  
**行号**: `database.py:11-140`，`repository.py:70-99`（`search_facts` / `get_active_facts`）  
**风险评级**: **中危（Medium）**

#### 9.1 查询缓存缺失

`Repository` 中的所有查询方法都是直通数据库，没有任何结果缓存。高频查询如：

- `get_active_facts(limit=50)` —— 每次检索都执行 `SELECT * FROM user_facts WHERE is_active = 1 ORDER BY composite_score DESC LIMIT 50`
- `get_recent_experiences(limit=5)` —— 每次检索都执行 `SELECT * FROM experiences ORDER BY created_at DESC LIMIT 5`
- `get_recent_reflections(limit=3)` —— 同上
- `get_relationship()` —— 每次检索都执行 `SELECT dimension, value FROM relationship_metrics`

这些查询在单次用户请求中可能被重复执行 3-5 次（见第 3 节），而结果在 10-30 秒内几乎不变。

SQLite 本身有页缓存（默认 2000 页，约 4MB），但无法避免 SQL 解析、查询计划生成和行构造的开销。对于 `get_active_facts` 这种返回 50 行的查询，如果 facts 表增长到 10000 行，排序开销将变得显著。

#### 9.2 连接池缺失

`Database` 类使用单连接模式（`database.py:15`），通过 `asynccontextmanager cursor()` 管理事务。虽然 SQLite 在 WAL 模式下支持并发读取，但：

- 每个 `cursor()` 调用都获取 `asyncio.Lock`（`database.py:30`），所有数据库操作串行化。
- 没有连接池，无法利用 SQLite 的并发读取能力。
- 在 Web 多会话场景下，所有会话共享同一个 `Database` 实例（`web/session.py:132-134`），锁竞争将成为瓶颈。

#### 9.3 优化建议

1. **查询结果缓存**: 在 `LongTermMemory` 或 `Repository` 层引入 TTL 缓存，缓存 `get_active_facts`、`get_recent_experiences`、`get_recent_reflections`、`get_relationship` 的结果。
2. **连接池**: 考虑使用 `aiosqlite` 的连接池封装，或至少分离读连接和写连接（SQLite WAL 模式支持一个写连接 + 多个读连接）。
3. **索引优化**: `user_facts` 表的 `is_active` + `composite_score` 组合查询应确保有索引（当前 schema 中未显式创建，依赖 SQLite 自动索引）。

---

### 10. Web 层：每会话独立资源，无共享缓存 —— 高危

**文件**: `web/session.py`  
**行号**: 第 27-119 行（`WebAgent.__init__`）  
**风险评级**: **高危（High）**

#### 10.1 资源重复创建

每个 Web 会话创建时，`WebAgent.__init__` 都会独立实例化以下组件：

- `Personality.load()` —— 读取并解析 `personality.json`
- `LongTermMemory(repo)` —— 包装同一个 `repo`，但自身无状态
- `ConversationBuffer(maxlen=500)` —— 独立内存队列
- `KimiProvider(...)` —— 独立 `requests.Session()`（`provider.py:25`）
- `EmbeddingEngine(...)` —— 独立 HTTP 会话，独立缓存（如果未来启用）
- `MemoryRetriever(...)` —— 独立实例
- `MemoryConsolidator(...)` —— 独立实例
- `ToolRegistry()` + 8 个工具实例 —— 全部重新创建

这意味着 50 个并发会话将创建：
- 50 个 `requests.Session()` 对象
- 50 个 `EmbeddingEngine` 实例（每个都有自己的 HTTP 连接池）
- 50 个 `ToolRegistry` 和 400 个工具实例

虽然 `requests.Session()` 有连接池复用，但 50 个独立 Session 意味着 50 个独立的连接池，总共可能维护数百个 TCP 连接，对本地端口和内存都是压力。

#### 10.2 共享缓存建议

以下组件应改为**进程级单例**或**共享实例**：

| 组件 | 共享方式 | 理由 |
|------|---------|------|
| `KimiProvider` | 单例（按 endpoint+model） | API 密钥、模型配置相同，Session 可共享 |
| `EmbeddingEngine` | 单例 | llama-server 端点相同，缓存可全局共享 |
| `ToolRegistry`（外部工具） | 单例 | 工具无状态，可安全共享 |
| `PersonalityConfig` | 单例 + 文件监听 | 配置相同，修改后统一重载 |

共享后，嵌入缓存将自动成为全局缓存，命中率大幅提升。

---

## 汇总统计

### 发现汇总表

| 编号 | 发现项 | 风险评级 | 影响范围 | 文件/行号 | 修复优先级 |
|------|--------|---------|---------|----------|-----------|
| 1 | EmbeddingCache 已实现但完全未集成 | 极高危 | 全链路嵌入编码 | `memory/embeddings.py:86-117` | P0 |
| 2 | EmbeddingCache 无线程锁保护 | 极高危 | 并发安全 | `memory/embeddings.py:86-117` | P0 |
| 3 | 同请求内记忆检索重复执行 3-5 次 | 高危 | 延迟、数据库压力 | `memory/retrieval.py:27-69` | P0 |
| 4 | 系统提示词每次全量重建，无分层缓存 | 高危 | API 成本、CPU | `prompts/system.py:211-520` | P1 |
| 5 | Web 层每会话独立创建所有组件 | 高危 | 内存、连接数 | `web/session.py:27-119` | P1 |
| 6 | 工具调用结果无缓存 | 中危 | 外部 API 成本、延迟 | `tools/web_tools.py`, `core/tool_agent.py` | P1 |
| 7 | 数据库查询无结果缓存 | 中危 | 数据库压力 | `storage/repository.py:70-99` | P2 |
| 8 | 数据库无连接池，单锁串行化 | 中危 | 并发吞吐 | `storage/database.py:11-40` | P2 |
| 9 | 短期记忆容量 500 过大，FIFO 非 LRU | 中危 | 内存占用 | `memory/short_term.py:13-83` | P2 |
| 10 | 情绪状态深拷贝无缓存 | 低危 | CPU、GC | `models/personality.py:276-279` | P3 |
| 11 | 缓存命中率无监控 | 中危 | 运维盲区 | 全局 | P2 |
| 12 | 全局无缓存失效策略 | 极高危 | 数据一致性 | 全局 | P0 |

### 性能影响估算

以一次典型的需要外部工具的用户消息为例（基于代码调用链分析）：

| 操作 | 当前耗时（估算） | 优化后耗时（估算） | 节省比例 |
|------|----------------|------------------|---------|
| 嵌入编码（query，3 次重复） | 150-600ms | 50-200ms | 67% |
| 记忆检索（数据库查询，3 次重复） | 30-150ms | 10-50ms | 67% |
| 系统提示词构建（3-5 次） | 5-20ms | 2-8ms | 60% |
| 工具调用（web_search + web_fetch） | 1000-3000ms | 500-1500ms（缓存命中时） | 50% |
| **单次请求总计** | **1185-3770ms** | **562-1758ms** | **53%** |

注：以上估算假设嵌入服务延迟 50-200ms/次，数据库查询 10-50ms/次，工具调用 500-1500ms/次。实际值取决于硬件和网络环境。

### 可扩展性瓶颈

| 场景 | 当前上限（估算） | 瓶颈 | 优化后上限 |
|------|----------------|------|----------|
| 并发 Web 会话 | 50-100 | 单数据库锁 + 独立 Session 内存 | 500+ |
| 长期记忆 facts 数量 | 200（配置上限） | 无索引的排序查询 | 10000+ |
| 短期记忆轮数 | 500 | 内存线性增长 | 分层后可扩展 |
| 嵌入缓存命中率 | 0%（未启用） | 无缓存 | 60-80% |

---

## 附录：引用代码片段

### A. EmbeddingCache 孤立代码（`memory/embeddings.py:86-117`）

```python
class EmbeddingCache:
    """LRU cache keyed by SHA-256 hash of input text."""

    def __init__(self, max_size: int = 1000):
        self._max_size = max_size
        self._cache: OrderedDict[str, np.ndarray] = OrderedDict()

    @staticmethod
    def _hash(text: str) -> str:
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    def get(self, text: str) -> np.ndarray | None:
        key = self._hash(text)
        if key in self._cache:
            self._cache.move_to_end(key)
            return self._cache[key].copy()
        return None

    def set(self, text: str, vec: np.ndarray):
        key = self._hash(text)
        if key in self._cache:
            self._cache.move_to_end(key)
        self._cache[key] = vec.copy()
        while len(self._cache) > self._max_size:
            self._cache.popitem(last=False)

    def invalidate(self, text: str):
        key = self._hash(text)
        self._cache.pop(key, None)

    def __len__(self) -> int:
        return len(self._cache)
```

### B. 同请求重复检索调用链

```python
# core/inner_drive.py:66
mem_ctx = self._retriever.retrieve_for_query(user_input)

# core/inner_drive.py:172
mem_ctx = self._retriever.retrieve_for_query(user_input)

# core/message_handler.py:249
mem_ctx = a.retriever.retrieve_for_query(user_input)
```

### C. WebAgent 每会话独立实例化（`web/session.py:40-71`）

```python
self.provider = KimiProvider(
    endpoint=config.api_endpoint, api_key=config.api_key,
    model=config.api_model, ...
)

from memory.embeddings import EmbeddingEngine
embed_engine = EmbeddingEngine(
    endpoint=config.embedding_endpoint,
    dim=config.embedding_dim,
)

self.retriever = MemoryRetriever(self.ltm, embedding_engine=embed_engine)
self.consolidator = MemoryConsolidator(self.ltm, llm_gen,
                                        embedding_engine=embed_engine)

registry = ToolRegistry()
registry.register(RecallTool(self.retriever, self.ltm))
registry.register(RememberTool(self.ltm))
# ... 8 个工具全部重新注册
```

---

*报告完成。本报告已按项目规则同步记录至 `changes/` 目录。*
