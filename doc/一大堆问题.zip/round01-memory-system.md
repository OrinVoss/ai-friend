# AI Friend 记忆系统分层架构深度审查报告（Round 01）

**审查日期**：2026-05-31
**审查范围**：`memory/` 目录下全部 5 个模块 + `storage/repository.py` + `storage/database.py` + `models/memory.py` + `models/conversation.py`
**审查目标**：评估短期记忆（LRU+Lock）、长期记忆（SQLite）、三层检索、记忆合并、嵌入引擎降级、数据流一致性、性能瓶颈与架构风险

---

## 一、概述

AI Friend 的记忆系统采用经典的三层分层架构：

```
┌─────────────────────────────────────────────────────────────┐
│  短期记忆 (STM)  ──  ConversationBuffer                      │
│  · 线程安全的 deque(maxlen=20)                               │
│  · 存储最近 N 轮对话 Turn 对象                               │
│  · 供 Agent 实时读取，构建 prompt 上下文                     │
├─────────────────────────────────────────────────────────────┤
│  长期记忆 (LTM)  ──  LongTermMemory + Repository + SQLite    │
│  · UserFact（用户事实）                                      │
│  · Experience（共享体验）                                    │
│  · Reflection（深度反思）                                    │
│  · Relationship（关系维度指标）                              │
├─────────────────────────────────────────────────────────────┤
│  检索层 (Retrieval) ── MemoryRetriever                       │
│  · Layer 1: Hot Memory（高评分事实 + 近期体验 + 反思）       │
│  · Layer 2: Hybrid Search（语义 0.6 + 关键词 0.4）          │
│  · Layer 3: On-demand（[回忆: xxx] 语法触发）                │
├─────────────────────────────────────────────────────────────┤
│  合并层 (Consolidation) ── MemoryConsolidator                │
│  · 定时/定量/情绪/空闲触发                                   │
│  · 事实提取 → 体验总结 → 反思生成 → 关系更新 → 剪枝         │
├─────────────────────────────────────────────────────────────┤
│  嵌入引擎 (Embeddings) ── EmbeddingEngine + EmbeddingCache   │
│  · llama-server OpenAI-compatible API                        │
│  · LRU 缓存（SHA-256 哈希键控）                              │
│  · L2 归一化 + 余弦相似度计算                                │
└─────────────────────────────────────────────────────────────┘
```

整体架构设计思路清晰，模块职责划分合理，但在实现层面存在若干**高风险问题**（线程安全、异步/同步混用、数据一致性、性能瓶颈）以及大量**中低风险问题**（错误处理、缓存策略、Schema 设计、代码重复等）。以下按文件逐项展开分析。

---

## 二、详细发现

### 2.1 short_term.py — 短期记忆（ConversationBuffer）

**文件路径**：`D:\桌面\编程作品\AI朋友\memory\short_term.py`

#### 2.1.1 线程安全分析

`ConversationBuffer` 使用 `threading.Lock` 保护内部 `deque`。所有读写操作（`add_turn`、`get_recent`、`get_all`、`format_for_prompt`、`clear`、`is_full`、`last_n_turns_content`）均包裹在 `with self._lock:` 中，基本实现正确。

**问题 1：锁粒度偏粗，但在此场景下可接受**

`format_for_prompt` 在锁内执行字符串拼接和截断逻辑（第 51-64 行），对于 maxlen=20 的小缓冲区而言，锁持有时间极短，不构成瓶颈。但若未来 `maxlen` 扩大或 `max_chars` 增大，可能需要优化。

**问题 2：`deque` 的 `maxlen` 在 `__post_init__` 中重新设置，存在初始化竞态**

```python
# 第 16 行
_turns: deque = field(default_factory=lambda: deque())  # 无 maxlen
# 第 20-21 行
def __post_init__(self):
    self._turns = deque(maxlen=self.maxlen)  # 重新赋值
```

在极端并发场景下，若对象创建后、__post_init__ 执行前被其他线程访问，会操作无 maxlen 的 deque。虽然 Python dataclass 的 `__post_init__` 在 `__init__` 返回前同步执行，实际风险极低，但代码表达上不够严谨。建议直接在 `default_factory` 中传入 maxlen：

```python
_turns: deque = field(default_factory=lambda self: deque(maxlen=self.maxlen))  # 不可行，lambda 无 self
# 更优方案：使用 __init__ 重写或工厂方法
```

**风险评级**：低

#### 2.1.2 数据模型设计

`Turn` 对象（来自 `models/conversation.py`）包含 `turn_id`、`role`、`content`、`timestamp`、`metadata`。`turn_id` 由 `ConversationBuffer._next_id` 自增生成，是**会话级局部 ID**，不具备全局唯一性。

**问题 3：`turn_id` 与长期记忆 `source_turn` 的关联脆弱**

`MemoryConsolidator._summarize_experience`（第 160-161 行）使用 `min/max(t.turn_id for t in self._pending_buffer)` 作为 `turn_range_start/end` 存入 `experiences` 表。但 `turn_id` 在 `short_term.clear()` 后会重置（`_next_id` 不重置，但 `deque` 清空），且不同会话的 `turn_id` 可能重叠。长期记忆无法准确回溯到具体对话轮次。

**风险评级**：中

#### 2.1.3 容量与配置不一致

`ConversationBuffer` 的默认 `maxlen=20`，但 `config.py` 中 `short_term_capacity=500`（第 19 行）。这个配置项似乎未被 `ConversationBuffer` 使用。若未来意图支持 500 轮短期记忆，当前 `deque(maxlen=20)` 显然不足。

**风险评级**：中

#### 2.1.4 `format_for_prompt` 的截断逻辑

第 51-64 行的截断逻辑从最新轮次向前遍历，累加字符长度，超过 `max_chars` 时插入 `"...[省略更早对话]"` 并 break，最后 `reverse()` 恢复时间顺序。

**问题 4：截断提示语插入位置可能导致语义断裂**

若第 N 轮内容本身很长，累加后刚超过阈值，则 `"...[省略更早对话]"` 会插入在第 N 轮和第 N-1 轮之间，但第 N 轮（最新）的完整内容仍被保留。这实际上意味着**更早的对话被省略**，但提示语位置略显突兀。更常见的做法是从最早轮次开始省略。

不过，由于遍历是从后往前（最新优先），确保最新对话完整性的策略是合理的。此问题属于设计选择，非缺陷。

**风险评级**：低

---

### 2.2 long_term.py — 长期记忆（LongTermMemory）

**文件路径**：`D:\桌面\编程作品\AI朋友\memory\long_term.py`

#### 2.2.1 异步/同步桥接设计

`LongTermMemory` 采用"异步为主、同步包装"的双层 API 设计。所有底层方法（`_store_fact`、`_search_facts` 等）为 `async`，外层通过 `_run_sync()` 包装为同步方法（`store_fact`、`search_facts` 等）。

**问题 5：`_run_sync` 实现存在严重线程/事件循环冲突风险**

```python
# 第 17-26 行
@staticmethod
def _run_sync(coro):
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return pool.submit(asyncio.run, coro).result()
```

此实现在以下场景会崩溃或死锁：

1. **已在事件循环中的线程调用**：若当前线程已有运行中的事件循环（如 Web 模式的 asyncio 主循环），`asyncio.get_running_loop()` 成功获取 loop，然后创建一个 `ThreadPoolExecutor` 并在新线程中执行 `asyncio.run(coro)`。`asyncio.run()` 会尝试创建新的事件循环，但如果该线程已有默认 loop 策略限制，可能失败。

2. **嵌套调用风险**：若 `LongTermMemory` 的同步方法在 `ThreadPoolExecutor` 的回调中被调用，会形成线程池嵌套，可能导致资源耗尽。

3. **与 `aiosqlite` 的兼容性**：`aiosqlite` 内部使用线程池执行 SQLite 操作。`LongTermMemory._run_sync` 再套一层 `ThreadPoolExecutor` + `asyncio.run`，形成"线程池套线程池套事件循环"的三层结构，性能极差且容易死锁。

**更关键的是**：`storage/repository.py` 第 13-21 行定义了**完全相同的 `_run_sync` 函数**，存在代码重复。

**风险评级**：高

#### 2.2.2 `_build_context` 方法冗余且低效

```python
# 第 78-90 行
async def _build_context(self, query: str = "") -> MemoryContext:
    facts = await self._search_facts(query, limit=10)
    keywords = [w for w in query.split() if len(w) > 1] if query else []
    experiences = await self._search_experiences(keywords, limit=5)
    if not experiences:
        experiences = await self._get_recent_experiences(limit=3)
    # ...
```

此方法在 `LongTermMemory` 中定义，但实际的上下文构建由 `MemoryRetriever.retrieve_for_query()` 负责（后者更复杂，包含 hybrid scoring、LLM rerank 等）。`_build_context` 似乎未被主流程使用，且其关键词提取逻辑（简单的 `query.split()`）与 `MemoryRetriever._extract_keywords`（正则提取 + 停用词过滤）不一致，可能导致行为差异。

**风险评级**：低（冗余代码）

#### 2.2.3 同步包装器的参数透传

```python
# 第 95-105 行
def store_fact(self, *a, **kw): return self._run_sync(self._store_fact(*a, **kw))
```

注意：`self._store_fact(*a, **kw)` 会**立即创建协程对象**（coroutine），然后传入 `_run_sync`。这意味着如果 `_store_fact` 的某个参数是异步生成器或需要延迟求值，会提前执行。不过在此场景下，参数均为普通值，不构成实际问题。

**风险评级**：低

---

### 2.3 retrieval.py — 三层检索逻辑（MemoryRetriever）

**文件路径**：`D:\桌面\编程作品\AI朋友\memory\retrieval.py`

#### 2.3.1 架构设计评估

`MemoryRetriever` 实现了文档化的三层检索：
- **Layer 1**（第 31-35 行）：Hot Memory —— 始终包含高评分事实（`get_all_active_facts(limit=50)`）、近期体验（`get_recent_experiences(limit=5)`）、反思（`get_recent_reflections(limit=3)`）、关系指标（`get_relationship()`）。
- **Layer 2**（第 37-61 行）：Hybrid Search —— 语义（0.6）+ 关键词（0.4），可选 LLM 重排。
- **Layer 3**（第 71-95 行）：On-demand —— `[回忆: xxx]` 语法触发。

整体设计思路优秀，但实现细节存在多处问题。

#### 2.3.2 Layer 1：Hot Memory 的候选池污染问题

```python
# 第 32-35 行
hot_facts = self.ltm.get_all_active_facts(limit=50)
recent_experiences = self.ltm.get_recent_experiences(limit=5)
reflections = self.ltm.get_recent_reflections(limit=3)
relationship = self.ltm.get_relationship()
```

Layer 1 获取 50 条 active facts 作为候选池，然后 Layer 2 的 hybrid scoring 在此候选池上进一步筛选（第 40-42 行）。

**问题 6：Layer 1 的 `limit=50` 可能遗漏重要但非 active 的事实**

`get_all_active_facts` 只返回 `is_active=1` 的记录（见 `repository.py` 第 90-99 行）。被 prune 标记为 `is_active=0` 的事实即使 `composite_score` 很高也不会出现在候选池中。这意味着一旦某条事实被剪枝，就**永久失去被检索的机会**，除非通过 Layer 3 的 `[回忆:]` 显式触发（而 Layer 3 使用 `search_facts`，也只查 `is_active=1`）。

**建议**：在语义搜索可用时，应考虑全表扫描（或至少扫描 composite_score 前 N 的 inactive 记录），避免"一旦剪枝、永不见天日"。

**风险评级**：中

#### 2.3.3 Layer 2：Hybrid Scoring 的实现缺陷

**问题 7：语义相似度计算重复调用 `encode_single`**

```python
# 第 111-115 行（_hybrid_score）
try:
    query_vec = self._embed.encode_single(query)
except Exception as e:
    logger.warning(f"[retrieval] embed failed, fallback to keyword: {e}")
    return self._score_facts(candidates, keywords, query)
```

```python
# 第 144-147 行（_search_experiences_semantic）
try:
    query_vec = self._embed.encode_single(query)
except Exception:
    return all_exp
```

同一次 `retrieve_for_query` 调用中，`query` 被编码了两次（一次为 facts，一次为 experiences）。`encode_single` 内部调用 `encode([text])`，即每次都会向 llama-server 发一次 HTTP 请求。虽然 `EmbeddingCache` 可以缓存结果，但 `encode_single` 并未使用 `EmbeddingCache`（见 `embeddings.py` 第 52-54 行）。

**风险评级**：中（性能浪费）

**问题 8：`EmbeddingCache` 未被 `EmbeddingEngine` 使用**

`EmbeddingEngine` 类（`embeddings.py` 第 13-83 行）与 `EmbeddingCache` 类（第 86-117 行）是**完全独立的两个类**。`EmbeddingEngine` 的 `encode` / `encode_single` 方法从未查询或写入 `EmbeddingCache`。`EmbeddingCache` 的存在意义不明——没有任何代码实例化或使用它。

这是一个**严重的架构脱节**：缓存层已编写但未被集成，导致每次嵌入请求都直接打到 llama-server，既浪费网络资源又增加延迟。

**风险评级**：高

**问题 9：`bytes(c.embedding)` 的类型转换风险**

```python
# 第 124 行
vec = EmbeddingEngine.bytes_to_vec(bytes(c.embedding))
```

`c.embedding` 来自 SQLite BLOB，通过 `aiosqlite.Row` 读取。`aiosqlite` 对 BLOB 的返回类型是 `bytes`，但 `bytes(bytes_obj)` 是幂等操作，不会出错。然而，若数据库中某条记录的 `embedding` 列因某种原因存储了非 bytes 类型（如 `str`），`bytes()` 的行为可能不符合预期。

更深层的问题是：`repository.py` 的 `_row_to_fact`（第 299-307 行）未映射 `embedding` 字段。`UserFact` dataclass 有 `embedding` 属性（虽然 `models/memory.py` 中未显示，但 `retrieval.py` 第 122 行使用了 `hasattr(c, 'embedding')`），但 `_row_to_fact` 未赋值。这意味着**从数据库读取的 UserFact 对象实际上没有 embedding 属性**，`hasattr(c, 'embedding')` 始终为 False，语义搜索对 facts 永远不起作用！

经核查 `models/memory.py`，`UserFact` 确实没有 `embedding` 字段。`Experience` 和 `Reflection` 同样没有。这是**数据模型与检索逻辑的严重不匹配**。

**风险评级**：高

**问题 10：关键词评分中的 `composite_score` 被覆盖**

```python
# 第 198-199 行
for f in facts:
    f.composite_score = MemoryRetriever._keyword_score_single(f, keywords, query)
    scored.append(f)
```

`_score_facts` 在内存中直接修改 `UserFact.composite_score`，但**不会写回数据库**。这意味着每次检索都会重新计算并覆盖内存中的 `composite_score`，而这个值与数据库中的 `composite_score` 列可能长期不一致。虽然 `composite_score` 的设计意图可能是动态计算的，但命名上容易与数据库持久化字段混淆。

更关键的是，`_keyword_score_single` 的计算公式（第 166-178 行）中，`composite_score` 本身参与了计算：

```python
score = f.composite_score * 0.2  # 使用旧值
```

如果这是数据库中的持久化值，则评分具有历史累积性；如果是临时计算的，则首次调用时 `composite_score` 为数据库默认值（1.0），导致所有事实获得 0.2 的基础分，产生偏差。

**风险评级**：中

#### 2.3.4 LLM Rerank 的鲁棒性问题

```python
# 第 221 行
indices = [int(x.strip()) for x in result.split(",") if x.strip().isdigit()]
```

**问题 11：LLM 可能返回非数字或越界索引，未做越界检查**

虽然第 49 行有 `if i < len(candidates)` 的过滤，但 `result.split(",")` 可能包含 LLM 输出的解释性文字（如 "0, 1, 2 是最相关的"）。`isdigit()` 会过滤掉含空格或标点的字符串，但无法防止 LLM 返回 "0-5" 或 "1、2、3"（中文顿号）等格式。

**风险评级**：低

#### 2.3.5 Layer 3：`retrieve_by_recall_tag` 与 `check_recall_tag` 重复**

```python
# 第 71-95 行
def retrieve_by_recall_tag(self, text: str) -> Optional[str]:
    m = re.search(r'\[回忆:\s*(.+?)\]', text)
    # ...

# 第 97-102 行
def check_recall_tag(self, response_text: str) -> Optional[str]:
    m = re.search(r'\[回忆:\s*(.+?)\]', response_text)
    if m:
        return m.group(1).strip()
    return None
```

两个方法执行完全相同的正则匹配。`retrieve_by_recall_tag` 已包含提取逻辑，`check_recall_tag` 是冗余的简化版。建议合并。

**风险评级**：低

#### 2.3.6 `_merge_unique_experiences` 的 ID 假设

```python
# 第 228-236 行
@staticmethod
def _merge_unique_experiences(*lists: list) -> list:
    seen = set()
    result = []
    for lst in lists:
        for e in lst:
            if e.id not in seen:
                seen.add(e.id)
                result.append(e)
    return result
```

依赖 `Experience.id` 去重。若 `id` 为 None（如未持久化的临时对象），`None in seen` 的行为是正确的（`None` 是可哈希的），但可能不符合业务预期。

**风险评级**：低

---

### 2.4 consolidation.py — 记忆合并逻辑

**文件路径**：`D:\桌面\编程作品\AI朋友\memory\consolidation.py`

#### 2.4.1 触发条件设计

```python
# 第 28-42 行
def should_consolidate(self, turn_count: int, emotional_intensity: float,
                       idle_duration: float, config) -> bool:
    if turn_count > 0 and turn_count % config.consolidation_interval == 0:
        return True
    if emotional_intensity > 0.7:
        return True
    if len(self._pending_buffer) >= 10:
        return True
    if idle_duration > 120 and self._pending_buffer:
        return True
    return False
```

触发条件包括：轮次间隔（默认 5 轮）、情绪强度（>0.7）、缓冲区满（>=10 条）、空闲超时（>120 秒）。设计合理，覆盖了定期合并、情绪驱动、容量驱动、空闲驱动四种模式。

**问题 12：`turn_count % config.consolidation_interval == 0` 在 turn_count=0 时也会触发**

条件中有 `turn_count > 0` 的保护，正确。但若 `consolidation_interval=1`，则每轮都触发，可能导致频繁的 LLM 调用（事实提取、体验总结、反思生成各一次）。

**风险评级**：低

#### 2.4.2 合并流程分析

```python
# 第 47-81 行
def consolidate(self, short_term: ConversationBuffer,
                personality: Personality,
                max_facts: int = 200,
                max_experiences: int = 100,
                max_reflections: int = 50) -> None:
```

合并流程：
1. `_extract_facts`：LLM 提取用户事实
2. `_summarize_experience`：LLM 总结体验（条件：turn_text > 200 字符）
3. `_generate_reflection`：LLM 生成反思（每次合并都执行）
4. `_update_relationship`：轻量级关系更新（无 LLM）
5. `_prune`：剪枝到上限
6. `_embed_new_items`：批量编码新条目
7. 清空 `_pending_buffer`

**问题 13：合并是"全有或全无"的原子性缺失**

若步骤 1-4 中的某一步因异常失败，后续步骤仍会执行。例如：
- `_extract_facts` 成功，`_summarize_experience` 失败，`_generate_reflection` 仍会执行
- 但 `_pending_buffer` 在步骤 7 才被清空，意味着失败的步骤会在下次合并时**重试**

这既是优点（容错）也是缺点（可能重复处理已成功步骤的数据）。例如，事实已被提取并存储，下次合并时相同的 turn_text 会再次送入 LLM，可能产生重复事实（虽然 `upsert_fact` 有 `ON CONFLICT` 保护，但 LLM 可能用不同的 key 表达同一事实）。

**风险评级**：中

**问题 14：`_generate_reflection` 每次合并都调用 LLM，成本高**

反思生成需要聚合最近 5 条体验、3 条反思、10 条事实，构造一个较长的 prompt 调用 LLM。若 `consolidation_interval=5` 且对话频繁，每 5 轮就调用一次，成本较高。建议增加更严格的触发条件（如每 N 次合并才生成一次，或仅在体验数量变化时生成）。

**风险评级**：中

#### 2.4.3 事实提取的解析鲁棒性

```python
# 第 102-123 行
for line in result.strip().split("\n"):
    line = line.strip()
    if line.startswith("FACT|"):
        parts = line.split("|")
        if len(parts) >= 5:
            _, category, key, value, conf_str = parts[:5]
            # ...
```

**问题 15：`FACT|` 格式解析过于严格**

LLM 输出可能包含多余空格（如 `FACT | preference | name | Alice | 0.9`），`startswith("FACT|")` 会失败。建议使用 `re.match(r'FACT\s*\|', line)` 或先 `line.replace(" ", "")` 预处理。

**风险评级**：低

**问题 16：`importance` 字段在 prompt 中要求 6 个部分，但解析容错不足**

`FACT_EXTRACTION_PROMPT` 要求格式：`FACT|分类|关键词|值|置信度|重要性`。但解析代码中 `importance` 是可选的（第 109-113 行），默认 0.5。这与 prompt 要求一致，但 LLM 可能省略 importance 或输出非数字值，容错处理基本正确。

**风险评级**：低

#### 2.4.4 体验总结的 `turn_range` 计算

```python
# 第 160-161 行
start_id = min((t.turn_id for t in self._pending_buffer), default=None)
end_id = max((t.turn_id for t in self._pending_buffer), default=None)
```

**问题 17：`turn_id` 不连续时，`turn_range` 可能包含未参与的轮次**

若 `_pending_buffer` 中的 turn_id 为 [10, 12, 15]，则 `turn_range_start=10, turn_range_end=15`，暗示 turn 11、13、14 也参与了，但实际上没有。这会导致体验与对话轮次的映射失真。

**风险评级**：低

#### 2.4.5 `_embed_new_items` 的实现分析

```python
# 第 255-297 行
def _embed_new_items(self) -> None:
    if not self._embed or not self._embed.health_check():
        return
    # ...
```

**问题 18：直接操作 `repo.db.get_connection()`，绕过 `cursor()` 上下文管理器**

```python
# 第 262 行
with self.ltm.repo.db.get_connection() as conn:
```

`Database.get_connection()`（第 41-45 行）返回原始 `aiosqlite.Connection`，不自动加锁。虽然 `_embed_new_items` 在 `consolidate()` 中同步调用，且 `consolidate()` 通常在单线程中执行，但 `Database` 设计了一个 `asyncio.Lock`（`_lock`）用于 `cursor()` 上下文。直接绕过锁可能导致与异步数据库操作的竞态。

更关键的是，`get_connection()` 的文档字符串说"Caller must manage locking"，但代码中没有锁管理。

**风险评级**：中

**问题 19：`_embed_new_items` 使用字符串拼接 SQL，存在 SQL 注入风险（虽然可控）**

```python
# 第 272-275 行
rows = conn.execute(
    f"SELECT id, {col_list} FROM {table} "
    "WHERE embedding IS NULL LIMIT 50"
).fetchall()
```

`table` 和 `col_list` 来自硬编码的元组列表，不是用户输入，因此 SQL 注入风险极低。但使用 f-string 拼接 SQL 仍是不良实践，建议改用参数化查询或至少使用白名单校验。

**风险评级**：低

**问题 20：`_embed_new_items` 的批量更新效率**

```python
# 第 291-294 行
for tbl in ["user_facts", "experiences", "reflections"]:
    tbl_updates = [(rid, emb) for t, rid, emb in all_updates if t == tbl]
    if tbl_updates:
        self.ltm.repo.bulk_update_embeddings(tbl, tbl_updates)
```

`bulk_update_embeddings`（`repository.py` 第 189-197 行）使用 `executemany`，效率较高。但注意 `LIMIT 50` 的限制——如果某次合并产生超过 50 条无嵌入的新记录（不太可能，但理论上可能），需要多次运行合并才能全部编码。

**风险评级**：低

#### 2.4.6 关系更新的增量逻辑

```python
# 第 225-246 行
def _update_relationship(self, personality: Personality) -> None:
    relationship = self.ltm.get_relationship()
    sentiment = 0
    if self._pending_buffer:
        last_user_turns = [t for t in self._pending_buffer[-3:] if t.role == "user"]
        if last_user_turns:
            sentiment, personal_sharing, _ = self.analyze_sentiment(last_user_turns[-1].content)
            if personal_sharing:
                new_val = min(1.0, relationship.get("intimacy", 0.3) + 0.03)
                self.ltm.update_relationship("intimacy", new_val)
    new_familiarity = min(1.0, relationship.get("familiarity", 0.3) + 0.02)
    self.ltm.update_relationship("familiarity", new_familiarity)
    if sentiment > 0.3:
        new_trust = min(1.0, relationship.get("trust", 0.3) + sentiment * 0.05)
        self.ltm.update_relationship("trust", new_trust)
```

**问题 21：关系维度只增不减，缺乏衰减机制**

`intimacy`、`familiarity`、`trust` 每次合并都单调递增（有上限 1.0），但没有任何衰减逻辑。长期运行后，所有维度都会趋近 1.0，失去区分度。例如，若用户 100 轮未对话，`familiarity` 仍保持上次值，不会自然下降。

**风险评级**：中

**问题 22：`analyze_sentiment` 每次只分析最后一条用户消息，但 `_pending_buffer` 可能包含多条**

```python
last_user_turns = [t for t in self._pending_buffer[-3:] if t.role == "user"]
if last_user_turns:
    sentiment, personal_sharing, _ = self.analyze_sentiment(last_user_turns[-1].content)
```

若 `_pending_buffer` 包含 10 条 turn（如 5 轮对话 = 5 user + 5 assistant），只分析最后一条 user 消息的情感，忽略了中间轮次的情感变化。例如，用户前几条消息很生气，最后一条平静了，系统会误判整体情感为平静。

**风险评级**：中

---

### 2.5 embeddings.py — 嵌入引擎与缓存

**文件路径**：`D:\桌面\编程作品\AI朋友\memory\embeddings.py`

#### 2.5.1 EmbeddingEngine 设计

```python
# 第 13-83 行
class EmbeddingEngine:
    def __init__(self, endpoint: str = "http://localhost:8080/v1/embeddings",
                 dim: int = 512, timeout: int = 30):
```

**问题 23：`health_check()` 的端点假设不可靠**

```python
# 第 74-83 行
def health_check(self) -> bool:
    try:
        resp = self._session.get(
            self._endpoint.replace("/embeddings", "/health"),
            timeout=5,
        )
        return resp.status_code == 200
    except Exception:
        return False
```

假设 llama-server 的 health endpoint 是 `/health`，且与 embeddings endpoint 在同一路径层级。若 llama-server 配置不同，或使用的是其他兼容 OpenAI API 的服务（如 text-embeddings-inference），`/health` 可能不存在或返回非 200。这是一个隐式约定，缺乏配置灵活性。

**风险评级**：低

**问题 24：`encode` 方法在异常时直接 raise，未提供降级方案**

```python
# 第 48-50 行
except Exception as e:
    logger.error(f"[embed] encoding failed: {e}")
    raise
```

调用方（如 `retrieval.py`）需要自行捕获异常并 fallback。这虽然符合"显式优于隐式"的原则，但意味着每个调用点都需要重复写 try/except。建议在 `EmbeddingEngine` 层提供 `encode_or_fallback` 方法，自动返回零向量或随机向量。

**风险评级**：低

#### 2.5.2 EmbeddingCache 的孤立问题

前文已述（问题 8），`EmbeddingCache` 完全未被使用。这是一个已完成但未集成的组件。

**问题 25：`EmbeddingCache` 的线程安全性**

```python
# 第 86-117 行
class EmbeddingCache:
    def __init__(self, max_size: int = 1000):
        self._max_size = max_size
        self._cache: OrderedDict[str, np.ndarray] = OrderedDict()
```

即使未来集成，`EmbeddingCache` 也没有使用锁。`OrderedDict` 不是线程安全的，`move_to_end` 和 `popitem` 在多线程环境下可能抛出 `RuntimeError: dictionary changed size during iteration` 或产生不一致状态。

**风险评级**：中（当前无影响，未来集成时需注意）

#### 2.5.3 向量序列化的维度校验

```python
# 第 62-67 行
@staticmethod
def bytes_to_vec(data: bytes, dim: int = 512) -> np.ndarray:
    vec = np.frombuffer(data, dtype=np.float32)
    if len(vec) != dim:
        raise ValueError(f"Expected {dim} floats, got {len(vec)}")
    return vec
```

**问题 26：维度不匹配时直接抛异常，未提供降级**

若数据库中某条记录的 embedding 是用旧模型（如 256 维）生成的，读取时会直接崩溃。建议增加降级逻辑：维度不匹配时记录警告并返回零向量，而不是中断整个检索流程。

**风险评级**：低

---

### 2.6 数据流分析：短期 → 长期 → 检索

#### 2.6.1 数据流向图

```
用户输入
    │
    ▼
┌─────────────────┐
│ ConversationBuffer.add_turn() │  ← 短期记忆（线程安全 deque）
└─────────────────┘
    │
    ▼
┌─────────────────┐     ┌─────────────────┐
│ MemoryConsolidator │ ← │ 触发条件满足？   │
│  · add_pending()   │   │  (interval/emotion/buffer/idle)
└─────────────────┘     └─────────────────┘
    │
    ▼
┌─────────────────────────────────────────────┐
│ consolidate()                               │
│  1. _extract_facts() → Repository.upsert_fact()
│  2. _summarize_experience() → Repository.insert_experience()
│  3. _generate_reflection() → Repository.insert_reflection()
│  4. _update_relationship() → Repository.upsert_relationship()
│  5. _prune() → 标记 is_active=0 / is_archived=1
│  6. _embed_new_items() → 批量更新 embedding BLOB
└─────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────┐
│ MemoryRetriever.retrieve_for_query()        │
│  Layer 1: get_all_active_facts(limit=50)    │
│  Layer 2: hybrid_score / score_facts        │
│  Layer 3: [回忆: xxx] 触发                  │
└─────────────────────────────────────────────┘
    │
    ▼
MemoryContext → Agent Prompt
```

#### 2.6.2 数据流中的断裂点

**断裂点 A：短期记忆的 turn_id 与长期记忆的 source_turn 无全局关联**

`ConversationBuffer._next_id` 是会话级自增 ID，`Repository.insert_turn()` 将 turn 存入 `conversation_turns` 表时使用的是表自增 `id`，而非 `ConversationBuffer` 的 `turn_id`。`UserFact.source_turn` 存储的是 `ConversationBuffer._next_id`，而 `Experience.turn_range_start/end` 也是 `ConversationBuffer._next_id`。这意味着无法通过 `source_turn` 或 `turn_range` 关联到 `conversation_turns` 表中的具体记录。

**风险评级**：中

**断裂点 B：embedding 字段在数据模型中缺失**

`models/memory.py` 中的 `UserFact`、`Experience`、`Reflection` 均没有 `embedding` 字段，但 `retrieval.py` 通过 `hasattr(c, 'embedding')` 检查。由于 `_row_to_fact` 等转换方法也未映射该字段，语义搜索对 facts 和 experiences 实际上**完全不可用**。

**风险评级**：高

**断裂点 C：`ConversationBuffer.clear()` 后 `_pending_buffer` 可能仍引用旧 turn**

若 `short_term.clear()` 在 `consolidate()` 之前被调用，`_pending_buffer` 中存储的是 `Turn` 对象引用（Python 对象引用），`clear()` 清空 deque 但不会删除对象。`_pending_buffer` 仍能访问这些 turn，但 `short_term` 中已无这些记录。这不是 bug，但可能导致 `_pending_buffer` 与 `short_term` 状态不一致。

**风险评级**：低

---

### 2.7 storage/repository.py — 仓储层

**文件路径**：`D:\桌面\编程作品\AI朋友\storage\repository.py`

#### 2.7.1 异步/同步桥接重复

第 13-21 行定义了与 `long_term.py` 完全相同的 `_run_sync` 函数。这是代码重复，维护时容易遗漏。

**风险评级**：低

#### 2.7.2 `upsert_fact` 的 embedding 处理

```python
# 第 34-67 行
async def upsert_fact(self, category: str, key: str, value: str,
                      confidence: float = 1.0, source_turn: Optional[int] = None,
                      importance: float = 0.5,
                      embedding: Optional[bytes] = None) -> int:
```

**问题 27：embedding 为 None 时，冲突更新不保留旧 embedding**

当 `embedding is None` 时（第 56-67 行），`ON CONFLICT` 更新语句**不包含 embedding 字段**。这意味着如果某条事实已有 embedding，后续更新（如更高 confidence 的相同 fact）会将 embedding 置为逻辑上的 NULL（实际不更新列，保持旧值）。这似乎是设计意图，但需注意：如果某次更新提供了 embedding，而后续更新未提供，embedding 列仍保持上次值，不会丢失。

然而，`recall_count` 在每次冲突时都 `+1`（第 50 行），无论 fact_value 是否变化。这可能导致频繁访问的事实 recall_count 持续累积，在 `_keyword_score_single` 中受到惩罚（`score -= min(f.recall_count * 0.02, 0.3)`）。设计意图可能是"越常 recalled 的事实越不重要"（因为已经是常识），但这与直觉相反。

**风险评级**：低（设计选择）

#### 2.7.3 `search_facts` 的 LIKE 查询性能

```python
# 第 70-88 行
await c.execute("""
    SELECT * FROM user_facts
    WHERE is_active = 1
      AND (fact_key LIKE ? OR fact_value LIKE ? OR category LIKE ?)
    ORDER BY composite_score DESC, recall_count DESC
    LIMIT ?
""", (f"%{query}%", f"%{query}%", f"%{query}%", limit))
```

**问题 28：LIKE 查询无索引，大数据量时性能差**

SQLite 的 `LIKE '%xxx%'` 无法使用 B-tree 索引，会触发全表扫描。虽然当前 `user_facts` 表上限 200 条，全表扫描可接受，但若未来扩容，需要增加 FTS（Full-Text Search）索引或至少对 `category` 建立索引。

**风险评级**：低（当前数据量小）

#### 2.7.4 `prune_facts` 的剪枝逻辑

```python
# 第 241-258 行
async def prune_facts(self, max_count: int) -> int:
    # ...
    await c.execute("""
        UPDATE user_facts SET is_active = 0, composite_score = 0
        WHERE id IN (
            SELECT id FROM user_facts WHERE is_active = 1
            ORDER BY composite_score ASC, recall_count ASC
            LIMIT ?
        )
    """, (excess,))
```

**问题 29：剪枝后 `composite_score = 0`，但数据库中 `recall_count` 不清零**

被剪枝的事实 `is_active=0`、`composite_score=0`，但 `recall_count` 保持原值。若未来重新激活（当前无重新激活机制），`recall_count` 的累积惩罚仍然存在。

**风险评级**：低

#### 2.7.5 `_row_to_fact` 等转换方法未映射 embedding

```python
# 第 299-307 行
def _row_to_fact(self, r) -> UserFact:
    return UserFact(
        id=r["id"], category=r["category"], fact_key=r["fact_key"],
        fact_value=r["fact_value"], confidence=r["confidence"],
        importance=r["importance"],
        source_turn=r["source_turn"], created_at=r["created_at"],
        updated_at=r["updated_at"], recall_count=r["recall_count"],
        is_active=bool(r["is_active"]), composite_score=r["composite_score"],
    )
```

未包含 `embedding` 和 `embedding_version` 字段。这是导致**语义搜索对 facts 不可用**的直接原因。`_row_to_experience` 和 `_row_to_reflection` 同样缺失。

**风险评级**：高

---

### 2.8 storage/database.py — 数据库层

**文件路径**：`D:\桌面\编程作品\AI朋友\storage\database.py`

#### 2.8.1 Schema 设计

数据库使用 `aiosqlite`（SQLite 的异步包装），启用 WAL 模式（第 21 行）和外键约束（第 22 行）。Schema 包含 6 张表：`schema_version`、`user_facts`、`experiences`、`reflections`、`relationship_metrics`、`conversation_turns`。

**问题 30：`schema_version` 表未实际使用**

`schema_version` 表被创建，但没有任何代码向其插入版本号。Schema 迁移逻辑（第 118-134 行）通过 `PRAGMA table_info` 动态检查列是否存在，这是一种"懒迁移"策略，但缺乏版本追踪，难以管理复杂迁移。

**风险评级**：低

#### 2.8.2 动态列添加的迁移策略

```python
# 第 118-134 行
for table, column, col_type, default_val in [
    ("user_facts", "importance", "REAL", "0.5"),
    ("experiences", "importance", "REAL", "0.5"),
    ("reflections", "is_active", "INTEGER", "1"),
    ("user_facts", "embedding", "BLOB", "NULL"),
    ("user_facts", "embedding_version", "INTEGER", "0"),
    ("experiences", "embedding", "BLOB", "NULL"),
    ("experiences", "embedding_version", "INTEGER", "0"),
    ("reflections", "embedding", "BLOB", "NULL"),
    ("reflections", "embedding_version", "INTEGER", "0"),
]:
```

**问题 31：迁移列表硬编码，新增列时容易遗漏**

当前迁移策略是"检查列是否存在，不存在则添加"。这适用于简单的列添加，但不支持：
- 列类型变更
- 列重命名
- 索引创建
- 数据迁移脚本

**风险评级**：低

#### 2.8.3 连接管理

```python
# 第 26-39 行
@asynccontextmanager
async def cursor(self):
    if self.conn is None:
        raise RuntimeError("Database not opened. Call await db.open() first.")
    async with self._lock:
        c = await self.conn.cursor()
        try:
            yield c
            await self.conn.commit()
        except aiosqlite.Error:
            await self.conn.rollback()
            raise
        finally:
            await c.close()
```

**问题 32：`cursor()` 上下文管理器自动 commit，不适合只读查询**

所有通过 `cursor()` 执行的查询都会自动 `commit`（第 34 行），即使是 `SELECT` 语句。这在 SQLite WAL 模式下不会导致数据损坏，但会产生不必要的 WAL 文件写入和 checkpoint 开销。

**风险评级**：低

**问题 33：`get_connection()` 返回原始连接，无锁保护**

```python
# 第 41-45 行
def get_connection(self):
    if self.conn is None:
        raise RuntimeError("Database not opened.")
    return self.conn
```

`consolidation.py` 的 `_embed_new_items` 使用此方法直接执行 SQL，绕过了 `_lock`。虽然 `aiosqlite` 内部使用线程池执行 SQLite 操作（SQLite 本身支持单写多读），但并发读写仍可能遇到 `OperationalError: database is locked`。

**风险评级**：中

---

### 2.9 models/memory.py — 数据模型

**文件路径**：`D:\桌面\编程作品\AI朋友\models\memory.py`

#### 2.9.1 embedding 字段缺失

```python
@dataclass
class UserFact:
    id: Optional[int] = None
    category: str = ""
    # ...
    # 缺少 embedding: Optional[bytes] = None
    # 缺少 embedding_version: int = 0
```

这是前文多次提及的问题根源。`UserFact`、`Experience`、`Reflection` 均未包含 `embedding` 和 `embedding_version` 字段，导致检索层无法使用语义搜索。

**风险评级**：高

#### 2.9.2 `Experience.tags` 的默认值

```python
@dataclass
class Experience:
    # ...
    tags: list[str] = field(default_factory=list)
```

正确使用了 `default_factory=list`，避免可变默认值陷阱。

**风险评级**：无

---

## 三、汇总统计

### 3.1 问题分类统计

| 风险等级 | 数量 | 占比 |
|---------|------|------|
| 高 | 5 | 16.1% |
| 中 | 12 | 38.7% |
| 低 | 14 | 45.2% |
| **合计** | **31** | **100%** |

### 3.2 高风险问题清单（必须优先修复）

| # | 问题 | 位置 | 影响 |
|---|------|------|------|
| 1 | `_run_sync` 的线程/事件循环冲突 | `long_term.py:17-26`, `repository.py:13-21` | 在 Web 模式（asyncio）下调用同步 LTM API 可能死锁或崩溃 |
| 2 | `EmbeddingCache` 完全未被使用 | `embeddings.py:86-117` | 每次嵌入请求都直接访问 llama-server，无缓存加速 |
| 3 | 数据模型缺失 `embedding` 字段 | `models/memory.py` | 语义搜索（Layer 2 hybrid）对 facts/experiences 完全不可用 |
| 4 | `_row_to_fact` 等未映射 `embedding` | `repository.py:299-327` | 数据库中的 embedding BLOB 无法被读取到内存对象 |
| 5 | `health_check` 硬编码 `/health` 端点 | `embeddings.py:74-83` | 嵌入服务兼容性差，不同部署可能误判为不可用 |

### 3.3 中风险问题清单（建议近期修复）

| # | 问题 | 位置 |
|---|------|------|
| 6 | 异步/同步桥接代码重复 | `long_term.py`, `repository.py` |
| 7 | `turn_id` 非全局唯一，`source_turn` 关联脆弱 | `short_term.py`, `consolidation.py` |
| 8 | `short_term_capacity=500` 配置未使用 | `config.py:19`, `short_term.py` |
| 9 | Layer 1 只查 `is_active=1`，剪枝后永久丢失 | `retrieval.py:32`, `repository.py:90-99` |
| 10 | 同一次检索中 `query` 被编码两次 | `retrieval.py:111-115`, `144-147` |
| 11 | `composite_score` 被内存覆盖但不持久化 | `retrieval.py:198-199` |
| 12 | 合并流程缺乏原子性，可能重复处理 | `consolidation.py:47-81` |
| 13 | `_generate_reflection` 每次合并都调用 LLM，成本高 | `consolidation.py:68` |
| 14 | `_embed_new_items` 绕过 `cursor()` 锁管理 | `consolidation.py:262` |
| 15 | 关系维度只增不减，缺乏衰减机制 | `consolidation.py:225-246` |
| 16 | `analyze_sentiment` 只分析最后一条 user 消息 | `consolidation.py:233-236` |
| 17 | `EmbeddingCache` 无线程锁 | `embeddings.py:86-117` |
| 18 | `get_connection()` 无锁，并发可能冲突 | `database.py:41-45` |

### 3.4 低风险问题清单（可逐步优化）

| # | 问题 | 位置 |
|---|------|------|
| 19 | `deque` 初始化竞态（极难触发） | `short_term.py:16-21` |
| 20 | `format_for_prompt` 截断提示语位置 | `short_term.py:51-64` |
| 21 | `_build_context` 冗余且关键词逻辑不一致 | `long_term.py:78-90` |
| 22 | LLM rerank 输出格式解析鲁棒性不足 | `retrieval.py:221` |
| 23 | `retrieve_by_recall_tag` 与 `check_recall_tag` 重复 | `retrieval.py:71-102` |
| 24 | `_merge_unique_experiences` 的 `None` ID 处理 | `retrieval.py:228-236` |
| 25 | `FACT|` 格式解析过于严格 | `consolidation.py:102-123` |
| 26 | 体验 `turn_range` 可能包含未参与轮次 | `consolidation.py:160-161` |
| 27 | `_embed_new_items` 使用 f-string SQL | `consolidation.py:272-275` |
| 28 | `encode` 异常时未提供自动降级 | `embeddings.py:48-50` |
| 29 | `bytes_to_vec` 维度不匹配时直接抛异常 | `embeddings.py:62-67` |
| 30 | `schema_version` 表未使用 | `database.py:50-53` |
| 31 | `cursor()` 自动 commit 不适合只读查询 | `database.py:26-39` |
| 32 | LIKE 查询无索引，大数据量性能差 | `repository.py:70-88` |
| 33 | 剪枝后 `recall_count` 不清零 | `repository.py:251` |

### 3.5 架构层面的核心建议

1. **修复语义搜索的断裂**：在 `models/memory.py` 的 `UserFact`、`Experience`、`Reflection` 中添加 `embedding: Optional[bytes] = None` 和 `embedding_version: int = 0` 字段，并在 `repository.py` 的 `_row_to_*` 方法中映射这些字段。这是当前记忆系统**最严重的功能缺陷**。

2. **集成 EmbeddingCache**：将 `EmbeddingCache` 集成到 `EmbeddingEngine` 中，在 `encode` / `encode_single` 方法中先查缓存、再调服务、最后写缓存。为 `EmbeddingCache` 添加 `threading.RLock` 保证线程安全。

3. **重构异步/同步桥接**：统一使用 `asyncio.run_coroutine_threadsafe()` 或完全分离同步/异步 API。避免在已有事件循环的线程中嵌套 `asyncio.run()`。建议 Web 端完全使用异步 API，CLI 端在启动时创建独立线程运行事件循环。

4. **优化合并触发策略**：将 `_generate_reflection` 的触发条件从"每次合并"改为"每 N 次合并"或"仅在新增体验时"。 reflection 生成是成本最高的步骤（长 prompt + LLM 调用）。

5. **增加关系衰减机制**：在 `MemoryConsolidator` 或独立定时任务中，定期（如每天）对 `relationship_metrics` 应用衰减函数（如 `new_val = old_val * 0.99`），避免所有维度趋近 1.0。

6. **建立全局 turn ID 体系**：将 `ConversationBuffer._next_id` 与 `conversation_turns.id` 统一，或使用 UUID/时间戳作为全局标识，确保 `source_turn` 和 `turn_range` 能准确回溯。

7. **增加 FTS 索引**：为 `user_facts.fact_key`、`user_facts.fact_value`、`experiences.summary` 等频繁搜索的文本列添加 SQLite FTS5 虚拟表，替代低效的 `LIKE '%xxx%'` 全表扫描。

---

## 四、结论

AI Friend 的记忆系统在**架构设计层面**表现出色：三层检索、多触发合并、嵌入缓存、关系维度等概念均体现了对长期 AI 伴侣产品的深入思考。然而，在**实现层面**存在若干关键断裂，尤其是：

- **语义搜索完全不可用**（数据模型缺失 embedding 字段）
- **嵌入缓存未集成**（每次请求都访问外部服务）
- **异步/同步桥接存在死锁风险**（Web 模式下的稳定性隐患）

这三个高风险问题建议在下一轮迭代中优先修复。修复后，记忆系统的核心能力（基于语义的相关性检索、高效的嵌入计算、稳定的多模式运行）将得到实质性提升。

---

*报告生成时间：2026-05-31*
*审查人：Claude Code（Sonnet 4.6）*
*审查范围：memory/*.py, storage/repository.py, storage/database.py, models/memory.py, models/conversation.py, config.py, prompts/templates.py*
