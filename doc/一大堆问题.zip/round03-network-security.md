# AI Friend 项目网络请求安全深度审查报告（Round 03）

**审查日期**：2026-05-31  
**审查范围**：`core/provider.py`、`tools/web_tools.py`、`tools/web_fetch.py`（已合并至 `web_tools.py`）、`config.py`、`memory/embeddings.py`、`web/server.py`、`core/dispatcher.py`、`core/tool_agent.py`、`tools/traits.py`  
**审查目标**：聚焦网络请求安全，覆盖 SSL/TLS 证书验证、请求超时配置、重定向跟随策略、代理设置（`trust_env=False` 的影响）、请求头注入风险、SSRF 攻击面、DNS 重绑定攻击、请求内容类型和编码安全、响应大小限制共 9 个维度  
**代码版本**：main 分支，commit `3c24cd3` 附近  
**关联文档**：`doc/round01-web-layer.md`、`doc/round01-tools-layer.md`、`doc/round01-config-management.md`

---

## 概述

AI Friend 项目作为基于大语言模型的对话型 AI 应用，其网络请求安全直接决定了 API 密钥安全、用户数据隐私和系统可用性。项目中的网络请求主要分布在三个层面：

1. **LLM API 层**（`core/provider.py`）：通过 `requests.Session` 与 DeepSeek API 通信，支持流式响应和重试机制；
2. **嵌入引擎层**（`memory/embeddings.py`）：通过 `requests.Session` 与本地 `llama-server` 的 OpenAI 兼容 API 通信；
3. **外部工具层**（`tools/web_tools.py`）：通过 `requests.Session` 调用 AnySearch JSON-RPC API，实现网页搜索和内容提取；
4. **Web 服务层**（`web/server.py`）：FastAPI 提供 WebSocket 和 REST API，接收外部请求并驱动内部网络调用。

本次审查发现 **2 个高危缺陷**、**7 个中危缺陷**、**6 个低危/架构建议项**，总体风险评级为 **中-高**。最严重的问题集中在 SSRF 攻击面（通过 `web_fetch` 工具间接暴露内部服务）、响应大小无限制导致的内存耗尽风险、以及 `trust_env=False` 策略下代理配置的完全缺失。以下按 9 个审查维度逐条展开，并给出风险评级与修复建议。

---

## 详细发现

### 一、SSL/TLS 证书验证

#### 【高危-1】`verify=True` 依赖隐式默认值，无证书固定或自定义 CA 支持

**文件**：`D:\桌面\编程作品\AI朋友\core\provider.py`，第 87-92 行

```python
resp = self.session.post(
    url,
    json=payload,
    stream=True,
    timeout=self.timeout,
)
```

**问题分析**：

1. `requests.Session.post()` 的 `verify` 参数默认为 `True`，这意味着当前实现确实启用了 SSL/TLS 证书验证。然而，这一关键安全行为完全依赖于 `requests` 库的隐式默认值，代码中没有显式声明 `verify=True`。如果未来某次重构中不小心传入了 `verify=False`（例如为了调试临时修改后忘记恢复），证书验证将被静默关闭，且代码审查难以发现。

2. 项目没有实现**证书固定（Certificate Pinning）**。在面向生产环境的应用中，仅依赖操作系统 CA 证书池是不够的——如果用户的操作系统被植入了恶意根证书（如某些企业监控软件、恶意软件），或者遭遇中间人攻击（MITM），攻击者可以使用由受信任 CA 签发的伪造证书截获与 DeepSeek API 的通信内容，包括 API 密钥和对话数据。

3. 项目没有提供自定义 CA 证书的路径配置。在某些企业网络环境中，HTTPS 流量需要通过企业代理进行 SSL 检查，这要求应用信任企业自签名的 CA 证书。当前代码无法配置 `verify=/path/to/ca-bundle.crt`，导致在这些环境中要么完全无法工作，要么被迫关闭证书验证。

4. `memory/embeddings.py` 和 `tools/web_tools.py` 中的 `session.post()` 同样存在上述问题，即依赖隐式默认值、无证书固定、无自定义 CA 支持。

**风险**：中间人攻击可导致 API 密钥和对话内容泄露；企业环境部署困难。

**建议**：
- 在所有 `session.post()` 调用中显式传入 `verify=True`，并通过代码审查或 lint 规则禁止 `verify=False` 的提交。
- 在 `Config` 中增加 `ssl_ca_bundle: str = ""` 配置项，非空时传入 `verify=cfg.ssl_ca_bundle`。
- 考虑实现证书固定：将 DeepSeek API 和 AnySearch API 的公钥指纹硬编码在配置中，每次连接时校验服务器证书链。

---

#### 【中危-1】嵌入引擎使用 HTTP 而非 HTTPS，存在明文传输风险

**文件**：`D:\桌面\编程作品\AI朋友\config.py`，第 40 行

```python
embedding_endpoint: str = "http://localhost:8080/v1/embeddings"
```

**问题分析**：

1. 默认配置中嵌入引擎端点使用 `http://` 协议。虽然 `localhost` 通常被认为是可信网络边界，但在以下场景中仍存在风险：
   - **容器化部署**：如果 `llama-server` 运行在独立容器中，AI Friend 应用通过 Docker 网络（如 `http://llama:8080`）访问，同一网络中的其他容器可能进行流量嗅探。
   - **多用户服务器**：如果应用部署在共享服务器上，其他用户可能通过 `tcpdump` 或网络命名空间逃逸获取嵌入请求内容（其中包含用户对话的文本片段）。
   - **反向代理场景**：如果 `llama-server` 前面有 Nginx 等反向代理提供 HTTPS 终止，但 AI Friend 仍直接访问 HTTP 端口，则 Nginx 到 AI Friend 这一段是明文的。

2. `memory/embeddings.py` 的 `EmbeddingEngine` 没有对端点协议进行校验，允许通过配置注入任意 HTTP/HTTPS 端点。如果攻击者通过篡改 `config.json` 将端点指向外部 HTTP 服务，嵌入文本将被明文传输到互联网。

**风险**：用户对话文本在局域网或容器网络中明文传输，存在隐私泄露风险。

**建议**：
- 将默认值改为 `https://localhost:8080/v1/embeddings`，并在文档中说明如何为 `llama-server` 配置 TLS（如使用自签名证书）。
- 在 `EmbeddingEngine.__init__` 中增加协议校验：若端点使用 `http://` 且主机非 `localhost`/`127.0.0.1`，打印安全警告。

---

### 二、请求超时配置

#### 【中危-2】LLM API 超时 180 秒过长，无分层超时策略

**文件**：`D:\桌面\编程作品\AI朋友\config.py`，第 14 行；`core/provider.py`，第 16、91 行

```python
# config.py
api_timeout: int = 180

# core/provider.py
self.timeout = timeout  # 默认 180
resp = self.session.post(url, json=payload, stream=True, timeout=self.timeout)
```

**问题分析**：

1. 180 秒的超时时间对于 HTTP 请求来说过长。在正常的 DeepSeek API 调用中，即使是复杂的推理任务，首次响应字节（TTFB）通常也在 10-30 秒内。180 秒的超时意味着如果 API 端出现网络分区、服务降级或连接挂死，应用将在 3 分钟后才意识到问题并抛出异常。

2. 更关键的是，当前使用的是单一超时值，没有实现**分层超时策略**（connect timeout / read timeout / total timeout）。`requests` 库的 `timeout` 参数支持元组 `(connect_timeout, read_timeout)`，但当前只传入了单个整数。这意味着：
   - TCP 连接建立阶段可能耗时极长（如目标 IP 不可达但未被 RST 时），消耗整个 180 秒配额。
   - 流式响应中，如果服务器每隔 179 秒发送一个字节（保持连接活跃），请求将永远不会超时，形成**慢速攻击（Slowloris-style attack）**的客户端等价物。

3. 在 Web 模式下，如果多个并发请求同时遭遇 API 延迟，每个请求都占用一个线程（通过 `run_in_executor`）长达 3 分钟，线程池将迅速耗尽，导致服务拒绝响应。

**风险**：服务可用性下降、线程资源耗尽、慢速响应攻击。

**建议**：
- 将默认超时拆分为 `(10, 60)`：连接 10 秒，读取 60 秒。
- 对于流式响应，增加**每字节超时**机制：如果在 30 秒内没有收到任何数据，主动断开连接。
- 在 `Config` 中增加 `api_connect_timeout` 和 `api_read_timeout` 两个独立配置项。

---

#### 【低危-1】AnySearch API 超时 30 秒合理，但无重试机制

**文件**：`D:\桌面\编程作品\AI朋友\tools\web_tools.py`，第 30 行

```python
resp = session.post(ANYSEARCH_ENDPOINT, json=payload, headers=headers, timeout=30)
```

**问题分析**：

30 秒的超时对于搜索 API 是合理的，但 `_anysearch_api()` 函数没有任何重试逻辑。如果 AnySearch 服务出现瞬时网络抖动或 503 错误，`web_search` 和 `web_fetch` 工具将直接失败，影响用户体验。

**风险**：工具可用性降低，偶发性网络故障导致功能中断。

**建议**：
- 为 `_anysearch_api()` 增加指数退避重试（最多 3 次），仅对 `ConnectionError` 和 5xx HTTP 错误重试，不对 4xx 重试。

---

### 三、重定向跟随策略

#### 【中危-3】未限制重定向次数，存在重定向循环和协议降级风险

**文件**：`D:\桌面\编程作品\AI朋友\core\provider.py`，第 87-92 行；`tools\web_tools.py`，第 30 行；`memory\embeddings.py`，第 31-35 行

**问题分析**：

1. `requests` 库默认允许最多 30 次重定向（`requests.defaults.DEFAULT_REDIRECT_LIMIT = 30`）。当前代码没有显式设置 `allow_redirects` 或 `max_redirects`，这意味着：
   - 如果 DeepSeek API 或 AnySearch API 的域名被劫持，攻击者可以构造一个无限重定向链（如 `A -> B -> A -> B ...`），虽然 `requests` 会在 30 次后停止，但在此之前已经消耗了大量时间和网络资源。
   - 更危险的是**协议降级重定向**：HTTPS 端点返回 301/302 重定向到 HTTP 端点。`requests` 默认会跟随这种重定向，导致后续通信变为明文传输。虽然 DeepSeek API 不太可能这样做，但嵌入引擎（`llama-server`）或 AnySearch 的替代端点可能存在此风险。

2. `tools/web_tools.py` 中的 `_anysearch_api()` 每次调用创建新的 `Session`，没有复用连接池，也没有配置重定向策略。如果 AnySearch 的 MCP 端点发生域名变更或负载均衡重定向，工具将无限制跟随。

**风险**：重定向循环导致资源耗尽；协议降级导致明文传输；钓鱼攻击通过重定向窃取请求内容。

**建议**：
- 在所有 `session.post()` 和 `session.get()` 调用中显式设置 `allow_redirects=True`（文档化意图）并限制重定向次数：
  ```python
  self.session.max_redirects = 5  # 在 Session 级别限制
  ```
- 实现重定向钩子（`hooks={'response': hook}`），检测协议降级（HTTPS -> HTTP）并抛出安全异常。

---

### 四、代理设置（trust_env=False 的影响）

#### 【低危-2】`trust_env=False` 正确阻止了环境变量代理，但导致合法代理无法配置

**文件**：`D:\桌面\编程作品\AI朋友\core\provider.py`，第 26 行；`tools\web_tools.py`，第 29 行；`memory\embeddings.py`，第 22 行

```python
# core/provider.py
self.session.trust_env = False

# tools/web_tools.py
session.trust_env = False

# memory/embeddings.py
self._session.trust_env = False
```

**问题分析**：

1. 项目规范明确要求使用 `trust_env=False` 以避免 Windows 系统代理环境变量拖慢请求。这是一个正确的安全决策：在 Windows 开发环境中，`HTTP_PROXY`/`HTTPS_PROXY` 环境变量可能被企业策略或恶意软件设置，导致流量被重定向到不可信的代理服务器。

2. 然而，`trust_env=False` 的副作用是**完全禁用了代理配置**。在企业网络或某些国家/地区的网络环境中，访问外部 API（如 DeepSeek、AnySearch）必须通过企业代理。当前代码没有提供任何替代配置途径，导致这些环境中应用完全无法工作。

3. 三个网络模块（`KimiProvider`、`_anysearch_api`、`EmbeddingEngine`）各自独立设置 `trust_env=False`，缺乏统一的代理配置策略。如果未来需要支持代理，需要修改三个不同的文件。

**风险**：企业环境部署失败；开发者被迫修改源码或临时关闭 `trust_env=False`，引入安全风险。

**建议**：
- 在 `Config` 中增加代理配置项：
  ```python
  http_proxy: str = ""
  https_proxy: str = ""
  ```
- 在 `KimiProvider`、`_anysearch_api`、`EmbeddingEngine` 中统一读取配置，显式设置代理：
  ```python
  if cfg.http_proxy:
      self.session.proxies = {"http": cfg.http_proxy, "https": cfg.https_proxy or cfg.http_proxy}
  ```
- 这样既能阻止未授权的环境变量代理，又能支持显式配置的合法代理。

---

### 五、请求头注入风险

#### 【中危-4】`Authorization` 头通过 f-string 拼接，无编码校验

**文件**：`D:\桌面\编程作品\AI朋友\core\provider.py`，第 27-30 行；`tools\web_tools.py`，第 19-21 行

```python
# core/provider.py
self.session.headers.update({
    "Authorization": f"Bearer {api_key}",
    "Content-Type": "application/json",
})

# tools/web_tools.py
headers = {"Content-Type": "application/json"}
if api_key:
    headers["Authorization"] = f"Bearer {api_key}"
```

**问题分析**：

1. API Key 通过 f-string 直接拼接到 `Authorization` 头中。如果 `api_key` 包含换行符（`\n`）、回车符（`\r`）或其他 HTTP 头非法字符，将导致**HTTP 头注入攻击（HTTP Header Injection）**。虽然 API Key 通常由字母数字和连字符组成，但如果密钥来自用户输入（如通过 Web 界面配置）或被配置文件篡改，存在注入风险。

2. 更现实的场景是：如果 `api_key` 意外包含空格（如 `"sk-xxx yyy"`），`Bearer` 头的格式将被破坏，可能导致服务器拒绝请求或产生不可预期的行为。

3. `tools/web_tools.py` 中的 `ANYSEARCH_API_KEY` 同样通过 f-string 拼接，且来自 `os.environ.get()`，如果环境变量被恶意设置（如包含 `\r\n` 和伪造的 HTTP 头），攻击者可以注入额外的请求头。

**风险**：HTTP 头注入可导致请求走私、缓存投毒、或向第三方服务器泄露敏感信息。

**建议**：
- 在设置 `Authorization` 头前，对 `api_key` 进行校验：只允许 ASCII 可打印字符（`[ -~]`），拒绝包含 `\r`、`\n`、空格的密钥。
- 使用 `requests` 库的 `PreparedRequest` 机制，让库本身处理头的编码和转义。

---

#### 【低危-3】`User-Agent` 头缺失，不利于安全审计和速率限制协商

**文件**：`D:\桌面\编程作品\AI朋友\core\provider.py`，第 27-30 行

**问题分析**：

`KimiProvider` 的 `session.headers` 只设置了 `Authorization` 和 `Content-Type`，没有设置 `User-Agent`。`requests` 库默认使用 `python-requests/2.x.x` 作为 User-Agent。这导致：
- API 提供商（DeepSeek）无法识别请求来源，不利于问题排查和速率限制协商。
- 如果 DeepSeek 对默认 `python-requests` User-Agent 实施更严格的速率限制，应用将受到影响。
- 从安全审计角度，日志中无法区分这是 AI Friend 的请求还是其他使用 `requests` 的脚本。

**风险**：运维困难、可能被误杀速率限制。

**建议**：
- 设置自定义 User-Agent：
  ```python
  "User-Agent": f"AI-Friend/{VERSION} (https://github.com/orinvoss/ai-friend)"
  ```

---

### 六、SSRF 攻击面（服务器端请求伪造）

#### 【高危-2】`web_fetch` 工具缺乏 URL 协议白名单，可间接访问内部服务

**文件**：`D:\桌面\编程作品\AI朋友\tools\web_tools.py`，第 121-132 行

```python
def execute(self, args: dict[str, Any]) -> ToolResult:
    url = args.get("url", "").strip()
    if not url:
        return ToolResult.fail("请提供URL")
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    logger.info(f"[tool] web_fetch url={url[:80]}")
    try:
        result = _anysearch_api("extract", {"url": url})
```

**问题分析**：

1. 虽然 `web_fetch` 的最终 HTTP 请求是由 AnySearch 服务端发出的（而非 AI Friend 服务器本身），但 URL 的校验逻辑存在严重缺陷：
   - 如果 LLM 输出 `url = "http://localhost:8080/v1/embeddings"`，`startswith` 检查通过，该 URL 将被传递给 AnySearch 的 `extract` API。
   - AnySearch 服务端在抓取该 URL 时，实际上是在执行一次由 AI Friend 用户控制的出站请求。如果 AnySearch 服务端与 AI Friend 部署在同一内网（或 AnySearch 服务端本身有内网访问权限），这构成了**间接 SSRF**：用户通过 AI Friend 诱导 AnySearch 访问内网服务（如 `http://localhost:8080/health`、`http://169.254.169.254/latest/meta-data/` 等）。

2. 更直接的 SSRF 风险在于 `memory/embeddings.py`。虽然当前 `EmbeddingEngine` 的端点是硬编码的 `http://localhost:8080/v1/embeddings`，但如果攻击者能够通过某种方式（如配置文件篡改、prompt injection 诱导 LLM 修改配置）改变端点地址，`EmbeddingEngine` 将直接向攻击者控制的 URL 发送包含用户对话文本的请求。

3. `core/provider.py` 的 `endpoint` 参数来自 `config.py`，如果 `config.json` 被篡改（如 `api_endpoint` 被改为攻击者控制的恶意服务器），所有对话数据（包括系统提示、用户输入、AI 回复）将被发送到第三方服务器。这是一个严重的数据泄露通道。

4. `web/server.py` 的 `/api/chat` 端点没有输入验证和鉴权，任何能够访问 Web 服务的客户端都可以发送消息。虽然这不是直接的 SSRF，但结合 `web_fetch` 工具，攻击者可以构造对话诱导 AI 使用 `web_fetch` 访问恶意 URL，形成**反射型 SSRF 链**。

**风险**：内网服务探测、云元数据服务访问（如 AWS 169.254.169.254）、对话数据泄露到恶意端点。

**建议**：
- **紧急**：在 `WebFetchTool.execute()` 中增加 URL 协议白名单和主机黑名单：
  ```python
  from urllib.parse import urlparse
  parsed = urlparse(url)
  if parsed.scheme not in ("http", "https"):
      return ToolResult.fail(f"不支持的协议: {parsed.scheme}")
  blocked_hosts = {"localhost", "127.0.0.1", "0.0.0.0", "::1", "169.254.169.254"}
  if parsed.hostname in blocked_hosts:
      return ToolResult.fail("禁止访问内部地址")
  ```
- 在 `load_config()` 中校验 `api_endpoint` 和 `embedding_endpoint` 的协议和主机，禁止指向私有 IP 范围（RFC 1918、RFC 4193）和元数据服务地址。
- 考虑在 `KimiProvider` 中硬编码允许的端点域名白名单（如 `api.deepseek.com`），拒绝连接到其他域名。

---

#### 【中危-5】`embedding_endpoint` 可配置为任意 URL，无校验

**文件**：`D:\桌面\编程作品\AI朋友\config.py`，第 40 行；`memory\embeddings.py`，第 16-18 行

```python
# config.py
embedding_endpoint: str = "http://localhost:8080/v1/embeddings"

# memory/embeddings.py
def __init__(self, endpoint: str = "http://localhost:8080/v1/embeddings", ...):
    self._endpoint = endpoint.rstrip("/")
```

**问题分析**：

1. `embedding_endpoint` 是一个完全自由的字符串配置，没有任何协议、主机或路径校验。攻击者可以通过修改 `config.json` 将其设置为 `https://attacker.com/exfil`，导致所有嵌入请求（包含用户对话文本）被发送到攻击者服务器。

2. 虽然修改 `config.json` 需要文件系统访问权限，但如果应用运行在有文件上传漏洞的 Web 服务器上，或 `config.json` 权限设置不当，这一风险是现实的。

3. `EmbeddingEngine.encode()` 发送的请求体包含原始文本：
   ```python
   resp = self._session.post(self._endpoint, json={"input": texts}, timeout=self._timeout)
   ```
   这些文本可能包含敏感信息（用户隐私、密码片段、商业机密），一旦被外泄，后果严重。

**风险**：用户对话文本泄露到第三方服务器。

**建议**：
- 在 `EmbeddingEngine.__init__` 中增加端点校验：
  ```python
  from urllib.parse import urlparse
  parsed = urlparse(endpoint)
  if parsed.scheme not in ("http", "https"):
      raise ValueError("embedding_endpoint must use http or https")
  if parsed.hostname not in ("localhost", "127.0.0.1") and not is_public_ip(parsed.hostname):
      logger.warning(f"Embedding endpoint {endpoint} is not localhost, ensure it is trusted")
  ```
- 在 `Config` 加载时，对 `embedding_endpoint` 和 `api_endpoint` 进行同样的校验。

---

### 七、DNS 重绑定攻击

#### 【中危-6】无 DNS 重绑定防护，内网服务可能被间接访问

**文件**：`D:\桌面\编程作品\AI朋友\tools\web_tools.py`，第 121-132 行；`core\provider.py`，第 87-92 行

**问题分析**：

1. **DNS 重绑定攻击（DNS Rebinding）** 是一种利用浏览器/应用 DNS 缓存策略的攻击方式。攻击者控制一个域名（如 `evil.com`），将其 DNS TTL 设置得非常短（如 1 秒）。当应用第一次解析 `evil.com` 时，DNS 返回一个公网 IP（通过安全检查），应用缓存该解析结果。但在随后的请求中，由于 TTL 过期，应用重新解析 `evil.com`，此时 DNS 返回一个内网 IP（如 `127.0.0.1` 或 `192.168.1.1`），应用将向内网服务发送请求。

2. 虽然 `tools/web_tools.py` 的最终请求是由 AnySearch 服务端发出的，AI Friend 本身不直接解析 `web_fetch` 的 URL，但如果 AnySearch 服务端没有 DNS 重绑定防护，攻击者可以通过 AI Friend 诱导 AnySearch 访问 `evil.com`，从而间接攻击 AnySearch 的内网。

3. 更直接的威胁在 `core/provider.py`。如果攻击者能够控制 `config.json` 中的 `api_endpoint`（如将其设为 `https://evil.com`），`KimiProvider` 在首次连接时解析到公网 IP，但在重试时（`ConnectionError` 后等待并重试），DNS 缓存可能已过期，第二次连接将指向内网 IP。虽然这种攻击需要精确的时间窗口控制，但在理论上可行。

4. `memory/embeddings.py` 同样面临此风险：如果 `embedding_endpoint` 被设为恶意域名，DNS 重绑定可将嵌入请求重定向到内网服务。

**风险**：绕过主机黑名单检查，访问内网服务；结合 SSRF 实现内网渗透。

**建议**：
- 对于 `api_endpoint` 和 `embedding_endpoint`，在配置加载时解析 DNS 并缓存 IP 地址，后续请求直接使用缓存的 IP，不再重新解析。
- 对于 `web_fetch` 的 URL，在传入 AnySearch 前，在 AI Friend 端进行预解析，拒绝解析到私有 IP 范围的域名。
- 实现**双重解析检查**：在请求前和请求时各解析一次域名，如果两次结果不同（且涉及公网到内网的切换），拒绝请求。

---

### 八、请求内容类型和编码安全

#### 【低危-4】`Content-Type: application/json` 正确，但无字符集声明

**文件**：`D:\桌面\编程作品\AI朋友\core\provider.py`，第 29 行；`tools\web_tools.py`，第 19 行

```python
"Content-Type": "application/json"
```

**问题分析**：

1. 当前所有 JSON 请求都正确设置了 `Content-Type: application/json`，但没有指定字符集（如 `application/json; charset=utf-8`）。虽然 RFC 8259 规定 JSON 默认使用 UTF-8，但某些服务器实现可能依赖 `charset` 参数进行解码。缺少字符集声明在极少数情况下可能导致编码问题。

2. `requests` 库的 `json=` 参数会自动将 Python 对象序列化为 UTF-8 编码的 JSON 字符串，并设置 `Content-Type: application/json`，但不会添加 `charset=utf-8`。这在绝大多数场景下没有问题，属于低危建议项。

**风险**：极低，仅在某些非标准服务器实现中可能出现编码问题。

**建议**：
- 显式设置 `Content-Type: application/json; charset=utf-8`，明确编码意图。

---

#### 【低危-5】流式响应解析缺乏内容类型校验

**文件**：`D:\桌面\编程作品\AI朋友\core\provider.py`，第 107-126 行

```python
for line in resp.iter_lines(decode_unicode=True):
    if not line:
        continue
    if line.startswith("data: "):
        data_str = line[6:]
        ...
```

**问题分析**：

1. `_do_request` 在解析流式响应时，没有先检查响应的 `Content-Type` 头。如果服务器因错误返回了 `text/html`（如 502 Bad Gateway 页面）或 `application/json`（非流式格式），代码将尝试按 SSE（Server-Sent Events）格式解析，导致大量 `JSONDecodeError` 被静默忽略（第 125-126 行）。

2. 更严重的是，如果服务器返回的是恶意构造的 HTML（如包含 XSS payload 的错误页面），虽然当前代码不会渲染 HTML，但错误页面内容可能通过日志或异常信息泄露到系统日志中。

**风险**：错误响应格式导致资源浪费；错误页面内容可能污染日志。

**建议**：
- 在解析流式响应前，校验 `Content-Type` 是否为 `text/event-stream` 或至少以 `text/` 开头：
  ```python
  if not resp.headers.get("Content-Type", "").startswith("text/event-stream"):
      logger.warning(f"Unexpected content type: {resp.headers.get('Content-Type')}")
      # 回退到非流式解析
  ```

---

### 九、响应大小限制

#### 【中危-7】流式响应无总大小限制，可能导致内存耗尽

**文件**：`D:\桌面\编程作品\AI朋友\core\provider.py`，第 107-128 行

```python
full_response = []
for line in resp.iter_lines(decode_unicode=True):
    ...
    full_response.append(token)
...
content = "".join(full_response)
```

**问题分析**：

1. 流式响应解析循环中，`full_response` 列表会无限增长，直到服务器发送 `[DONE]` 或连接断开。如果 DeepSeek API 因故障或恶意攻击（如 API 密钥泄露后被滥用）返回了超大响应（如数百万 token），应用将耗尽可用内存并崩溃。

2. 虽然 DeepSeek API 有 `max_tokens` 参数限制输出长度，但这一限制是在服务器端的。如果服务器端限制失效（如 bug、配置错误），或被攻击者通过其他方式绕过，客户端没有任何防护措施。

3. 在 Web 模式下，如果多个并发请求同时遭遇超大响应，内存耗尽将导致整个服务崩溃（OOM Killer），影响所有用户。

4. `tools/web_tools.py` 的 `_anysearch_api()` 同样没有响应大小限制：`resp.json()` 会将整个响应加载到内存中。如果 AnySearch 返回了超大 JSON（如包含数百万搜索结果的恶意响应），将导致内存耗尽。

**风险**：内存耗尽（OOM）、服务拒绝（DoS）、进程崩溃。

**建议**：
- 在流式响应解析中增加累计大小限制：
  ```python
  MAX_STREAM_SIZE = 1024 * 1024  # 1MB
  total_size = 0
  for line in resp.iter_lines(decode_unicode=True):
      total_size += len(line) if line else 0
      if total_size > MAX_STREAM_SIZE:
          logger.error("Stream response exceeded max size, aborting")
          raise ConnectionError("Response too large")
      ...
  ```
- 为非流式响应（`resp.json()`）设置最大内容长度：
  ```python
  if len(resp.content) > MAX_RESPONSE_SIZE:
      raise ConnectionError("Response too large")
  ```
- 将 `MAX_STREAM_SIZE` 和 `MAX_RESPONSE_SIZE` 作为 `Config` 的可配置项。

---

#### 【低危-6】`web_fetch` 返回内容截断 8000 字符，但无原始大小记录

**文件**：`D:\桌面\编程作品\AI朋友\tools\web_tools.py`，第 140 行

```python
return ToolResult.ok(f"{header}:\n```\n{content[:8000]}\n```")
```

**问题分析**：

1. `web_fetch` 将返回内容截断为 8000 字符，这是一个合理的限制（防止 prompt 过长）。但截断操作是静默的——输出中没有告知用户 "内容已截断"。Agent 3 可能基于不完整的内容做出错误判断。

2. 更重要的是，截断发生在 AnySearch 返回内容之后。如果 AnySearch 返回了超大页面（如数十 MB 的网页），`content` 变量在截断前已经占用了大量内存。虽然 AnySearch 服务端应该有自己的大小限制，但客户端不应依赖服务端的安全措施。

**风险**：Agent 基于不完整信息做出错误决策；大页面短暂占用内存。

**建议**：
- 截断时添加提示：
  ```python
  truncated = len(content) > 8000
  suffix = "\n...(内容已截断，共 {len(content)} 字符)" if truncated else ""
  return ToolResult.ok(f"{header}:\n```\n{content[:8000]}{suffix}\n```")
  ```
- 在 AnySearch 调用前，增加对 `extract` API 返回大小的预期限制（如通过 API 参数请求最大 10000 字符）。

---

### 十、其他网络相关发现

#### 【中危-8】`KimiProvider` 的 `requests.Session` 无连接池限制，高并发下资源耗尽

**文件**：`D:\桌面\编程作品\AI朋友\core\provider.py`，第 25-26 行

```python
self.session = requests.Session()
self.session.trust_env = False
```

**问题分析**：

1. 每个 `KimiProvider` 实例创建一个 `requests.Session`，默认使用 `HTTPAdapter` 的连接池（`pool_connections=10, pool_maxsize=10`）。在 Web 模式下，每个会话创建一个 `WebAgent`，每个 `WebAgent` 创建一个 `KimiProvider`。如果 `SessionManager` 中同时存在 50 个活跃会话，总连接池大小将达到 500。

2. 更严重的是，`WebAgent` 被移除后（如用户断开连接），`KimiProvider` 和 `requests.Session` 没有被显式关闭（`session.close()`），连接池中的 TCP 连接保持打开直到超时（默认 `keep-alive` 超时）。这导致连接泄漏，在高并发场景下可能耗尽文件描述符。

3. `tools/web_tools.py` 的 `_anysearch_api()` 每次调用都创建新的 `requests.Session()`，完全不利用连接池复用。频繁的搜索/提取操作将创建大量短连接，增加延迟和系统开销。

**风险**：TCP 连接耗尽、文件描述符耗尽、服务性能下降。

**建议**：
- 在 `WebAgent` 销毁时调用 `self.provider.session.close()`。
- 将 `_anysearch_api()` 的 `Session` 提升为模块级单例，复用连接池。
- 考虑为 `KimiProvider` 配置连接池大小限制：
  ```python
  from requests.adapters import HTTPAdapter
  adapter = HTTPAdapter(pool_connections=5, pool_maxsize=10)
  self.session.mount("https://", adapter)
  ```

---

#### 【低危-7】JSON-RPC `id` 固定为 1，不符合规范且无请求关联能力

**文件**：`D:\桌面\编程作品\AI朋友\tools\web_tools.py`，第 22-27 行

```python
payload = {
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {"name": tool_name, "arguments": arguments},
}
```

**问题分析**：

JSON-RPC 2.0 规范要求 `id` 字段在每次请求中唯一，以便客户端将响应与请求关联。当前硬编码 `id: 1` 违反了规范，虽然 AnySearch 的 MCP 端点可能是无状态的单向调用，但如果未来需要支持批量请求或异步回调，固定的 `id` 将导致响应无法匹配。

从安全角度，固定的 `id` 使得请求更容易被重放攻击（Replay Attack）识别和利用。

**风险**：规范不符合；重放攻击风险轻微增加。

**建议**：
- 使用递增整数或 UUID 生成 `id`：
  ```python
  import uuid
  "id": str(uuid.uuid4())
  ```

---

#### 【低危-8】`web_search` 的 `freshness` 参数未校验 enum 值

**文件**：`D:\桌面\编程作品\AI朋友\tools\web_tools.py`，第 72-84 行

```python
freshness = args.get("freshness", "").strip() or None
...
if freshness:
    arguments["freshness"] = freshness
```

**问题分析**：

`parameters_schema()` 中定义了 `enum: ["day", "week", "month", "year"]`，但 `execute()` 没有校验传入值。LLM 可能输出 `"freshness": "today"`，该值将直接传递给 AnySearch API，可能导致 API 返回 400 错误。虽然这不是直接的安全漏洞，但属于输入验证缺失，可能被利用进行 API 错误探测（Error-based probing）。

**风险**：API 错误率上升；轻微的攻击面暴露。

**建议**：
- 增加 enum 校验，非法值时忽略或返回失败：
  ```python
  VALID_FRESHNESS = {"day", "week", "month", "year"}
  if freshness and freshness not in VALID_FRESHNESS:
      return ToolResult.fail(f"无效的时效性参数: {freshness}")
  ```

---

## 汇总统计

### 风险分级

| 级别 | 数量 | 编号 | 说明 |
|------|------|------|------|
| **高危** | 2 | 高危-1、高危-2 | SSL/TLS 依赖隐式默认值（无证书固定）；`web_fetch` 缺乏 URL 白名单（SSRF） |
| **中危** | 7 | 中危-1~中危-8 | 嵌入引擎明文传输；超时过长无分层；重定向无限制；头注入风险；`embedding_endpoint` 无校验；DNS 重绑定无防护；流式响应无大小限制；连接池无限制 |
| **低危** | 6 | 低危-1~低危-8 | AnySearch 无重试；代理无法配置；User-Agent 缺失；Content-Type 无 charset；流式响应无类型校验；截断无提示；JSON-RPC id 固定；freshness 未校验 |

### 核心问题地图

```
网络请求安全
├── SSL/TLS
│   ├── [高危] 依赖隐式 verify=True，无证书固定
│   └── [中危] 嵌入引擎默认 HTTP 明文传输
├── 请求超时
│   ├── [中危] 180s 单一超时，无分层策略
│   └── [低危] AnySearch 30s 无重试
├── 重定向
│   └── [中危] 未限制重定向次数，存在协议降级风险
├── 代理配置
│   └── [低危] trust_env=False 正确但完全阻断合法代理
├── 请求头安全
│   ├── [中危] Authorization 头 f-string 拼接，无编码校验
│   └── [低危] User-Agent 缺失
├── SSRF 攻击面
│   ├── [高危] web_fetch URL 无协议/主机白名单
│   └── [中危] embedding_endpoint / api_endpoint 可配置为任意 URL
├── DNS 重绑定
│   └── [中危] 无 DNS 缓存和双重解析检查
├── 内容类型/编码
│   ├── [低危] Content-Type 无 charset 声明
│   └── [低危] 流式响应未校验 Content-Type
└── 响应大小限制
    ├── [中危] 流式响应无总大小限制，可 OOM
    └── [低危] web_fetch 截断无提示，大页面先全量加载
```

### 修复优先级建议

**P0（立即修复）**：
1. `tools/web_tools.py` 第 127-128 行：为 `web_fetch` 增加 URL 协议白名单和主机黑名单，防御 SSRF。
2. `core/provider.py` 第 87-92 行：显式设置 `verify=True`，并在 `Config` 中增加 `ssl_ca_bundle` 配置项。
3. `config.py` 第 40 行：将 `embedding_endpoint` 默认值改为 HTTPS，并增加端点校验逻辑。

**P1（本周修复）**：
4. `core/provider.py` 第 91 行：将超时拆分为 `(connect_timeout, read_timeout)`，默认值 `(10, 60)`。
5. `core/provider.py` 第 25-26 行：为 `requests.Session` 配置连接池大小限制，并在 `WebAgent` 销毁时关闭 session。
6. `core/provider.py` 第 27-30 行：对 `api_key` 进行字符校验，设置自定义 `User-Agent`。
7. `tools/web_tools.py` 第 28-30 行：将 `_anysearch_api()` 的 Session 提升为模块级单例，增加重试逻辑。
8. `memory/embeddings.py` 和 `core/provider.py`：增加响应大小限制（流式 1MB，非流式 10MB）。

**P2（本月修复）**：
9. `config.py`：增加 `http_proxy`/`https_proxy` 配置项，在禁用环境变量代理的同时支持显式代理。
10. `core/provider.py` 和 `memory/embeddings.py`：实现 DNS 解析缓存和双重解析检查，防御 DNS 重绑定。
11. `core/provider.py` 第 107-126 行：流式响应解析前校验 `Content-Type`。
12. `tools/web_tools.py` 第 22-27 行：使用 UUID 替代固定的 JSON-RPC `id`。

**P3（技术债务）**：
13. 考虑实现证书固定机制，将 DeepSeek 和 AnySearch 的公钥指纹硬编码。
14. 为所有网络请求增加统一的追踪 ID 和耗时统计，提升可观测性。
15. 引入 `httpx` 替代 `requests`，利用其原生异步支持和更精细的超时控制。

---

*报告生成时间：2026-05-31*  
*审查工具：Claude Code 深度代码审查*  
*关联文档：doc/round01-web-layer.md、doc/round01-tools-layer.md、doc/round01-config-management.md、doc/round01-entry-points.md、doc/round01-memory-system.md、doc/round01-ui-layer.md*
