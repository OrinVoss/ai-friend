# AI Friend 长期记忆与检索数据流深度审查报告（Round 02）

**审查日期**：2026-05-31
**审查范围**：`memory/long_term.py`、`memory/retrieval.py`、`storage/repository.py`、`models/memory.py`、`memory/embeddings.py`、`memory/consolidation.py`、`prompts/templates.py`、`prompts/system.py`、`tools/memory_tools.py`、`core/inner_drive.py`、`core/agent.py`、`core/cli_controller.py`、`core/message_handler.py`
**审查目标**：跟踪记忆从存储到三层检索再到上下文构建的完整数据流，识别信息丢失、性能瓶颈、一致性问题

---

## 一、概述

AI Friend 的长期记忆系统采用三层检索架构（Layer 1 Hot Memory + Layer 2 Hybrid Search + Layer 3 On-demand Recall），支撑 Agent 1（InnerDrive）、Agent 2（ToolAgent）和 Agent 3（Roleplay）的完整决策链。本报告聚焦**数据流**视角——从用户输入触发检索，到 MemoryContext 注入 prompt，再到记忆写入和剪枝的全生命周期。

核心发现：

1. **数据流存在多处断裂和短路**：Layer 2 的语义搜索在事实检索中仅对候选池做重排，未直接查询向量数据库；Layer 3 的 `[回忆:]` 语法触发路径与主检索路径完全隔离。
2. **composite_score 语义混乱**：数据库持久化值、内存临时计算值、prune 排序值三者混用同一字段名，导致评分逻辑不可预测。
3. **embedding 覆盖不完整**：仅 facts 和 experiences 有 embedding 列，reflections 虽有列但检索时从未使用语义搜索；且 embedding 生成是异步后台任务，与写入不同步。
4. **检索结果去重机制缺失**：facts 无去重，experiences 仅在合并 recent + keyword 时做 ID 去重，但语义搜索与关键词搜索的重复体验未被处理。
5. **性能瓶颈集中在数据库查询模式**：全表扫描 + LIKE 模糊匹配，无索引；embedding 批量生成在 consolidation 时同步执行，可能阻塞主线程。

---

## 二、数据流图

### 2.1 完整检索数据流（主路径）

```
用户输入
    │
    ▼
┌─────────────────────────────────────────────────────────────────────┐
│  Agent 1: InnerDrive.assess()                                       │
│  Agent 3: MessageHandler._run_agent3()                              │
│  CLI: CliController._on_perceive()                                  │
│  ── 均调用 retriever.retrieve_for_query(query) ──                  │
└─────────────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────────────┐
│  MemoryRetriever.retrieve_for_query(query)                          │
│  memory/retrieval.py:27-69                                          │
└─────────────────────────────────────────────────────────────────────┘
    │
    ├──▶ Layer 1: Hot Memory（始终包含）
    │    ├── get_all_active_facts(limit=50)  ──▶  repo.get_active_facts()
    │    │                                          storage/repository.py:90-99
    │    │                                          SELECT * FROM user_facts
    │    │                                          WHERE is_active=1
    │    │                                          ORDER BY composite_score DESC,
    │    │                                                   recall_count DESC
    │    │                                          LIMIT 50
    │    │
    │    ├── get_recent_experiences(limit=5) ──▶  repo.get_recent_experiences()
    │    │                                          storage/repository.py:151-159
    │    │                                          ORDER BY created_at DESC
    │    │
    │    └── get_recent_reflections(limit=3) ──▶  repo.get_recent_reflections()
    │                                               storage/repository.py:180-187
    │                                               ORDER BY created_at DESC
    │
    ├──▶ Layer 2: Hybrid Search（条件触发）
    │    │
    │    ├── 事实检索分支
    │    │    ├── IF embed.health_check():
    │    │    │      _hybrid_score(query, hot_facts, keywords)
    │    │    │      memory/retrieval.py:106-134
    │    │    │      ├─ 对 Layer 1 已取出的 50 条 facts 做语义重排
    │    │    │      ├─ query_vec = embed.encode_single(query)
    │    │    │      ├─ 对每个 fact: semantic = dot(vec, query_vec)
    │    │    │      ├─ keyword = _keyword_score_single()
    │    │    │      └─ final = semantic*0.6 + keyword*0.4
    │    │    │      取 top 30
    │    │    │
    │    │    └── ELSE:
    │    │           _score_facts(hot_facts, keywords, query)
    │    │           memory/retrieval.py:194-202
    │    │           ├─ 原地修改 f.composite_score（不写回DB）
    │    │           └─ 按 composite_score 排序
    │    │
    │    ├── LLM 重排（条件触发）
    │    │    IF len(candidates) > 15 AND llm_rerank_fn exists:
    │    │       _llm_rerank(query, candidates)
    │    │       memory/retrieval.py:204-225
    │    │       ├─ 构造 MEMORY_RERANK_PROMPT
    │    │       ├─ 调用 llm_rerank_fn(prompt)
    │    │       └─ 解析逗号分隔的序号
    │    │    取 top 15（max_candidates）
    │    │
    │    └── 最终选择：selected_facts = candidates[:10]
    │
    ├──▶ 体验检索分支
    │    ├── IF embed.health_check():
    │    │      _search_experiences_semantic(query, recent, keywords)
    │    │      memory/retrieval.py:136-161
    │    │      ├─ 先关键词搜索：search_experiences(keywords, limit=15)
    │    │      ├─ 合并 recent_experiences（_merge_unique_experiences）
    │    │      ├─ 对合并后的列表做语义重排
    │    │      └─ 取 top 5
    │    │
    │    └── ELSE:
    │          search_experiences(keywords, limit=5)
    │          storage/repository.py:128-149
    │          ├─ LIKE 匹配 summary 和 tags
    │          └─ ORDER BY composite_score DESC, created_at DESC
    │
    ├──▶ 体验合并去重
    │    _merge_unique_experiences(keyword_experiences, recent_experiences)
    │    memory/retrieval.py:228-236
    │    └─ 按 ID 去重，保留首次出现顺序
    │
    └──▶ 组装 MemoryContext
         MemoryContext(
             facts=selected_facts[:10],
             experiences=all_experiences[:5],
             reflections=reflections[:3],
             relationship=relationship,
         )
         models/conversation.py:18-24
```

### 2.2 记忆写入数据流（Consolidation 路径）

```
对话轮次累积
    │
    ▼
┌─────────────────────────────────────────────────────────────────────┐
│  MemoryConsolidator.consolidate()                                   │
│  memory/consolidation.py:47-81                                      │
│  触发条件：turn_count % interval == 0 / emotional_intensity > 0.7  │
│            / pending_buffer >= 10 / idle > 120s                    │
└─────────────────────────────────────────────────────────────────────┘
    │
    ├──▶ Step 1: 提取事实
    │    _extract_facts(turn_text)
    │    ├─ LLM 生成 FACT|category|key|value|confidence|importance
    │    └─ ltm.store_fact() ──▶ repo.upsert_fact()
    │         storage/repository.py:34-68
    │         ├─ ON CONFLICT(category, fact_key) DO UPDATE
    │         ├─ confidence = MAX(old, new)
    │         ├─ importance = MAX(old, new)
    │         └─ recall_count = recall_count + 1  ← 每次 upsert 都 +1
    │
    ├──▶ Step 2: 总结体验
    │    _summarize_experience(turn_text, short_term)
    │    ├─ LLM 生成 SUMMARY/TONE/SIGNIFICANCE/IMPORTANCE/TAGS
    │    └─ ltm.store_experience() ──▶ repo.insert_experience()
    │         storage/repository.py:113-126
    │         └─ 纯 INSERT，无冲突处理
    │
    ├──▶ Step 3: 生成反思
    │    _generate_reflection(personality)
    │    ├─ 检索最近 5 条 experiences + 3 条 reflections + 10 条 facts
    │    ├─ LLM 生成 TYPE/CONTENT/SIGNIFICANCE/RELATED_EXPERIENCES
    │    └─ ltm.store_reflection() ──▶ repo.insert_reflection()
    │         storage/repository.py:168-178
    │         └─ 纯 INSERT，无冲突处理
    │
    ├──▶ Step 4: 更新关系
    │    _update_relationship(personality)
    │    └─ 基于情感分析更新 trust/familiarity/intimacy
    │
    ├──▶ Step 5: 剪枝
    │    _prune(max_facts, max_experiences, max_reflections)
    │    ├─ prune_facts: ORDER BY composite_score ASC, recall_count ASC
    │    ├─ prune_experiences: ORDER BY composite_score ASC, created_at ASC
    │    └─ prune_reflections: ORDER BY significance ASC, created_at ASC
    │
    └──▶ Step 5.5: 批量生成 Embedding
         _embed_new_items()
         memory/consolidation.py:255-297
         ├─ 查询 embedding IS NULL 的记录（每表最多 50 条）
         ├─ 拼接文本列（category+key+value / summary+tone+tags / content）
         ├─ embed.encode(texts) ──▶ llama-server API
         └─ repo.bulk_update_embeddings(table, updates)
              storage/repository.py:189-197
```

### 2.3 Layer 3 On-demand 数据流（独立路径）

```
用户输入 / AI 回复
    │
    ▼
┌─────────────────────────────────────────────────────────────────────┐
│  MemoryRetriever.retrieve_by_recall_tag(text)                       │
│  memory/retrieval.py:71-95                                          │
│  触发条件：文本中包含 "[回忆: xxx]" 语法                            │
└─────────────────────────────────────────────────────────────────────┘
    │
    ├──▶ 正则提取 query = m.group(1).strip()
    ├──▶ keywords = _extract_keywords(query)
    ├──▶ facts = search_facts(query, limit=5)     ← 直接 LIKE 查询
    ├──▶ experiences = search_experiences(keywords, limit=3)
    ├──▶ reflections = get_recent_reflections(limit=2)
    │
    └──▶ 格式化为自然语言文本返回（非 MemoryContext）
         ├─ "关于用户："
         ├─ "相关回忆："
         └─ "相关反思："
```

---

## 三、详细发现

### 3.1 Layer 1（Hot Memory）检索实现分析

#### 3.1.1 facts 的 Hot Memory 查询模式

**代码位置**：`storage/repository.py:90-99`

```python
async def get_active_facts(self, limit: int = 50) -> list[UserFact]:
    await c.execute("""
        SELECT * FROM user_facts
        WHERE is_active = 1
        ORDER BY composite_score DESC, recall_count DESC
        LIMIT ?
    """, (limit,))
```

**分析**：

Layer 1 的 "Hot Memory" 概念在代码中被实现为"所有活跃事实按 composite_score 降序取前 50"。这与架构文档中"高评分事实 + 近期体验 + 反思"的描述基本一致，但存在以下问题：

1. **无时间衰减因子**：`composite_score` 在数据库中默认值为 1.0（`user_facts`）或 0.5（`experiences`），且没有任何机制根据时间推移自动降低。一条 100 轮前写入的 fact 如果未被剪枝，其 composite_score 可能仍然是 1.0，与刚写入的 fact 同等竞争。

2. **`recall_count` 语义错误**：`recall_count` 的设计意图可能是"被检索次数"，但在 `upsert_fact` 中（`repository.py:50`），每次冲突更新时都会 `recall_count = recall_count + 1`。这意味着 `recall_count` 实际上是"写入/更新次数"，而非"被回忆次数"。在 `get_active_facts` 的 `ORDER BY` 中，`recall_count DESC` 会让频繁更新的事实排在前面——这可能与预期相反（频繁更新可能意味着该事实不稳定或临时）。

3. **全表扫描风险**：`user_facts` 表在 `is_active` 和 `composite_score` 上无索引。虽然 SQLite 能利用 `is_active` 列的稀疏性做部分优化，但随着数据量增长（上限 200 条），全表扫描成本会逐渐显现。

**风险评级**：中

#### 3.1.2 experiences 的 Hot Memory 查询模式

**代码位置**：`storage/repository.py:151-159`

```python
async def get_recent_experiences(self, limit: int = 5) -> list[Experience]:
    await c.execute("""
        SELECT * FROM experiences
        WHERE is_archived = 0
        ORDER BY created_at DESC
        LIMIT ?
    """)
```

**分析**：

experiences 的 Layer 1 仅按时间排序，完全不考虑 `composite_score` 或 `significance`。这与 facts 的排序逻辑不一致。如果某条早期体验非常重要（高 significance），但近期产生了大量普通体验，这条重要体验将永远不会出现在 Layer 1 中。

**建议**：统一 Hot Memory 的排序逻辑，引入 `significance` 和 `composite_score` 的加权排序，或至少保留一个"重要体验"的快捷通道。

**风险评级**：低

#### 3.1.3 reflections 的 Hot Memory 查询模式

**代码位置**：`storage/repository.py:180-187`

```python
async def get_recent_reflections(self, limit: int = 5) -> list[Reflection]:
    await c.execute("""
        SELECT * FROM reflections WHERE is_active = 1
        ORDER BY created_at DESC
        LIMIT ?
    """)
```

**分析**：

reflections 与 experiences 类似，仅按时间排序。但 reflections 有一个独特问题：`Reflection` 模型（`models/memory.py:38-45`）**没有 `composite_score` 字段**，而数据库表（`storage/database.py:86-94`）也没有该列。这意味着 reflections 完全没有评分机制，无法区分重要反思和随口思考。

**风险评级**：低

---

### 3.2 Layer 2（语义/向量）检索实现分析

#### 3.2.1 事实的 Hybrid Score 实现

**代码位置**：`memory/retrieval.py:106-134`

```python
def _hybrid_score(self, query: str, candidates: list, keywords: list) -> list:
    SEMANTIC_WEIGHT = 0.6
    KEYWORD_WEIGHT = 0.4
    query_vec = self._embed.encode_single(query)
    # ...
    for c in candidates:
        semantic = 0.0
        if hasattr(c, 'embedding') and c.embedding is not None:
            vec = EmbeddingEngine.bytes_to_vec(bytes(c.embedding))
            semantic = float(np.dot(vec, query_vec))
        keyword = self._keyword_score_single(c, keywords, query)
        final = semantic * SEMANTIC_WEIGHT + keyword * KEYWORD_WEIGHT
```

**分析**：

1. **候选池受限**：`_hybrid_score` 的输入 `candidates` 来自 Layer 1 的 `get_all_active_facts(limit=50)`。这意味着语义搜索**仅在 50 条活跃事实中进行重排**，而非全表语义检索。如果某条语义相关的事实因 composite_score 低而未进入前 50，即使语义相似度极高，也永远不会被召回。

2. **embedding 可能为 NULL**：`consolidation.py` 的 `_embed_new_items()` 是异步后台任务，在 fact 写入后可能延迟执行。在 embedding 生成前，事实的 `embedding` 列为 NULL，`_hybrid_score` 中 `semantic = 0.0`，这些事实完全依赖关键词评分（0.4 权重），处于劣势。

3. **未使用 embedding 索引**：当前实现将所有候选的 embedding 从数据库读出后在 Python 中逐条计算点积。对于 50 条候选这没有问题，但如果未来扩大候选池，这种 O(N) 的逐条计算将成为瓶颈。应考虑使用向量索引（如 faiss、sqlite-vss）或至少预过滤。

4. **权重硬编码**：`SEMANTIC_WEIGHT = 0.6`、`KEYWORD_WEIGHT = 0.4` 是经验值，但缺乏根据查询类型动态调整的能力。对于专有名词密集的查询（如"用户公司的名字"），关键词权重应更高；对于抽象概念查询（如"用户最近的压力来源"），语义权重应更高。

**风险评级**：高

#### 3.2.2 体验的语义搜索实现

**代码位置**：`memory/retrieval.py:136-161`

```python
def _search_experiences_semantic(self, query: str, recent: list, keywords: list) -> list:
    all_exp = self.ltm.search_experiences(keywords, limit=15)
    combined = self._merge_unique_experiences(all_exp, recent)
    # ... semantic scoring on combined
```

**分析**：

1. **先关键词后语义的两阶段漏斗**：体验检索首先通过关键词 LIKE 查询从数据库中取出 15 条，然后与 recent_experiences 合并去重，最后做语义重排。这个漏斗比 facts 更宽（15 vs 50），但仍然受限于关键词查询的召回率。

2. **关键词查询的 LIKE 性能问题**：`search_experiences`（`repository.py:128-149`）对每个关键词生成 `summary LIKE ? OR tags LIKE ?` 条件。当关键词数量较多时（如中文句子可能提取 5-10 个关键词），SQL 的 OR 链会急剧膨胀，且 `LIKE '%word%'` 无法使用索引。

3. **无 embedding 直接检索**：与 facts 类似，如果体验的 embedding 为 NULL（尚未生成），语义评分返回 0.0，这些体验在重排中处于劣势。

**风险评级**：高

#### 3.2.3 Embedding 引擎与缓存

**代码位置**：`memory/embeddings.py`

```python
class EmbeddingEngine:
    def __init__(self, endpoint: str = "http://localhost:8080/v1/embeddings",
                 dim: int = 512, timeout: int = 30):
    # ...
    def encode(self, texts: list[str]) -> np.ndarray:
        # POST to llama-server, L2 normalize
```

**分析**：

1. **EmbeddingCache 未被使用**：`EmbeddingCache` 类（`memory/embeddings.py:86-117`）定义了 LRU 缓存，但在整个代码库中没有任何地方实例化或使用它。每次检索都重新编码 query，造成不必要的 API 调用。

2. **llama-server 单点故障**：embedding 服务依赖本地 llama-server。如果服务未启动或崩溃，`health_check()` 返回 False，系统降级为纯关键词搜索。但降级是静默的，用户和开发者都不会收到通知。

3. **BLOB 存储无压缩**：512 维 float32 向量 = 2048 字节/条。200 条 facts + 100 条 experiences = 约 600KB，在 SQLite 中可接受。但如果未来扩展到更高维度或更多记录，应考虑量化（如 int8）或外部向量数据库。

**风险评级**：中

---

### 3.3 Layer 3（LLM 重排）实现分析

#### 3.3.1 LLM Rerank 触发条件与实现

**代码位置**：`memory/retrieval.py:204-225`

```python
def _llm_rerank(self, query: str, candidates: list[UserFact],
                max_candidates: int = 15) -> Optional[list[int]]:
    prompt = MEMORY_RERANK_PROMPT.format(query=query, candidates="\n".join(candidate_lines))
    result = self.llm_rerank_fn(prompt)
    indices = [int(x.strip()) for x in result.split(",") if x.strip().isdigit()]
    return indices[:max_candidates]
```

**分析**：

1. **触发门槛过高**：仅在 `len(candidates) > 15` 时触发。但 candidates 已经经过 Layer 1（50 条）和 Layer 2（30 条）的过滤，实际场景中很难超过 15 条。这意味着 LLM 重排在大多数查询中**永远不会被触发**。

2. **prompt 设计过于简单**：`MEMORY_RERANK_PROMPT`（`prompts/templates.py:88-98`）仅要求"回复序号，逗号分隔"，没有提供候选记忆的历史使用上下文（如该记忆上次被回忆是什么时候、用户是否曾纠正过该记忆）。LLM 缺乏足够信息做出精细判断。

3. **解析脆弱**：`result.split(",")` 假设 LLM 严格输出逗号分隔数字。如果 LLM 输出"1, 2, 3"或"1\n2\n3"或包含解释文字，解析会失败或产生错误索引。

4. **无 fallback 机制**：如果 LLM 返回 "NONE" 或解析失败，`_llm_rerank` 返回 `None`，外层代码保留原始 candidates。这是合理的 fallback，但浪费了 LLM 调用成本。

**风险评级**：中

---

### 3.4 _retrieve_facts / _retrieve_experiences / _retrieve_reflections 的差异分析

在 `MemoryRetriever` 中，三种记忆的检索逻辑存在显著不对称：

| 维度 | Facts | Experiences | Reflections |
|------|-------|-------------|-------------|
| **Layer 1 来源** | `get_all_active_facts(limit=50)` | `get_recent_experiences(limit=5)` | `get_recent_reflections(limit=3)` |
| **Layer 2 语义搜索** | 是（_hybrid_score） | 是（_search_experiences_semantic） | 否 |
| **Layer 2 关键词搜索** | 是（_score_facts fallback） | 是（search_experiences） | 否 |
| **LLM 重排** | 是 | 否 | 否 |
| **去重机制** | 无 | `_merge_unique_experiences` | 无 |
| **数量限制** | 10 | 5 | 3 |
| **数据库排序** | composite_score DESC, recall_count DESC | created_at DESC | created_at DESC |
| **embedding 使用** | 是 | 是 | 否（有列但未使用） |

**关键差异**：

1. **Reflections 完全没有语义/关键词检索**：`retrieve_for_query` 中 reflections 直接取最近 3 条，完全不考虑 query 内容。如果用户询问"我之前说过我喜欢什么"，reflections 中可能包含相关洞察，但由于没有针对性检索，这些洞察被淹没在时间排序中。

2. **Facts 的检索最复杂，但存在过度工程化**：facts 经过 Layer 1（50 条）-> Layer 2 语义重排（30 条）-> LLM 重排（15 条）-> 最终选择（10 条）的四层漏斗。每层都有信息损失，且 LLM 重排很少触发。

3. **Experiences 的检索最实用**：关键词搜索（15 条）+ 语义重排（5 条）的两阶段设计较为合理，但关键词搜索的 LIKE 性能是瓶颈。

**风险评级**：中

---

### 3.5 composite_score 的计算和权重分析

#### 3.5.1 数据库中的 composite_score

**代码位置**：`storage/database.py`

```sql
user_facts.composite_score REAL DEFAULT 1.0
experiences.composite_score REAL DEFAULT 0.5
```

**分析**：

- `user_facts` 默认 1.0，`experiences` 默认 0.5，默认值不一致且无文档说明原因。
- `reflections` 表完全没有 `composite_score` 列。
- 数据库层面的 `composite_score` 在写入后**几乎不再更新**（除了 `prune_facts` 将其设为 0）。

#### 3.5.2 内存中的 composite_score 覆盖

**代码位置**：`memory/retrieval.py:198-199`

```python
def _score_facts(facts, keywords, query):
    for f in facts:
        f.composite_score = MemoryRetriever._keyword_score_single(f, keywords, query)
```

**分析**：

这是整个数据流中最混乱的部分：

1. **原地修改内存对象**：`_score_facts` 直接修改 `UserFact.composite_score`，但这个修改**不会写回数据库**。

2. **循环依赖的评分公式**：`_keyword_score_single`（`retrieval.py:166-178`）的计算为：
   ```python
   score = f.composite_score * 0.2      # 使用数据库中的旧值
   score += f.importance * 0.3
   keyword_hits = sum(1 for kw in keywords if kw in ...)
   score += keyword_hits * 0.2
   if any(kw == f.category for kw in keywords):
       score += 0.2
   score -= min(f.recall_count * 0.02, 0.3)
   return max(0, score)
   ```

   首次调用时 `f.composite_score` 为数据库默认值（1.0 或 0.5），所有 fact 获得 0.2 或 0.1 的基础分，造成系统性偏差。

3. **recall_count 惩罚逻辑反直觉**：`score -= min(f.recall_count * 0.02, 0.3)` 意味着被频繁更新（upsert）的事实会受到惩罚。但 `recall_count` 实际上是写入次数，高频写入的事实（如"用户当前位置"）反而被降权，可能错过重要信息。

4. **prune 使用数据库 composite_score，检索使用内存 composite_score**：`prune_facts` 按数据库中的 `composite_score ASC` 删除最低分记录，但检索时使用的是临时计算的内存值。两者可能长期不一致，导致"该删的没删，不该删的删了"。

**风险评级**：高

---

### 3.6 检索结果的去重和格式化分析

#### 3.6.1 Facts 去重

**代码位置**：`storage/repository.py:34-68`

```python
ON CONFLICT(category, fact_key) DO UPDATE SET
    fact_value = CASE WHEN excluded.confidence >= user_facts.confidence
                     THEN excluded.fact_value ELSE user_facts.fact_value END,
```

**分析**：

Facts 在数据库层面通过 `(category, fact_key)` 的唯一约束实现去重。但存在以下问题：

1. **语义重复未检测**："用户喜欢 pizza" 和 "用户最喜欢的食物是 pizza" 有不同的 `fact_key`，会被视为两条独立记录。`#129 user_facts 大量重复` 已记录此问题。

2. **value 更新策略保守**：仅在 `excluded.confidence >= user_facts.confidence` 时更新 value。如果新信息置信度较低但更准确（如用户纠正了之前的错误信息），更新会被拒绝。

#### 3.6.2 Experiences 去重

**代码位置**：`memory/retrieval.py:228-236`

```python
def _merge_unique_experiences(*lists: list) -> list:
    seen = set()
    result = []
    for lst in lists:
        for e in lst:
            if e.id not in seen:
                seen.add(e.id)
                result.append(e)
```

**分析**：

Experiences 仅在检索结果合并时做 ID 去重。但数据库层面没有任何唯一性约束，相同的体验（如同一次对话被多次总结）会被重复插入。

#### 3.6.3 Reflections 去重

Reflections 完全没有去重机制。LLM 可能在多次 consolidation 中生成内容相似的反思，全部存入数据库。

**风险评级**：中

#### 3.6.4 MemoryContext 格式化

**代码位置**：`prompts/system.py:368-381`

```python
if memory_context.facts:
    blocks.append("=== 你知道的关于用户的事情 ===")
    for f in memory_context.facts[:10]:
        blocks.append(f"- {f.fact_key}: {f.fact_value}")

if memory_context.experiences:
    blocks.append("=== 你们的共同回忆 ===")
    for e in memory_context.experiences[:5]:
        blocks.append(f"- [{e.emotional_tone}] {e.summary}")

if memory_context.reflections:
    blocks.append("=== 你的最近思考 ===")
    for r in memory_context.reflections[:3]:
        blocks.append(f"- {r.content}")
```

**分析**：

1. **无相关性标注**：LLM 无法区分哪些记忆是高相关、哪些是低相关。所有记忆以相同的 `-` 列表格式呈现。

2. **无时间戳信息**：`created_at` 字段存在于模型中，但未在 prompt 中使用。LLM 无法判断记忆的时效性。

3. **无置信度/重要性标注**：`confidence` 和 `importance` 字段未在 prompt 中展示，LLM 无法对低置信度记忆保持怀疑。

**风险评级**：低

---

### 3.7 数据流中的信息丢失

#### 3.7.1 剪枝导致永久丢失

**代码位置**：`storage/repository.py:241-258`

```python
async def prune_facts(self, max_count: int) -> int:
    # ...
    UPDATE user_facts SET is_active = 0, composite_score = 0
    WHERE id IN (
        SELECT id FROM user_facts WHERE is_active = 1
        ORDER BY composite_score ASC, recall_count ASC
        LIMIT ?
    )
```

**分析**：

被剪枝的事实 `is_active=0`，而所有检索查询都带有 `WHERE is_active = 1` 条件。这意味着一旦某条事实被剪枝，就**永久失去被检索的机会**。即使未来用户明确提到相关话题，Layer 1 和 Layer 2 都不会召回该事实。

唯一的例外是 Layer 3 `[回忆:]` 语法，但 `retrieve_by_recall_tag` 调用的 `search_facts` 同样只查 `is_active=1`（`repository.py:74-87`）。

**风险评级**：高

#### 3.7.2 embedding 延迟导致新记忆不可检索

**代码位置**：`memory/consolidation.py:255-297`

```python
def _embed_new_items(self) -> None:
    # 查询 embedding IS NULL 的记录
    # encode -> bulk_update_embeddings
```

**分析**：

记忆写入（`store_fact`、`store_experience`）和 embedding 生成（`_embed_new_items`）是两个独立步骤。`_embed_new_items` 仅在 consolidation 时执行，而 consolidation 的触发条件是轮次间隔或情绪强度。这意味着：

1. 新写入的事实可能在数轮对话内都没有 embedding。
2. 在没有 embedding 期间，这些事实在 Layer 2 语义搜索中获得 `semantic = 0.0`，处于严重劣势。
3. 如果 embedding 服务不可用，这些事实将永远无法参与语义搜索。

**建议**：在写入时同步生成 embedding（如果服务可用），或至少将无 embedding 的事实优先送入 embedding 队列。

**风险评级**：中

#### 3.7.3 关系数据未参与检索

`relationship` 数据（trust/familiarity/intimacy/playfulness）被注入 prompt（`prompts/system.py:358-365`），但从未参与检索排序。例如，当 `intimacy` 很高时，与亲密关系相关的记忆应该被优先召回，但当前系统没有这种动态权重调整。

**风险评级**：低

---

### 3.8 性能瓶颈分析

#### 3.8.1 数据库查询瓶颈

| 查询 | 位置 | 问题 |
|------|------|------|
| `search_facts` | `repository.py:70-88` | `LIKE '%query%'` 三列模糊匹配，无索引 |
| `search_experiences` | `repository.py:128-149` | 动态 OR 链 + LIKE，无索引 |
| `get_active_facts` | `repository.py:90-99` | 全表扫描 + 排序，无复合索引 |
| `prune_facts` | `repository.py:241-258` | 子查询 + 更新，可能锁表 |

**建议**：
- 为 `user_facts(is_active, composite_score)` 和 `experiences(is_archived, composite_score)` 创建复合索引。
- 考虑使用 SQLite FTS5 扩展替代 LIKE 模糊匹配。
- 对于语义搜索，考虑引入 sqlite-vss 或外部向量数据库。

#### 3.8.2 Embedding 生成瓶颈

`_embed_new_items` 在 consolidation 时同步调用 `embed.encode(texts)`，这会阻塞到 llama-server 的 HTTP 请求。如果一次 consolidation 有 50 条新记录，且 llama-server 的吞吐量为 10 texts/秒，这将阻塞 5 秒。

**建议**：将 embedding 生成移至独立的后台任务或线程池，避免阻塞主对话流程。

#### 3.8.3 LLM 重排成本

`_llm_rerank` 每次调用消耗一次 LLM API 请求。虽然触发频率低，但一旦触发，在已经做了语义搜索的情况下，额外的 LLM 调用是否带来足够的收益提升，缺乏 A/B 测试数据支撑。

**风险评级**：中

---

### 3.9 一致性问题

#### 3.9.1 同步/异步混用

`LongTermMemory` 同时提供异步方法（`_store_fact` 等）和同步包装（`store_fact` 等）。`MemoryRetriever` 的所有方法都是同步的，但内部调用 `self.ltm.get_all_active_facts()` 等同步包装，这些包装通过 `ThreadPoolExecutor` 运行异步代码。

在 Web 端（async 环境）和 CLI 端（sync 环境）混用这些接口时，可能出现：
- 线程池耗尽（`#46 线程池风险` 已记录）
- 事件循环嵌套异常

**风险评级**：高

#### 3.9.2 多调用点检索结果不一致

`retrieve_for_query` 在以下位置被调用：
- `inner_drive.py:66`（Agent 1 assess）
- `inner_drive.py:124`（Agent 1 proactive）
- `inner_drive.py:172`（Agent 1 review）
- `inner_drive.py:222`（Agent 1 re_decide）
- `message_handler.py:171`（Agent 3 proactive）
- `message_handler.py:202`（Agent 3 explore）
- `message_handler.py:249`（Agent 3 run_agent3）
- `cli_controller.py:128`（CLI perceive）
- `cli_controller.py:144`（CLI think proactive）

同一轮对话中，Agent 1 和 Agent 3 分别调用 `retrieve_for_query`，如果期间有新记忆写入（如 Agent 1 调用了 `remember` 工具），两次检索的结果可能不同。这种不一致在 ReAct 循环中可能导致 Agent 3 看到 Agent 1 没有看到的记忆，或反之。

**风险评级**：中

#### 3.9.3 recall_count 语义不一致

| 位置 | 行为 | 预期语义 |
|------|------|----------|
| `upsert_fact` | 每次冲突 `recall_count + 1` | 写入次数 |
| `get_active_facts ORDER BY` | `recall_count DESC` | 检索频率 |
| `_keyword_score_single` | `score -= recall_count * 0.02` | 检索频率 |

`recall_count` 同时被用于"写入次数统计"和"检索惩罚因子"，但两者的数值含义完全相反。高频写入的事实被惩罚，这与"常用信息更重要"的直觉相反。

**风险评级**：中

---

## 四、汇总统计

### 4.1 问题统计

| 风险等级 | 数量 | 关键问题 |
|----------|------|----------|
| **高** | 6 | (1) 语义搜索候选池受限（仅50条）；(2) composite_score 语义混乱（内存覆盖不写回）；(3) 剪枝后永久丢失（is_active=0 不可恢复）；(4) embedding 延迟导致新记忆不可检索；(5) 同步/异步混用线程池风险；(6) 全表扫描 + LIKE 无索引 |
| **中** | 10 | (1) recall_count 语义错误；(2) LLM 重排触发门槛高 + 解析脆弱；(3) reflections 无语义检索；(4) 体验关键词查询 OR 链膨胀；(5) EmbeddingCache 未使用；(6) 多调用点检索不一致；(7) facts 语义重复未检测；(8) experiences 无数据库去重；(9) embedding 同步阻塞；(10) 关系数据未参与检索排序 |
| **低** | 6 | (1) 无时间衰减因子；(2) experiences Hot Memory 仅按时间排序；(3) reflections 无 composite_score；(4) prompt 无相关性/时间戳/置信度标注；(5) 权重硬编码；(6) 默认值不一致 |

### 4.2 数据流健康度评分

| 环节 | 评分 | 说明 |
|------|------|------|
| 存储层（Repository） | 65/100 | 基本 CRUD 正确，但索引缺失、语义重复未处理、NULL 风险 |
| Layer 1（Hot Memory） | 60/100 | 召回率有保障，但排序逻辑不一致、无时间衰减 |
| Layer 2（Hybrid Search） | 55/100 | 语义搜索存在但候选池受限、embedding 覆盖不完整、降级静默 |
| Layer 3（LLM Rerank） | 40/100 | 触发频率极低、prompt 设计简单、解析脆弱 |
| 上下文构建（MemoryContext） | 70/100 | 格式清晰，但缺少相关性标注和时间信息 |
| 写入流（Consolidation） | 60/100 | 流程完整，但 embedding 延迟、去重缺失、阻塞风险 |
| 整体数据流一致性 | 55/100 | 多调用点可能不一致、同步/异步混用、字段语义混乱 |

### 4.3 优先修复建议

#### P0（立即修复）

1. **修复 composite_score 语义混乱**（`memory/retrieval.py:198-199`）
   - 将内存评分使用独立字段（如 `_temp_score`），不覆盖 `composite_score`。
   - 或实现定期将内存评分写回数据库的机制。

2. **为 search_facts / search_experiences 添加数据库索引**（`storage/database.py`）
   - `CREATE INDEX IF NOT EXISTS idx_facts_active_score ON user_facts(is_active, composite_score);`
   - `CREATE INDEX IF NOT EXISTS idx_exps_archived_score ON experiences(is_archived, composite_score);`

3. **修复 recall_count 语义**（`storage/repository.py:50`）
   - 将 upsert 中的 `recall_count + 1` 改为 `write_count + 1`（新增列）。
   - 在 `search_facts` / `get_active_facts` 被调用时递增真正的 `recall_count`。

#### P1（短期修复）

4. **扩大语义搜索候选池或实现全表语义检索**（`memory/retrieval.py:106-134`）
   - 方案 A：将 `get_all_active_facts(limit=50)` 扩大至 200（即上限）。
   - 方案 B：实现基于 embedding 相似度阈值的全表过滤，而非先按 composite_score 截断。

5. **启用 EmbeddingCache**（`memory/embeddings.py`）
   - 在 `EmbeddingEngine` 中集成 `EmbeddingCache`，避免重复编码相同 query。

6. **为 reflections 添加语义检索支持**（`memory/retrieval.py`）
   - 实现 `_search_reflections_semantic`，与 experiences 类似的混合搜索。

7. **实现剪枝恢复机制**（`storage/repository.py`）
   - 在语义搜索可用时，允许检索 `is_active=0` 但 embedding 相似度高的记录。
   - 或实现"软删除 + 定期复活"机制。

#### P2（中期优化）

8. **实现写入时同步 embedding**（`memory/long_term.py`）
   - 在 `store_fact` / `store_experience` 时，如果 embedding 服务可用，立即生成 embedding。

9. **使用 FTS5 替代 LIKE**（`storage/repository.py`）
   - 为 `user_facts` 和 `experiences` 创建 FTS5 虚拟表，提升关键词搜索性能。

10. **动态调整 hybrid 权重**（`memory/retrieval.py:106-134`）
    - 根据 query 特征（如专有名词密度、长度）动态调整 semantic/keyword 权重。

11. **在 prompt 中标注记忆元数据**（`prompts/system.py`）
    - 在记忆列表中附加 `(置信度: 0.9, 时间: 2026-05-20)` 等信息，帮助 LLM 判断记忆可靠性。

---

## 五、结论

AI Friend 的长期记忆与检索系统具备清晰的三层架构设计，但在实现层面存在**数据流断裂、语义混乱、性能瓶颈**三类核心问题。

最紧迫的问题是 **composite_score 的语义混乱**和**语义搜索候选池受限**，这两者直接导致检索质量不可预测。其次是**剪枝永久丢失**和**同步/异步混用**，前者造成数据不可逆损失，后者可能在并发场景下引发系统性故障。

建议按照 P0/P1/P2 优先级分阶段修复，同时建立检索质量的量化评估机制（如召回率@K、NDCG），以便验证修复效果。

---

*报告生成时间：2026-05-31*
*审查人：AI Friend 代码审查系统*
*关联文档：doc/round01-memory-system.md, doc/milestones-and-issues.md*
