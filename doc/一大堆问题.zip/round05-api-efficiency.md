# 第5轮审查：性能与可扩展性——API调用效率

**审查日期**：2026-05-31  
**审查范围**：`core/provider.py`、`core/message_handler.py`、`core/inner_drive.py`、`core/tool_agent.py`、`core/agent.py`、`core/context_manager.py`、`memory/consolidation.py`、`memory/retrieval.py`、`prompts/system.py`、`prompts/templates.py`、`web/server.py`、`web/session.py`、`core/sleep_manager.py`  
**审查目标**：识别API调用次数冗余、流式/非流式使用不当、token输入输出比失衡、压缩机制副作用、记忆检索LLM调用开销、情绪分析LLM调用开销、批量调用优化机会。

---

## 一、概述

AI Friend采用三层Agent架构（Agent 1 InnerDrive → Agent 2 ToolAgent → Agent 3 Roleplay），每一层均通过`KimiProvider.generate()`发起对DeepSeek API的HTTP调用。在典型的一次用户对话中，API调用链条可能涉及：**Agent 1 初始评估 → Agent 2 工具执行（多轮+重试）→ Agent 1 审查/重决策 → Agent 3 ReAct循环（多轮工具调用）→ 情绪分析 → 记忆固化**。在最坏情况下，单次用户输入可触发**10次以上**API调用，产生严重的延迟和成本问题。

本次审查发现以下核心问题：

| 类别 | 问题数量 | 最高风险等级 |
|------|----------|-------------|
| 每次对话API调用次数过多 | 5 | 严重 |
| 三层Agent架构冗余调用 | 4 | 严重 |
| 流式vs非流式使用不当 | 3 | 高 |
| token输入输出比失衡 | 4 | 高 |
| 压缩机制副作用 | 2 | 中 |
| 记忆检索中的LLM调用 | 2 | 高 |
| 情绪分析中的LLM调用 | 2 | 中 |
| 批量调用优化机会 | 3 | 中 |

---

## 二、详细发现

### 2.1 每次对话的API调用次数

#### FIND-5.1.1 Agent 1 `assess()` 方法在每次对话中固定发起1次API调用

**文件路径**：`D:\桌面\编程作品\AI朋友\core\inner_drive.py`  
**行号**：61-111

```python
# core/inner_drive.py:85
resp = self._provider.generate(messages, stream=False, max_tokens=512)
```

Agent 1的`assess()`方法无论用户输入多么简单（如"你好"），都会构建一个包含完整人格、情绪、记忆、对话历史的system prompt，并发起一次512 tokens的LLM调用。该调用仅用于判断"是否需要外部工具"。

**风险分析**：
- 对于闲聊类输入（占比可能超过60%），这次调用的输出几乎总是"不需要外部工具"
- 输入prompt通常包含2000-4000字符（约500-1000 tokens），输出约50-100 tokens
- 输入输出比约为 10:1，大量输入token被浪费在简单的二元决策上

**风险评级**：**高**

**建议**：
1. 引入轻量级规则预筛选：关键词匹配（URL、文件路径、搜索意图）可直接判定需要工具，跳过Agent 1调用
2. 对短输入（<20字符）且不含工具关键词的直接走Agent 3，不调用Agent 1
3. 缓存Agent 1的决策结果：相同或相似输入在短期记忆窗口内直接复用

---

#### FIND-5.1.2 Agent 2 工具执行在失败场景下最多可触发9次API调用

**文件路径**：`D:\桌面\编程作品\AI朋友\core\tool_agent.py`  
**行号**：142-224

```python
# core/tool_agent.py:169
for attempt in range(1, max_retries + 1):
    resp = self._provider.generate(messages, stream=False, max_tokens=512,
                                  response_format=json_schema)
```

`run_with_request()`方法在单轮内最多重试3次。结合`message_handler.py`中的外层循环：

```python
# core/message_handler.py:98-116
while round_num < MAX_AGENT2_ROUNDS and drive_result.needs_external_tools:
    ...
    while tracker.can_retry_in_round and not tool_result.any_success:
        tracker.retry_count += 1
        tool_result = self._tool_agent.run_with_request(request_text)
```

**最坏情况调用次数**：3轮 × 3次重试 = **9次API调用**仅用于工具执行。

**风险分析**：
- 每次重试都重新构建完整的system prompt + user message
- 工具执行失败通常是由于网络问题或参数错误，简单重试同一prompt成功率极低
- 9次调用 × 512 tokens输出 ≈ 4608 tokens输出，成本高昂且延迟巨大

**风险评级**：**严重**

**建议**：
1. 区分失败类型：网络超时重试有意义，参数错误/工具不存在不应重试
2. 重试时使用指数退避的max_tokens递减策略，避免浪费
3. 引入"快速失败"机制：首次失败后让Agent 1重新决策（换工具/换参数），而非盲目重试同一请求

---

#### FIND-5.1.3 Agent 3 的ReAct循环最多可迭代10次

**文件路径**：`D:\桌面\编程作品\AI朋友\core\agent.py`  
**行号**：119-181

```python
# core/agent.py:127
for _idx in range(self._max_tool_iterations):
    resp = self.provider.generate(
        messages, stream=False if _idx > 0 else True,
        ...
    )
```

`_react_loop()`设置`self._max_tool_iterations = 10`。在每次迭代中，如果模型输出包含`<tool_call>`标签，就会执行工具并将结果追加到messages中，然后再次调用API。

**风险分析**：
- 正常对话通常1-2次迭代即可结束，但复杂查询（如"帮我查一下最近关于AI的新闻然后总结一下"）可能触发多轮工具调用
- 每轮迭代都会累积历史消息，导致输入token线性增长
- 第10轮时的输入token可能达到第1轮的5-10倍

**风险评级**：**高**

**建议**：
1. 设置迭代间的输入token上限，超过则强制截断或总结
2. 对非首轮回退到非流式输出（当前已部分实现），但应同时降低max_tokens
3. 引入"迭代预算"概念：总API调用次数/总token数超过阈值时提前终止

---

#### FIND-5.1.4 记忆固化每3轮触发一次，单次触发4次LLM调用

**文件路径**：`D:\桌面\编程作品\AI朋友\core\agent.py`  
**行号**：216-221

```python
# core/agent.py:216-221
if self.turn_count % 3 == 0:
    self.consolidator.add_pending(self.short_term.get_all()[-1])
    self.consolidator.consolidate(self.short_term, self.personality,
                                  max_facts=self.config.max_facts,
                                  max_experiences=self.config.max_experiences,
                                  max_reflections=self.config.max_reflections)
```

**文件路径**：`D:\桌面\编程作品\AI朋友\memory\consolidation.py`  
**行号**：47-81

```python
# memory/consolidation.py:60-68
self._extract_facts(turn_text)          # 第1次LLM调用
if len(turn_text) > 200:
    self._summarize_experience(turn_text, short_term)  # 第2次LLM调用
self._generate_reflection(personality)   # 第3次LLM调用
```

此外，`_update_relationship()`内部又调用了`analyze_sentiment()`（第4次LLM调用）：

```python
# memory/consolidation.py:234
sentiment, personal_sharing, _ = self.analyze_sentiment(last_user_turns[-1].content)
```

**风险分析**：
- 每3轮对话触发一次，单次触发4次独立的LLM调用
- 这些调用全部是异步后台任务，用户感知延迟来自Agent 3的响应，但会占用API配额和连接池
- 在高并发场景下（Web端多session），后台调用会显著增加总QPS压力

**风险评级**：**高**

**建议**：
1. 将4次调用合并为1次多任务prompt（"请同时完成：提取事实、总结体验、生成反思、分析情感"）
2. 使用低优先级队列处理固化任务，避免与用户-facing调用竞争
3. 考虑将固化频率从每3轮降低到每5轮或动态调整（对话密度低时延长间隔）

---

#### FIND-5.1.5 主动行为循环持续消耗API配额

**文件路径**：`D:\桌面\编程作品\AI朋友\web\server.py`  
**行号**：130-196

```python
# web/server.py:168-171
intent = await loop.run_in_executor(
    None, ag.decide_proactive_action, idle
)
```

`decide_proactive_action()`调用`InnerDriveAgent.assess_proactive()`，后者发起一次LLM调用：

```python
# core/inner_drive.py:146
resp = self._provider.generate(messages, stream=False, max_tokens=256)
```

**风险分析**：
- `_proactive_loop`每15秒检查一次（`await asyncio.sleep(15)`）
- 每次检查先计算`score = ag._calculate_proactivity(idle)`，只有当`random.random() < score`时才调用Agent 1
- 但`score`在idle时间较长时可能达到0.5-0.8，意味着平均每2-3次检查就触发一次Agent 1调用
- 即：**每30-45秒就可能触发一次无用户输入的API调用**
- 在Web端长连接场景下，用户离开页面后后台仍在持续消耗API配额

**风险评级**：**严重**

**建议**：
1. 增加proactive调用的冷却期：单次session在1小时内最多触发2次proactive Agent 1调用
2. 引入"用户活跃度"检测：WebSocket长时间无消息时降低检查频率到60秒或暂停
3. 将`assess_proactive`替换为纯本地规则引擎（基于情绪、时间、关系的简单打分），仅在score>阈值时才用LLM细化决策

---

### 2.2 三层Agent架构中的冗余调用

#### FIND-5.2.1 Agent 1和Agent 2之间存在prompt重复构建

**文件路径**：`D:\桌面\编程作品\AI朋友\core\inner_drive.py`、`core/tool_agent.py`、`core/message_handler.py`

Agent 1 (`assess`)构建的prompt包含：人格、情绪、记忆、对话历史、可用工具列表。  
Agent 2 (`run_with_request`)构建的prompt包含：工具列表、用户输入/Agent 1请求。  
Agent 3 (`_run_agent3`)构建的prompt包含：人格、情绪、记忆、对话历史、工具结果、inner drive summary。

**冗余点**：
- Agent 1和Agent 3都重复构建了完整的人格/情绪/记忆上下文
- Agent 2的prompt虽然精简，但每次重试都重新构建，未复用之前的schema
- `message_handler.py:120-123`在Agent 2多轮执行时，每次都重新格式化`combined_records`

**风险评级**：**高**

**建议**：
1. 在`MessageHandler`级别缓存`build_system_prompt()`的结果，当人格/情绪/记忆未变化时直接复用
2. Agent 2的`json_schema`在初始化时预计算，避免每次调用`to_json_schema()`
3. Agent 1的决策结果（`InnerDriveResult`）应包含已格式化的上下文摘要，供Agent 3直接使用，避免Agent 3重新检索记忆

---

#### FIND-5.2.2 Agent 1的`review()`和`re_decide()`重复检索记忆

**文件路径**：`D:\桌面\编程作品\AI朋友\core\inner_drive.py`  
**行号**：154-264

```python
# core/inner_drive.py:172 (review方法)
mem_ctx = self._retriever.retrieve_for_query(user_input)
conv_hist = self._short_term.format_for_prompt(max_chars=2000)

# core/inner_drive.py:222 (re_decide方法)
mem_ctx = self._retriever.retrieve_for_query(user_input)
conv_hist = self._short_term.format_for_prompt(max_chars=2000)
```

在Agent 2执行失败后，`re_decide()`重新检索记忆和格式化对话历史，但这些数据在`assess()`中已经检索过，且在此期间对话历史没有变化。

**风险分析**：
- `retrieve_for_query()`本身涉及数据库查询和可能的LLM重排（见2.6节）
- 重复检索增加了不必要的计算和延迟
- 在Agent 2多轮执行场景中，同一`user_input`可能被检索3次以上

**风险评级**：**中**

**建议**：
1. 在`InnerDriveAgent`实例级别缓存最近一次`assess()`的`mem_ctx`和`conv_hist`
2. 仅在`short_term`发生变化（新增turn）时才使缓存失效

---

#### FIND-5.2.3 Agent 3的`_react_loop`在工具调用后未复用已构建的system prompt

**文件路径**：`D:\桌面\编程作品\AI朋友\core\agent.py`  
**行号**：119-181

```python
# core/agent.py:127-133
for _idx in range(self._max_tool_iterations):
    resp = self.provider.generate(
        messages, stream=False if _idx > 0 else True,
        on_token=on_token if _idx == 0 else None,
        max_tokens=max_tok if _idx == 0 else max(384, max_tok * 2 // 3),
    )
```

在ReAct循环中，`messages`列表被不断追加assistant和user消息。虽然system prompt本身没有被修改，但Python列表的传递方式是引用传递，实际上每次调用时API客户端都会遍历整个`messages`列表来计算`input_chars`。

**风险分析**：
- 随着迭代次数增加，`messages`列表长度线性增长
- `provider.py:85`的`input_chars`计算遍历所有消息，时间复杂度O(n)
- 虽然单次计算很快，但在高并发或长对话场景下累积效应明显

**风险评级**：**低**

**建议**：
1. 在`KimiProvider.generate()`中缓存messages的字符数，当messages引用未变化时直接复用
2. 对长对话引入消息摘要机制，每轮迭代后替换已执行的工具调用历史为摘要

---

#### FIND-5.2.4 `handle_explore`在主动探索模式下额外触发Agent 2 + Agent 3全套调用

**文件路径**：`D:\桌面\编程作品\AI朋友\core\message_handler.py`  
**行号**：189-241

```python
# core/message_handler.py:206-207
explore_prompt = f"[自由探索] 可以搜搜关于{topic}的内容。用 web_search 和 web_fetch。"
tool_result = self._tool_agent.run(explore_prompt)
```

主动探索模式（explore）下，系统会：
1. 调用Agent 2执行`web_search`/`web_fetch`（1-3次API调用）
2. 调用Agent 3的`_react_loop`生成分享内容（1-2次API调用）

**风险分析**：
- explore模式是后台触发的（无用户等待），但同样消耗API配额
- `run()`方法内部有`max_iterations=5`的循环，可能多次调用API
- explore的rate limit是1次/小时，但单次explore内部可能产生5+次API调用

**风险评级**：**中**

**建议**：
1. 限制explore模式内Agent 2的最大迭代次数为1-2次
2. explore的Agent 3调用使用更短的max_tokens（如256），因为分享内容通常较短
3. 考虑将explore结果缓存，避免短时间内重复搜索相同主题

---

### 2.3 流式vs非流式的使用场景

#### FIND-5.3.1 Agent 1、Agent 2全部使用非流式，但输出通常很短

**文件路径**：`D:\桌面\编程作品\AI朋友\core\inner_drive.py`、`core/tool_agent.py`

```python
# core/inner_drive.py:85
resp = self._provider.generate(messages, stream=False, max_tokens=512)

# core/tool_agent.py:102-106
resp = self._provider.generate(
    messages, stream=False, max_tokens=512,
    response_format=self._registry.to_json_schema(),
)
```

Agent 1和Agent 2的输出通常是结构化的JSON或简短决策文本（<200 tokens），使用非流式是合理的。但问题在于：

**风险分析**：
- 非流式调用需要等待完整响应才能继续，增加了端到端延迟
- Agent 1的决策阻塞了Agent 2的执行，Agent 2的执行又阻塞了Agent 3的响应
- 三层串行调用导致延迟叠加：T_total = T_agent1 + T_agent2 + T_agent3

**风险评级**：**中**

**建议**：
1. 对Agent 1的短输出（如二元决策）考虑使用更小的模型或本地规则替代
2. 如果必须使用LLM，保持非流式但降低`max_tokens`到128（Agent 1决策通常很短）
3. 探索Agent 1和Agent 2的并行化：某些场景下可以预执行Agent 2（如检测到URL时直接fetch，不等Agent 1确认）

---

#### FIND-5.3.2 Agent 3首轮回退到非流式的逻辑存在延迟风险

**文件路径**：`D:\桌面\编程作品\AI朋友\core\agent.py`  
**行号**：127-133

```python
# core/agent.py:129-133
resp = self.provider.generate(
    messages, stream=False if _idx > 0 else True,
    on_token=on_token if _idx == 0 else None,
    max_tokens=max_tok if _idx == 0 else max(384, max_tok * 2 // 3),
)
```

Agent 3的ReAct循环中，第0轮（首次调用）使用流式输出（`stream=True`），后续轮次使用非流式。

**问题**：
- 如果Agent 3在第0轮就输出了`<tool_call>`标签（需要调用工具），流式输出会被完整收集后才解析
- 这意味着即使模型在输出开头就给出了工具调用，用户也看不到任何token（因为`on_token`只在第0轮有效，且工具调用时用户不应看到中间内容）
- 实际上，Agent 3的工具调用轮次用户不会收到token，但流式连接仍然建立和传输

**风险分析**：
- 流式连接建立有额外开销（HTTP chunked transfer）
- 如果模型输出的是工具调用而非对话内容，流式传输的数据被丢弃，浪费带宽
- 当前实现中`on_token`回调仅在第0轮有效，但第0轮恰好最可能是工具调用轮次

**风险评级**：**中**

**建议**：
1. 对Agent 3引入"预检"机制：先以非流式、低max_tokens（如128）调用，判断是否需要工具调用
2. 如果不需要工具调用，再用流式生成完整回复
3. 这样可以避免在工具调用场景下建立无意义的流式连接

---

#### FIND-5.3.3 Web端REST API使用非流式，WebSocket使用流式但实现方式低效

**文件路径**：`D:\桌面\编程作品\AI朋友\web\server.py`  
**行号**：39-54、199-249

```python
# web/server.py:47
response = agent.process_message(message)

# web/server.py:233
response = await loop.run_in_executor(None, agent.process_message, content)
```

REST API端点`/api/chat`调用`process_message()`时不传`on_token`，因此即使Agent 3内部第0轮使用流式，也没有回调接收token，等效于非流式。

WebSocket端点虽然传入了`on_token`（通过`WebAgent.set_on_token`），但实现方式是将完整响应生成后再分段发送：

```python
# web/server.py:116-127
async def _send_segments(websocket, agent, response, emotion):
    segments = _split_segments(response)
    for i, seg in enumerate(segments):
        if i > 0:
            await asyncio.sleep(_calc_delay(emotion, len(seg)))
        await websocket.send_text(json.dumps({"type": "segment", "content": seg}))
```

**风险分析**：
- WebSocket端实际上仍然是"先完整生成，后分段发送"，而非真正的流式传输
- 用户感知的首字延迟等于完整响应生成时间，而非首个token生成时间
- `_calc_delay`模拟打字效果，但延迟的是网络发送而非模型生成
- 在模型生成长回复时，用户需要等待数秒才能看到第一个字

**风险评级**：**高**

**建议**：
1. 将WebSocket的`on_token`回调直接连接到WebSocket发送，实现真正的token级流式传输
2. 移除`_split_segments`和`_calc_delay`的人工延迟，或将其改为基于实际token到达时间的动态延迟
3. REST API可考虑支持SSE（Server-Sent Events）以提供流式响应

---

### 2.4 Token输入输出比

#### FIND-5.4.1 Agent 1的prompt输入远大于有效输出

**文件路径**：`D:\桌面\编程作品\AI朋友\prompts\system.py`  
**行号**：22-98

`build_inner_drive_prompt()`构建的prompt包含：
- 当前时间（~20 tokens）
- 自我认知：人格名称、特质、情绪状态、关系指标（~100-150 tokens）
- 用户事实：最多8条（~80-200 tokens）
- 共同回忆：最多3条（~60-150 tokens）
- 内驱推理指令（~150 tokens）
- 可用工具列表（~100-200 tokens）
- 最近对话历史：最多2000字符（~500-800 tokens）

**总计输入**：约1000-1800 tokens  
**典型输出**：50-150 tokens（决策+理由）

**输入输出比**：约 **10:1 到 15:1**

**风险分析**：
- 大量输入token用于提供"上下文"，但Agent 1的决策通常是简单的模式匹配
- 对于"用户发了URL"这类明显场景，1000+ tokens的上下文是严重浪费
- 按DeepSeek API定价，输入token成本约为输出的1/2到1/3，但总量巨大

**风险评级**：**高**

**建议**：
1. 为Agent 1设计极简prompt版本：仅包含工具列表+用户输入+最近2轮对话
2. 仅在检测到复杂意图时才使用完整prompt
3. 考虑使用更小的模型（如deepseek-v4-flash而非deepseek-v4）处理Agent 1任务

---

#### FIND-5.4.2 Agent 3的system prompt过于冗长

**文件路径**：`D:\桌面\编程作品\AI朋友\prompts\system.py`  
**行号**：211-520

`build_system_prompt()`构建的Agent 3 prompt包含11个block：
1. 当前时间
2. Phase 1工具结果（可能很长）
3. Inner drive summary
4. 身份定义（人格、特质、说话风格、背景、兴趣）
5. 对话示例（8个示例，约300-400 tokens）
6. 情绪状态描述（含15种情绪的详细行为指令）
7. 怨恨状态
8. 情绪事件
9. 关系上下文
10. 长期记忆（事实、体验、反思）
11. 指令

**估算输入**：2000-4000 tokens（取决于记忆量和工具结果长度）  
**典型输出**：100-300 tokens（对话回复）

**输入输出比**：约 **10:1 到 20:1**

**风险分析**：
- 每个block都是静态或准静态内容（对话示例、行为指令几乎不变）
- 每次API调用都重复传输这些静态内容
- 工具结果（block 2）可能包含6000+字符的网页内容，进一步恶化比例

**风险评级**：**严重**

**建议**：
1. 使用prompt缓存技术（如果API提供商支持）：将静态system prompt缓存，只传输动态内容
2. 将对话示例从8个减少到2-3个最具代表性的
3. 情绪行为指令使用模板化短句，避免长段落
4. 工具结果在传入Agent 3前应进行摘要或截断（当前已截断到6000字符，但仍过长）

---

#### FIND-5.4.3 记忆固化的4次调用各自存在高输入低输出问题

**文件路径**：`D:\桌面\编程作品\AI朋友\memory\consolidation.py`、`prompts\templates.py`

| 调用 | 输入估算 | 输出估算 | 比例 |
|------|---------|---------|------|
| `_extract_facts` | 500-1000 tokens（对话文本+指令） | 50-100 tokens（FACT行） | 10:1 |
| `_summarize_experience` | 500-1000 tokens | 50-80 tokens | 12:1 |
| `_generate_reflection` | 800-1500 tokens（体验+反思+事实+关系） | 50-100 tokens | 15:1 |
| `analyze_sentiment` | 100-300 tokens（单条消息+指令） | 20-30 tokens（JSON） | 10:1 |

**风险分析**：
- 4次调用合计输入约2000-4000 tokens，输出约200-300 tokens
- 整体输入输出比约 **15:1**
- 这些调用是后台任务，用户不感知延迟，但成本累积显著

**风险评级**：**高**

**建议**：
1. 合并4个任务为1个多输出prompt，输入共享，输出格式化为结构化JSON
2. 预估合并后输入仍为2000-4000 tokens，但输出增加到300-500 tokens，比例改善到约8:1
3. 减少API调用次数从4次到1次，延迟降低约60-70%（考虑网络往返）

---

#### FIND-5.4.4 压缩机制本身消耗额外token

**文件路径**：`D:\桌面\编程作品\AI朋友\core\context_manager.py`  
**行号**：62-98

```python
# core/context_manager.py:88-91
result = self._provider.generate(
    [{"role": "user", "content": CONTEXT_COMPRESS_PROMPT.format(conversation=text)}],
    stream=False,
)
```

当对话历史超过`COMPRESS_THRESHOLD`（144000 tokens的80% = 115200 tokens）时，触发压缩。

**风险分析**：
- 压缩prompt包含完整对话历史（截断到8000字符），输入约2000-3000 tokens
- 输出为100-150字的摘要，约50-100 tokens
- 压缩本身是一次额外的API调用
- 如果对话频繁触发压缩（如长对话场景），累积成本显著

**风险评级**：**中**

**建议**：
1. 压缩触发阈值当前为115200 tokens，对于max_tokens=512的模型几乎不可能达到，该机制实际上很少触发
2. 应降低阈值到更合理的水平（如20000 tokens），或改为基于轮数触发（每20轮压缩一次）
3. 压缩结果应缓存，避免相同对话历史重复压缩

---

### 2.5 压缩机制对API调用次数的影响

#### FIND-5.5.1 压缩阈值设置过高导致机制形同虚设

**文件路径**：`D:\桌面\编程作品\AI朋友\core\context_manager.py`  
**行号**：7-8

```python
# core/context_manager.py:7-8
_MODEL_CONTEXT = 180_000
COMPRESS_THRESHOLD = int(_MODEL_CONTEXT * 0.8)
```

`COMPRESS_THRESHOLD = 144000 tokens`。

**风险分析**：
- 当前配置的模型`deepseek-v4-flash`的上下文窗口实际为128K tokens（131072）
- 180K的设定已经超出模型实际能力
- 即使按180K计算，144K的阈值对于 typical 对话（每轮500-1000 tokens输入）需要100+轮才会触发
- `short_term`的maxlen仅为20轮（`ConversationBuffer(maxlen=20)`），远达不到阈值
- 因此压缩机制实际上**永远不会触发**

**风险评级**：**中**

**建议**：
1. 将`_MODEL_CONTEXT`修正为131072（或从配置读取）
2. 将`COMPRESS_THRESHOLD`降低到合理值，如20000-30000 tokens
3. 或者改为基于轮数触发：当`short_term`满（20轮）时触发压缩，清空buffer并保留摘要

---

#### FIND-5.5.2 压缩后清空短期记忆导致信息丢失

**文件路径**：`D:\桌面\编程作品\AI朋友\core\context_manager.py`  
**行号**：92-96

```python
# core/context_manager.py:92-96
if result.strip():
    self._compressed_summary = result.strip()
    self._estimated_tokens_used = 0
    self._short_term.clear()
```

压缩成功后，短期记忆被完全清空。

**风险分析**：
- 短期记忆清空后，后续对话的上下文仅依赖摘要，可能丢失细节
- Agent 1和Agent 3的prompt中都包含"最近对话"，清空后该部分变为空或仅依赖摘要
- 如果压缩质量不佳（摘要遗漏关键信息），对话连贯性受损

**风险评级**：**中**

**建议**：
1. 压缩后保留最近2-3轮对话在short_term中，而非完全清空
2. 压缩摘要应包含"待办事项"、"用户未完成的请求"等关键状态
3. 引入压缩质量评估：让LLM自我评分，低分时保留更多原始对话

---

### 2.6 记忆检索中的LLM调用（重排）

#### FIND-5.6.1 LLM重排在候选数>15时触发，但重排prompt成本较高

**文件路径**：`D:\桌面\编程作品\AI朋友\memory\retrieval.py`  
**行号**：45-49、204-225

```python
# memory/retrieval.py:46-49
if len(candidates) > 15 and self.llm_rerank_fn and query.strip():
    selected_indices = self._llm_rerank(query, candidates)
    if selected_indices is not None:
        candidates = [candidates[i] for i in selected_indices if i < len(candidates)]
```

```python
# memory/retrieval.py:212-218
prompt = MEMORY_RERANK_PROMPT.format(
    query=query,
    candidates="\n".join(candidate_lines),
)
result = self.llm_rerank_fn(prompt)
```

**风险分析**：
- 重排prompt包含最多30条候选记忆，每条约20-50 tokens，输入约600-1500 tokens
- 输出为逗号分隔的序号，约10-30 tokens
- 重排发生在每次`retrieve_for_query()`调用时，即：Agent 1的`assess()`、Agent 1的`review()`、Agent 1的`re_decide()`、Agent 3的`_run_agent3()`各调用一次
- 单次用户对话可能触发**2-4次重排**，每次消耗600-1500 tokens输入

**风险评级**：**高**

**建议**：
1. 重排结果缓存：相同query在5分钟内直接复用
2. 降低重排触发阈值到更合理的水平：当前是>15候选，可改为>25候选（减少触发频率）
3. 使用本地轻量级重排模型（如cross-encoder）替代LLM重排，零API成本
4. 或者完全移除LLM重排，依赖混合评分（semantic+keyword）已经足够精确

---

#### FIND-5.6.2 `retrieve_for_query`在空查询时仍执行完整检索

**文件路径**：`D:\桌面\编程作品\AI朋友\memory\retrieval.py`  
**行号**：27-69

```python
# memory/retrieval.py:27
def retrieve_for_query(self, query: str) -> MemoryContext:
```

在`assess_proactive()`中调用：

```python
# core/inner_drive.py:124
mem_ctx = self._retriever.retrieve_for_query("")
```

传入空字符串作为query。

**风险分析**：
- 空query时，`keywords = self._extract_keywords("")`返回空列表
- 混合评分退化为仅依赖`composite_score`和`importance`的静态排序
- 语义搜索`self._embed.encode_single("")`可能产生无意义向量
- LLM重排因`query.strip()`为False而被跳过（唯一的好处）
- 但整个检索流程（数据库查询、评分计算）仍在执行，返回的结果质量低

**风险评级**：**中**

**建议**：
1. 空query时直接返回"热点记忆"（最近事实+最近体验），跳过复杂的混合搜索和重排
2. 在`retrieve_for_query()`入口处添加短路逻辑：`if not query.strip(): return self._get_hot_memory_context()`

---

### 2.7 情绪分析中的LLM调用

#### FIND-5.7.1 `analyze_sentiment`每次调用消耗独立API请求

**文件路径**：`D:\桌面\编程作品\AI朋友\memory\consolidation.py`  
**行号**：83-96

```python
# memory/consolidation.py:86-87
prompt = EMOTION_ANALYSIS_PROMPT.format(text=text)
result = self.llm(prompt, temperature=0.2)
```

**文件路径**：`D:\桌面\编程作品\AI朋友\prompts\templates.py`  
**行号**：73-85

```python
EMOTION_ANALYSIS_PROMPT = """分析用户这条消息的情感倾向。
输出格式（一行JSON）：
{{"sentiment": <float -1.0~1.0>, "personal_sharing": <true/false>, "topic_energy": <float 0.0~1.0>}}
...
"""
```

**风险分析**：
- 每次用户对话后都调用一次（在`_process_emotion()`中）
- 输入为单条用户消息（通常<200 tokens），输出为JSON（约20 tokens）
- 虽然单次成本低，但频率高（每轮1次）
- 更关键的是：该调用与记忆固化的`analyze_sentiment`调用是分开的，`_update_relationship()`中又调用了一次

**风险评级**：**中**

**建议**：
1. 将情绪分析结果缓存到`Turn`对象中，同一turn不重复分析
2. 使用本地情感分析模型（如基于BERT的中文情感分类器）替代LLM调用
3. 或者将情绪分析合并到记忆固化的多任务prompt中（见2.4.3）

---

#### FIND-5.7.2 情绪分析失败时静默回退，可能累积错误

**文件路径**：`D:\桌面\编程作品\AI朋友\memory\consolidation.py`  
**行号**：94-96

```python
# memory/consolidation.py:94-96
except Exception as e:
    logger.warning(f"Sentiment analysis failed: {e}")
    return 0.0, False, 0.5
```

**风险分析**：
- 失败时返回中性默认值（0.0, False, 0.5）
- 如果API间歇性故障，连续多轮返回默认值，情绪系统无法正确响应用户负面情绪
- 没有重试机制（与`KimiProvider`的3次重试不同，`analyze_sentiment`直接捕获所有异常）

**风险评级**：**低**

**建议**：
1. 在`analyze_sentiment`内部使用与`KimiProvider`相同的重试策略
2. 记录连续失败次数，超过阈值时切换到本地规则分析（关键词匹配）

---

### 2.8 批量调用优化机会

#### FIND-5.8.1 记忆固化的4次LLM调用可合并为1次

**文件路径**：`D:\桌面\编程作品\AI朋友\memory\consolidation.py`  
**行号**：47-81

当前实现：
```python
self._extract_facts(turn_text)          # 调用1
if len(turn_text) > 200:
    self._summarize_experience(turn_text, short_term)  # 调用2
self._generate_reflection(personality)   # 调用3
```
加上`_update_relationship`中的`analyze_sentiment`（调用4）。

**优化方案**：
设计一个统一的consolidation prompt：
```
基于以下对话，请完成4个任务：
1. 提取用户事实（输出FACT|...行）
2. 总结体验（输出SUMMARY:...等）
3. 生成反思（输出TYPE:... CONTENT:...等）
4. 分析情感（输出{"sentiment":..., "personal_sharing":..., "topic_energy":...}）

对话：{turn_text}
最近体验：{experiences}
已有反思：{reflections}
用户事实：{facts}
```

**收益**：
- API调用次数从4次减少到1次
- 共享输入上下文，减少重复token
- 网络延迟从4次RTT减少到1次

**风险评级**：**中**

---

#### FIND-5.8.2 Agent 2的批量工具调用未利用并行执行

**文件路径**：`D:\桌面\编程作品\AI朋友\core\tool_agent.py`  
**行号**：109-130

```python
# core/tool_agent.py:102-106
resp = self._provider.generate(
    messages,
    stream=False,
    max_tokens=512,
    response_format=self._registry.to_json_schema(),
)
cleaned, calls = parse_tool_calls(resp)
```

Agent 2在一次API调用中返回多个工具调用（`calls`数组），但：
- 这些工具调用在`execute_tool_calls()`中是串行执行的
- 如果`calls`包含`web_search`和`web_fetch`，后者依赖前者结果，串行是合理的
- 但如果`calls`包含独立的`read_file`和`notify`，它们可以并行执行

**风险分析**：
- 工具执行时间叠加，增加了Agent 2的整体延迟
- 在`run_with_request`中，工具执行延迟直接累加到API调用延迟上

**风险评级**：**低**

**建议**：
1. 在`execute_tool_calls()`中识别无依赖关系的工具调用，使用`asyncio.gather`并行执行
2. 为工具添加`is_async`和`dependencies`元数据，支持智能调度

---

#### FIND-5.8.3 多session场景下缺乏API调用配额管理

**文件路径**：`D:\桌面\编程作品\AI朋友\web\session.py`  
**行号**：121-175

`SessionManager`管理多个WebAgent实例，每个实例有独立的provider、agent、memory。

**风险分析**：
- 每个session独立发起API调用，没有全局配额控制
- 在高并发场景下（如50个活跃session），总QPS可能超出API提供商限制
- 没有优先级队列：后台的proactive调用和记忆固化可能与用户-facing调用竞争
- 没有熔断机制：单个session的异常行为（如陷入重试循环）可能耗尽全局配额

**风险评级**：**高**

**建议**：
1. 实现全局API调用速率限制器（token bucket或leaky bucket算法）
2. 区分调用优先级：用户-facing > 记忆检索 > 记忆固化 > proactive
3. 为每个session设置每分钟的API调用上限
4. 实现熔断机制：连续失败10次后暂停该session的API调用30秒

---

## 三、汇总统计

### 3.1 单次典型对话的API调用链分析

假设场景：用户输入"帮我查一下今天AI领域的新闻"，需要搜索+回复。

| 步骤 | 调用点 | 流式 | max_tokens | 估算输入tokens | 估算输出tokens | 次数 |
|------|--------|------|-----------|--------------|--------------|------|
| 1 | Agent 1 assess | 否 | 512 | 1200 | 100 | 1 |
| 2 | Agent 2 执行搜索 | 否 | 512 | 300 | 150 | 1 |
| 3 | Agent 1 review | 否 | 512 | 1500 | 80 | 1 |
| 4 | Agent 3 生成回复 | 是 | 512 | 2500 | 200 | 1 |
| 5 | 情绪分析 | 否 | 256 | 200 | 20 | 1 |
| **小计** | | | | **~5700** | **~550** | **5** |

最坏情况（Agent 2失败重试3轮，Agent 3 ReAct 3轮）：

| 步骤 | 调用点 | 次数 |
|------|--------|------|
| Agent 1 assess | 1 |
| Agent 2 执行（含重试） | 3 |
| Agent 1 re_decide | 1 |
| Agent 2 重新执行 | 1 |
| Agent 3 ReAct迭代 | 3 |
| 情绪分析 | 1 |
| **小计** | **~10次** |

### 3.2 后台任务API调用频率

| 任务 | 触发频率 | 单次调用次数 | 月度估算（1000轮对话） |
|------|---------|-------------|---------------------|
| 记忆固化 | 每3轮 | 4次LLM调用 | ~1333次调用 |
| 情绪分析 | 每轮 | 1次LLM调用 | 1000次调用 |
| Proactive评估 | 每30-45秒 | 1次LLM调用 | 取决于在线时长 |
| 梦境生成 | 每天1-2次 | 1次LLM调用 | ~45次调用 |

### 3.3 风险汇总表

| ID | 发现 | 风险等级 | 影响 |
|----|------|---------|------|
| FIND-5.1.1 | Agent 1固定发起1次API调用 | 高 | 闲聊场景浪费50%+调用 |
| FIND-5.1.2 | Agent 2失败时最多9次调用 | 严重 | 延迟和成本暴增 |
| FIND-5.1.3 | Agent 3 ReAct最多10轮 | 高 | 长对话token爆炸 |
| FIND-5.1.4 | 记忆固化单次4次LLM调用 | 高 | 后台消耗大量配额 |
| FIND-5.1.5 | Proactive循环持续消耗API | 严重 | 用户离开后仍扣费 |
| FIND-5.2.1 | 三层Agent prompt重复构建 | 高 | 重复token传输 |
| FIND-5.2.2 | Agent 1重复检索记忆 | 中 | 冗余数据库查询 |
| FIND-5.2.3 | Agent 3未复用system prompt | 低 | 轻微性能损耗 |
| FIND-5.2.4 | Explore模式全套调用 | 中 | 后台任务成本高 |
| FIND-5.3.1 | Agent 1/2全用非流式 | 中 | 延迟叠加 |
| FIND-5.3.2 | Agent 3流式逻辑低效 | 中 | 带宽浪费 |
| FIND-5.3.3 | Web端伪流式传输 | 高 | 首字延迟差 |
| FIND-5.4.1 | Agent 1输入输出比10:1 | 高 | 大量输入token浪费 |
| FIND-5.4.2 | Agent 3 prompt过于冗长 | 严重 | 单次调用成本翻倍 |
| FIND-5.4.3 | 固化调用输入输出比15:1 | 高 | 后台成本累积 |
| FIND-5.4.4 | 压缩机制消耗额外token | 中 | 极少触发但成本高 |
| FIND-5.5.1 | 压缩阈值过高形同虚设 | 中 | 机制无效 |
| FIND-5.5.2 | 压缩后清空短期记忆 | 中 | 信息丢失风险 |
| FIND-5.6.1 | LLM重排成本高且频繁 | 高 | 每次检索额外消耗 |
| FIND-5.6.2 | 空查询仍执行完整检索 | 中 | 低质量结果+浪费 |
| FIND-5.7.1 | 情绪分析独立API请求 | 中 | 高频低价值调用 |
| FIND-5.7.2 | 情绪分析失败静默回退 | 低 | 情绪响应不准确 |
| FIND-5.8.1 | 固化4次调用可合并 | 中 | 优化空间明确 |
| FIND-5.8.2 | 工具调用未并行化 | 低 | 延迟叠加 |
| FIND-5.8.3 | 无全局API配额管理 | 高 | 高并发下服务降级 |

### 3.4 优化优先级建议

**P0（立即修复）**：
1. 修复压缩阈值（FIND-5.5.1）
2. 为proactive循环添加冷却期和用户离开检测（FIND-5.1.5）
3. 引入全局API调用配额管理（FIND-5.8.3）

**P1（短期优化）**：
1. 合并记忆固化的4次LLM调用为1次（FIND-5.8.1）
2. 为Agent 1引入轻量级规则预筛选，减少不必要的LLM调用（FIND-5.1.1）
3. 优化Agent 3的prompt长度，减少静态内容重复（FIND-5.4.2）
4. 缓存LLM重排结果或移除重排（FIND-5.6.1）
5. 实现真正的WebSocket流式传输（FIND-5.3.3）

**P2（中期改进）**：
1. 使用本地模型替代LLM情绪分析（FIND-5.7.1）
2. 优化Agent 2的重试策略，区分失败类型（FIND-5.1.2）
3. 并行化独立工具调用（FIND-5.8.2）
4. 在Agent 1和Agent 3之间共享已构建的上下文（FIND-5.2.1）

---

*审查完成。本报告基于代码静态分析，实际token数和调用次数可能因输入内容和模型行为而有所差异。*
