# AI Friend 项目第1轮代码审查报告：入口点与启动流程

**审查日期**: 2026-05-31
**审查范围**: main.py, web_main.py, config.py, config.json, core/logging_setup.py 及其关联启动链路
**审查人**: Claude Code (Sonnet 4.6)

---

## 1. 概述

本项目采用双入口架构：CLI 入口 (`main.py`) 和 Web 入口 (`web_main.py`)。两者共享配置系统 (`config.py`)、日志系统 (`core/logging_setup.py`) 以及底层 Agent 核心 (`core/agent.py`)。CLI 路径通过 `Agent.run()` 进入状态机循环，由 `CliController` 驱动；Web 路径通过 `uvicorn` 启动 FastAPI 服务，由 `web/server.py` 处理 HTTP/WebSocket 请求，通过 `SessionManager` 和 `WebAgent` 管理会话。

本次审查发现 **高风险问题 4 项、中风险问题 8 项、低风险问题 6 项**，总计 18 项问题。核心风险集中在：CLI/Web 初始化逻辑严重重复、配置加载异常处理薄弱、日志系统存在重复 Handler 风险、资源生命周期管理不一致、以及多处同步/异步混用导致的潜在死锁和性能问题。

---

## 2. 详细发现

### 发现 #1: CLI 与 Web 入口存在大量重复初始化代码

**问题描述**

`main.py` (第 28-109 行) 和 `web/session.py` 中的 `WebAgent.__init__` (第 28-79 行) 几乎完全复制了同一套初始化逻辑：加载配置、设置日志、初始化数据库、加载人格、初始化记忆系统、创建 Provider、创建 EmbeddingEngine、创建 MemoryRetriever、创建 MemoryConsolidator、注册工具、创建 Agent。这种重复违反了 DRY 原则，导致任何对初始化顺序或组件参数的修改都需要在两个地方同步进行，极易遗漏。

具体重复内容包括：
- `KimiProvider` 的构造参数完全一致（endpoint, api_key, model, temperature, max_tokens, thinking, reasoning_effort, timeout）
- `EmbeddingEngine` 的构造参数完全一致（endpoint, dim）
- `MemoryRetriever` 和 `MemoryConsolidator` 的构造逻辑一致
- 8 个工具的注册顺序和方式完全一致
- `Agent` 的构造参数基本一致（WebAgent 缺少 `ui` 参数）

**位置**
- `D:\桌面\编程作品\AI朋友\main.py` 第 28-109 行
- `D:\桌面\编程作品\AI朋友\web\session.py` 第 28-79 行

**风险等级**: **高**

**建议修复**

提取一个共享的 `AgentFactory` 或 `Bootstrap` 类，封装完整的初始化流程。例如：

```python
# core/bootstrap.py
class AgentBootstrap:
    def __init__(self, config: Config):
        self.config = config
        self.db: Database | None = None
        self.repo: Repository | None = None
        self.personality: Personality | None = None
        self.provider: KimiProvider | None = None
        self.ltm: LongTermMemory | None = None
        self.short_term: ConversationBuffer | None = None
        self.retriever: MemoryRetriever | None = None
        self.consolidator: MemoryConsolidator | None = None
        self.tool_registry: ToolRegistry | None = None

    async def init_storage(self) -> None:
        self.db = Database(self.config.db_path)
        await self.db.open()
        self.repo = Repository(self.db)

    def init_personality(self) -> None:
        self.personality = Personality.load(self.config.personality_file)

    def init_memory(self) -> None:
        self.ltm = LongTermMemory(self.repo)
        self.short_term = ConversationBuffer(maxlen=self.config.short_term_capacity)

    def init_provider(self) -> None:
        self.provider = KimiProvider(...)

    def init_tools(self) -> None:
        self.tool_registry = ToolRegistry()
        # register all tools

    def build_agent(self, ui=None) -> Agent:
        return Agent(
            personality=self.personality,
            provider=self.provider,
            ltm=self.ltm,
            retriever=self.retriever,
            consolidator=self.consolidator,
            short_term=self.short_term,
            ui=ui,
            config=self.config,
        )
```

然后 `main.py` 和 `WebAgent` 都使用这个工厂类，消除重复。

---

### 发现 #2: CLI 入口 `agent.run()` 是同步调用，但 Agent 内部大量依赖异步数据库操作

**问题描述**

`main.py` 第 111 行调用 `agent.run()`，这是一个同步方法。`Agent.run()` 内部委托给 `CliController.run()`，后者是一个同步的状态机循环。然而，Agent 内部的许多操作（如 `ltm.repo.insert_turn_sync`）通过 `_run_sync` 包装器将异步协程转换为同步调用。

在 `storage/repository.py` 第 13-21 行，`_run_sync` 的实现如下：

```python
def _run_sync(coro):
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return pool.submit(asyncio.run, coro).result()
```

这个实现在嵌套事件循环场景下会出问题：如果 `asyncio.get_running_loop()` 已经返回了一个运行中的事件循环（比如在某些测试框架或 Jupyter 环境中），`_run_sync` 会尝试在同一个线程中通过 `ThreadPoolExecutor` 运行 `asyncio.run(coro)`。`asyncio.run()` 会尝试创建新的事件循环并设置为当前线程的循环，但如果该线程已经有运行中的循环，在某些 Python 版本中会抛出 `RuntimeError`。

更关键的是，`main.py` 第 36 行 `await db.open()` 是在 `async def main()` 中正确执行的，但随后所有通过 `Repository` 的数据库操作都被同步包装。这种"半同步半异步"的架构非常脆弱。

**位置**
- `D:\桌面\编程作品\AI朋友\main.py` 第 111 行
- `D:\桌面\编程作品\AI朋友\storage\repository.py` 第 13-21 行
- `D:\桌面\编程作品\AI朋友\core\cli_controller.py` 多处调用 `insert_turn_sync`

**风险等级**: **高**

**建议修复**

方案 A（推荐）：将 CLI 状态机完全异步化。`CliController.run()` 改为 `async def run()`，所有状态处理函数改为 async，彻底消除 `_run_sync` 的需求。

方案 B：如果必须保持同步 CLI，则使用 `asyncio.run()` 在顶层运行整个 CLI 循环，确保所有异步操作都在同一个事件循环中执行，而不是通过 `_run_sync` 嵌套调用。

---

### 发现 #3: Web 入口在模块导入时即加载配置，存在副作用和测试困难

**问题描述**

`web/server.py` 第 17-18 行在模块顶层执行：

```python
config = load_config()
session_manager = SessionManager(config)
```

这意味着只要导入 `web.server` 模块（例如 `uvicorn.run("web.server:app", ...)` 时），就会立即读取文件系统、解析 JSON、初始化 `SessionManager`。这带来以下问题：

1. **测试困难**: 在单元测试中导入 `web.server` 会触发真实的配置加载和 SessionManager 初始化，无法通过依赖注入提供 mock 配置。
2. **副作用**: 模块导入不应该产生 I/O 副作用。PEP 8 和 Python 最佳实践都建议将初始化延迟到函数调用时。
3. **配置热重载困难**: 由于配置在导入时固化，无法在不重启服务的情况下重新加载配置。
4. **循环导入风险**: 如果 `SessionManager` 的初始化逻辑未来变得复杂，可能引入循环导入。

**位置**
- `D:\桌面\编程作品\AI朋友\web\server.py` 第 17-18 行

**风险等级**: **高**

**建议修复**

使用 FastAPI 的依赖注入系统或 `lifespan` 上下文管理器来延迟初始化。实际上 `lifespan` 已经在第 21-27 行定义，但 `config` 和 `session_manager` 仍然是在模块顶层创建的。

修改为：

```python
# 不在模块顶层初始化
config: Config | None = None
session_manager: SessionManager | None = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global config, session_manager
    config = load_config()
    setup_logging(config.log_level)
    session_manager = SessionManager(config)
    await session_manager.open()
    logger.info("Server starting...")
    yield
    logger.info("Server shutting down...")
```

同时修改所有使用 `config` 和 `session_manager` 的地方，增加空值检查或使用 `typing.cast`。

---

### 发现 #4: 配置加载异常处理过于粗糙，且存在静默失败风险

**问题描述**

`config.py` 第 48-78 行的 `load_config` 函数存在多个问题：

1. **JSON 解析异常处理过于宽泛** (第 58-59 行):
   ```python
   except (json.JSONDecodeError, OSError):
       logger.warning(f"[config] failed to parse: {path}, using defaults")
   ```
   这里捕获了 `OSError`，但 `OSError` 包含权限错误、磁盘错误等严重问题，不应该静默降级为默认值。应该区分 "文件不存在"（正常降级）和 "文件存在但无法读取"（应该报错）。

2. **环境变量覆盖缺乏类型校验** (第 71-76 行):
   ```python
   val = os.environ.get(env_var, "")
   if val:
       setattr(cfg, attr, val)
   ```
   所有环境变量值都被当作字符串设置。例如 `AI_FRIEND_DB_PATH` 是字符串，没问题；但如果未来添加数值类型的环境变量覆盖，这里会静默地将字符串赋给数值字段，可能导致后续类型错误。

3. **缺少配置校验**:
   `load_config` 返回的 `Config` 对象没有任何校验。例如 `api_key` 为空字符串时，后续 API 调用会失败，但失败点距离配置加载很远，调试困难。

4. **日志在配置加载前可能未初始化**:
   `config.py` 第 6 行创建了 `logger = logging.getLogger(__name__)`，但在 `load_config` 被调用时，日志系统可能尚未初始化（`setup_logging` 在 `main.py` 第 30 行才调用）。这意味着第 57、59、61、75 行的日志记录可能丢失或输出到默认的 `warnings` 流。

**位置**
- `D:\桌面\编程作品\AI朋友\config.py` 第 48-78 行

**风险等级**: **高**

**建议修复**

1. 细化异常处理：
   ```python
   if os.path.exists(path):
       try:
           with open(path, encoding="utf-8") as f:
               data = json.load(f)
       except json.JSONDecodeError as e:
           logger.warning(f"[config] invalid JSON in {path}: {e}, using defaults")
       except PermissionError:
           logger.error(f"[config] permission denied reading {path}")
           raise
       except OSError as e:
           logger.error(f"[config] OS error reading {path}: {e}")
           raise
       else:
           for k, v in data.items():
               if hasattr(cfg, k):
                   setattr(cfg, k, v)
           logger.info(f"[config] loaded from: {path}")
   ```

2. 添加配置校验函数：
   ```python
   def validate_config(cfg: Config) -> None:
       if not cfg.api_key:
           raise ValueError("api_key is required (set in config.json or DEEPSEEK_API_KEY env var)")
       if cfg.short_term_capacity < 1:
           raise ValueError("short_term_capacity must be >= 1")
       # ... more validations
   ```

3. 在 `load_config` 末尾调用 `validate_config(cfg)`。

---

### 发现 #5: 日志系统可能重复添加 Handler，导致重复输出

**问题描述**

`core/logging_setup.py` 第 22-37 行的 `setup_logging` 函数每次被调用都会无条件地向 root logger 添加两个 Handler（FileHandler 和 StreamHandler）：

```python
root = logging.getLogger()
root.setLevel(...)

fh = logging.FileHandler(log_file, encoding="utf-8")
fh.setFormatter(fmt)
root.addHandler(fh)

ch = logging.StreamHandler(sys.stderr)
ch.setFormatter(console_fmt)
root.addHandler(ch)
```

如果 `setup_logging` 被调用多次（例如在测试中被多次导入，或在 Web 热重载时），root logger 会累积多个 Handler，导致每条日志被重复输出多次。这是一个经典但容易被忽视的 Python 日志问题。

此外，FileHandler 每次调用都会创建新的文件句柄，如果调用频繁，可能导致文件描述符泄漏。

**位置**
- `D:\桌面\编程作品\AI朋友\core\logging_setup.py` 第 22-37 行

**风险等级**: **中**

**建议修复**

1. 在添加 Handler 前检查是否已存在相同类型的 Handler：
   ```python
   def setup_logging(level: str = "INFO") -> None:
       root = logging.getLogger()
       root.setLevel(getattr(logging, level.upper(), logging.INFO))
       
       # 检查是否已初始化
       if getattr(root, "_ai_friend_logging_setup", False):
           return
       
       # ... 创建 handlers ...
       
       root.addHandler(fh)
       root.addHandler(ch)
       root._ai_friend_logging_setup = True
   ```

2. 或者更优雅地，使用命名 logger 而非 root logger：
   ```python
   logger = logging.getLogger("ai_friend")
   logger.setLevel(...)
   # 只给 ai_friend logger 添加 handler
   ```

3. 更好的方案是使用 `logging.config.dictConfig` 进行一次性配置，避免程序化添加 Handler 的复杂性。

---

### 发现 #6: CLI 入口缺少对关键初始化失败的显式处理

**问题描述**

`main.py` 第 35-40 行：

```python
db = Database(config.db_path)
await db.open()
repo = Repository(db)

personality = Personality.load(config.personality_file)
```

这里 `db.open()` 是异步的，如果在 `await db.open()` 时发生异常（如数据库文件被占用、磁盘满、权限不足），异常会向上传播到 `asyncio.run(main())`，最终被 Python 运行时打印为未处理的异常。虽然这是默认行为，但用户体验不佳：用户看到的是 Python 的 traceback，而不是友好的错误信息。

同样，`Personality.load()` 在文件不存在时会静默创建默认人格（`core/personality.py` 第 89-90 行），这本身不是问题，但如果 `personality.json` 存在但内容损坏，会记录 warning 并使用默认值，用户可能不知道自己的配置被忽略了。

**位置**
- `D:\桌面\编程作品\AI朋友\main.py` 第 35-40 行
- `D:\桌面\编程作品\AI朋友\core\personality.py` 第 88-97 行

**风险等级**: **中**

**建议修复**

在 `main.py` 的 `main()` 函数中添加显式的初始化错误处理：

```python
async def main():
    try:
        config = load_config()
    except Exception as e:
        print(f"配置加载失败: {e}", file=sys.stderr)
        sys.exit(1)
    
    setup_logging(config.log_level)
    logger = logging.getLogger(__name__)
    
    try:
        db = Database(config.db_path)
        await db.open()
    except Exception as e:
        logger.error(f"数据库初始化失败: {e}")
        print(f"无法打开数据库 {config.db_path}: {e}", file=sys.stderr)
        sys.exit(1)
    
    try:
        personality = Personality.load(config.personality_file)
    except Exception as e:
        logger.error(f"人格配置加载失败: {e}")
        # 这里可以选择退出或继续使用默认人格
```

---

### 发现 #7: Web 入口的 `uvicorn.run` 参数硬编码，缺乏灵活性

**问题描述**

`web_main.py` 第 26-32 行：

```python
uvicorn.run(
    "web.server:app",
    host=host,
    port=port,
    reload=False,
    log_level="info",
)
```

`reload=False` 和 `log_level="info"` 是硬编码的，无法通过配置调整。在开发环境中，开发者通常希望 `reload=True`；在生产环境中，可能需要调整 uvicorn 的日志级别。`workers` 参数也未暴露，无法利用多进程提升性能。

此外，`uvicorn.run` 会阻塞当前线程，这意味着 `main()` 函数在服务器运行期间不会返回，这是预期的行为，但如果在 `main()` 中还有其他需要在启动后执行的逻辑（如健康检查、定时任务），则无法实现。

**位置**
- `D:\桌面\编程作品\AI朋友\web_main.py` 第 26-32 行

**风险等级**: **中**

**建议修复**

1. 从配置中读取 uvicorn 参数：
   ```python
   uvicorn.run(
       "web.server:app",
       host=host,
       port=port,
       reload=getattr(config, 'web_reload', False),
       log_level=getattr(config, 'web_log_level', 'info'),
       workers=getattr(config, 'web_workers', 1),
   )
   ```

2. 在 `Config` 类中添加相应字段：
   ```python
   web_reload: bool = False
   web_log_level: str = "info"
   web_workers: int = 1
   ```

---

### 发现 #8: `main.py` 的 `finally` 块中 `db.close()` 是同步调用，但 `Database.close()` 是异步的

**问题描述**

`main.py` 第 114-115 行：

```python
finally:
    db.close()
```

而 `storage/database.py` 第 136-140 行的 `close()` 方法是：

```python
async def close(self) -> None:
    if self.conn:
        logger.info(f"[db] closed: {self.db_path}")
        await self.conn.close()
        self.conn = None
```

在 `finally` 块中直接调用 `db.close()` 实际上不会执行 `await self.conn.close()`，因为 `close()` 返回的是一个协程对象，而不是执行关闭操作。这个协程对象被创建后立即被丢弃，数据库连接实际上没有被正确关闭。

这会导致：
1. SQLite WAL 文件（`-wal` 和 `-shm`）可能不会被正确清理
2. 文件句柄泄漏
3. 在程序退出时数据可能未完全落盘

**位置**
- `D:\桌面\编程作品\AI朋友\main.py` 第 114-115 行
- `D:\桌面\编程作品\AI朋友\storage\database.py` 第 136-140 行

**风险等级**: **中**

**建议修复**

方案 A：在 `finally` 块中使用 `asyncio.run()` 或确保在异步上下文中关闭：

```python
try:
    agent.run()
except KeyboardInterrupt:
    pass
finally:
    await db.close()
```

但这要求 `main()` 函数在 `finally` 块中能够使用 `await`。由于 `main()` 已经是 `async def`，这是可行的。

方案 B：为 `Database` 添加同步关闭方法，或修改 `main.py` 使用 `asyncio.run()` 包装关闭逻辑：

```python
finally:
    asyncio.get_event_loop().run_until_complete(db.close())
```

但如果在 `async def main()` 中使用 `run_until_complete`，在已有事件循环中可能会报错。最干净的方案是确保 `main()` 完全异步化，包括资源清理。

---

### 发现 #9: `config.json` 中 API 密钥以明文存储，存在安全风险

**问题描述**

`config.json` 第 3 行：

```json
"api_key": "sk-618d33e37dde45d5904b94838b779c64"
```

API 密钥以明文形式存储在 JSON 配置文件中，且该文件被纳入 Git 版本控制（从 `git status` 可以看到 `M config.json` 的修改状态）。这意味着：

1. 密钥可能已通过 Git 历史泄露
2. 任何能够访问项目文件的人都能看到密钥
3. 如果项目被开源或共享，密钥会公开暴露

虽然 `config.py` 支持通过 `DEEPSEEK_API_KEY` 环境变量覆盖，但配置文件中的明文密钥仍然是安全隐患。

**位置**
- `D:\桌面\编程作品\AI朋友\config.json` 第 3 行

**风险等级**: **中**

**建议修复**

1. **立即从 `config.json` 中删除 `api_key` 字段**，将其值设置为空字符串 `""`。
2. **轮换（revoke）当前密钥**，因为密钥可能已通过 Git 历史泄露。
3. **将 `config.json` 添加到 `.gitignore`**，或者创建一个 `config.example.json` 作为模板，让真实配置不被版本控制。
4. **强制使用环境变量**存储敏感信息，在 `validate_config` 中检查 `api_key` 是否为空，如果为空则报错并提示用户设置环境变量。
5. **清理 Git 历史**中的密钥（使用 `git filter-repo` 或 BFG Repo-Cleaner），如果仓库是私有的且从未共享过，风险较低；但如果曾经 push 到远程，必须轮换密钥。

---

### 发现 #10: `allowed_read_paths` 包含绝对路径，可移植性差

**问题描述**

`config.py` 第 32-38 行：

```python
allowed_read_paths: list[str] = field(default_factory=lambda: [
    ".",
    "D:\\音乐",
    "D:\\桌面",
    "~/Documents",
    "~/Downloads",
])
```

`allowed_read_paths` 中硬编码了 Windows 绝对路径 `D:\音乐` 和 `D:\桌面`。这导致：

1. 代码在不同机器上运行时，这些路径可能不存在，导致 `ReadFileTool` 的路径检查失败。
2. 如果项目需要在 Linux/macOS 上运行，这些 Windows 路径毫无意义。
3. `~`（用户主目录）的展开依赖于 `os.path.expanduser()`，在 `tools/file_tools.py` 第 42 行有处理，但默认值中混用 `.`、`~` 和绝对路径，风格不一致。

**位置**
- `D:\桌面\编程作品\AI朋友\config.py` 第 32-38 行
- `D:\桌面\编程作品\AI朋友\tools\file_tools.py` 第 31-48 行

**风险等级**: **中**

**建议修复**

1. 将默认的 `allowed_read_paths` 改为仅包含相对路径和通用路径：
   ```python
   allowed_read_paths: list[str] = field(default_factory=lambda: [
       ".",
       "~/Documents",
       "~/Downloads",
   ])
   ```

2. 在 `config.json` 中覆盖特定机器的路径，而不是在代码中硬编码。

3. 在 `ReadFileTool` 的路径解析中增加更清晰的错误提示，当路径不在允许列表中时，告知用户当前允许的根目录有哪些。

---

### 发现 #11: `ConsoleInterface` 在 `main.py` 中初始化但 `Agent` 构造时传入，而 `WebAgent` 中不传入

**问题描述**

`main.py` 第 82 行创建 `ui = ConsoleInterface()`，然后在第 98-107 行构造 `Agent` 时传入 `ui=ui`。而在 `web/session.py` 第 73-78 行构造 `Agent` 时，`ui` 参数被省略（默认为 `None`）。

`Agent.__init__` 的签名中 `ui` 是 `Optional[ConsoleInterface]`。这意味着 `Agent` 类必须同时处理 `ui` 为实例和为 `None` 的情况。从 `core/agent.py` 第 42 行和第 49 行可以看到，`ui` 确实是可选的。

这种设计导致 `Agent` 类与 `ConsoleInterface` 存在耦合，而 Web 路径实际上不需要 `ConsoleInterface`。更合理的做法是将 UI 交互抽象为一个接口（如 `UIInterface` 协议类），CLI 和 Web 分别实现，或者将 UI 逻辑完全从 `Agent` 中剥离。

**位置**
- `D:\桌面\编程作品\AI朋友\main.py` 第 82 行、第 98-107 行
- `D:\桌面\编程作品\AI朋友\web\session.py` 第 73-78 行
- `D:\桌面\编程作品\AI朋友\core\agent.py` 第 42、49 行

**风险等级**: **中**

**建议修复**

1. 定义一个 `UIInterface` 协议类：
   ```python
   from typing import Protocol
   
   class UIInterface(Protocol):
       def start(self) -> None: ...
       def stop(self) -> None: ...
       def display_banner(self, name: str) -> None: ...
   ```

2. `Agent` 类依赖 `UIInterface` 而非具体的 `ConsoleInterface`。

3. Web 路径可以传入一个 `NoOpUI` 实现，或者更好的做法是：将 UI 交互完全从 `Agent` 中移除，`Agent` 只负责核心逻辑，UI 层在 `CliController` 或 `WebAgent` 中处理。

---

### 发现 #12: `Personality.load()` 和 `Personality.save()` 的 IO 操作没有异常处理

**问题描述**

`core/personality.py` 第 113-116 行的 `save()` 方法：

```python
def save(self, path: str) -> None:
    logger.info(f"[personality] saved to: {path}")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
```

这里 `open()` 和 `json.dump()` 可能抛出 `OSError`（磁盘满、权限不足、路径不存在等），但没有异常处理。如果保存失败，异常会向上传播，可能导致 Web 请求的 500 错误或 CLI 的崩溃。

在 Web 路径中，`WebAgent.process_message()` 第 88 行调用 `self.personality.save(self.config.personality_file)`，这意味着每次用户消息都会触发一次文件写入。如果磁盘临时不可用，整个请求会失败。

**位置**
- `D:\桌面\编程作品\AI朋友\core\personality.py` 第 113-116 行
- `D:\桌面\编程作品\AI朋友\web\session.py` 第 84-89 行

**风险等级**: **中**

**建议修复**

1. 在 `save()` 中添加异常处理：
   ```python
   def save(self, path: str) -> None:
       try:
           with open(path, "w", encoding="utf-8") as f:
               json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
           logger.info(f"[personality] saved to: {path}")
       except OSError as e:
           logger.error(f"[personality] failed to save to {path}: {e}")
           raise
   ```

2. 考虑将 `personality.save()` 的调用频率降低，不要每次消息都保存。可以改为：
   - 定期保存（如每 N 轮）
   - 在程序退出时保存
   - 使用防抖机制（debounce），在最后一次修改后延迟保存

---

### 发现 #13: `EmbeddingEngine` 初始化时没有优雅降级处理

**问题描述**

`main.py` 第 70-73 行：

```python
from memory.embeddings import EmbeddingEngine
embed_engine = EmbeddingEngine(
    endpoint=config.embedding_endpoint,
    dim=config.embedding_dim,
)
```

`EmbeddingEngine` 在构造时不会检查嵌入服务是否可用。在 `memory/retrieval.py` 第 39 行和 54 行，通过 `self._embed.health_check()` 在运行时检查，但如果嵌入服务端点配置错误（如端口错误、服务未启动），这个错误直到第一次检索时才会被发现。

更关键的是，`EmbeddingEngine.encode()` 在失败时会抛出异常（`memory/embeddings.py` 第 48-50 行），而调用方（如 `retrieval.py` 第 112-115 行）有 try-except 回退到关键字搜索。这个回退机制是有效的，但初始化时的静默可能让开发者误以为嵌入服务已正确配置。

**位置**
- `D:\桌面\编程作品\AI朋友\main.py` 第 70-73 行
- `D:\桌面\编程作品\AI朋友\memory\embeddings.py` 第 74-83 行
- `D:\桌面\编程作品\AI朋友\memory\retrieval.py` 第 39-42 行

**风险等级**: **低**

**建议修复**

在 `main.py` 初始化 `EmbeddingEngine` 后，增加一次可选的健康检查并记录状态：

```python
embed_engine = EmbeddingEngine(endpoint=config.embedding_endpoint, dim=config.embedding_dim)
if embed_engine.health_check():
    logger.info("[embed] embedding service is healthy")
else:
    logger.warning(f"[embed] embedding service unavailable at {config.embedding_endpoint}, will fallback to keyword search")
```

这样开发者在启动时就能知道嵌入服务的状态。

---

### 发现 #14: `config.py` 的 `save_config` 没有原子写入，存在数据损坏风险

**问题描述**

`config.py` 第 81-83 行：

```python
def save_config(cfg: Config, path: str = CONFIG_PATH) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump({k: getattr(cfg, k) for k in cfg.__dataclass_fields__}, f, indent=2, ensure_ascii=False)
```

直接写入目标文件，如果程序在写入过程中崩溃，配置文件会被截断为不完整的内容，导致下次启动时 JSON 解析失败。

**位置**
- `D:\桌面\编程作品\AI朋友\config.py` 第 81-83 行

**风险等级**: **低**

**建议修复**

使用临时文件 + 原子重命名：

```python
import tempfile
import os

def save_config(cfg: Config, path: str = CONFIG_PATH) -> None:
    data = {k: getattr(cfg, k) for k in cfg.__dataclass_fields__}
    dir_name = os.path.dirname(os.path.abspath(path)) or "."
    fd, tmp_path = tempfile.mkstemp(dir=dir_name, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(tmp_path, path)
    except Exception:
        os.unlink(tmp_path)
        raise
```

---

### 发现 #15: `main.py` 中 `llm_generate` 和 `llm_rerank` 两个包装函数重复

**问题描述**

`main.py` 第 59-66 行：

```python
def llm_generate(prompt: str, temperature: float = 0.2) -> str:
    messages = [{"role": "user", "content": prompt}]
    return provider.generate(messages, stream=False)

def llm_rerank(prompt: str) -> str:
    messages = [{"role": "user", "content": prompt}]
    return provider.generate(messages, stream=False)
```

这两个函数的实现几乎完全相同，唯一的区别是 `llm_generate` 接受 `temperature` 参数而 `llm_rerank` 不接受。这种重复是不必要的，可以直接使用 `llm_generate` 替代 `llm_rerank`，或者将 `llm_rerank` 定义为 `llm_generate` 的偏函数。

**位置**
- `D:\桌面\编程作品\AI朋友\main.py` 第 59-66 行

**风险等级**: **低**

**建议修复**

```python
from functools import partial

def llm_generate(prompt: str, temperature: float = 0.2) -> str:
    messages = [{"role": "user", "content": prompt}]
    return provider.generate(messages, stream=False, temperature=temperature)

llm_rerank = partial(llm_generate, temperature=0.2)
```

或者直接在 `MemoryRetriever` 的构造中传入 `llm_generate`，因为 `llm_rerank` 和 `llm_generate` 的签名和用途已经趋同。

---

### 发现 #16: `web_main.py` 的 `print()` 输出与日志系统混合使用

**问题描述**

`web_main.py` 第 22-24 行：

```python
print(f"  AI Friend - {config.api_model}")
print(f"  Web: http://localhost:{port}")
print()
```

在已经配置了日志系统（第 14 行 `setup_logging`）的情况下，仍然使用 `print()` 输出启动信息。这导致输出流分裂：一部分信息通过 logging 框架输出（带时间戳、级别、logger 名），另一部分通过 `print()` 直接输出到 stdout。

在生产环境中，如果日志被重定向到文件或日志收集系统，`print()` 的输出可能会丢失或分散到不同的流。

**位置**
- `D:\桌面\编程作品\AI朋友\web_main.py` 第 22-24 行

**风险等级**: **低**

**建议修复**

统一使用日志输出：

```python
logger.info(f"AI Friend - {config.api_model}")
logger.info(f"Web: http://localhost:{port}")
```

如果需要在控制台显示简洁的启动信息（不带日志前缀），可以添加一个专门的 `ConsoleHandler` 或使用 `logging.StreamHandler` 配合不同的 formatter。

---

### 发现 #17: `SessionManager` 的 `cleanup_old` 方法存在字典顺序依赖

**问题描述**

`web/session.py` 第 169-174 行：

```python
def cleanup_old(self, max_sessions: int = 50) -> None:
    with self._lock:
        while len(self._sessions) > max_sessions:
            oldest = next(iter(self._sessions))
            self._sessions.pop(oldest)
            logger.info(f"Session evicted: {oldest}")
```

`next(iter(self._sessions))` 获取字典的"第一个"键。在 Python 3.7+ 中，字典保持插入顺序，所以这会弹出最早插入的会话。但这种方法依赖于字典顺序，不够明确。更重要的是，`cleanup_old` 方法似乎从未被调用——在 `web/server.py` 中没有找到对 `cleanup_old` 的调用。这意味着会话会无限增长，直到内存耗尽。

**位置**
- `D:\桌面\编程作品\AI朋友\web\session.py` 第 169-174 行
- `D:\桌面\编程作品\AI朋友\web\server.py` 全文

**风险等级**: **中**

**建议修复**

1. 在 `SessionManager` 中记录每个会话的最后访问时间，基于时间而非插入顺序进行清理：
   ```python
   self._session_access_time: dict[str, float] = {}
   ```

2. 在 `get_or_create` 中更新访问时间。

3. 在 `cleanup_old` 中按访问时间排序：
   ```python
   sorted_sessions = sorted(self._sessions.items(), 
                           key=lambda x: self._session_access_time.get(x[0], 0))
   ```

4. **最重要的是**：在 `web/server.py` 中定期调用 `cleanup_old`，例如在 `lifespan` 中启动一个后台任务，或在每次创建新会话时检查。

---

### 发现 #18: `Database` 类缺少连接池和并发控制

**问题描述**

`storage/database.py` 使用 `aiosqlite` 进行异步 SQLite 操作。`aiosqlite` 内部使用单个连接，而 SQLite 的并发写入性能有限。`Database` 类虽然有一个 `_lock`（`asyncio.Lock`），但这只在 `cursor()` 上下文管理器中使用。

更关键的是，`Database` 类没有连接池。在高并发 Web 场景下，所有请求共享同一个连接，虽然 `asyncio.Lock` 保证了操作的原子性，但无法充分利用 SQLite 的并发读取能力（通过 WAL 模式可以支持并发读取）。

此外，`Database` 没有超时设置。`aiosqlite.connect()` 默认没有 busy_timeout，如果数据库被锁定，操作会立即失败而不是等待。

**位置**
- `D:\桌面\编程作品\AI朋友\storage\database.py` 第 11-23 行

**风险等级**: **低**

**建议修复**

1. 设置 busy timeout：
   ```python
   async def open(self) -> None:
       # ...
       self.conn = await aiosqlite.connect(self.db_path, timeout=10.0)
       await self.conn.execute("PRAGMA busy_timeout = 5000")
       await self.conn.execute("PRAGMA journal_mode=WAL")
       # ...
   ```

2. 考虑使用连接池（如 `aiosqlite` 配合 `asqlite` 或自己实现简单的连接池），在高并发场景下提升性能。

---

## 3. 汇总统计

| 风险等级 | 数量 | 发现编号 |
|---------|------|---------|
| **高** | 4 | #1, #2, #3, #4 |
| **中** | 8 | #5, #6, #7, #8, #9, #10, #11, #12, #17 |
| **低** | 6 | #13, #14, #15, #16, #18 |
| **总计** | **18** | — |

### 按类别统计

| 类别 | 数量 | 相关发现 |
|------|------|---------|
| 代码重复/DRY | 2 | #1, #15 |
| 同步/异步混用 | 2 | #2, #8 |
| 配置管理 | 4 | #3, #4, #9, #10 |
| 资源生命周期 | 3 | #6, #8, #12 |
| 日志系统 | 2 | #5, #16 |
| 安全 | 1 | #9 |
| 架构耦合 | 2 | #1, #11 |
| 性能/可扩展性 | 2 | #17, #18 |
| 健壮性 | 2 | #13, #14 |

---

## 4. 优先修复建议

### 立即修复（本周内）

1. **#9 安全配置**: 从 `config.json` 中删除明文 API 密钥，轮换密钥，将真实配置加入 `.gitignore`。
2. **#4 配置校验**: 添加 `validate_config()` 函数，在启动时校验必要字段（`api_key` 非空等）。
3. **#8 数据库关闭**: 修复 `main.py` 中 `db.close()` 的异步调用问题，确保数据库正确关闭。

### 短期修复（本月内）

4. **#1 初始化重复**: 提取 `AgentBootstrap` 工厂类，统一 CLI 和 Web 的初始化逻辑。
5. **#3 Web 模块级状态**: 将 `web/server.py` 的模块级初始化移入 `lifespan`。
6. **#5 日志重复 Handler**: 修复 `setup_logging` 的重复添加问题。
7. **#2 同步/异步架构**: 评估将 CLI 完全异步化的可行性，消除 `_run_sync` 的嵌套事件循环风险。

### 中期改进（后续迭代）

8. **#11 UI 抽象**: 引入 `UIInterface` 协议，解耦 `Agent` 与 `ConsoleInterface`。
9. **#17 会话清理**: 实现基于 LRU 的会话清理机制，并在 Web 服务器中定期触发。
10. **#18 数据库优化**: 添加 busy timeout，评估连接池需求。

---

*报告结束*
