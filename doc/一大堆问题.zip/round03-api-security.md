# AI Friend 项目 API 密钥与认证安全审查报告

**审查日期**：2026-05-31
**审查范围**：`config.py`, `config.json`, `config.example.json`, `core/provider.py`, `main.py`, `web_main.py`, `web/session.py`, `web/server.py`, `core/logging_setup.py`, `tools/web_tools.py`, `tools/file_tools.py`, `memory/embeddings.py`, `.gitignore`
**审查目标**：API 密钥存储、传输、生命周期、日志泄漏、多用户隔离、密钥轮换等全链路安全

---

# 概述

AI Friend 项目是一个基于 DeepSeek API 的 AI 伴侣应用，支持 CLI 和 Web 两种运行模式。项目涉及两类外部 API 密钥：
1. **DeepSeek API Key** — 用于大语言模型推理（核心功能）
2. **AnySearch API Key** — 用于网络搜索和网页抓取（可选工具）

本次审查发现 **1 项严重风险、3 项高风险、5 项中风险、3 项低风险**，共计 12 项安全问题。最严重的问题是 `config.json` 中明文存储了真实的 DeepSeek API 密钥，且该文件已被提交到 Git 仓库历史中，存在密钥永久泄漏的风险。此外，项目在日志脱敏、内存密钥生命周期、多用户密钥隔离、HTTPS 传输验证、密钥轮换机制等方面均存在不同程度的安全缺陷。

---

# 详细发现

## S1 [严重] config.json 明文存储真实 API 密钥且已提交至 Git 历史

**风险评级**：严重
**相关文件**：`D:\桌面\编程作品\AI朋友\config.json`（第 3 行）

### 现象

`config.json` 文件中第 3 行明文存储了真实的 DeepSeek API 密钥：

```json
{
  "api_endpoint": "https://api.deepseek.com",
  "api_key": "sk-618d33e37dde45d5904b94838b779c64",
  ...
}
```

经检查，该文件虽然当前在 `.gitignore` 中被忽略（第 8 行 `config.json`），但 `git diff HEAD -- config.json` 显示该文件与 HEAD 版本无差异，说明此密钥已经存在于 Git 提交历史中。即使后续将文件加入 `.gitignore`，历史提交中的密钥仍然可通过 `git log -p -- config.json` 等命令被任何人获取。

### 影响

- 任何能够访问该 Git 仓库的人（包括未来的开源贡献者、CI/CD 系统、备份服务）都可以获取此密钥
- 密钥一旦泄漏到 Git 历史，几乎无法完全清除（`git filter-branch` 或 BFG Repo-Cleaner 可以清理，但已克隆的副本无法回收）
- 攻击者可以使用该密钥调用 DeepSeek API，造成直接的财务损失和数据滥用

### 根因分析

1. 开发者将包含真实密钥的配置文件直接提交到版本控制
2. `.gitignore` 规则是在密钥提交之后才添加的，或者添加后没有从历史中移除该文件
3. 项目缺乏密钥管理的开发规范，没有使用环境变量或专门的密钥管理服务

### 修复建议

1. **立即撤销该 API 密钥**：登录 DeepSeek 控制台，删除或禁用密钥 `sk-618d33e...`，生成新密钥
2. **从历史中清除**：使用 `git filter-repo` 或 BFG Repo-Cleaner 从整个 Git 历史中移除 `config.json` 文件
3. **强制所有协作者重新克隆**：历史清理后，所有已克隆的仓库副本仍然包含旧密钥，需要通知所有协作者删除旧副本并重新克隆
4. **建立密钥管理规范**：禁止将任何密钥提交到版本控制，使用环境变量或 `.env` 文件（已加入 `.gitignore`）

### 深度分析：Git 历史泄漏的不可逆性

Git 的设计哲学是内容的不可变性。一旦某个文件被提交到仓库，该内容就会永久存在于 Git 对象数据库中，直到执行显式的历史重写操作。对于 `config.json` 这样的敏感文件，即使后续将其加入 `.gitignore`，已提交的版本仍然可以通过以下方式被提取：

```bash
# 查看 config.json 的完整历史变更
git log -p -- config.json

# 查找所有包含 "sk-" 模式的提交
git log -S "sk-" --source --all

# 从对象数据库中直接提取文件内容
git cat-file -p $(git rev-list --all -- config.json | head -1):config.json
```

这意味着，如果该仓库曾经被推送到任何远程服务器（GitHub、GitLab、私有 Git 服务器），或者曾经被任何协作者克隆到本地，那么密钥的副本就已经分布在多个不可控的位置。即使执行了 `git filter-repo` 清理主仓库，已经存在的 fork、clone、mirror 仍然保留原始历史。

更为严重的是，GitHub 等公共平台会对仓库内容进行索引和缓存。一旦密钥被推送到公共仓库，恶意扫描工具（如 GitHub 的 secret scanning、第三方安全扫描机器人）可能在几分钟内就发现并记录该密钥。即使立即删除仓库或清理历史，也无法保证密钥未被外部系统缓存。

因此，对于已提交到 Git 历史的真实密钥，**唯一有效的补救措施是立即撤销该密钥**。历史清理是为了防止未来更多的人发现旧密钥，但无法挽回已经发生的泄漏。

---

## S2 [高] 日志系统未对 API 密钥进行脱敏处理，存在泄漏风险

**风险评级**：高
**相关文件**：`D:\桌面\编程作品\AI朋友\core/provider.py`（第 28 行）、`D:\桌面\编程作品\AI朋友\config.py`（第 74-75 行）

### 现象

在 `core/provider.py` 第 28 行，`KimiProvider` 初始化时将 API 密钥直接设置到 `requests.Session` 的请求头中：

```python
self.session.headers.update({
    "Authorization": f"Bearer {api_key}",
    "Content-Type": "application/json",
})
```

虽然此处没有直接打印密钥，但存在以下日志泄漏路径：

1. **config.py 环境变量日志**（第 74-75 行）：
   ```python
   masked = "***" if "KEY" in env_var else val
   logger.info(f"[config] env override: {env_var}={masked}")
   ```
   这段代码意图对环境变量中的密钥进行脱敏，但存在两个问题：
   - 脱敏逻辑仅基于变量名是否包含 `"KEY"`，如果环境变量名不符合此模式（如 `DEEPSEEK_TOKEN`），密钥将以明文记录
   - 脱敏后的值为 `"***"`，无法区分密钥是否已设置，也不记录密钥长度或哈希，不利于审计

2. **requests 库底层日志**：当启用 `requests` 库的调试日志（如通过 `HTTP_DEBUG=1` 或修改日志级别）时，`requests` 会记录完整的请求头，包括 `Authorization: Bearer sk-...`，导致密钥泄漏到日志文件

3. **异常堆栈中的密钥暴露**：如果 API 请求发生异常（如连接超时、HTTP 错误），异常对象可能包含完整的请求对象或响应对象，其中带有 `Authorization` 头。Python 的异常回溯（traceback）会打印这些对象的 `repr()`，从而泄漏密钥

### 影响

- 日志文件通常具有较宽松的权限（`logs/YYYY-MM-DD.log` 默认继承项目目录权限）
- 日志可能被备份到外部系统（如 ELK、Sentry、云监控），扩大泄漏面
- 开发者在调试时可能将包含密钥的日志片段粘贴到公共论坛或聊天工具中

### 修复建议

1. **添加全局日志过滤器**：在 `core/logging_setup.py` 中添加 `SecretsFilter`，对包含 `Bearer sk-`、`api_key`、`apikey` 等模式的日志内容进行自动脱敏替换
2. **自定义 requests 适配器**：子类化 `requests.adapters.HTTPAdapter`，在 `send()` 方法中拦截日志输出，确保 `Authorization` 头不被记录
3. **异常处理时擦除密钥**：在 `KimiProvider._do_request()` 和 `generate()` 的异常处理中，捕获异常后主动清除异常对象中可能包含的请求头信息
4. **改进脱敏逻辑**：在 `config.py` 中，对所有敏感字段（不仅限于名称含 `KEY` 的变量）统一脱敏，并记录密钥哈希（如 SHA-256 前 8 位）以便审计

### 深度分析：Python 日志系统的密钥泄漏路径

Python 的 `logging` 模块是一个分层的日志系统，根日志记录器（root logger）的配置会影响所有子记录器。在 AI Friend 项目中，`setup_logging()` 函数配置了根记录器的 `FileHandler` 和 `StreamHandler`，这意味着所有通过 `logging.getLogger(__name__)` 获取的记录器都会继承这些处理器。

`requests` 库在调试级别（`logging.DEBUG`）会记录完整的 HTTP 请求和响应信息，包括所有请求头。如果开发者临时将日志级别调整为 `DEBUG` 以排查问题，`Authorization` 头将以明文形式出现在日志文件中：

```
2026-05-31 10:00:00 [DEBUG] urllib3.connectionpool: https://api.deepseek.com:443 "POST /v1/chat/completions HTTP/1.1" 200 None
2026-05-31 10:00:00 [DEBUG] urllib3.connectionpool: header: Authorization: Bearer sk-618d33e37dde45d5904b94838b779c64
```

此外，Python 的异常对象在回溯（traceback）中会包含完整的局部变量和对象状态。如果 API 请求发生异常，异常处理链中的 `requests.Session` 对象可能包含带有密钥的请求头。当这个异常被记录或打印时，密钥会随 traceback 一起输出：

```python
try:
    resp = self.session.post(url, json=payload)
except Exception as e:
    # e 可能包含 session 对象的引用，进而包含 api_key
    logger.error(f"Request failed: {e}")  # 可能泄漏密钥
```

更为隐蔽的风险来自第三方日志聚合服务。如果项目未来集成 Sentry、Datadog、Loggly 等服务，这些服务会收集日志和异常信息。如果没有预先配置脱敏规则，密钥将被发送到第三方服务器，扩大信任边界。

---

## S3 [高] 多用户 Web 场景下所有会话共享同一 API 密钥，无隔离机制

**风险评级**：高
**相关文件**：`D:\桌面\编程作品\AI朋友\web/session.py`（第 40-46 行）、`D:\桌面\编程作品\AI朋友\web/server.py`（第 17-18 行）

### 现象

在 `web/session.py` 中，`WebAgent` 初始化时直接使用全局 `config.api_key`：

```python
self.provider = KimiProvider(
    endpoint=config.api_endpoint, api_key=config.api_key,
    model=config.api_model, temperature=config.temperature,
    max_tokens=config.max_tokens,
    thinking=config.thinking, reasoning_effort=config.reasoning_effort,
    timeout=config.api_timeout,
)
```

`SessionManager` 为每个 Web 会话创建独立的 `WebAgent` 实例，但所有实例共享同一个 `Config` 对象和同一个 `api_key`。在 `web/server.py` 第 17-18 行：

```python
config = load_config()
session_manager = SessionManager(config)
```

全局只加载一次配置，所有会话共用。

### 影响

- **无法区分不同用户的 API 调用成本**：如果未来支持多用户各自使用自己的 API 密钥，当前架构无法支持
- **单点密钥泄漏影响所有用户**：如果密钥被撤销或限额耗尽，所有用户同时受影响
- **缺乏用户级速率限制**：恶意用户可以通过大量请求耗尽 API 配额，影响其他正常用户
- **审计追踪困难**：无法将 API 调用与具体用户关联，不利于安全审计和滥用追踪

### 根因分析

项目当前设计为单用户本地运行（`0.0.0.0:8000` 监听所有接口），没有多租户架构的概念。`SessionManager` 虽然管理多个会话，但会话之间仅隔离了对话历史和人格状态，没有隔离底层资源（API 密钥、数据库连接等）。

### 修复建议

1. **短期**：在文档中明确声明当前版本为单用户模式，不建议部署到公网多用户环境
2. **中期**：引入用户配置隔离机制，允许每个会话通过请求参数或用户认证信息指定独立的 API 密钥
3. **长期**：设计多租户架构，每个用户拥有独立的 `Config` 副本和 API 密钥，并在数据库中记录每个用户的 API 调用量和成本
4. **添加速率限制**：在 `web/server.py` 中为每个 session_id 添加基于内存或 Redis 的速率限制，防止单用户耗尽配额

### 深度分析：共享密钥架构的安全隐患

当前 `SessionManager` 的设计虽然在会话层面隔离了对话历史（`short_term`）和人格状态（`personality`），但在底层资源层面是完全共享的。所有 `WebAgent` 实例共享同一个 `Database` 连接、同一个 `Repository` 实例、同一个 `Config` 对象，以及同一个 `api_key`。

这种架构在单用户本地使用场景下没有问题，但一旦部署到公网或局域网供多人使用，就会产生以下攻击面：

**会话劫持风险**：当前 WebSocket 端点（`/ws`）仅通过 `session_id` 标识会话，没有任何身份验证机制。攻击者如果猜测或枚举到其他用户的 `session_id`，就可以通过 WebSocket 发送 `{"type": "init", "session_id": "目标会话ID"}` 来劫持该会话。由于所有会话共享同一个 API 密钥，劫持者不仅可以读取对话历史，还可以消耗 API 配额。

**配额耗尽攻击**：`SessionManager.cleanup_old()` 方法仅在会话数量超过 50 个时才进行清理，且没有基于时间的过期机制。攻击者可以通过不断创建新会话来填满会话池，每个会话都会触发 proactive 行为（每 15 秒检查一次），从而产生大量 API 调用。由于所有会话共享同一个密钥，攻击者可以轻易耗尽该密钥的月度配额，导致正常用户无法使用。

**成本不可追踪**：`KimiProvider` 的日志仅记录模型名称和 token 数量，没有记录是哪个 `session_id` 发起的请求。如果密钥的 API 账单出现异常消费，无法追溯是哪一个会话或哪一个用户造成的，给安全事件响应带来极大困难。

---

## S4 [高] 无 API 密钥轮换机制，密钥长期有效

**风险评级**：高
**相关文件**：`D:\桌面\编程作品\AI朋友\config.py`（全局）、`D:\桌面\编程作品\AI朋友\core/provider.py`（全局）

### 现象

项目中没有任何密钥轮换（Key Rotation）相关的代码或文档：

- `Config` 数据类只有一个 `api_key` 字段，没有 `api_key_secondary`、`api_key_expires_at` 等字段
- `KimiProvider` 初始化后密钥固定不变，运行期间不支持热切换
- 没有定时任务检查密钥有效期或自动轮换逻辑
- 没有密钥失效后的优雅降级机制（如切换到备用密钥或提示用户更新）

### 影响

- 密钥一旦泄漏，在手动撤销前将长期有效，攻击者有充足时间滥用
- 如果密钥被第三方服务（如 DeepSeek）强制轮换，应用将突然停止工作，没有平滑过渡方案
- 不符合安全合规要求（如 SOC 2、ISO 27001 要求定期轮换凭证）

### 修复建议

1. **支持多密钥配置**：在 `Config` 中添加 `api_key_secondary` 字段，主密钥失效时自动切换
2. **热重载机制**：实现配置热重载（如监听文件变化或定时重新加载），无需重启服务即可更新密钥
3. **密钥有效期监控**：在 `KimiProvider` 中记录密钥首次使用时间，接近建议轮换周期时发出警告日志
4. **失效自动检测**：当 API 返回 401/403 认证错误时，尝试使用备用密钥，并记录轮换事件

### 深度分析：密钥轮换的行业实践

密钥轮换（Key Rotation）是现代云安全的核心实践之一。AWS、Google Cloud、Azure 等主流云平台都建议或强制要求定期轮换 API 密钥和访问凭证。DeepSeek 等 AI API 提供商虽然通常不强制轮换，但从安全最佳实践角度，建议至少每 90 天更换一次密钥。

当前 AI Friend 项目的密钥管理处于"静态配置"模式：密钥在应用启动时从 `config.json` 或环境变量加载，之后在整个进程生命周期内保持不变。这种模式存在几个关键问题：

**无平滑过渡机制**：当需要更换密钥时，必须停止正在运行的服务，修改配置文件，然后重新启动。对于 Web 模式，这意味着所有在线用户都会被强制断开连接。在生产环境中，这种中断是不可接受的。

**无失效检测**：`KimiProvider.generate()` 方法虽然有重试逻辑（3 次尝试，指数退避），但重试仅针对连接错误（`ConnectionError`）和 5xx 服务端错误。对于 401 Unauthorized 或 403 Forbidden 等认证错误，代码会直接抛出异常，没有尝试备用密钥或给出明确的用户提示。

**无轮换审计**：即使手动更换了密钥，项目中也没有任何记录表明密钥何时被更换、由谁更换、旧密钥何时失效。在安全审计时，这种信息的缺失会导致无法追溯密钥的生命周期。

理想的密钥轮换流程应该包括：
1. 同时配置新旧两个密钥
2. 新密钥创建后有一个并行期（如 24 小时），期间两个密钥都有效
3. 应用优先使用新密钥，新密钥失败时回退到旧密钥
4. 旧密钥在并行期结束后被标记为失效
5. 所有轮换事件记录到审计日志

---

## S5 [中] 未验证 HTTPS 证书或强制 TLS 版本

**风险评级**：中
**相关文件**：`D:\桌面\编程作品\AI朋友\core/provider.py`（第 87-92 行）、`D:\桌面\编程作品\AI朋友\memory/embeddings.py`（第 31-35 行）、`D:\桌面\编程作品\AI朋友\tools/web_tools.py`（第 28-30 行）

### 现象

`core/provider.py` 第 87-92 行使用 `requests.Session.post()` 发送 API 请求：

```python
resp = self.session.post(
    url,
    json=payload,
    stream=True,
    timeout=self.timeout,
)
```

`memory/embeddings.py` 第 31-35 行：

```python
resp = self._session.post(
    self._endpoint,
    json={"input": texts},
    timeout=self._timeout,
)
```

`tools/web_tools.py` 第 28-30 行：

```python
session = requests.Session()
session.trust_env = False
resp = session.post(ANYSEARCH_ENDPOINT, json=payload, headers=headers, timeout=30)
```

以上所有 HTTP 请求均未显式配置 `verify=True`（虽然 `requests` 默认启用证书验证），也没有强制最低 TLS 版本（如 TLS 1.2+）。在 Windows 环境下，如果系统证书存储被篡改或存在恶意代理，可能存在中间人攻击风险。

### 影响

- 在不受信任的网络环境（如公共 WiFi）中，攻击者可能通过伪造证书实施中间人攻击，截获 API 密钥和请求内容
- 如果系统被植入恶意根证书，`requests` 的默认验证可能无法发现

### 修复建议

1. **显式启用证书验证**：在所有 `requests` 调用中显式设置 `verify=True`，并考虑使用 `certifi` 提供的证书包而非系统证书
2. **强制 TLS 1.2+**：通过自定义 `HTTPAdapter` 配置 `ssl.SSLContext`，设置 `minimum_version=ssl.TLSVersion.TLSv1_2`
3. **证书固定（可选）**：对于 DeepSeek API 等固定端点，考虑实现证书固定（Certificate Pinning），进一步降低中间人攻击风险

### 深度分析：TLS/SSL 配置的隐蔽风险

`requests` 库默认启用证书验证（`verify=True`），这看似安全，但实际上存在多个隐蔽的风险点：

**系统证书存储的可信度**：`requests` 在 Windows 上使用系统的证书存储进行验证。如果系统被恶意软件感染，攻击者可能向系统证书存储中添加伪造的根证书。这种情况下，`requests` 的验证会通过，但连接实际上被中间人攻击了。使用 `certifi` 包提供的独立证书包可以减少这种依赖。

**TLS 版本降级攻击**：虽然 `requests` 底层使用 `urllib3`，而 `urllib3` 默认使用系统 SSL 库的最高支持版本，但在某些老旧系统或特定配置下，可能协商到 TLS 1.0 或 TLS 1.1。这些旧版本存在已知漏洞（如 BEAST、POODLE），不应被用于传输 API 密钥等敏感信息。

**SNI（Server Name Indication）问题**：`requests` 默认启用 SNI，这在现代环境中没有问题。但如果部署在非常老旧的 Python 版本（如 Python 2.7）或特定嵌入式环境中，SNI 可能不被支持，导致连接失败或证书验证错误。虽然 AI Friend 项目使用 Python 3，但这是一个值得注意的兼容性风险。

**代理环境的证书问题**：`core/provider.py` 和 `memory/embeddings.py` 都设置了 `session.trust_env = False`，这是正确的做法，可以防止 Windows 系统代理拖慢请求。但这也意味着 `requests` 不会读取系统环境变量中的 `HTTP_PROXY`、`HTTPS_PROXY` 等代理设置。如果用户确实需要通过代理连接 API，这种设置会导致连接失败。项目需要在安全性和功能性之间取得平衡，例如允许用户显式配置代理，而不是完全禁用环境代理。

---

## S6 [中] 配置文件权限未限制，其他用户可读

**风险评级**：中
**相关文件**：`D:\桌面\编程作品\AI朋友\config.json`（文件系统权限）

### 现象

`config.json` 的文件权限为 `0o100666`（即 `-rw-rw-rw-`），表示所有用户（包括系统上的其他用户）都具有读写权限。在 Windows 环境下，虽然 POSIX 权限模型不完全适用，但文件仍然对同一台机器上的其他用户账户可见和可读写。

### 影响

- 如果服务器被多用户共享（如远程桌面服务器、家庭共用电脑），其他用户可以读取 `config.json` 获取 API 密钥
- 如果应用以管理员权限运行，低权限进程可能通过文件句柄继承等方式访问该文件
- 备份工具、同步工具（如 OneDrive、Dropbox）可能将该文件同步到云端，扩大暴露面

### 修复建议

1. **创建配置时设置权限**：在 `save_config()` 函数中，保存文件后调用 `os.chmod(path, 0o600)` 限制仅所有者可读写
2. **启动时检查权限**：在 `load_config()` 中增加权限检查，如果文件权限过于宽松（如 group/other 可读），发出安全警告日志
3. **Windows ACL 设置**：在 Windows 上使用 `ctypes` 或 `win32security` 设置更严格的 ACL，仅当前用户可访问

### 深度分析：Windows 文件权限的复杂性

在 Unix/Linux 系统上，文件权限模型相对简单：用户（owner）、组（group）、其他（other）三类权限。`os.chmod(path, 0o600)` 可以确保只有文件所有者能够读写。但在 Windows 系统上，权限模型基于 ACL（Access Control List），更加复杂。

Windows 的 POSIX 权限模拟（通过 `os.chmod`）并不完全等同于 Unix 的行为。`0o100666` 在 Windows 上通常表示文件对当前用户可读写，对其他用户也开放读写权限（取决于父目录的继承设置）。这意味着：

- 如果该文件位于用户目录（如 `C:\Users\Username\Documents`），其他标准用户通常无法访问，因为目录本身的 ACL 会阻止访问
- 但如果文件位于共享目录（如 `D:\桌面\编程作品\AI朋友`），且该目录的 ACL 允许其他用户访问，那么 `config.json` 的宽松权限就会成为一个实际问题
- 如果系统启用了 UAC（用户账户控制），管理员权限的进程可以访问所有用户的文件，但标准用户进程不应能跨用户边界访问

此外，Windows 的备份和同步服务（如 OneDrive、Dropbox、Google Drive）通常以当前用户身份运行，因此它们可以读取 `config.json` 并将其同步到云端。如果用户的云账户被攻破，密钥将随配置文件一起泄漏。

另一个容易被忽视的渠道是 Windows 的卷影复制（Volume Shadow Copy）和文件历史记录功能。即使后续删除了 `config.json` 或更换了密钥，旧版本的文件可能仍然存在于系统备份中，攻击者可以通过这些备份恢复旧密钥。

---

## S7 [中] .gitignore 对密钥文件的保护不完整

**风险评级**：中
**相关文件**：`D:\桌面\编程作品\AI朋友\.gitignore`

### 现象

`.gitignore` 文件内容如下：

```
# Config with keys
config.json

# Runtime
.env
```

虽然 `config.json` 和 `.env` 已被忽略，但存在以下问题：

1. **未忽略备份文件**：没有忽略 `config.json.bak`、`config.json~`、`config_backup.json` 等常见备份文件命名模式
2. **未忽略 IDE 配置文件**：`.vscode/settings.json`、`.idea/` 等 IDE 配置目录中可能包含密钥（如某些 IDE 的 HTTP Client 配置）
3. **未忽略临时文件**：没有忽略 `*.tmp`、`*.swp`、`*~` 等临时文件，这些文件可能是在编辑 `config.json` 时产生的，包含密钥内容
4. **历史提交未清理**：如前所述，`.gitignore` 只能防止未来提交，无法保护已存在于历史中的密钥

### 影响

- 开发者可能在备份或临时编辑时不小心将包含密钥的文件提交到 Git
- IDE 自动生成的配置文件中可能缓存了 API 密钥
- 历史提交中的密钥永久存在，即使 `.gitignore` 已完善

### 修复建议

1. **扩展 .gitignore**：
   ```
   # Config backups
   config.json.*
   config*.json.bak
   *.json~
   *~
   *.tmp
   *.swp

   # IDE secrets
   .vscode/settings.json
   .idea/httpRequests/
   ```
2. **使用 Git 钩子**：添加 `pre-commit` 钩子，扫描提交内容中是否包含 `sk-` 开头的 DeepSeek 密钥模式，发现时阻止提交
3. **历史清理**：如前所述，使用 `git filter-repo` 从历史中移除所有包含密钥的提交

### 深度分析：Git 泄漏的扩展攻击面

`.gitignore` 是防止敏感文件进入版本控制的第一道防线，但它不是唯一的防线，也不是最可靠的防线。开发者在使用 Git 时可能通过多种方式绕过 `.gitignore`：

**强制添加**：使用 `git add -f config.json` 或 `git add --force` 可以强制将已被忽略的文件添加到暂存区。如果开发者在调试时修改了 `config.json` 并习惯性地执行 `git add .`，然后发现需要强制添加，密钥就会进入提交。

**IDE 集成**：许多现代 IDE（如 VS Code、PyCharm）提供了图形化的 Git 提交界面。这些界面通常会在提交前显示所有变更文件的列表。如果开发者没有仔细检查这个列表，可能会不小心勾选并提交 `config.json`。

**子模块和依赖**：如果项目未来引入 Git 子模块或依赖其他 Git 仓库，子模块中的 `.gitignore` 配置不会自动继承到主仓库。如果子模块中包含密钥文件，主仓库的 `.gitignore` 无法保护它们。

**Git 工作树**：使用 `git worktree` 创建多个工作目录时，每个工作目录都有自己的 `.gitignore` 生效，但共享同一个对象数据库。如果一个工作目录中不小心提交了密钥，它会立即出现在所有工作目录的历史中。

**pre-commit 钩子的局限性**：虽然 pre-commit 钩子可以在本地阻止包含密钥的提交，但钩子本身可以被绕过（`git commit --no-verify`）。此外，pre-commit 钩子不会生效于通过 GitHub Web 界面直接编辑文件、通过 API 提交、或使用没有安装钩子的 Git 客户端进行的提交。

因此，`.gitignore` 和 pre-commit 钩子应该作为防御体系的一部分，而不是唯一的依赖。最根本的解决方案是：**不在任何本地文件中存储真实密钥**，而是使用环境变量或外部密钥管理服务。

---

## S8 [中] API 密钥在内存中以明文形式长期驻留

**风险评级**：中
**相关文件**：`D:\桌面\编程作品\AI朋友\core/provider.py`（第 18 行）、`D:\桌面\编程作品\AI朋友\web/session.py`（第 40-46 行）

### 现象

`KimiProvider` 将 API 密钥以明文字符串形式存储在实例属性中：

```python
self.api_key = api_key
```

该字符串在 Python 的内存中作为普通对象存在，直到垃圾回收。在 Web 模式下，`WebAgent` 实例被 `SessionManager` 长期持有（第 126 行 `self._sessions: dict[str, WebAgent] = {}`），即使会话空闲，密钥仍然驻留在内存中。

### 影响

- 如果进程被转储（如通过 `gcore`、Windows 任务管理器的"创建转储文件"功能），内存中的密钥可以被提取
- 如果存在内存泄漏或缓冲区溢出漏洞，攻击者可能读取相邻内存区域获取密钥
- Python 的字符串驻留（interning）机制可能导致密钥字符串在内存中存活更久，即使显式删除引用也可能无法立即释放

### 修复建议

1. **使用安全字符串类型**：考虑使用 `bytearray` 或专门的 `SecureString` 类存储密钥，需要时临时解码，使用后立即清零内存
2. **最小化密钥驻留时间**：在 `KimiProvider` 中不长期保存 `api_key`，而是在每次请求前从环境变量或安全存储中动态获取
3. **会话超时清理**：在 `SessionManager` 中为空闲会话设置超时（如 30 分钟无活动自动移除），释放关联的 `WebAgent` 和 `KimiProvider` 实例
4. **进程内存保护**：在文档中建议用户启用操作系统级的内存保护功能（如 Windows 的 Credential Guard、Linux 的 `mlock`）

### 深度分析：Python 内存管理与密钥安全

Python 作为一门高级动态语言，其内存管理机制对密钥安全提出了特殊挑战：

**字符串不可变性**：Python 的 `str` 类型是不可变的。一旦创建，字符串内容在内存中保持不变，直到垃圾回收器回收该对象。即使执行 `api_key = ""`，原来的字符串对象并不会被立即覆盖或清零，它只是失去了引用，等待垃圾回收。在垃圾回收之前，该内存区域仍然包含完整的密钥内容，可以通过内存扫描工具提取。

**字符串驻留（Interning）**：Python 会对短字符串进行自动驻留，即在全局字符串池中维护唯一副本。如果 API 密钥的某些子串恰好与代码中的其他字符串匹配，这些子串可能被驻留，从而在内存中长期存在，即使原始的 `api_key` 变量已被删除。

**内存碎片与复制**：在 `KimiProvider` 的初始化过程中，`api_key` 字符串被多次复制：
1. 从 `config.api_key` 传递到 `KimiProvider.__init__`
2. 存储到 `self.api_key`
3. 格式化为 `f"Bearer {api_key}"` 存储到请求头
4. `requests` 库内部可能再次复制该字符串用于 HTTP 编码

每一次复制都会在内存中留下一个新的密钥副本，增加了被提取的风险。

**垃圾回收的不确定性**：Python 使用引用计数为主、分代垃圾回收为辅的内存管理策略。字符串对象的回收时间取决于引用计数何时归零，以及分代回收器何时运行。在长时间运行的 Web 服务中，密钥字符串可能存活数小时甚至数天。

**进程转储的威胁**：在 Windows 上，任何具有调试权限的进程都可以使用 `MiniDumpWriteDump` API 创建另一个进程的内存转储文件。如果 AI Friend 以普通用户权限运行，同一用户会话中的恶意软件可以轻易地转储其内存并搜索 `sk-` 模式来提取密钥。

---

## S9 [中] AnySearch API 密钥管理同样存在缺陷

**风险评级**：中
**相关文件**：`D:\桌面\编程作品\AI朋友\tools/web_tools.py`（第 18-21 行）

### 现象

`tools/web_tools.py` 中的 `_anysearch_api()` 函数从环境变量获取 AnySearch API 密钥：

```python
api_key = os.environ.get("ANYSEARCH_API_KEY", "")
headers = {"Content-Type": "application/json"}
if api_key:
    headers["Authorization"] = f"Bearer {api_key}"
```

存在以下问题：

1. **空密钥仍发送请求**：如果 `ANYSEARCH_API_KEY` 未设置或为空字符串，代码仍然发送请求（只是不带 `Authorization` 头），可能导致请求被服务端拒绝，但错误处理不够明确
2. **无密钥时无警告**：未设置密钥时没有任何日志警告，用户可能不知道搜索功能因缺少密钥而受限
3. **与 DeepSeek 密钥同样存在日志泄漏风险**：`Authorization` 头同样可能被 `requests` 调试日志或异常堆栈记录

### 影响

- AnySearch 密钥同样面临日志泄漏、内存暴露等风险
- 缺少密钥时的静默失败可能导致用户体验下降，开发者难以排查问题

### 修复建议

1. **统一密钥管理**：将 AnySearch 密钥也纳入 `Config` 数据类管理，支持 `config.json` 和环境变量双重配置
2. **空密钥时明确报错**：如果密钥未设置，在工具执行时返回明确的错误信息，提示用户设置 `ANYSEARCH_API_KEY`
3. **共享脱敏逻辑**：复用为 DeepSeek 密钥设计的日志过滤器和异常处理逻辑

---

## S10 [低] 未使用专门的密钥管理服务或加密存储

**风险评级**：低
**相关文件**：`D:\桌面\编程作品\AI朋友\config.py`（全局）

### 现象

项目完全依赖文件系统（`config.json`）和环境变量存储密钥，没有使用任何专门的密钥管理服务：

- 无 HashiCorp Vault、AWS Secrets Manager、Azure Key Vault 等集成
- 无操作系统密钥环（如 Windows Credential Manager、`keyring` Python 库）支持
- `config.json` 中的密钥以明文 JSON 存储，无加密

### 影响

- 在本地开发环境可以接受，但在生产环境或团队共享环境中安全性不足
- 配置文件备份时密钥一同备份，增加泄漏面
- 不符合企业级安全合规要求

### 修复建议

1. **支持操作系统密钥环**：集成 `keyring` 库，优先从操作系统密钥环读取 API 密钥，回退到环境变量和配置文件
2. **支持加密配置文件**：使用用户密码或机器指纹对 `config.json` 中的敏感字段进行 AES-256 加密
3. **文档说明**：在部署文档中说明生产环境应使用环境变量或密钥管理服务，不建议使用明文配置文件

---

## S11 [低] Web 端点未启用 HTTPS，Authorization 头明文传输

**风险评级**：低
**相关文件**：`D:\桌面\编程作品\AI朋友\web_main.py`（第 26-32 行）、`D:\桌面\编程作品\AI朋友\config.py`（第 29 行）

### 现象

`web_main.py` 启动 uvicorn 时未配置 SSL/TLS：

```python
uvicorn.run(
    "web.server:app",
    host=host,
    port=port,
    reload=False,
    log_level="info",
)
```

`config.py` 中 `web_host` 默认为 `"0.0.0.0"`，监听所有网络接口。虽然 DeepSeek API 请求是从服务器端到 DeepSeek 服务端（HTTPS），但用户浏览器与 AI Friend Web 服务器之间的通信是 HTTP 明文。

### 影响

- 如果 Web 服务部署在公网或局域网中，中间人可以截获用户与 AI Friend 之间的通信内容
- 虽然 API 密钥不会直接传输到浏览器（密钥仅在服务器端使用），但用户的对话内容可能被窃听
- 如果未来支持用户通过 Web 界面配置 API 密钥，该密钥将以明文传输到服务器

### 修复建议

1. **文档警告**：在 README 中明确说明默认 HTTP 模式仅适用于本地开发，公网部署必须配置 HTTPS
2. **提供 HTTPS 配置示例**：在 `config.example.json` 中添加 `ssl_certfile` 和 `ssl_keyfile` 字段，并在 `web_main.py` 中支持传递给 `uvicorn.run()`
3. **本地开发提示**：启动时如果检测到 `host != "127.0.0.1"` 且未配置 SSL，打印安全警告

---

## S12 [低] 缺乏 API 调用审计和异常监控

**风险评级**：低
**相关文件**：`D:\桌面\编程作品\AI朋友\core/provider.py`（第 100-103 行、第 130-133 行）

### 现象

`KimiProvider` 的日志仅记录基本的调用统计：

```python
logger.info(
    f"[api] model={self.model} stream=off "
    f"tok_in={usage.get('prompt_tokens', '?')} tok_out={usage.get('completion_tokens', '?')} "
    f"duration={elapsed:.2f}s chars_in={input_chars} chars_out={len(content)}"
)
```

缺少以下安全相关的审计信息：

1. **无请求指纹**：没有记录请求的唯一标识（如 UUID），无法追踪单个请求的全链路
2. **无异常详情记录**：当 API 返回 401/403 认证错误时，仅记录通用的 `HTTPError`，没有记录具体的错误响应体，不利于排查是密钥无效还是配额耗尽
3. **无调用频率监控**：没有记录单位时间内的 API 调用次数，无法检测异常流量（如密钥被盗用后的高频调用）
4. **无成本追踪**：没有累计 API 调用成本，无法及时发现异常消费

### 影响

- 密钥被盗用后，无法通过日志及时发现异常调用模式
- API 服务返回认证错误时，难以快速定位是密钥问题还是服务端问题
- 缺乏数据支持进行安全事件的事后分析

### 修复建议

1. **添加请求 ID**：为每个 API 请求生成 UUID，记录到日志中，并在异常时关联
2. **详细错误记录**：在 HTTP 错误处理中，安全地记录状态码和错误响应摘要（注意脱敏）
3. **调用频率统计**：在 `KimiProvider` 中添加简单的内存计数器，记录最近 1 小时内的调用次数，超过阈值时发出警告
4. **成本估算**：根据 `usage.prompt_tokens` 和 `usage.completion_tokens` 估算每次调用的成本，累计到日志中

---

# 汇总统计

| 风险等级 | 数量 | 问题编号 |
|---------|------|---------|
| 严重 | 1 | S1 |
| 高 | 3 | S2, S3, S4 |
| 中 | 5 | S5, S6, S7, S8, S9 |
| 低 | 3 | S10, S11, S12 |
| **合计** | **12** | — |

## 按维度分布

| 审查维度 | 涉及问题 | 最严重等级 |
|---------|---------|-----------|
| API 密钥存储方式 | S1, S6, S10 | 严重 |
| 密钥在日志中的泄漏风险 | S2, S9 | 高 |
| 密钥在内存中的生命周期 | S8 | 中 |
| 请求头中 Authorization 的传输安全 | S5, S11 | 中 |
| 配置文件的权限和访问控制 | S1, S6, S7 | 严重 |
| .gitignore 是否有效保护密钥 | S1, S7 | 严重 |
| 多用户场景下的密钥隔离 | S3 | 高 |
| 密钥轮换机制 | S4 | 高 |

## 优先级修复建议

### 立即执行（P0）
1. **撤销并更换 DeepSeek API 密钥**（S1）
2. **从 Git 历史中移除 config.json**（S1, S7）
3. **为日志系统添加密钥脱敏过滤器**（S2）

### 短期执行（P1）
4. **限制配置文件权限为 0o600**（S6）
5. **扩展 .gitignore 并添加 pre-commit 钩子**（S7）
6. **实现多密钥配置和热重载**（S4）
7. **为 Web 模式添加速率限制**（S3）

### 中期执行（P2）
8. **显式启用 HTTPS 证书验证和 TLS 1.2+**（S5）
9. **优化内存中密钥的生命周期管理**（S8）
10. **统一 AnySearch 和 DeepSeek 的密钥管理**（S9）
11. **添加 API 调用审计和异常监控**（S12）

### 长期规划（P3）
12. **集成操作系统密钥环或 KMS**（S10）
13. **为 Web 部署提供 HTTPS 配置支持**（S11）
14. **设计多租户架构下的密钥隔离方案**（S3）

---

*报告生成时间：2026-05-31*
*审查人：Claude Code 安全审查*
