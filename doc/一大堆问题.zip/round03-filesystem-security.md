# AI Friend 项目文件系统安全审查报告

**审查日期**: 2026-05-31
**审查范围**: tools/file_tools.py, tools/search_tools.py, config.py, core/provider.py 及相关调用链
**审查人**: Claude Code
**风险评级标准**: 严重(Critical) / 高(High) / 中(Medium) / 低(Low) / 信息(Info)

---

# 概述

AI Friend 项目通过 `ReadFileTool`、`GlobTool`、`GrepTool` 三个工具向 LLM 提供文件系统访问能力，同时 `MusicPlayTool` 和 `MusicListTool` 也涉及受限的文件系统操作。本报告聚焦文件系统访问安全，从路径白名单机制、路径遍历攻击防御、符号链接风险、目录遍历控制、二进制文件检测、文件大小限制、写入操作风险、Windows/Linux 路径差异等八个维度进行全面审查。

经过深度代码审计，共发现 **2 个严重风险**、**3 个高风险**、**5 个中风险** 和 **4 个低风险** 问题。最严重的问题是 `ReadFileTool` 和 `GlobTool`/`GrepTool` 共享的白名单机制存在路径遍历绕过漏洞，在 Windows 环境下可通过 `..\..\` 和符号链接组合绕过目录限制，读取系统敏感文件。此外，API 密钥以明文形式存储在 `config.json` 中，存在信息泄露风险。

---

# 详细发现

## 1. ReadFileTool 的路径白名单机制

### 1.1 白名单配置与解析逻辑

**文件**: `config.py` 第 32-38 行

```python
allowed_read_paths: list[str] = field(default_factory=lambda: [
    ".",
    "D:\\音乐",
    "D:\\桌面",
    "~/Documents",
    "~/Downloads",
])
```

**文件**: `tools/file_tools.py` 第 31-48 行

```python
def _get_allowed_roots() -> list[str]:
    try:
        from config import load_config
        cfg = load_config()
        paths = []
        project = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        for p in getattr(cfg, 'allowed_read_paths', []):
            if p == ".":
                paths.append(project)
            else:
                paths.append(os.path.abspath(os.path.expanduser(p)))
        if project not in paths:
            paths.append(project)
        return paths
    except Exception as e:
        logger.warning(f"Config load failed for allowed roots, using project fallback: {e}")
        return [os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))]
```

**风险评级**: **中风险 (Medium)**

**分析**:

白名单机制的设计意图是合理的：通过配置 `allowed_read_paths` 限制 LLM 可访问的目录范围，并在运行时通过 `_get_allowed_roots()` 解析为绝对路径。`os.path.expanduser()` 正确处理了 `~` 前缀（如 `~/Documents`），`os.path.abspath()` 将相对路径解析为绝对路径。

然而，该机制存在以下问题：

1. **默认配置过于宽泛**: 默认配置包含了 `D:\桌面` 和 `D:\音乐` 两个用户目录。在 Windows 系统上，`桌面` 通常是用户存放各类文件的地方，可能包含敏感文档、快捷方式（指向其他位置的符号链接）、甚至密码管理器导出的文件。`~/Downloads` 同理，下载目录经常包含临时敏感文件。

2. **配置持久化风险**: `config.py` 第 81-83 行的 `save_config()` 函数会将整个配置对象（包括 `allowed_read_paths`）序列化到 `config.json`。如果攻击者能够通过其他手段修改 `config.json`，就可以扩大白名单范围。虽然这不是直接的文件系统漏洞，但构成了配置层面的攻击面。

3. **缺少运行时变更审计**: 白名单在每次工具调用时动态加载（`_get_allowed_roots()` 每次都重新调用 `load_config()`），这意味着如果 `config.json` 在运行时被修改，新的白名单会立即生效，但没有任何日志记录白名单的变更。

**建议**:
- 将默认白名单收紧，移除 `D:\桌面` 和 `~/Downloads`，仅保留项目目录和明确需要的目录。
- 在 `_get_allowed_roots()` 中加入变更检测和审计日志。
- 考虑将白名单配置与运行时配置分离，避免通过 `save_config()` 意外修改。

---

### 1.2 路径检查函数 `_path_in_allowed()`

**文件**: `tools/file_tools.py` 第 51-61 行

```python
def _path_in_allowed(filepath: str) -> str | None:
    resolved = os.path.abspath(filepath)
    for root in _get_allowed_roots():
        try:
            if resolved.startswith(os.path.abspath(root)):
                return resolved
        except Exception as e:
            logger.debug(f"Path check failed for root {root}: {e}")
            continue
    return None
```

**风险评级**: **严重 (Critical)**

**分析**:

这是整个文件系统安全机制的核心检查函数，但它存在**严重的设计缺陷**。

**问题 1: `str.startswith()` 路径前缀匹配的固有漏洞**

`resolved.startswith(os.path.abspath(root))` 是 Python 中常见的路径安全检查反模式。虽然在本项目中由于 `os.path.abspath()` 的使用，单纯的 `../` 攻击在大多数情况下会被解析为绝对路径后无法匹配，但该检查仍然存在绕过可能：

- **符号链接绕过**: 如果白名单目录内存在指向白名单外的符号链接（symlink）或 junction point，`os.path.abspath()` 不会解析符号链接，而是返回符号链接本身的路径。因此，如果 `D:\音乐\link_to_c_drive` 是一个指向 `C:\` 的 junction，`os.path.abspath("D:\\音乐\\link_to_c_drive\\Windows\\System32\\config\\SAM")` 返回的路径仍然以 `D:\\音乐` 开头，检查通过。但实际 `open()` 操作会读取 `C:\Windows\System32\config\SAM` 的内容。

- **大小写敏感性问题**: 在 Windows 上，文件系统不区分大小写，但 Python 的 `str.startswith()` 区分大小写。虽然 `os.path.abspath()` 在 Windows 上返回的路径大小写与传入参数一致，但如果通过某些方式构造大小写不一致的路径（如 `d:\\音乐` vs `D:\\音乐`），在某些边缘情况下可能产生不一致行为。不过，由于 `os.path.abspath()` 会规范化驱动器字母为大写，这个问题在此项目中影响较小。

**问题 2: 缺少路径规范化中的符号链接解析**

正确的做法应该是使用 `os.path.realpath()` 而非 `os.path.abspath()`。`realpath()` 会解析所有符号链接，返回文件的真实物理路径。当前代码：

```python
resolved = os.path.abspath(filepath)  # 不解析符号链接！
```

应改为：

```python
resolved = os.path.realpath(filepath)  # 解析符号链接
```

**问题 3: 目录遍历符在边界处的绕过**

考虑以下场景：白名单根目录为 `D:\音乐`，攻击者传入路径 `D:\音乐\..\..\Windows\System32\config\SAM`。`os.path.abspath()` 会将其解析为 `D:\Windows\System32\config\SAM`。这个路径以 `D:\音乐` 开头吗？不，它以 `D:\Windows` 开头，所以检查会失败。这看起来是安全的。

但如果白名单根目录末尾没有路径分隔符呢？例如，如果根目录是 `D:\音乐`（没有尾部反斜杠），攻击者传入 `D:\音乐fake\..\..\Windows\System32\config\SAM`，`os.path.abspath()` 会解析为 `D:\Windows\System32\config\SAM`，仍然安全。

真正的风险在于**符号链接**。假设 `D:\音乐\纯音乐` 是一个 junction point，指向 `C:\Users\Public\Music`。攻击者请求 `D:\音乐\纯音乐\..\..\Windows\System32\config\SAM`。`os.path.abspath()` 不会展开 junction point，它看到的是 `D:\音乐\纯音乐\..\..\...`，经过规范化后可能仍然是 `D:\音乐\纯音乐\..\..\...` 的某种形式。但实际上，当 `os.path.abspath()` 处理 `..` 时，它纯粹是字符串层面的路径规范化，不涉及文件系统查询。因此 `D:\音乐\纯音乐\..` 会被规范化为 `D:\音乐`，检查通过。但如果 `纯音乐` 是一个 junction point 指向 `C:\Users\Public\Music`，那么实际的文件系统遍历在 `..` 时会回到 `C:\Users\Public`，而不是 `D:\音乐`。

等等，这里需要更仔细地分析。`os.path.abspath()` 是纯字符串操作，它不知道 `纯音乐` 是 junction point。所以 `D:\音乐\纯音乐\..\secret.txt` 经过 `abspath` 后变成 `D:\音乐\secret.txt`，检查通过。但实际的 `open()` 操作在文件系统层面会解析 junction point，`..` 在 `C:\Users\Public\Music` 的父目录是 `C:\Users\Public`，所以实际打开的文件是 `C:\Users\Public\secret.txt`。这取决于 junction point 的目标。

实际上这个分析有误。在 Windows 上，`os.path.abspath("D:\\音乐\\纯音乐\\..")` 确实返回 `D:\\音乐`，因为 `abspath` 不知道 `纯音乐` 是 junction。但如果 `纯音乐` 是一个 junction point 指向 `C:\Users\Public\Music`，那么 `os.path.abspath()` 返回的路径是 `D:\\音乐`，检查通过。然后 `open("D:\\音乐\\纯音乐\\..\\secret.txt")` 时，Windows 文件系统驱动会解析 junction point，`..` 在 `C:\Users\Public\Music` 的上下文中会回到 `C:\Users\Public`。所以实际访问的是 `C:\Users\Public\secret.txt`。但 `open()` 的参数路径本身仍然是 `D:\\音乐\\纯音乐\\..\\secret.txt`，`os.path.abspath()` 已经把它规范化为 `D:\\音乐\\secret.txt`。

让我重新思考。`_path_in_allowed` 检查的是规范化后的路径是否以白名单根开头。如果传入 `D:\音乐\纯音乐\..\..\Windows\System32\config\SAM`，`os.path.abspath()` 会解析为 `D:\Windows\System32\config\SAM`（因为 `D:\音乐\纯音乐\..` = `D:\音乐`，再 `..` 就是 `D:\`）。这个路径不以 `D:\音乐` 开头，所以检查失败。

但如果传入的是 `D:\音乐\纯音乐\..\secret.txt`，`abspath` 返回 `D:\音乐\secret.txt`，以 `D:\音乐` 开头，检查通过。实际文件系统访问时，如果 `纯音乐` 是 junction 指向 `C:\Users\Public\Music`，那么 `D:\音乐\纯音乐\..\secret.txt` 实际解析到 `C:\Users\Public\secret.txt`。但 `os.path.abspath()` 已经把它规范化为 `D:\音乐\secret.txt`，检查通过了。然后 `open()` 打开 `D:\音乐\secret.txt` 还是 `C:\Users\Public\secret.txt`？

答案是：`open()` 会打开 `D:\音乐\secret.txt`。因为 `os.path.abspath()` 的规范化结果才是实际传入 `open()` 的路径。等等，不对。`_path_in_allowed` 接收的是 `filepath` 参数，它调用 `os.path.abspath(filepath)` 得到 `resolved`，然后检查 `resolved` 是否以 root 开头。如果检查通过，返回 `resolved`。然后 `_read_one` 使用 `resolved` 进行 `os.path.exists(resolved)` 和 `open(resolved)` 操作。

所以如果 `filepath = "D:\\音乐\\纯音乐\\..\\secret.txt"`，`os.path.abspath()` 返回 `D:\\音乐\\secret.txt`。检查通过。然后 `open("D:\\音乐\\secret.txt")` 打开的是 `D:\音乐\secret.txt`，不是 junction 目标下的文件。所以这个特定的攻击向量不成立。

但是！如果攻击者传入 `filepath = "D:\\音乐\\纯音乐\\secret.txt"`，而 `纯音乐` 是一个 junction point 指向 `C:\Users\Public\Music`，那么 `os.path.abspath("D:\\音乐\\纯音乐\\secret.txt")` 返回 `D:\\音乐\\纯音乐\\secret.txt`。这个路径以 `D:\\音乐` 开头，检查通过。然后 `open("D:\\音乐\\纯音乐\\secret.txt")` 实际打开的是 `C:\Users\Public\Music\secret.txt`。这就是**符号链接绕过**！

**结论**: `_path_in_allowed()` 使用 `os.path.abspath()` 而非 `os.path.realpath()`，导致无法检测通过符号链接/junction point 的目录穿越攻击。

**建议**:
1. 立即将 `os.path.abspath()` 替换为 `os.path.realpath()`。
2. 在白名单根目录后追加路径分隔符再进行前缀匹配，防止 `D:\音乐fake` 匹配 `D:\音乐` 的情况（虽然 `abspath` 已经处理了，但防御性编程更好）。
3. 考虑使用 `pathlib.Path.resolve()`，它在 Python 3.6+ 中提供了更现代的路径处理。

---

## 2. 路径遍历攻击防御

### 2.1 `../` 和 `..\` 序列处理

**文件**: `tools/file_tools.py` 第 52-53 行, `tools/search_tools.py` 第 15-16 行

```python
# file_tools.py
resolved = os.path.abspath(filepath)

# search_tools.py
resolved = os.path.abspath(search_path)
```

**风险评级**: **高风险 (High)**

**分析**:

`os.path.abspath()` 在规范化路径时会正确处理 `..` 和 `.` 序列。例如：
- `os.path.abspath("D:\\音乐\\..\\..\\Windows\\System32\\config\\SAM")` → `D:\\Windows\\System32\\config\\SAM`
- `os.path.abspath("D:\\音乐\\subdir\\..\\..\\secret.txt")` → `D:\\secret.txt`

这些规范化后的路径不会以 `D:\\音乐` 开头，因此 `startswith` 检查会正确拒绝它们。

**但是**，存在以下绕过场景：

**场景 1: 双重编码/URL 编码**

如果 LLM 或攻击者传入经过 URL 编码的路径，如 `D:\音乐\%2e%2e\%2e%2e\Windows\System32\config\SAM`。`os.path.abspath()` 不会解码 URL 编码，它会将其视为字面量 `%2e%2e`。因此规范化后的路径是 `D:\音乐\%2e%2e\%2e%2e\Windows\System32\config\SAM`，这仍然以 `D:\音乐` 开头，检查通过。但实际的 `open()` 调用会尝试打开一个不存在的文件（因为文件名中包含 `%2e%2e`）。所以这种攻击不成立，除非操作系统或 Python 的 `open()` 会自动解码 URL 编码——实际上不会。

**场景 2: NTFS 备用数据流 (Alternate Data Streams)**

在 Windows NTFS 上，文件可以有备用数据流，语法为 `filename:streamname`。例如 `D:\音乐\song.mp3:$DATA` 或 `D:\音乐\song.mp3:secret`。`os.path.abspath()` 会保留这个冒号，检查通过。`open()` 会打开备用数据流而不是主文件。虽然这不直接构成目录穿越，但如果白名单目录内有文件其备用数据流包含敏感信息，或者可以利用备用数据流执行某些操作，则存在风险。不过本项目只读取文本内容，且备用数据流仍然在同一个文件内，风险较低。

**场景 3: 空字节注入**

在 Python 3 中，`open()` 不接受空字节（`\x00`），会抛出 `ValueError: embedded null byte`。所以空字节注入不成立。

**场景 4: 软链接/硬链接/Junction Point 穿越（已在 1.2 中详细分析）**

这是最主要的风险向量。`_path_in_allowed()` 不解析符号链接，允许通过白名单目录内的符号链接访问白名单外的文件。

**场景 5: 大小写混淆**

Windows 文件系统不区分大小写。`os.path.abspath()` 在 Windows 上会保留传入的大小写，但驱动器字母会大写。如果白名单根是 `D:\音乐`，传入 `d:\音乐\secret.txt`，`abspath` 返回 `D:\音乐\secret.txt`，仍然以 `D:\音乐` 开头。安全。

但如果白名单根是 `D:\音乐`（小写 `d`），`os.path.abspath("D:\\音乐")` 返回 `D:\\音乐`（大写 D）。`os.path.abspath(root)` 返回 `d:\\音乐`（小写 d）。`"D:\\音乐".startswith("d:\\音乐")` 在 Python 中返回 `False`，因为字符串比较区分大小写。这意味着如果配置中的路径大小写与传入路径不一致，可能导致合法请求被拒绝。这是可用性问题而非安全问题。

**场景 6: 相对路径的边界条件**

当传入相对路径时，`os.path.abspath()` 会相对于当前工作目录解析。例如，如果 CWD 是 `D:\桌面\编程作品\AI朋友`，传入 `..\..\..\Windows\System32\config\SAM`，`abspath` 解析为 `D:\Windows\System32\config\SAM`。如果白名单包含项目目录 `D:\桌面\编程作品\AI朋友`，那么检查 `D:\Windows\System32\config\SAM.startswith("D:\\桌面\\编程作品\\AI朋友")` 返回 `False`。安全。

但如果传入的是 `..\..\..\桌面\secret.txt`，`abspath` 解析为 `D:\桌面\secret.txt`。如果白名单包含 `D:\桌面`，检查通过。这实际上是合法访问，因为 `D:\桌面` 确实在白名单中。

**总结**: 直接的 `../` 路径遍历攻击被 `os.path.abspath()` 有效防御。真正的风险在于符号链接绕过（见 1.2）和某些边缘情况。

**建议**:
1. 使用 `os.path.realpath()` 替代 `os.path.abspath()` 以解析符号链接。
2. 对传入路径进行更严格的预处理，拒绝包含空字节、控制字符的路径。
3. 考虑添加路径规范化后的二次验证。

---

### 2.2 符号链接和 Junction Point 风险

**风险评级**: **严重 (Critical)**

**分析**:

这是本次审查发现的**最严重的安全漏洞**。

在 Windows 上，存在三种类型的重解析点（reparse points）：
1. **符号链接 (Symbolic Link)**: 需要管理员权限创建，可以指向文件或目录。
2. **Junction Point**: 不需要管理员权限，只能指向目录，可以跨卷。
3. **硬链接 (Hard Link)**: 只能指向同一卷上的文件，不能指向目录。

当前代码完全不防御这些机制：

```python
# tools/file_tools.py 第 52-53 行
resolved = os.path.abspath(filepath)
# 不调用 os.path.realpath()，不解析符号链接
```

**攻击场景**:

假设攻击者（或 LLM 在用户诱导下）执行以下操作：

1. 用户在 `D:\音乐` 目录下创建一个 junction point：`mklink /J "D:\音乐\系统文件" "C:\Windows\System32"`
2. LLM 调用 `read_file` 工具，路径为 `D:\音乐\系统文件\config\SAM`
3. `_path_in_allowed("D:\\音乐\\系统文件\\config\\SAM")` 调用 `os.path.abspath()`，返回 `D:\\音乐\\系统文件\\config\\SAM`
4. 检查 `D:\\音乐\\系统文件\\config\\SAM.startswith("D:\\音乐")` → `True`
5. 检查通过，`open("D:\\音乐\\系统文件\\config\\SAM")` 实际打开 `C:\\Windows\\System32\\config\\SAM`
6. 成功读取 Windows SAM 数据库（虽然需要 SYSTEM 权限才能读取，但其他系统文件如 `C:\Windows\System32\drivers\etc\hosts` 可以被普通用户读取）

另一个更现实的攻击：

1. 在 `D:\桌面` 下创建 junction `mklink /J "D:\桌面\我的文档" "C:\Users\<用户名>\Documents"`
2. LLM 读取 `D:\桌面\我的文档\passwords.txt`
3. 检查通过，实际读取用户的 `Documents\passwords.txt`

**影响**:
- 可以读取用户任意目录下的文件，只要能在白名单目录内创建一个指向目标目录的 junction point。
- 在 Windows 上，普通用户无需管理员权限即可创建 junction point（从 Windows Vista 开始）。
- 即使 LLM 不主动创建 junction point，用户计算机上可能已经存在 junction point（例如某些软件安装时创建的）。

**修复方案**:

```python
import os

def _path_in_allowed(filepath: str) -> str | None:
    """Resolve and check path is in an allowed directory. Returns absolute path or None."""
    # 使用 realpath 解析符号链接、junction point 和硬链接
    resolved = os.path.realpath(filepath)
    for root in _get_allowed_roots():
        try:
            root_real = os.path.realpath(root)
            # 确保根目录末尾有路径分隔符，防止前缀匹配漏洞
            prefix = root_real if root_real.endswith(os.sep) else root_real + os.sep
            if resolved == root_real or resolved.startswith(prefix):
                return resolved
        except Exception as e:
            logger.debug(f"Path check failed for root {root}: {e}")
            continue
    return None
```

**建议**:
1. **立即修复**: 将 `os.path.abspath()` 替换为 `os.path.realpath()`。
2. **追加分隔符**: 在白名单根目录后追加 `os.sep` 再进行前缀匹配，防止 `D:\音乐fake` 匹配 `D:\音乐`。
3. **符号链接检测**: 在 `open()` 之前，可以额外检查路径或其任何父目录是否为符号链接，如果是则拒绝或记录警告。

---

## 3. GlobTool 和 GrepTool 的目录遍历风险

### 3.1 GlobTool 的搜索路径解析

**文件**: `tools/search_tools.py` 第 14-23 行, 第 55-65 行

```python
def _resolve_search_path(search_path: str) -> str | None:
    resolved = os.path.abspath(search_path)
    for root in _get_allowed_roots():
        try:
            if resolved.startswith(os.path.abspath(root)):
                return resolved
        except Exception:
            pass
    return None

class GlobTool(Tool):
    def execute(self, args: dict[str, Any]) -> ToolResult:
        pattern = args.get("pattern", "").strip()
        search_root = args.get("path", ".").strip()
        # ...
        root = _resolve_search_path(search_root)
        if root is None:
            return ToolResult.fail(f"路径不在可访问范围内: {search_root}")
        # os.walk(root) ...
```

**风险评级**: **高风险 (High)**

**分析**:

`GlobTool` 存在与 `ReadFileTool` 相同的路径检查漏洞：使用 `os.path.abspath()` 而非 `os.path.realpath()`，不解析符号链接。

此外，`GlobTool` 还有其特有的风险：

**问题 1: `os.walk()` 遍历符号链接子目录**

`os.walk()` 默认会**跟随**符号链接进入子目录（在 Python 3.2+ 中，`os.walk()` 的 `followlinks` 参数默认为 `False`，但实际上 `os.walk()` 在 Windows 上对 junction point 的处理取决于底层行为）。

在 `tools/search_tools.py` 第 68 行：

```python
for dirpath, _, fnames in os.walk(root):
```

这里没有设置 `followlinks=False`。在 Unix 上，Python 的 `os.walk()` 默认 `followlinks=False`，不会进入符号链接目录。但在 Windows 上，`os.walk()` 对 junction point 的处理是将其视为普通目录遍历，因为 Windows 的 junction point 在文件系统层面就是目录。

这意味着如果 `D:\音乐\子目录` 是一个 junction point 指向 `C:\Windows\System32`，`GlobTool` 的 `os.walk()` 会遍历 `C:\Windows\System32` 下的所有文件，并将它们作为搜索结果返回。虽然 `_resolve_search_path()` 检查的是起始路径，但 `os.walk()` 会递归进入 junction point 目标目录。

**问题 2: 搜索结果泄露目录结构**

即使无法读取文件内容，`GlobTool` 返回的文件列表本身就可能泄露敏感信息。例如，如果 junction point 指向 `C:\Users\<用户名>\AppData\Roaming\Mozilla\Firefox\Profiles\<profile>\`，`glob` 搜索 `**/*.json` 可能返回 `logins.json`、`key4.db` 等文件名，泄露用户使用了 Firefox 浏览器及其配置文件结构。

**问题 3: 结果数量无上限导致的 DoS**

`GlobTool` 对结果数量做了限制（最多显示 200 个），但 `os.walk()` 在限制之前会遍历整个目录树。如果起始目录是一个指向大型目录树（如 `C:\`）的 junction point，`os.walk()` 可能遍历数十万个文件，导致显著的 CPU 和 I/O 消耗，构成拒绝服务攻击。

**建议**:
1. 将 `_resolve_search_path()` 中的 `os.path.abspath()` 替换为 `os.path.realpath()`。
2. 在 `os.walk()` 中显式设置 `followlinks=False`（虽然 Windows 上 junction point 不受此参数控制，但防御性编程）。
3. 在遍历过程中增加实时计数器，当已遍历文件数超过某个阈值（如 10000）时提前终止，防止 DoS。
4. 对遍历的每个目录调用 `os.path.realpath()`，检查是否仍在白名单范围内。

---

### 3.2 GrepTool 的搜索路径解析

**文件**: `tools/search_tools.py` 第 97-223 行

```python
class GrepTool(Tool):
    def execute(self, args: dict[str, Any]) -> ToolResult:
        # ...
        target = _resolve_search_path(search_path)
        if target is None:
            return ToolResult.fail(f"路径不在可访问范围内: {search_path}")
        # ...
        if os.path.isfile(target):
            files = [target]
        else:
            for dirpath, _, fnames in os.walk(target):
                if any(skip in dirpath for skip in ["__pycache__", ".git", "node_modules", ".venv", "data"]):
                    continue
                for fname in fnames:
                    full = os.path.join(dirpath, fname)
                    rel = os.path.relpath(full, target)
                    if fnmatch.fnmatch(fname, file_glob) or fnmatch.fnmatch(rel, file_glob):
                        try:
                            if os.path.getsize(full) <= self.MAX_SIZE:
                                files.append(full)
                        except OSError:
                            pass
```

**风险评级**: **高风险 (High)**

**分析**:

`GrepTool` 继承了与 `GlobTool` 相同的路径检查漏洞和 `os.walk()` 遍历风险。

此外，`GrepTool` 还有以下特有风险：

**问题 1: 正则表达式 ReDoS**

`GrepTool` 允许 LLM 提供任意正则表达式：

```python
regex = re.compile(pattern, re.IGNORECASE if ignore_case else 0)
```

如果 LLM 或攻击者提供具有灾难性回溯的正则表达式（如 `(a+)+$` 匹配大量 `a` 后接 `b`），可能导致 CPU 100% 占用，构成正则表达式拒绝服务（ReDoS）。

虽然 `GrepTool` 有文件大小限制（500KB）和结果数量限制（50 个匹配），但单个文件内的正则匹配仍可能消耗大量 CPU 时间。

**问题 2: 二进制文件读取**

`GrepTool` 以 `encoding="utf-8", errors="ignore"` 打开文件：

```python
with open(filepath, encoding="utf-8", errors="ignore") as f:
    lines = f.readlines()
```

这比 `ReadFileTool` 的 `errors="replace"` 更宽松。对于二进制文件，`errors="ignore"` 会静默丢弃无法解码的字节，可能导致匹配到意外的文本片段。虽然 `GrepTool` 没有显式的二进制检测，但 500KB 的文件大小限制在一定程度上缓解了这个问题。

**问题 3: 跳过目录列表不完整**

```python
if any(skip in dirpath for skip in ["__pycache__", ".git", "node_modules", ".venv", "data"]):
    continue
```

这个跳过逻辑使用子字符串匹配（`"data" in dirpath`），可能导致误跳。例如，如果有一个目录叫 `my_data_analysis`，它会因为包含 `"data"` 而被跳过。更严重的是，它跳过了 `data` 目录，但 `data` 目录可能正是项目存储 SQLite 数据库的地方（`config.py` 中 `db_path = "data/ai_friend.db"`）。虽然跳过 `data` 目录可以防止 LLM 读取数据库文件，但如果用户将其他重要文件放在 `data` 目录下，也会被跳过。

另一方面，跳过列表缺少一些常见的敏感目录，如 `.ssh`、`.gnupg`、`.aws`、`.docker` 等。

**建议**:
1. 修复路径检查，使用 `os.path.realpath()`。
2. 为正则表达式匹配添加超时机制（使用 `signal` 或 `threading.Timer`）。
3. 完善跳过目录列表，使用精确匹配而非子字符串匹配。
4. 在 `os.walk()` 中加入实时路径验证，确保遍历过程中不离开白名单范围。

---

## 4. 文件读取的权限边界

### 4.1 文件系统权限检查

**文件**: `tools/file_tools.py` 第 104-112 行, 第 144-150 行

```python
if not os.path.exists(resolved):
    return ToolResult.fail(f"文件不存在: {filepath}")

# If it's a directory, list contents
if os.path.isdir(resolved):
    try:
        items = sorted(os.listdir(resolved))
    except PermissionError:
        return ToolResult.fail(f"无权限访问目录: {filepath}")
    # ...

try:
    with open(resolved, encoding="utf-8", errors="replace") as f:
        all_lines = f.readlines()
except PermissionError:
    return ToolResult.fail(f"无权限: {filepath}")
except Exception as e:
    return ToolResult.fail(f"读取失败: {e}")
```

**风险评级**: **低风险 (Low)**

**分析**:

`ReadFileTool` 对 `PermissionError` 进行了适当的捕获和处理，当文件或目录没有读取权限时返回友好的错误信息。这是良好的实践。

但存在以下问题：

**问题 1: 目录列表权限与文件读取权限不一致**

`ReadFileTool` 允许列出目录内容（第 108-132 行），即使目录内的某些文件没有读取权限。目录列表本身就可能泄露敏感信息。例如，列出 `C:\Users\<用户名>\AppData\Local\Microsoft\Windows\INetCookies` 目录可以看到所有 cookie 文件名，即使无法读取内容。

**问题 2: 目录列表中的文件大小信息**

在列出目录时，代码尝试获取每个文件的大小：

```python
sz = os.path.getsize(full)
```

如果文件存在但无法访问大小信息（例如权限不足），会抛出 `OSError`，代码捕获后显示大小为 0。这不会导致崩溃，但可能泄露文件存在的信息（因为 `OSError` 只在文件存在但无法获取大小时抛出，如果文件不存在则不会进入这个分支）。

**问题 3: 隐藏文件和系统文件**

目录列表没有过滤隐藏文件和系统文件。在 Windows 上，以 `.` 开头的文件不一定是隐藏的，但具有隐藏属性的文件会被列出。在 Unix 上，以 `.` 开头的隐藏文件会被列出。这可能泄露 `.env`、`.ssh`、`.bash_history` 等敏感文件的存在。

**建议**:
1. 考虑是否确实需要目录列表功能。如果只需要读取文件，可以移除目录列表功能。
2. 如果保留目录列表，添加对隐藏文件和系统文件的过滤。
3. 对目录列表结果进行更严格的权限检查。

---

### 4.2 跨用户数据访问

**风险评级**: **中风险 (Medium)**

**分析**:

当前配置允许访问 `~/Documents` 和 `~/Downloads`。在 Windows 上，`~` 被 `os.path.expanduser()` 解析为当前用户的主目录（`C:\Users\<用户名>`）。这意味着 LLM 可以读取当前用户的文档和下载内容。

如果 AI Friend 运行在多用户系统上（虽然不太可能，因为这是一个个人 AI 助手），或者如果用户账户具有管理员权限，LLM 理论上可以通过符号链接（如果修复了符号链接检查）访问其他用户的数据。

更现实的风险是：如果 `allowed_read_paths` 被配置为包含其他用户的目录（例如 `"C:\\Users\\OtherUser\\Documents"`），当前的路径检查机制会允许这种访问。

**建议**:
1. 在 `_get_allowed_roots()` 中加入检查，确保所有白名单目录都在当前用户的主目录或系统临时目录下，防止意外配置导致跨用户访问。
2. 记录一条警告日志，当白名单包含非当前用户目录时。

---

## 5. 二进制文件检测

### 5.1 `_is_binary()` 函数分析

**文件**: `tools/file_tools.py` 第 20-28 行

```python
def _is_binary(filepath: str) -> bool:
    """Quick check if file is likely binary."""
    try:
        with open(filepath, "rb") as f:
            chunk = f.read(1024)
        return b"\x00" in chunk
    except Exception as e:
        logger.debug(f"Binary check failed for {path}: {e}")
        return False
```

**风险评级**: **中风险 (Medium)**

**分析**:

`_is_binary()` 函数通过检查文件前 1024 字节中是否包含空字节（`\x00`）来判断文件是否为二进制。这是一种常见的启发式方法，基于文本文件通常不包含空字节的假设。

**问题 1: 误报（将文本文件识别为二进制）**

某些文本文件格式可能包含空字节，例如：
- UTF-16 编码的文本文件（Windows 的某些配置文件使用 UTF-16 LE，其中 ASCII 字符表示为 `\x41\x00`）
- 某些编程语言的源文件（虽然不常见）
- 包含二进制数据的文本文件（如 base64 编码的图片嵌入在文本中）

如果合法文本文件被误判为二进制，用户无法通过 `read_file` 读取其内容。

**问题 2: 漏报（将二进制文件识别为文本）**

许多二进制文件的前 1024 字节可能不包含空字节，例如：
- 小型图片文件（某些 PNG 或 JPEG 文件的头几个字节后可能长时间没有空字节）
- 压缩文件（ZIP、GZ 等）
- 某些可执行文件格式
- PDF 文件（以 `%PDF-1.x` 开头，可能前 1024 字节没有空字节）

如果二进制文件被误判为文本，`ReadFileTool` 会尝试以 UTF-8 编码读取它。`errors="replace"` 会将无法解码的字节替换为 Unicode 替换字符（`U+FFFD`），所以不会导致崩溃，但会返回无意义的乱码，浪费 token 并可能让 LLM 产生幻觉。

**问题 3: 日志中的变量名错误**

```python
logger.debug(f"Binary check failed for {path}: {e}")
```

这里使用了 `path` 变量，但函数参数是 `filepath`。由于这个 `except` 块捕获所有异常，如果 `open()` 失败（例如文件不存在或权限不足），会进入这个分支并抛出 `NameError: name 'path' is not defined`。实际上不会抛出，因为 `logger.debug()` 的参数是 f-string，在传入 `logger.debug()` 之前就会求值，如果 `path` 未定义会抛出 `NameError`，然后被外层的 `except Exception` 捕获... 等等，这里 `except Exception as e` 已经捕获了 `open()` 的异常，然后执行 `logger.debug(...)`。如果 `path` 未定义，会抛出 `NameError`，但 `NameError` 是 `Exception` 的子类，它会被同一层的 `except Exception as e` 捕获吗？不会，因为此时已经在 `except` 块内部了。`NameError` 会向上传播到调用者。

实际上，Python 的异常处理不会捕获同一 `try` 块内 `except` 处理器中抛出的异常。所以如果 `logger.debug()` 抛出 `NameError`，它会传播到 `_is_binary()` 的调用者。但 `_is_binary()` 的调用者在 `_read_one()` 中：

```python
if _is_binary(resolved):
    return ToolResult.fail(f"二进制文件，无法读取文本内容")
```

这里没有 try-except，所以 `NameError` 会进一步向上传播，可能导致整个工具调用失败。这是一个**代码缺陷**。

**建议**:
1. 修复变量名错误：将 `{path}` 改为 `{filepath}`。
2. 增强二进制检测：除了检查空字节，还可以检查文件扩展名（虽然扩展名不可靠），或使用 `python-magic` 库进行更准确的文件类型检测。
3. 考虑对已知二进制格式（如 `.exe`、`.dll`、`.zip`、`.pdf` 等）进行硬编码拒绝。

---

## 6. 文件大小限制

### 6.1 ReadFileTool 大小限制

**文件**: `tools/file_tools.py` 第 10 行, 第 137-139 行

```python
MAX_FILE_SIZE = 500 * 1024  # 500KB

size = os.path.getsize(resolved)
if size > MAX_FILE_SIZE:
    return ToolResult.fail(f"文件太大 ({size/1024:.0f}KB > {MAX_FILE_SIZE/1024:.0f}KB)")
```

**风险评级**: **低风险 (Low)**

**分析**:

500KB 的文件大小限制是合理的，可以防止 LLM 读取过大的文件导致 token 溢出或响应时间过长。

但存在以下问题：

**问题 1: 大小检查与读取之间的竞态条件**

`os.path.getsize()` 和 `open()` 是两个独立的系统调用。在这两个调用之间，文件可能被其他进程修改（增大或缩小）。虽然这是一个时间窗口很小的竞态条件，但在理论上：
- 如果文件在 `getsize()` 和 `open()` 之间被其他进程增大到超过 500KB，`open()` 仍然会成功打开并读取（可能超过 500KB）。
- 如果文件被删除，`open()` 会失败。

更安全的做法是在读取时限制读取的字节数：

```python
with open(resolved, encoding="utf-8", errors="replace") as f:
    all_lines = f.readlines(MAX_FILE_SIZE)
```

但 `readlines()` 的 hint 参数只是提示，不保证精确限制。

更好的做法：

```python
with open(resolved, "rb") as f:
    chunk = f.read(MAX_FILE_SIZE + 1)
if len(chunk) > MAX_FILE_SIZE:
    return ToolResult.fail(f"文件太大")
# 然后解码 chunk
```

**问题 2: 行数限制与大小限制的关系**

`ReadFileTool` 同时有大小限制（500KB）和行数限制（默认 200 行，最大 2000 行）。这两个限制是独立的。一个 100KB 的文件可能有 10000 行（如果每行很短），此时大小检查通过，但读取全部 10000 行到内存中，然后只返回前 200 行。这造成了不必要的内存消耗。

**建议**:
1. 在读取时限制字节数，避免竞态条件。
2. 使用生成器逐行读取，避免一次性加载大文件到内存。

---

### 6.2 GrepTool 大小限制

**文件**: `tools/search_tools.py` 第 100 行, 第 177-178 行

```python
MAX_SIZE = 500 * 1024  # 500KB per file

if os.path.getsize(full) <= self.MAX_SIZE:
    files.append(full)
```

**风险评级**: **低风险 (Low)**

**分析**:

`GrepTool` 同样使用 500KB 的文件大小限制，但它只限制单个文件的大小，不限制搜索的目录树大小或总文件数。如果 `os.walk()` 遍历一个包含数万个小文件（每个 10KB）的目录，`GrepTool` 会尝试在所有这些文件中进行正则匹配，可能导致显著的 CPU 和内存消耗。

**建议**:
1. 添加总文件数限制（例如最多搜索 1000 个文件）。
2. 添加总搜索时间限制，防止长时间运行。

---

## 7. 写入操作的风险

### 7.1 文件系统写入工具审查

经过全面审查，当前代码库中**不存在**直接的文件写入工具。`ReadFileTool`、`GlobTool`、`GrepTool` 都是只读工具。`MusicPlayTool` 和 `MusicListTool` 也是只读的（`MusicPlayTool` 调用 `os.startfile()` 只是启动外部播放器，不修改文件）。

**风险评级**: **信息 (Info)**

**分析**:

虽然没有直接的文件写入工具，但存在以下间接写入风险：

**问题 1: `config.py` 的 `save_config()` 函数**

```python
def save_config(cfg: Config, path: str = CONFIG_PATH) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump({k: getattr(cfg, k) for k in cfg.__dataclass_fields__}, f, indent=2, ensure_ascii=False)
```

这个函数可以向任意路径写入配置。虽然它没有被注册为 LLM 可调用的工具，但如果代码中存在调用 `save_config()` 的地方且路径参数来自不可信来源，就可能存在写入风险。

在代码库中搜索 `save_config` 的使用：
- `config.py` 中定义，但没有被其他模块直接调用（除了可能的测试代码）。
- `core/personality.py` 中可能有类似的功能。

**问题 2: `personality.save()` 的写入操作**

`personality.json` 在每次对话后都会被保存（`web/session.py` 第 88 行, `core/cli_controller.py` 第 292 行）。虽然这是预期的行为，但如果 `personality_file` 路径被配置为指向敏感位置，可能导致数据覆盖。

**问题 3: 数据库写入**

`LongTermMemory` 和 `Repository` 提供了数据库写入功能（存储事实、经验、反思等）。虽然这不是文件系统写入，但数据库内容可能被 LLM 间接影响。例如，`RememberTool` 允许 LLM 存储任意文本：

```python
class RememberTool(Tool):
    def execute(self, args: dict[str, Any]) -> ToolResult:
        category = args.get("category", "preference")
        key = args.get("key", "").strip()
        value = args.get("value", "").strip()
        importance = float(args.get("importance", 0.6))
        self.ltm.store_fact(category, key, value, confidence=0.9, importance=importance)
```

虽然 `store_fact` 写入的是 SQLite 数据库而非文件系统，但如果攻击者通过大量存储操作填满数据库文件，可能导致磁盘空间耗尽。

**建议**:
1. 对 `RememberTool` 的调用频率进行限制。
2. 监控数据库文件大小，设置上限。
3. 确保 `save_config()` 和 `personality.save()` 的路径参数不会来自不可信来源。

---

## 8. Windows vs Linux 路径安全差异

### 8.1 Windows 特有的路径问题

**风险评级**: **中风险 (Medium)**

**分析**:

当前项目在 Windows 上运行（`D:\桌面\编程作品\AI朋友`），存在以下 Windows 特有的安全问题：

**问题 1: 驱动器字母穿越**

Windows 路径以驱动器字母开头（如 `D:\`）。`os.path.abspath()` 在 Windows 上不会跨驱动器。例如，`os.path.abspath("D:\\音乐\\..\\..\\C:\\Windows")` 返回 `C:\Windows`，而不是 `D:\C:\Windows`。但如果传入的路径本身就是 `C:\Windows\System32\config\SAM`，且白名单包含 `D:\音乐`，`os.path.abspath("C:\\Windows\\System32\\config\\SAM")` 返回 `C:\Windows\System32\config\SAM`，不以 `D:\音乐` 开头，检查失败。

但如果白名单配置中包含了多个驱动器（例如 `"C:\\Users\\<用户名>\\Documents"` 和 `"D:\\音乐"`），那么跨驱动器的访问取决于具体配置。

**问题 2: UNC 路径**

Windows 支持 UNC 路径（`\\server\share\path`）。`os.path.abspath("\\\\server\\share\\secret.txt")` 返回 `\\server\share\secret.txt`。如果白名单根目录是 `D:\音乐`，这个 UNC 路径不以 `D:\音乐` 开头，检查失败。但如果白名单配置中包含了 `\\server\share`，则 LLM 可以访问网络共享上的文件。

**问题 3: 设备名称路径**

Windows 保留了一些设备名称，如 `CON`、`PRN`、`AUX`、`NUL`、`COM1`-`COM9`、`LPT1`-`LPT9`。在旧版 Windows 上，可以通过 `C:\some\path\NUL` 或 `\\.\NUL` 访问这些设备。在 Python 中，`open("NUL")` 在 Windows 上打开空设备（类似于 Unix 的 `/dev/null`）。虽然这通常不会导致安全问题，但 `open("CON")` 会打开控制台输入/输出。

更危险的是，如果代码尝试读取 `\\.\PhysicalDrive0`，可能直接访问物理磁盘。但 `os.path.abspath("\\\\.\\PhysicalDrive0")` 返回 `\\.\PhysicalDrive0`，如果白名单不包含这个路径，检查会失败。

**问题 4: 短文件名 (8.3 格式)**

Windows 支持短文件名（8.3 格式），如 `PROGRA~1` 代表 `Program Files`。如果白名单包含 `C:\Program Files`，攻击者可能通过 `C:\PROGRA~1` 访问同一目录。`os.path.abspath("C:\\PROGRA~1")` 返回 `C:\PROGRA~1`，不以 `C:\Program Files` 开头（字符串比较），检查失败。但实际的文件系统访问会解析到 `C:\Program Files`。这是一个潜在的风险，但在此项目中由于 `_path_in_allowed` 返回的是 `abspath` 结果，而 `open()` 使用的是 `abspath` 结果，所以短文件名不会被用于实际打开文件——除非传入的参数本身就是短文件名。

等等，如果传入 `filepath = "D:\\音乐\\PROGRA~1\\secret.txt"`，`os.path.abspath()` 返回 `D:\\音乐\\PROGRA~1\\secret.txt`，检查通过。然后 `open("D:\\音乐\\PROGRA~1\\secret.txt")` 会解析短文件名并打开实际文件。如果 `PROGRA~1` 实际上是某个敏感目录的短文件名，这就构成了绕过。但在 `D:\音乐` 目录下通常不会有 `PROGRA~1` 这样的短文件名目录。

**问题 5: 路径分隔符混合**

Windows 同时支持 `\` 和 `/` 作为路径分隔符。`os.path.abspath("D:/音乐/secret.txt")` 在 Windows 上返回 `D:\\音乐\\secret.txt`。`os.path.abspath()` 正确处理了混合分隔符。

**建议**:
1. 在路径检查前，拒绝包含 UNC 前缀（`\\`）和设备路径前缀（`\\.\`）的路径。
2. 拒绝包含冒号（`:`）的路径（除了驱动器字母后的冒号），防止备用数据流攻击。
3. 使用 `pathlib.Path` 进行更现代的路径处理，它自动处理平台差异。

---

### 8.2 跨平台兼容性

**风险评级**: **低风险 (Low)**

**分析**:

当前代码在 Windows 上运行，但如果在 Linux 上运行，存在以下差异：

**问题 1: `os.path.expanduser()` 的行为差异**

在 Linux 上，`~` 被解析为 `$HOME` 环境变量对应的目录。在 Windows 上，`~` 被解析为 `USERPROFILE` 环境变量对应的目录。行为一致。

**问题 2: `os.startfile()` 的可用性**

`MusicPlayTool._play()` 使用了 `os.startfile()`：

```python
def _play(self, filepath: str, display_name: str) -> ToolResult:
    try:
        os.startfile(filepath)
        return ToolResult.ok(f"正在播放: {display_name}")
    except Exception as e:
        return ToolResult.fail(f"播放失败: {e}")
```

`os.startfile()` 是 Windows 特有的函数，在 Linux 上不存在。如果项目在 Linux 上运行，`MusicPlayTool` 会失败。这不是安全问题，而是兼容性问题。

**问题 3: 大小写敏感性**

Linux 文件系统区分大小写，Windows 不区分。当前代码使用 `str.startswith()` 进行路径检查，这在 Linux 上更加严格（大小写必须完全匹配），在 Windows 上相对宽松（因为文件系统本身不区分大小写，但 Python 的字符串比较区分）。

**建议**:
1. 在 `MusicPlayTool` 中使用跨平台的文件打开方式，或添加平台检测。
2. 在 Linux 上部署时，确保路径检查考虑大小写敏感性。

---

## 9. 其他安全问题

### 9.1 API 密钥明文存储

**文件**: `config.json`

```json
{
  "api_key": "sk-618d33e37dde45d5904b94838b779c64",
  ...
}
```

**风险评级**: **中风险 (Medium)**

**分析**:

DeepSeek API 密钥以明文形式存储在 `config.json` 中。虽然 `config.py` 支持通过环境变量覆盖（`DEEPSEEK_API_KEY`），但默认行为是将密钥写入配置文件。如果：
- `config.json` 被提交到 Git 仓库（`.gitignore` 中可能未排除）
- 配置文件权限设置不当，其他用户可以读取
- LLM 通过 `read_file` 工具读取 `config.json`

则 API 密钥可能泄露。

在 `config.py` 第 74 行：

```python
masked = "***" if "KEY" in env_var else val
logger.info(f"[config] env override: {env_var}={masked}")
```

日志中对环境变量中的密钥进行了掩码处理，这是好的实践。但 `config.json` 本身没有加密或掩码。

**建议**:
1. 在 `save_config()` 中，对包含敏感信息的字段（如 `api_key`）进行掩码或排除。
2. 在 `.gitignore` 中确保 `config.json` 被排除。
3. 优先使用环境变量存储密钥，并在文档中强调这一点。

---

### 9.2 `notify` 工具的命令注入

**文件**: `tools/notify_tool.py` 第 50-65 行

```python
def _show():
    ps = f'''
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null
$template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
$textNodes = $template.GetElementsByTagName('text')
$textNodes.Item(0).AppendChild($template.CreateTextNode('{title}')) > $null
$textNodes.Item(1).AppendChild($template.CreateTextNode('{message}')) > $null
$toast = [Windows.UI.Notifications.ToastNotification]::new($template)
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('AI Friend').Show($toast)
'''
    try:
        subprocess.run(
            ['powershell', '-NoProfile', '-Command', ps],
            capture_output=True, timeout=10,
        )
    except Exception:
        pass
```

**风险评级**: **中风险 (Medium)**

**分析**:

`NotifyTool` 将用户提供的 `title` 和 `message` 直接嵌入到 PowerShell 脚本中，存在**命令注入**风险。

如果 LLM 或攻击者提供包含单引号的标题或消息，例如：
- `title = "test'; Remove-Item 'C:\\important.txt'; '"`

PowerShell 脚本会变成：
```powershell
$textNodes.Item(0).AppendChild($template.CreateTextNode('test'; Remove-Item 'C:\important.txt'; '')) > $null
```

这会导致 PowerShell 语法错误，不会执行 `Remove-Item`。但如果构造更精巧的注入：
- `title = "test')) | ForEach-Object { Remove-Item 'C:\\important.txt' } #"`

由于 `AppendChild` 和 `CreateTextNode` 的调用方式，直接注入可执行代码的难度较高，但并非不可能。更现实的攻击是：
- `title = "test`n[恶意内容]`n"`（使用 PowerShell 换行符注入多行命令）

此外，即使不能执行任意命令，如果 `title` 或 `message` 包含 PowerShell 特殊字符（如 `$`、`` ` ``、`(`、`)`），也可能导致脚本行为异常。

**建议**:
1. 对 `title` 和 `message` 进行严格的输入验证和转义。
2. 使用 `subprocess.run()` 的参数传递方式，避免将用户输入嵌入到命令字符串中。但由于 PowerShell 脚本的复杂性，这可能不太容易。
3. 考虑使用 Python 的 `win10toast` 或 `plyer` 库替代直接调用 PowerShell。

---

### 9.3 `web_fetch` 的 SSRF 风险

**文件**: `tools/web_tools.py` 第 121-143 行

```python
def execute(self, args: dict[str, Any]) -> ToolResult:
    url = args.get("url", "").strip()
    if not url:
        return ToolResult.fail("请提供URL")
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    # ...
    result = _anysearch_api("extract", {"url": url})
```

**风险评级**: **低风险 (Low)**

**分析**:

`WebFetchTool` 允许 LLM 提供任意 URL。虽然请求是通过 AnySearch API 代理的（不是直接访问），但如果 AnySearch API 本身没有对目标 URL 进行限制，可能存在服务器端请求伪造（SSRF）风险。不过，由于请求是从 AnySearch 的服务器发出的，而不是从 AI Friend 的服务器发出，对 AI Friend 本身的影响有限。

更相关的是，如果 LLM 被诱导访问恶意网站，AnySearch API 可能返回恶意内容，然后被注入到 LLM 的上下文中。

**建议**:
1. 对 URL 进行验证，拒绝内网 IP、localhost、私有地址范围。
2. 对 AnySearch API 返回的内容进行适当的过滤和清理。

---

# 汇总统计

## 风险汇总表

| 序号 | 问题描述 | 风险评级 | 影响文件 | 行号 | 修复优先级 |
|:---:|---------|:-------:|---------|:---:|----------|
| 1 | `_path_in_allowed()` 使用 `os.path.abspath()` 而非 `os.path.realpath()`，不解析符号链接/junction point，允许目录穿越 | **严重** | `tools/file_tools.py` | 52-53 | P0 |
| 2 | `_resolve_search_path()` 同样使用 `os.path.abspath()`，符号链接绕过 | **严重** | `tools/search_tools.py` | 15-23 | P0 |
| 3 | `GlobTool` 的 `os.walk()` 会遍历 junction point 目标目录，导致目录结构泄露和 DoS | **高** | `tools/search_tools.py` | 68 | P1 |
| 4 | `GrepTool` 的正则表达式缺少超时机制，存在 ReDoS 风险 | **高** | `tools/search_tools.py` | 159, 196 | P1 |
| 5 | `ReadFileTool` 允许目录列表，可能泄露隐藏文件和敏感文件名 | **高** | `tools/file_tools.py` | 108-132 | P1 |
| 6 | `_is_binary()` 函数存在变量名错误（`path` vs `filepath`），可能导致 `NameError` | **中** | `tools/file_tools.py` | 27 | P2 |
| 7 | 默认白名单配置过于宽泛（包含 `D:\桌面`、`~/Downloads`） | **中** | `config.py` | 32-38 | P2 |
| 8 | API 密钥明文存储在 `config.json` | **中** | `config.json` | - | P2 |
| 9 | `NotifyTool` 存在 PowerShell 命令注入风险 | **中** | `tools/notify_tool.py` | 50-65 | P2 |
| 10 | `GrepTool` 跳过目录使用子字符串匹配，可能误跳合法目录 | **中** | `tools/search_tools.py` | 170 | P2 |
| 11 | `ReadFileTool` 大小检查与读取之间存在竞态条件 | **低** | `tools/file_tools.py` | 137-146 | P3 |
| 12 | `GrepTool` 不限制总搜索文件数，可能导致大量 I/O | **低** | `tools/search_tools.py` | 168-180 | P3 |
| 13 | `ReadFileTool` 未过滤隐藏文件和系统文件 | **低** | `tools/file_tools.py` | 110-131 | P3 |
| 14 | `MusicPlayTool` 使用 Windows 特有的 `os.startfile()`，跨平台兼容性差 | **低** | `tools/music_tool.py` | 152 | P3 |

## 按风险等级统计

| 风险等级 | 数量 | 问题编号 |
|:-------:|:----:|---------|
| 严重 (Critical) | 2 | #1, #2 |
| 高 (High) | 3 | #3, #4, #5 |
| 中 (Medium) | 5 | #6, #7, #8, #9, #10 |
| 低 (Low) | 4 | #11, #12, #13, #14 |
| **总计** | **14** | - |

## 核心修复建议

### 立即修复（P0 - 严重）

1. **将 `os.path.abspath()` 替换为 `os.path.realpath()`**
   - 文件: `tools/file_tools.py` 第 52 行
   - 文件: `tools/search_tools.py` 第 16 行
   - 这是防止符号链接/junction point 目录穿越的关键修复。

2. **追加路径分隔符进行前缀匹配**
   ```python
   prefix = root_real if root_real.endswith(os.sep) else root_real + os.sep
   if resolved == root_real or resolved.startswith(prefix):
   ```

### 短期修复（P1 - 高）

3. **在 `GlobTool` 和 `GrepTool` 的 `os.walk()` 中加入实时路径验证**
   ```python
   for dirpath, _, fnames in os.walk(root):
       if not _path_in_allowed(dirpath):
           continue  # 跳过越界的目录
   ```

4. **为 `GrepTool` 的正则匹配添加超时机制**
   ```python
   import signal
   
   def _regex_search_with_timeout(regex, line, timeout=1.0):
       # 使用线程或信号实现超时
       ...
   ```

5. **收紧默认白名单配置**
   ```python
   allowed_read_paths: list[str] = field(default_factory=lambda: [
       ".",  # 仅项目目录
       # "D:\\音乐",  # 移除或注释掉
       # "D:\\桌面",  # 移除或注释掉
       # "~/Documents",  # 移除或注释掉
       # "~/Downloads",  # 移除或注释掉
   ])
   ```

### 中期修复（P2 - 中）

6. 修复 `_is_binary()` 中的变量名错误。
7. 对 `config.json` 中的敏感字段进行加密或掩码处理。
8. 对 `NotifyTool` 的 PowerShell 脚本进行参数化或使用安全的通知库。
9. 完善 `GrepTool` 的跳过目录逻辑，使用精确匹配。

### 长期改进（P3 - 低）

10. 使用 `pathlib.Path` 替代 `os.path` 进行路径操作。
11. 为文件读取添加生成器支持，避免大文件内存问题。
12. 添加更完善的文件类型检测（考虑使用 `python-magic`）。
13. 增强跨平台兼容性，特别是 `MusicPlayTool`。

---

# 附录：关键代码修复示例

## A. 修复后的 `_path_in_allowed()`

```python
def _path_in_allowed(filepath: str) -> str | None:
    """Resolve and check path is in an allowed directory. Returns absolute path or None."""
    # 解析符号链接、junction point 和硬链接
    try:
        resolved = os.path.realpath(filepath)
    except (OSError, ValueError):
        return None
    
    # 拒绝设备路径和 UNC 路径
    if resolved.startswith("\\\\") or resolved.startswith("//"):
        return None
    
    for root in _get_allowed_roots():
        try:
            root_real = os.path.realpath(root)
            # 确保根目录末尾有路径分隔符
            prefix = root_real if root_real.endswith(os.sep) else root_real + os.sep
            if resolved == root_real or resolved.startswith(prefix):
                return resolved
        except Exception as e:
            logger.debug(f"Path check failed for root {root}: {e}")
            continue
    return None
```

## B. 修复后的 `_is_binary()`

```python
def _is_binary(filepath: str) -> bool:
    """Quick check if file is likely binary."""
    try:
        with open(filepath, "rb") as f:
            chunk = f.read(1024)
        return b"\x00" in chunk
    except Exception as e:
        logger.debug(f"Binary check failed for {filepath}: {e}")
        return False  # 无法检查时保守地假设为文本
```

## C. 修复后的 `GlobTool.execute()`

```python
def execute(self, args: dict[str, Any]) -> ToolResult:
    pattern = args.get("pattern", "").strip()
    search_root = args.get("path", ".").strip()
    if not pattern:
        return ToolResult.fail("请提供 glob 模式")
    
    root = _resolve_search_path(search_root)
    if root is None:
        return ToolResult.fail(f"路径不在可访问范围内: {search_root}")
    
    results = []
    file_count = 0
    MAX_FILES = 10000
    
    for dirpath, _, fnames in os.walk(root, followlinks=False):
        # 实时验证遍历路径仍在白名单内
        if _resolve_search_path(dirpath) is None:
            continue
        
        rel_dir = os.path.relpath(dirpath, root)
        for fname in fnames:
            rel_path = os.path.join(rel_dir, fname) if rel_dir != "." else fname
            if fnmatch.fnmatch(rel_path, pattern) or fnmatch.fnmatch(fname, pattern):
                full_path = os.path.join(dirpath, fname)
                try:
                    size = os.path.getsize(full_path)
                except OSError:
                    size = 0
                results.append((rel_path, size))
        
        file_count += len(fnames)
        if file_count > MAX_FILES:
            logger.warning(f"Glob search exceeded max file count: {file_count}")
            break
    
    # ... 后续处理不变
```

---

*报告结束。本审查基于 2026-05-31 的代码快照。建议在修复后重新进行安全审查。*
