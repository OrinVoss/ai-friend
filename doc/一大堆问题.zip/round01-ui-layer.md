# AI Friend 项目 UI 层架构深度审查报告（Round 01）

**审查日期：** 2026-05-31
**审查范围：** `ui/cli.py`、`ui/display.py`、`core/cli_controller.py` 及其与核心层、Web 层的交互关系
**审查目标：** UI 层与核心层的耦合程度、控制台交互逻辑、显示格式化、CLI 控制器职责、架构问题与重复代码识别

---

## 一、概述

AI Friend 项目采用双入口架构：CLI 入口（`main.py`）和 Web 入口（`web_main.py`）。UI 层由 `ui/cli.py` 和 `ui/display.py` 组成，负责控制台输入输出；核心控制逻辑由 `core/cli_controller.py` 承担，实现了一个基于状态机（`AgentState`）的运行循环。Web 端则完全绕过 CLI 控制器，通过 `web/server.py` 和 `web/session.py` 直接与 `Agent` 实例交互。

本次审查发现，UI 层在职责划分、耦合控制、代码复用等方面存在**中高风险**问题。核心控制器 `CliController` 承担了过多的职责，与 `Agent` 和 `MessageHandler` 之间存在大量重复逻辑；`ui/cli.py` 和 `ui/display.py` 的设计过于简单，未能形成有效的抽象隔离；Web 端与 CLI 端在工具注册、记忆初始化、Agent 构建等流程上存在显著的代码重复。以下将从七个维度展开详细分析。

---

## 二、详细发现

### 2.1 文件逐行分析

#### 2.1.1 `D:\桌面\编程作品\AI朋友\ui\cli.py`

该文件定义了两个类：`NonBlockingInputReader`（第 6-36 行）和 `ConsoleInterface`（第 39-72 行）。

**`NonBlockingInputReader` 分析：**

- **第 6 行：** 类注释说明其为"后台守护线程用于非阻塞 stdin 读取"。这是一个合理的设计，允许状态机在等待用户输入的同时执行空闲逻辑（如主动行为检测）。
- **第 9-13 行：** `__init__` 中创建了 `Queue`、`Event` 和 `Thread`。`daemon=True` 的设置是正确的，确保主线程退出时不会阻塞。
- **第 15-19 行：** `start()` 方法使用 `_started` 标志防止重复启动，逻辑正确。
- **第 21-22 行：** `stop()` 方法仅设置 `sentinel`，但**没有 join 线程**。虽然守护线程会在主进程结束时自动终止，但在需要优雅关闭的场景下（如单元测试或嵌入式使用），这可能导致资源泄漏或测试不稳定。
- **第 24-29 行：** `read_line(timeout=0)` 方法实现非阻塞读取。注意这里的 `timeout` 参数虽然存在，但实际实现中并未使用（`get_nowait()` 是立即返回的）。这是一个**API 设计缺陷**——调用者可能误以为可以指定超时，实际上不能。
- **第 31-36 行：** `_reader()` 后台循环读取 `sys.stdin.readline()`。问题在于：如果 `sys.stdin` 被重定向或关闭（如管道输入结束），`readline()` 会返回空字符串，循环正确退出。但如果 `sys.stdin` 是终端且用户按下 Ctrl+D（EOF），行为也正确。然而，**没有处理 `sys.stdin` 编码问题**，在 Windows 上可能遇到 `UnicodeDecodeError`。

**`ConsoleInterface` 分析：**

- **第 39-41 行：** `__init__` 中仅创建了 `reader`，`display` 属性是延迟初始化的（在 `start()` 中）。这种延迟初始化是合理的，避免了在导入时产生副作用。
- **第 43-47 行：** `start()` 方法从 `ui.display` 导入 `DisplayEngine` 并赋值给 `self.display`，然后启动 reader。注意这里使用了**相对导入的绝对形式**（`from ui.display import DisplayEngine`），在项目根目录运行时有效，但如果 `ui` 包被单独导入或在不同工作目录下运行，可能失败。
- **第 48-49 行：** `stop()` 方法仅调用 `reader.stop()`，但没有清理 `display`。`DisplayEngine` 目前是无状态的，所以这不是大问题，但如果未来 `DisplayEngine` 需要资源释放（如颜色主题恢复、光标显示恢复），这里会遗漏。
- **第 51-57 行：** `display_banner()` 是静态方法，直接使用 ANSI 转义码输出横幅。硬编码了 "你的 AI 朋友" 文本，**未使用国际化或配置化**，对于需要品牌定制或本地化的场景不够灵活。
- **第 59-72 行：** `display_help()` 同样是静态方法，硬编码了命令列表。这里存在一个**职责错位**：帮助信息的定义应该在控制器层或配置层，而不是 UI 层。`ConsoleInterface` 应该只负责"如何显示"，而"显示什么"应该由调用者提供。当前设计导致帮助文本与 UI 实现耦合，如果未来需要支持 Web 端的帮助显示，无法复用这里的文本。

#### 2.1.2 `D:\桌面\编程作品\AI朋友\ui\display.py`

该文件定义了 `DisplayEngine` 类（第 6-63 行），负责所有格式化输出。

- **第 6-8 行：** `__init__` 接受 `typing_speed` 参数，默认 0.02 秒/字符。这个参数控制打字机效果的播放速度。
- **第 10-19 行：** `typewrite()` 方法实现打字机效果。逻辑如下：
  - 对每个字符调用 `print(ch, end="", flush=True)`
  - 根据字符类型施加不同延迟：标点符号（`.!?。！？\n`）延迟 8 倍，逗号等（`,;:，；：`）延迟 4 倍，普通字符延迟 1 倍
  - 最后打印 `end` 参数（默认换行）

  **问题：** 这个方法**没有处理终端宽度变化**。如果文本很长且终端很窄，`print` 会自动换行，但打字机效果会逐字符打印，导致换行发生在任意位置，破坏 `_word_wrap` 的预期效果。更严重的是，如果在打字过程中终端被 resize，`shutil.get_terminal_size()` 在 `respond()` 中只调用一次，不会动态适应。

- **第 21-31 行：** `respond()` 方法先计算终端宽度（上限 80），如果有 `prefix` 则先打印前缀并延迟，然后对每一行调用 `typewrite()`。注意第 28-29 行的逻辑：当 `i > 0`（即非第一行）且存在 `prefix` 时，打印空格以对齐前缀后的文本。这是一个细心的设计，但存在**边缘情况**：如果 `prefix` 包含 ANSI 颜色码，`len(prefix)` 会计算转义序列的长度，导致对齐偏移。例如 `prefix="\033[1mBot\033[0m"` 的 `len()` 是 11 而非 3。

- **第 33-35 行：** `show_thinking()` 打印 " ..."。这是一个非常简单的思考指示器，没有动画效果（如旋转的 `/ - \ |`）。

- **第 37-47 行：** `print_system()`、`print_error()`、`print_mood()` 三个静态方法，分别使用不同的 ANSI 颜色码：系统消息为暗灰色（`\033[2;37m`），错误为红色（`\033[31m`），心情为洋红色（`\033[35m`）。**所有颜色码都是硬编码的**，没有支持主题切换或无障碍模式（如高对比度、色盲友好）。

- **第 49-63 行：** `_word_wrap()` 静态方法实现文本换行。算法如下：
  - 如果 `width < 20`，强制设为 20
  - 按段落（`\n` 分隔）处理
  - 对每个段落，如果长度超过 `width`，从右侧找空格作为断点
  - 如果找不到合适的空格（`break_at < width // 2`），则硬截断到 `width`

  **问题：**
  1. **硬截断不处理单词完整性**：当 `break_at < width // 2` 时，直接在 `width` 处截断，可能截断一个单词的中间。对于中文文本，这可能导致截断在字符中间（虽然 Python 字符串切片对 Unicode 是安全的，但视觉上不美观）。
  2. **没有处理 ANSI 转义序列**：如果输入文本包含颜色码，`_word_wrap` 会将转义序列计入长度，导致实际可见字符数少于 `width` 时就被截断。
  3. **没有处理制表符和特殊空白字符**：`paragraph.rfind(" ", 0, width)` 只查找普通空格，如果文本包含制表符（`\t`），换行位置可能不理想。
  4. **性能考虑**：对于超长文本（如 LLM 返回的长段落），`while len(paragraph) > width` 循环的每次迭代都调用 `rfind`，时间复杂度为 O(n^2)。虽然对于控制台输出 n 通常不大，但这是一个潜在的性能隐患。

#### 2.1.3 `D:\桌面\编程作品\AI朋友\core\cli_controller.py`

这是本次审查的核心文件，定义了 `CliController` 类（第 16-334 行），负责 CLI 状态机的完整运行循环。

**整体架构：**

`CliController` 采用状态机模式，状态定义在 `core/agent.py` 的 `AgentState` 枚举中。`run()` 方法是主循环，根据当前状态调用对应的 `_on_*` 处理器。这种设计本身是清晰的，但实现中存在严重的职责膨胀问题。

**`__init__`（第 19-24 行）：**

- 接收 `agent` 参数，保存为 `self._agent`
- 延迟初始化 `_tool_agent` 和 `_inner_drive`
- 维护 `_tool_records` 和 `_inner_drive_result` 两个临时状态变量

**`_ensure_inner_drive()`（第 26-34 行）：**

- 延迟导入 `InnerDriveAgent`
- 从 `self.a`（即 `self._agent`）提取 provider、personality、ltm、retriever、short_term、tool_registry 等依赖
- 创建 `InnerDriveAgent` 实例

**`_ensure_tool_agent()`（第 36-42 行）：**

- 延迟导入 `ToolAgent`
- 从 `self.a` 提取 provider 和 tool_registry
- 创建 `ToolAgent` 实例

**`_make_internal_registry()`（第 44-51 行）：**

- 创建仅包含 `recall` 和 `remember` 两个工具的过滤注册表
- 用于在 Agent 2 已执行外部工具后，限制 Agent 3 只能调用内部记忆工具

**`a` property（第 54-56 行）：**

- 简写属性，返回 `self._agent`
- 在整个类中被大量使用，减少了代码冗余，但也在一定程度上模糊了依赖关系

**`run()`（第 60-87 行）：**

- 第 63-65 行：如果 `a.ui` 存在，调用 `a.ui.start()` 和 `a.ui.display_banner()`
- 第 66 行：设置初始状态为 `BOOT`
- 第 67 行：调用 `_on_boot()`
- 第 68-86 行：主循环，状态不为 `SHUTDOWN` 且 `_running` 为真时持续运行
- 第 69-78 行：通过字典映射状态到处理器。注意这里没有 `default` 分支，如果状态是未预期的值，`handler` 为 `None`，循环继续但不执行任何操作。这是一个**静默失败**的风险点。
- 第 79-80 行：捕获 `KeyboardInterrupt`，设置状态为 `SHUTDOWN`
- 第 81-85 行：捕获其他异常，记录日志，如果有 UI 则显示错误，等待 1 秒后回到 `IDLE` 状态。这里的异常处理**过于宽泛**，任何异常（包括编程错误如 `AttributeError`）都会被吞掉，可能导致难以调试的问题。
- 第 87 行：循环结束后调用 `_on_shutdown()`

**`_on_boot()`（第 89-97 行）：**

- 从 personality 配置获取 `first_run_greeting`，如果没有则使用默认问候语
- 通过 `a.ui.display.respond()` 显示问候语
- 设置状态为 `IDLE`

**`_on_idle()`（第 99-116 行）：**

- 第 102-104 行：如果 `_prompt_shown` 为假，打印 "用户输入: " 提示符并设置标志。注意这里**直接调用了 `print()` 而不是通过 `a.ui.display`**，这是一个**职责泄漏**——UI 相关的输出应该统一由 UI 层处理。
- 第 105 行：通过 `a.ui.reader.read_line()` 非阻塞读取输入。如果 `a.ui` 为 `None`，返回 `None`。
- 第 106-109 行：如果有输入，保存到 `a.current_input` 并进入 `PERCEIVE` 状态。
- 第 110-115 行：计算空闲时间，如果超过 `proactive_min_idle`，则计算主动行为概率，随机决定是否主动发起对话。
- 第 116 行：如果没有输入也没有触发主动行为，睡眠 0.1 秒。

**问题：** 这里的主动行为逻辑与 `core/agent.py` 中的 `ProactivityManager` 存在功能重叠。`_on_idle` 中直接调用了 `a._calculate_proactivity()`，而这个方法又委托给 `ProactivityManager`。虽然委托链是清晰的，但主动行为的决策逻辑分散在控制器和 Agent 之间。

**`_on_perceive()`（第 118-135 行）：**

- 第 122-126 行：处理以 `/` 开头的命令，调用 `_handle_command()`。命令处理后回到 `IDLE` 或 `SHUTDOWN`。
- 第 127 行：将用户输入加入短期记忆。
- 第 128 行：检索记忆上下文。
- 第 129 行：将用户回合同步插入长期记忆数据库。
- 第 132-133 行：确保 `InnerDriveAgent` 已初始化，调用 `assess()` 进行 Agent 1 推理。
- 第 134 行：重置 `_tool_records`。
- 第 135 行：进入 `THINK` 状态。

**问题：**
1. 第 129 行的 `insert_turn_sync` 是同步数据库操作，如果数据库繁忙或磁盘 I/O 慢，会阻塞整个状态机循环。虽然当前是 CLI 模式，用户感知不明显，但如果未来需要支持高并发或实时交互，这里会成为瓶颈。
2. `_on_perceive` 的职责过重：输入解析、命令处理、记忆存储、Agent 1 推理全部集中在一个方法中。

**`_on_think()`（第 137-236 行）：**

这是整个类中最长、最复杂的方法，长达 99 行。它负责构建 LLM 提示、调用生成、处理流式输出、解析工具调用。

- **第 141-147 行：** 判断是否是主动行为模式。如果是，检索空查询的记忆，构建 `[主动开启对话]` 消息；否则构建 `用户输入：` 消息。
- **第 149-157 行：** Agent 2 工具执行。如果 Agent 1 决定需要外部工具且不是主动模式，调用 `ToolAgent` 执行工具，并格式化结果到 `_tool_records`。
- **第 159-188 行：** 构建系统提示和消息列表。这里包含大量逻辑：
  - 调用 `build_system_prompt()` 构建系统提示
  - 从短期记忆获取历史对话，反转顺序后逐条加入消息列表
  - 进行 token 估算和截断（`COMPRESS_THRESHOLD`）
  - 将消息列表重新反转回正确顺序
  - 注入工具结果作为 USER 消息
  - 如果不是主动模式，注入用户输入消息
- **第 189 行：** 保存构建好的消息列表到 `a._react_messages`
- **第 194-229 行：** LLM 生成阶段。分为两种情况：
  - **第 195-205 行（迭代 > 0）：** 非流式生成，显示"思考中..."，如果发生 `ConnectionError` 则显示错误并重置。
  - **第 206-229 行（迭代 = 0）：** 流式生成，显示"..."，通过 `on_token` 回调实时输出 token。这里包含复杂的终端控制逻辑：第 214 行打印 `\r` 清除之前的 "..."，第 215 行打印带颜色的名字前缀。
- **第 230-236 行：** 解析响应，提取工具调用，保存到状态，进入 `ACT` 状态。

**严重问题：**

1. **方法过长（99 行）**：违反了单一职责原则。`_on_think()` 同时承担了提示构建、工具协调、LLM 调用、流式输出处理、错误处理等多项职责。

2. **与 `MessageHandler.handle_message()` 的大量重复**：对比 `core/message_handler.py` 第 64-156 行，`CliController._on_think()` 和 `MessageHandler.handle_message()` 都实现了三层 Agent 的协调逻辑（Agent 1 决策、Agent 2 工具执行、Agent 3 响应生成）。两者的核心流程几乎相同，但实现细节有差异：
   - `MessageHandler` 支持 Agent 2 的多轮执行（`MAX_AGENT2_ROUNDS = 3`）和失败重试（`ToolAttemptTracker`）
   - `CliController` 的 Agent 2 只执行一轮（第 152 行只取 `tool_requests[0]`），没有重试机制
   - 两者都调用了 `build_system_prompt()` 和 `_build_messages()`（或等效逻辑）
   - 两者都处理了工具结果的注入方式

   这种重复意味着**任何对三层 Agent 协调逻辑的修改都需要在两个地方同步更新**，极易导致不一致。

3. **流式输出的终端控制逻辑混杂在控制器中**：第 211-217 行的 `on_token` 回调直接操作 `print()` 和 ANSI 转义码。这些终端控制细节应该封装在 `DisplayEngine` 中，而不是暴露在控制器里。当前设计导致控制器与终端输出强耦合，无法支持非终端 UI（如 GUI 或测试 mock）。

4. **错误处理不一致**：第 200-204 行和第 221-225 行分别处理了非流式和流式生成中的 `ConnectionError`，代码几乎完全相同，是明显的重复。

5. **Token 估算逻辑重复**：第 170-176 行的 token 估算和截断逻辑与 `MessageHandler._build_messages()` 第 274-291 行的逻辑类似，但实现方式不同（`CliController` 使用 `a._context` 对象跟踪，`MessageHandler` 直接计算）。

**`_on_act()`（第 238-261 行）：**

- 第 241 行：获取待处理的工具调用列表
- 第 243-247 行：如果超过最大工具迭代次数，显示提示并结束响应
- 第 248-249 行：显示"执行 N 个工具..."
- 第 251-253 行：如果 Agent 2 已执行过外部工具，则使用过滤后的内部注册表
- 第 254-255 行：执行工具调用并格式化结果
- 第 256-257 行：将结果注入消息列表
- 第 258-259 行：如果所有工具都失败且响应包含虚假操作声明，追加纠正提示
- 第 260 行：回到 `THINK` 状态，进入下一轮 ReAct 循环

**问题：**
1. 第 258-259 行的 `contains_fake_action()` 检查和纠正提示注入，与 `core/agent.py` 中 `_react_loop()` 的第 139-154 行逻辑类似但实现不同。`_react_loop` 使用英文提示，`_on_act` 使用中文提示，两者可能产生不同的行为。
2. 工具执行的错误处理在 `execute_tool_calls()` 中完成，但 `_on_act` 没有处理 `execute_tool_calls` 可能抛出的异常（虽然 `execute_tool_calls` 内部已经 try-except，但如果 `tool_registry` 为 `None` 会抛出 `AttributeError`）。

**`_finish_react_response()`（第 264-277 行）：**

- 第 267-269 行：如果有响应且迭代次数 > 1，通过 UI 显示响应。注意这里的条件 `a._react_iteration > 1` 意味着**第一轮（迭代 0）的响应已经在流式输出中实时显示过了**，所以不需要再次显示。这是一个隐含的假设，如果未来改变流式输出的行为，这里会出错。
- 第 270-271 行：将响应保存到短期记忆和长期记忆数据库。
- 第 272 行：增加回合计数。
- 第 273 行：更新最后活动时间。
- 第 274 行：调用 `a._reset_react()` 重置 ReAct 状态。
- 第 275-276 行：重置控制器本地的工具记录和 Agent 1 结果。
- 第 277 行：进入 `REFLECT` 状态。

**问题：**
1. 第 270-271 行的记忆保存与 `MessageHandler._run_agent3()` 第 251-252 行以及 `Agent._react_loop()` 第 172-176 行的逻辑重复。
2. `turn_count` 的递增位置在 `_finish_react_response()` 中，但 `insert_turn_sync` 使用的是递增前的 `a.turn_count`。这与 `Agent._react_loop()` 中先 `insert_turn_sync` 再 `turn_count += 1` 的顺序一致，但需要确认数据库中的回合编号是否与预期一致。

**`_on_reflect()`（第 279-294 行）：**

- 第 282 行：计算情绪绝对值
- 第 283 行：计算空闲时间
- 第 284-288 行：判断是否需要进行记忆合并（consolidation），如果需要则执行
- 第 289-290 行：将最近两个回合加入待合并队列
- 第 291-292 行：每 10 个回合保存一次 personality 状态
- 第 293-294 行：清空当前响应，回到 `IDLE` 状态

**问题：**
1. 记忆合并逻辑与 `Agent._process_emotion()` 第 216-221 行的逻辑部分重叠。`_process_emotion()` 在每 3 个回合触发一次合并，而 `_on_reflect()` 使用 `should_consolidate()` 进行更智能的判断。两者的触发条件不同，可能导致合并过于频繁或遗漏。
2. `should_consolidate()` 的参数包括 `turn_count`、`ei`（情绪强度）、`idle`（空闲时间）和 `config`，但 `should_consolidate` 的具体实现在 `MemoryConsolidator` 中，本次审查未深入。

**`_on_shutdown()`（第 296-305 行）：**

- 第 298-301 行：强制进行一次记忆合并
- 第 302 行：保存 personality 状态
- 第 303-304 行：如果 UI 存在，调用 `a.ui.stop()`
- 第 305 行：打印告别消息

**问题：** 第 305 行再次直接调用 `print()` 而不是通过 `a.ui.display`，与 `_on_idle()` 中的问题相同。

**`_handle_command()`（第 307-334 行）：**

- 支持 `/exit`、`/quit`、`/save`、`/mood`、`/status`、`/forget`、`/help` 命令
- 每个命令直接操作 Agent 的状态或调用相关方法
- 所有输出都通过 `a.ui.display` 或 `a.ui` 进行

**问题：**
1. 命令处理逻辑与 `Agent` 的核心业务逻辑耦合。`CliController` 不应该直接操作 `a.short_term.clear()` 或 `a.consolidator.consolidate()`，这些操作应该通过 `Agent` 的公共 API 进行。
2. `/mood` 和 `/status` 命令的格式化逻辑在控制器中实现，如果 Web 端也需要显示类似信息，无法复用。
3. 命令列表是硬编码的，没有支持插件化扩展。

---

### 2.2 UI 层与核心层的耦合程度

#### 2.2.1 耦合点分析

UI 层（`ui/cli.py`、`ui/display.py`）与核心层（`core/cli_controller.py`、`core/agent.py`）之间存在以下耦合点：

| 耦合点 | 位置 | 耦合类型 | 风险等级 |
|--------|------|----------|----------|
| `Agent.ui` 属性 | `core/agent.py:49` | 数据耦合 | 中 |
| `CliController` 直接访问 `Agent` 的内部属性 | `core/cli_controller.py` 多处 | 内容耦合 | **高** |
| `CliController` 直接调用 `print()` | `core/cli_controller.py:103,305` | 控制耦合 | 中 |
| `CliController` 直接操作终端控制序列 | `core/cli_controller.py:214-215` | 内容耦合 | **高** |
| `MessageHandler` 与 `CliController` 重复三层 Agent 逻辑 | `core/message_handler.py` vs `core/cli_controller.py` | 逻辑耦合 | **高** |
| Web 端完全绕过 CLI 控制器 | `web/server.py` | 架构分裂 | **高** |

#### 2.2.2 详细耦合分析

**（1）`Agent.ui` 属性的可空设计**

`core/agent.py` 第 49 行定义了 `self.ui = ui`，这是一个可选属性（`Optional[ConsoleInterface]`）。在整个代码库中，大量存在 `if a.ui:` 的检查（`core/cli_controller.py` 中至少有 15 处）。这种设计允许"无头模式"（headless mode）运行，对于测试和 Web 端是有益的。

然而，这种可空设计也导致了**防御式编程的泛滥**。每个 UI 操作都需要先检查 `a.ui` 是否存在，增加了代码噪音。更优雅的做法是引入**Null Object 模式**，创建一个 `NullConsoleInterface` 类，实现与 `ConsoleInterface` 相同的接口但所有方法为空操作。这样 `Agent.ui` 永远不为 `None`，可以消除所有的 `if a.ui:` 检查。

**（2）`CliController` 对 `Agent` 内部属性的深度访问**

`CliController` 通过 `self.a` 属性访问 `Agent` 实例，然后直接读取和修改大量内部属性：

- 读取：`a.state`、`a._running`、`a._prompt_shown`、`a.current_input`、`a.personality.config.name`、`a.short_term`、`a.ltm`、`a.retriever`、`a._tool_registry`、`a._react_messages`、`a._react_iteration`、`a._max_tool_iterations`、`a._tool_calls_pending`、`a._context`、`a._consecutive_negative`、`a.turn_count`、`a.last_activity_time`、`a.config` 等
- 修改：`a.state`、`a.current_input`、`a.current_response`、`a._react_messages`、`a._react_iteration`、`a._tool_calls_pending`、`a._prompt_shown`、`a.turn_count`、`a.last_activity_time`

这种**内容耦合**意味着 `CliController` 对 `Agent` 的内部实现细节有完全的依赖。如果 `Agent` 的内部结构发生变化（如重命名属性、改变数据结构），`CliController` 必须同步修改。这违反了**迪米特法则**（Law of Demeter）。

**（3）`CliController` 中的终端控制逻辑**

`core/cli_controller.py` 第 214-215 行：

```python
print("\r", end="", flush=True)
print(f"\033[1;36m{a.personality.config.name}:\033[0m ", end="", flush=True)
```

这段代码直接操作 ANSI 转义码和光标控制（`\r` 回车），这些细节应该完全封装在 `DisplayEngine` 中。当前设计导致：
- 控制器无法在不支持 ANSI 的环境中运行（如 Windows CMD 默认不支持 ANSI，除非启用虚拟终端处理）
- 测试困难：需要 mock `print()` 函数才能验证输出
- 无法支持其他输出方式（如日志文件、GUI 文本框）

**（4）`MessageHandler` 与 `CliController` 的逻辑重复**

这是本次审查发现的**最严重架构问题**。

`core/message_handler.py` 的 `MessageHandler` 类和 `core/cli_controller.py` 的 `CliController` 类都实现了三层 Agent 的协调逻辑：

| 功能 | `MessageHandler` | `CliController` |
|------|------------------|-----------------|
| Agent 1 (InnerDrive) 初始化 | `_ensure_inner_drive()` | `_ensure_inner_drive()` |
| Agent 2 (ToolAgent) 初始化 | `_ensure_tool_agent()` | `_ensure_tool_agent()` |
| 内部注册表构建 | `_make_internal_registry()` | `_make_internal_registry()` |
| Agent 1 评估 | `self._inner_drive.assess(user_input)` | `self._inner_drive.assess(user_input)` |
| Agent 2 执行 | 多轮 + 重试（`MAX_AGENT2_ROUNDS = 3`） | 单轮，无重试 |
| Agent 3 提示构建 | `build_system_prompt()` + `_build_messages()` | `build_system_prompt()` + 内联构建 |
| Agent 3 执行 | 委托给 `a._react_loop()` | 内联实现（流式/非流式） |
| 工具结果注入 | `messages.insert(-1, ...)` | `messages.append(...)` |

两者的代码重复度估计在 **60%-70%**。这种重复源于历史演进：Web 端最初可能直接调用了 `Agent.process_message()`，而 CLI 端使用状态机循环。后来为了支持 Web 端的三层 Agent 协调，创建了 `MessageHandler`，但 CLI 端的 `CliController` 没有被重构以复用 `MessageHandler`。

**后果：**
- 任何对三层 Agent 协调逻辑的修复或优化都需要在两个地方同步进行
- 两个路径的行为可能不一致（如 `MessageHandler` 支持 Agent 2 重试，`CliController` 不支持）
- 增加了维护成本和引入 bug 的风险

**（5）Web 端与 CLI 端的架构分裂**

Web 端（`web/server.py`、`web/session.py`）完全独立于 CLI 控制器：
- `WebAgent` 类直接创建 `Agent` 实例，不设置 `ui` 属性
- Web 端通过 `agent.process_message()` 调用 `MessageHandler`，不经过 `CliController`
- Web 端有自己的工具注册、记忆初始化、Provider 创建逻辑（`web/session.py` 第 28-79 行）
- Web 端的流式输出通过 WebSocket 分段发送，与 CLI 端的终端流式输出完全不同

这种分裂导致**大量初始化代码重复**：
- `main.py` 第 34-94 行 和 `web/session.py` 第 28-79 行都执行了几乎相同的初始化序列：创建 Database、Repository、Personality、LongTermMemory、ConversationBuffer、Provider、EmbeddingEngine、MemoryRetriever、MemoryConsolidator、ToolRegistry、Agent
- 唯一的区别是 Web 端还恢复了最近的对话历史（`web/session.py:36-37`）

**建议：** 提取一个 `AgentFactory` 或 `AgentBuilder` 类，统一封装 Agent 及其依赖的创建逻辑，消除 `main.py` 和 `web/session.py` 之间的重复。

---

### 2.3 控制台交互逻辑

#### 2.3.1 输入处理

`NonBlockingInputReader` 使用后台线程读取 `sys.stdin`，通过 `Queue` 实现非阻塞。这种设计允许状态机在 `IDLE` 状态时执行其他逻辑（如主动行为检测）。

**优点：**
- 简单有效，不需要依赖外部库（如 `select`、`curses`、`prompt_toolkit`）
- 跨平台兼容性好（Windows 和 Unix 都支持 `threading` 和 `sys.stdin`）

**缺点：**
- 在 Windows 上，`sys.stdin.readline()` 可能遇到编码问题（默认使用系统编码，而非 UTF-8）
- 不支持行编辑功能（如退格、光标移动、历史记录），用户体验较差
- 后台线程在程序退出时可能无法优雅终止（`stop()` 只设置标志，不 join）
- 如果 `sys.stdin` 被重定向为文件或管道，行为可能不符合预期

#### 2.3.2 输出处理

`DisplayEngine` 提供了打字机效果、换行、颜色输出等功能。

**打字机效果（`typewrite()`）：**

- 通过 `time.sleep()` 实现延迟，阻塞主线程
- 在 `_on_think()` 的流式输出中，打字机效果与 LLM 的流式生成叠加，可能导致输出速度不可控
- 对于长文本（如几百字），打字机效果会显著增加等待时间

**换行（`_word_wrap()`）：**

- 简单的基于空格的换行算法
- 不支持中文排版优化（如标点避头尾、全角/半角混合处理）
- 不处理 ANSI 转义序列长度

**颜色输出：**

- 硬编码的 ANSI 颜色码
- 没有检测终端是否支持颜色（如 `NO_COLOR` 环境变量、非 TTY 输出）
- 没有提供禁用颜色的选项

#### 2.3.3 命令处理

`_handle_command()` 实现了 7 个内置命令。命令处理是直接的条件分支（`if/elif`），没有使用命令模式或注册表。

**问题：**
- 无法扩展：添加新命令需要修改 `CliController` 的源代码
- 命令帮助文本硬编码在 `ConsoleInterface.display_help()` 中，与命令实现分离
- 命令没有参数解析支持（如 `/status --json`）

---

### 2.4 显示格式化

#### 2.4.1 `DisplayEngine` 的职责边界

`DisplayEngine` 的职责应该是"如何显示"，而不是"显示什么"。当前实现基本遵循了这一原则，但存在以下问题：

1. **横幅和帮助文本硬编码**：`ConsoleInterface.display_banner()` 和 `display_help()` 包含了具体的文本内容，这些内容应该由调用者提供或从配置中读取。

2. **颜色主题不可配置**：所有颜色码都是硬编码的，没有支持主题切换。

3. **缺乏输出抽象**：`DisplayEngine` 的方法直接调用 `print()`，没有抽象到更通用的输出接口（如 `write()`、`flush()`）。这使得无法将输出重定向到文件、日志或 GUI 组件。

#### 2.4.2 格式化算法问题

**`_word_wrap()` 的缺陷：**

```python
# ui/display.py:50-63
@staticmethod
def _word_wrap(text: str, width: int) -> list[str]:
    if width < 20:
        width = 20
    lines = []
    for paragraph in text.split("\n"):
        while len(paragraph) > width:
            break_at = paragraph.rfind(" ", 0, width)
            if break_at < width // 2:
                break_at = width
            lines.append(paragraph[:break_at])
            paragraph = paragraph[break_at:].strip()
        if paragraph:
            lines.append(paragraph)
    return lines
```

**问题 1：硬截断可能破坏单词**

当 `break_at < width // 2` 时，直接在 `width` 处截断。例如：
- `width = 40`，段落 = "这是一个非常长的中文段落没有任何空格所以会被硬截断"
- `rfind(" ", 0, 40)` 返回 -1（没有空格）
- `break_at = -1`，`-1 < 20` 为真，所以 `break_at = 40`
- 结果："这是一个非常长的中文段落没有任何空格所以会被"（40 个字符）

对于中文文本，这种截断在字符边界上是安全的（Python 字符串切片按 Unicode 码点），但视觉上可能截断在一个不自然的位置。

**问题 2：没有处理 CJK 字符宽度**

中文字符在终端中通常占 2 个列宽，而英文字符占 1 个。`len()` 函数返回的是字符数而非显示宽度。例如：
- 文本 "你好 world" 的 `len()` 是 8，但显示宽度是 9（"你好" 占 4，空格占 1，"world" 占 5）
- 如果 `width = 10`，`_word_wrap` 认为可以容纳 10 个字符，但实际上可能超出终端宽度

**问题 3：没有处理 ANSI 转义序列**

如果输入文本包含颜色码，如 `"\033[31m错误\033[0m"`，`len()` 返回 15（包含转义序列），但实际可见字符只有 2 个。这会导致换行过早。

---

### 2.5 CLI 控制器的职责

#### 2.5.1 当前职责清单

`CliController` 当前承担了以下职责：

1. **状态机管理**：维护 `AgentState` 的状态转换（`run()` 主循环）
2. **输入处理**：通过 `NonBlockingInputReader` 读取用户输入（`_on_idle()`）
3. **命令解析**：处理 `/` 开头的命令（`_handle_command()`）
4. **输出渲染**：通过 `DisplayEngine` 显示响应（`_on_boot()`、`_on_think()`、`_finish_react_response()`）
5. **三层 Agent 协调**：初始化并协调 InnerDriveAgent、ToolAgent、ReAct Agent（`_on_perceive()`、`_on_think()`、`_on_act()`）
6. **提示构建**：构建系统提示和消息列表（`_on_think()`）
7. **LLM 调用**：直接调用 `provider.generate()`（`_on_think()`）
8. **工具执行**：调用 `execute_tool_calls()`（`_on_act()`）
9. **记忆管理**：保存对话到短期和长期记忆（`_on_perceive()`、`_finish_react_response()`）
10. **记忆合并**：触发 consolidation（`_on_reflect()`、`_on_shutdown()`、`_handle_command()`）
11. **主动行为检测**：计算空闲时间和主动概率（`_on_idle()`）
12. **情绪处理**：保存 personality 状态（`_on_reflect()`）
13. **错误处理**：捕获和显示异常（`run()`）
14. **资源管理**：启动和停止 UI（`run()`、`_on_shutdown()`）

#### 2.5.2 职责分析

根据**单一职责原则**（SRP），一个类应该只有一个引起它变化的原因。`CliController` 至少有 14 个职责，明显违反了 SRP。

**应该保留在 `CliController` 中的职责：**
- 状态机管理（1）
- 输入处理（2）
- 命令解析（3）
- 输出渲染（4）
- 资源管理（14）

**应该移出 `CliController` 的职责：**
- 三层 Agent 协调（5）：应该由 `MessageHandler` 统一处理
- 提示构建（6）：应该由 `MessageHandler` 或专门的 `PromptBuilder` 处理
- LLM 调用（7）：应该由 `Agent` 或 `MessageHandler` 处理
- 工具执行（8）：应该由 `Agent` 或 `ToolExecutor` 处理
- 记忆管理（9）：应该由 `Agent` 处理
- 记忆合并（10）：应该由 `Agent` 处理
- 主动行为检测（11）：应该由 `ProactivityManager` 处理
- 情绪处理（12）：应该由 `Personality` 或 `Agent` 处理
- 错误处理（13）：部分可以保留，但业务逻辑错误应该由业务层处理

#### 2.5.3 理想的职责划分

```
CliController
├── 状态机循环 (run)
├── 输入读取 (_on_idle)
├── 命令分发 (_handle_command)
└── 生命周期管理 (start/stop)

Agent
├── 三层 Agent 协调 (delegate to MessageHandler)
├── 记忆管理 (short_term, ltm)
├── 情绪处理 (personality)
└── 主动行为 (delegate to ProactivityManager)

MessageHandler
├── Agent 1 协调 (InnerDrive)
├── Agent 2 协调 (ToolAgent)
├── Agent 3 协调 (ReAct loop)
├── 提示构建
└── 工具结果注入

DisplayEngine
├── 打字机效果
├── 换行
├── 颜色输出
└── 终端控制
```

---

### 2.6 架构问题与重复代码

#### 2.6.1 重复代码统计

| 重复代码块 | 位置 A | 位置 B | 重复度 |
|-----------|--------|--------|--------|
| Agent 初始化序列 | `main.py:34-94` | `web/session.py:28-79` | ~80% |
| 三层 Agent 协调 | `core/cli_controller.py:118-236` | `core/message_handler.py:64-156` | ~70% |
| `_ensure_inner_drive()` | `core/cli_controller.py:26-34` | `core/message_handler.py:29-40` | ~95% |
| `_ensure_tool_agent()` | `core/cli_controller.py:36-42` | `core/message_handler.py:47-53` | ~95% |
| `_make_internal_registry()` | `core/cli_controller.py:44-51` | `core/message_handler.py:55-62` | ~95% |
| 工具结果注入 | `core/cli_controller.py:180-181` | `core/message_handler.py:268-269` | ~80% |
| 记忆保存 | `core/cli_controller.py:270-271` | `core/message_handler.py:251-252` | ~90% |
| ConnectionError 处理 | `core/cli_controller.py:200-204` | `core/cli_controller.py:221-225` | ~95%（同一文件内） |
| 记忆合并触发 | `core/cli_controller.py:284-288` | `core/agent.py:216-221` | ~60% |

#### 2.6.2 关键架构问题

**问题 1：CLI 和 Web 双路径的代码重复**

`main.py` 和 `web/session.py` 都包含完整的 Agent 初始化逻辑。这种重复意味着：
- 添加新工具需要在两个地方注册
- 修改 Provider 参数需要在两个地方更新
- 修改记忆系统配置需要在两个地方同步

**问题 2：`CliController` 和 `MessageHandler` 的功能重叠**

两者都实现了三层 Agent 协调，但 `CliController` 的版本更旧、功能更少（缺少 Agent 2 重试）。这暗示了代码演进过程中的技术债务：`MessageHandler` 是为了 Web 端创建的，但 CLI 端没有被重构以使用它。

**问题 3：`Agent` 类的职责不清**

`core/agent.py` 的 `Agent` 类同时承担了：
- 数据容器（保存 personality、provider、memory 等引用）
- 业务逻辑（`_react_loop`、`_process_emotion`、`_max_tokens_for_emotion`）
- 委托入口（`process_message`、`process_proactive`、`run`）
- 状态管理（`_react_messages`、`_react_iteration`、`_tool_calls_pending`）

`Agent` 类有 255 行代码，加上导入和注释，是一个相当大的类。它知道太多关于 CLI 和 Web 两端的细节（如 `_react_loop` 是为 Web 端设计的，`run()` 委托给 `CliController` 是为 CLI 端设计的）。

**问题 4：缺乏统一的输出抽象**

CLI 端使用 `print()` 和 ANSI 转义码，Web 端使用 WebSocket JSON 消息。两者没有共享任何输出抽象。如果未来需要添加日志记录、指标收集或第三方集成，都需要分别实现。

**问题 5：异常处理不一致**

- `CliController.run()` 捕获所有异常并回到 `IDLE`
- `Agent._react_loop()` 没有 try-except，异常会向上传播
- `web/server.py` 的 WebSocket 处理有 try-except，但 REST API (`/api/chat`) 没有
- `execute_tool_calls()` 内部捕获工具执行异常，但 `asyncio.run()` 的调用可能引发 `RuntimeError`（如果已有事件循环运行）

---

### 2.7 风险评级与具体建议

#### 2.7.1 风险评级矩阵

| 问题 | 影响范围 | 发生概率 | 修复难度 | 风险等级 |
|------|----------|----------|----------|----------|
| `CliController` 与 `MessageHandler` 重复 | 维护成本、一致性 | 高 | 中 | **高** |
| CLI/Web 初始化代码重复 | 维护成本、一致性 | 高 | 低 | **高** |
| `CliController` 职责过重 | 可测试性、可维护性 | 高 | 中 | **高** |
| 终端控制逻辑泄漏到控制器 | 可移植性、可测试性 | 中 | 低 | 中 |
| ANSI 颜色码硬编码 | 可访问性、可配置性 | 中 | 低 | 中 |
| `_word_wrap` 算法缺陷 | 显示质量 | 中 | 低 | 中 |
| 异常处理过于宽泛 | 调试难度、可靠性 | 中 | 低 | 中 |
| `NonBlockingInputReader` 编码问题 | 跨平台兼容性 | 低 | 低 | 低 |
| 缺乏 Null Object 模式 | 代码噪音 | 高 | 低 | 低 |

#### 2.7.2 具体建议

**建议 1：统一三层 Agent 协调逻辑（优先级：高）**

将 `CliController` 中的三层 Agent 协调逻辑（`_on_perceive`、`_on_think`、`_on_act`）重构为使用 `MessageHandler`。`CliController` 只负责状态机循环和 UI 交互，`MessageHandler` 负责所有业务逻辑。

具体步骤：
1. 扩展 `MessageHandler` 以支持 CLI 端需要的功能（如流式输出回调）
2. 在 `CliController._on_perceive()` 中调用 `self.a._messages.handle_message()` 或等效方法
3. 移除 `CliController` 中的 `_inner_drive`、`_tool_agent`、`_tool_records`、`_inner_drive_result` 等状态
4. 确保 `MessageHandler` 的 Agent 2 多轮执行和重试机制也适用于 CLI 端

**建议 2：提取 AgentFactory 消除初始化重复（优先级：高）**

创建 `core/agent_factory.py`，封装 Agent 及其所有依赖的创建逻辑。

```python
class AgentFactory:
    def __init__(self, config: Config):
        self.config = config
    
    async def create_agent(self, db: Database = None, restore_history: bool = False) -> Agent:
        # 统一初始化逻辑
        ...
```

`main.py` 和 `web/session.py` 都使用 `AgentFactory` 创建 Agent。

**建议 3：引入 Null Object 模式（优先级：低）**

创建 `NullDisplayEngine` 和 `NullConsoleInterface` 类，实现相同接口但所有方法为空操作。

```python
class NullDisplayEngine:
    def typewrite(self, text: str, end: str = "\n") -> None: pass
    def respond(self, text: str, prefix: str = "") -> None: pass
    # ... 其他方法

class NullConsoleInterface:
    def __init__(self):
        self.reader = NullInputReader()
        self.display = NullDisplayEngine()
    # ... 其他方法
```

在 `Agent.__init__` 中默认使用 `NullConsoleInterface`，消除所有 `if a.ui:` 检查。

**建议 4：封装终端控制逻辑（优先级：中）**

将 `core/cli_controller.py` 第 214-215 行的终端控制逻辑移到 `DisplayEngine` 中：

```python
class DisplayEngine:
    def start_response(self, prefix: str) -> None:
        print("\r", end="", flush=True)
        print(f"\033[1;36m{prefix}:\033[0m ", end="", flush=True)
    
    def write_token(self, token: str) -> None:
        print(token, end="", flush=True)
```

**建议 5：改进 `_word_wrap()` 算法（优先级：中）**

1. 使用 `wcwidth` 库或类似方法正确处理 CJK 字符宽度
2. 过滤 ANSI 转义序列后再计算长度
3. 考虑使用 Python 的 `textwrap` 标准库作为基础

**建议 6：支持 `NO_COLOR` 环境变量（优先级：中）**

在 `DisplayEngine` 初始化时检查 `NO_COLOR` 环境变量，如果设置则禁用所有 ANSI 颜色码。

**建议 7：改进异常处理（优先级：中）**

1. 在 `CliController.run()` 中区分业务异常（如 `ConnectionError`）和编程错误（如 `AttributeError`）
2. 编程错误应该记录详细堆栈并终止程序，而不是静默恢复
3. 为 `Agent._react_loop()` 添加适当的异常处理

**建议 8：使用 `prompt_toolkit` 替代自定义输入读取（优先级：低）**

如果项目允许添加依赖，使用 `prompt_toolkit` 替代 `NonBlockingInputReader`，可以获得：
- 跨平台的行编辑支持
- 历史记录
- 自动补全
- 更好的 Unicode 支持
- 无需后台线程

---

## 三、汇总统计

### 3.1 文件统计

| 文件 | 总行数 | 类数 | 方法数 | 问题数 |
|------|--------|------|--------|--------|
| `ui/cli.py` | 72 | 2 | 9 | 6 |
| `ui/display.py` | 64 | 1 | 8 | 7 |
| `core/cli_controller.py` | 334 | 1 | 18 | 15 |
| **合计** | **470** | **4** | **35** | **28** |

### 3.2 问题分类统计

| 问题类型 | 数量 | 占比 |
|----------|------|------|
| 代码重复 | 9 | 32% |
| 职责过重/耦合 | 7 | 25% |
| 硬编码/不可配置 | 5 | 18% |
| 算法/实现缺陷 | 4 | 14% |
| 异常处理 | 3 | 11% |

### 3.3 风险等级统计

| 风险等级 | 问题数 | 占比 |
|----------|--------|------|
| 高 | 3 | 11% |
| 中 | 13 | 46% |
| 低 | 12 | 43% |

### 3.4 关键代码引用

**最严重的重复代码（`core/cli_controller.py` vs `core/message_handler.py`）：**

`core/cli_controller.py:26-51` 和 `core/message_handler.py:29-62` 几乎完全相同：

```python
# core/cli_controller.py:26-51
def _ensure_inner_drive(self):
    if self._inner_drive is None:
        from core.inner_drive import InnerDriveAgent
        a = self.a
        self._inner_drive = InnerDriveAgent(
            provider=a.provider, personality=a.personality,
            ltm=a.ltm, retriever=a.retriever, short_term=a.short_term,
            tool_registry=a._tool_registry,
        )

def _ensure_tool_agent(self):
    if self._tool_agent is None:
        from core.tool_agent import ToolAgent
        self._tool_agent = ToolAgent(
            provider=self.a.provider,
            tool_registry=self.a._tool_registry,
        )

def _make_internal_registry(self):
    from tools.traits import ToolRegistry
    r = ToolRegistry()
    for name in ("recall", "remember"):
        tool = self.a._tool_registry.get(name)
        if tool:
            r.register(tool)
    return r
```

```python
# core/message_handler.py:29-62
def _ensure_inner_drive(self):
    if self._inner_drive is None:
        from core.inner_drive import InnerDriveAgent
        a = self.a
        self._inner_drive = InnerDriveAgent(
            provider=a.provider,
            personality=a.personality,
            ltm=a.ltm,
            retriever=a.retriever,
            short_term=a.short_term,
            tool_registry=a._tool_registry,
        )

def _ensure_tool_agent(self):
    if self._tool_agent is None:
        from core.tool_agent import ToolAgent
        self._tool_agent = ToolAgent(
            provider=self.a.provider,
            tool_registry=self.a._tool_registry,
        )

def _make_internal_registry(self):
    from tools.traits import ToolRegistry
    r = ToolRegistry()
    for name in ("recall", "remember"):
        tool = self.a._tool_registry.get(name)
        if tool:
            r.register(tool)
    return r
```

**终端控制逻辑泄漏（`core/cli_controller.py:211-217`）：**

```python
# core/cli_controller.py:211-217
def on_token(tok: str) -> None:
    if tok and not stream_done:
        if not accumulated and a.ui:
            print("\r", end="", flush=True)
            print(f"\033[1;36m{a.personality.config.name}:\033[0m ", end="", flush=True)
        accumulated.append(tok)
        if a.ui:
            print(tok, end="", flush=True)
```

**直接 `print()` 调用（`core/cli_controller.py:103`）：**

```python
# core/cli_controller.py:103
print("\033[33m用户输入: \033[0m", end="", flush=True)
```

**`_word_wrap` 算法问题（`ui/display.py:50-63`）：**

```python
# ui/display.py:50-63
@staticmethod
def _word_wrap(text: str, width: int) -> list[str]:
    if width < 20:
        width = 20
    lines = []
    for paragraph in text.split("\n"):
        while len(paragraph) > width:
            break_at = paragraph.rfind(" ", 0, width)
            if break_at < width // 2:
                break_at = width
            lines.append(paragraph[:break_at])
            paragraph = paragraph[break_at:].strip()
        if paragraph:
            lines.append(paragraph)
    return lines
```

---

## 四、结论

AI Friend 项目的 UI 层架构在当前阶段基本可用，但存在明显的技术债务和架构风险。最核心的问题是 **CLI 控制器与消息处理器之间的功能重复**，这导致了维护成本增加、行为不一致的风险。其次，**CLI 端和 Web 端的初始化代码重复**也是一个需要优先解决的问题。

`DisplayEngine` 和 `ConsoleInterface` 的设计相对简单，能够满足当前需求，但在可配置性、可测试性和跨平台兼容性方面有待改进。`CliController` 的职责过重，需要进行职责拆分，将业务逻辑委托给 `MessageHandler` 和 `Agent`。

建议按照以下优先级进行重构：

1. **高优先级**：统一三层 Agent 协调逻辑（合并 `CliController` 和 `MessageHandler` 的重复代码）
2. **高优先级**：提取 `AgentFactory` 消除 CLI/Web 初始化重复
3. **中优先级**：封装终端控制逻辑，改进 `_word_wrap` 算法
4. **中优先级**：改进异常处理和错误报告
5. **低优先级**：引入 Null Object 模式，支持 `NO_COLOR`，考虑使用 `prompt_toolkit`

---

*报告生成时间：2026-05-31*
*审查文件：ui/cli.py、ui/display.py、core/cli_controller.py、core/agent.py、core/message_handler.py、web/server.py、web/session.py、main.py、tests/test_cli_controller.py*
