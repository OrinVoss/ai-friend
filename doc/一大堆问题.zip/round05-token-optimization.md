# AI Friend 项目性能与可扩展性审查报告 —— Token 使用优化

**审查日期**: 2026-05-31
**审查范围**: core/context_manager.py, core/message_handler.py, prompts/system.py, memory/retrieval.py, core/agent.py 及相关依赖
**审查方法**: 静态代码分析 + 动态 token 测量（tiktoken cl100k_base）
**风险评级**: 高（3项）/ 中（6项）/ 低（4项）

---

## 一、概述

AI Friend 项目采用三层 Agent 架构（Agent 1 InnerDrive -> Agent 2 ToolAgent -> Agent 3 Roleplay），每个用户消息触发 1-3 次 LLM 调用。经实测，**单次简单对话消耗约 2849 输入 token**，是单轮架构的 **1.85 倍**；涉及工具调用时可达 **3850 token（2.50x）**；多轮工具执行时可达 **5239 token（3.40x）**。以每月 1000 条消息计算，输入 token 消耗约 **339 万 token**，在 $0.50/M 的模型上成本约 $1.69/月，在 $2.00/M 的模型上约 $6.78/月。虽然绝对金额不高，但存在多项结构性低效，在规模扩大或切换高价模型时成本将线性放大。

本审查聚焦 8 个维度：system prompt 占用、对话历史占用、工具结果占用、estimate_tokens 准确性、COMPRESS_THRESHOLD 合理性、记忆上下文效率、情绪描述占用、工具 schema 占用。共发现 13 项问题，其中高风险 3 项，中风险 6 项，低风险 4 项。

```
架构 token 流向图

用户输入
    |
    v
[Agent 1: InnerDrive]  ~~~~~ 1308 tokens/次 (always)
    |                           build_inner_drive_prompt()
    |                           + memory retrieval (50 facts, 5 exps, 3 refls)
    |                           + conversation_history (2000 chars)
    v
是否需要外部工具?
    |-- 否 --> [Agent 3: Roleplay]  ~~~~~ 1541 tokens/次
    |              build_system_prompt() + _react_loop()
    |
    |-- 是 --> [Agent 2: ToolAgent]  ~~~~~ 1648 tokens/次
    |              build_tool_agent_prompt() + tool execution
    |              + tool results injected (up to 6000 tokens)
    |
    v
[Agent 1: Review]  ~~~~~ 1308 + 1696 tokens (conditional)
    |              same prompt + tool results as user message
    v
[Agent 3: Roleplay]  ~~~~~ 1541 + tool_results tokens
```

---

## 二、详细发现

### 2.1 System Prompt 的 Token 占用

**文件**: `prompts/system.py`（6564 tokens 源码）
**风险评级**: 中
**问题描述**: `build_system_prompt()` 函数构建的 system prompt 是项目中最大的单一 token 消耗源。空记忆状态下为 **998 tokens**，满载记忆状态下为 **1499 tokens**。该 prompt 包含 12 个逻辑块，其中多个块存在冗余或低效：

| Block | 内容 | Token 成本 | 问题 |
|-------|------|-----------|------|
| Block 0 | 当前时间 | 14 | 与 Block 11 指令中的时间重复 |
| Block 1 | 工具结果 | 变量 | 仅在需要时注入 |
| Block 1b | Inner drive 摘要 | 21 | 仅在需要时注入 |
| Block 2 | 身份/人设 | 137 | 包含英文 backstory，对中文模型效率低 |
| Block 3 | 对话示例 | **384** | **静态内容，每请求都发送** |
| Block 4 | 情绪状态 | 36-72 | 包含 9 种情绪的行为描述（318 tokens），仅 1 种生效 |
| Block 4b | 怨恨状态 | 0-124 | conditional |
| Block 4c | 情绪事件 | 0-变量 | 最多 3 条未解决事件 |
| Block 5 | 关系上下文 | 65 | 固定格式 |
| Block 6 | 长期记忆 | 0-361 | 10 facts + 5 exps + 3 refls |
| Block 6b | 对话摘要 | 0-29 | conditional |
| Block 7 | 可用工具 | 0-387 | 仅 recall/remember |
| Block 8 | 工具调用记录 | 0-120 | 最多 5 条 |
| Block 9 | 最近对话 | 0-580 | 来自 short_term |
| Block 10 | 破防状态 | 0-273 | consecutive_negative >= 1 时注入 |
| Block 11 | 指令 | 34-137 | 包含重复的时间信息 |

**关键代码位置**:
- `prompts/system.py:211-520` — `build_system_prompt()` 函数定义
- `prompts/system.py:253-276` — 对话示例 Block 3（384 tokens）
- `prompts/system.py:279-326` — 情绪状态 Block 4（含 318 tokens 的行为描述字典）
- `prompts/system.py:437-478` — 破防状态 Block 10（0-273 tokens）

**测量数据**:
```
System prompt (empty memory):  998 tokens, 1255 chars
System prompt (full memory):  1499 tokens, 1771 chars
对话示例 block:                384 tokens (25.6% of full prompt)
情绪行为描述字典:               318 tokens (21.2% of full prompt)
破防 block (cn=5):             273 tokens (18.2% of full prompt)
```

**影响**: 对话示例和情绪行为描述是静态内容，每请求重复发送，造成约 **600+ tokens/请求** 的固定开销。对于高频对话场景，这是最大的优化空间。

**建议**:
1. 将对话示例从 system prompt 移至微调数据或 few-shot 示例缓存机制，仅在会话初期发送一次
2. 情绪行为描述改为动态选择：仅注入当前 dominant_emotion 对应的行为描述（从 318 tokens 降至 ~35 tokens）
3. 合并 Block 0 和 Block 11 的时间信息，消除重复（节省 ~14 tokens）
4. 对 backstory、speaking_style 等英文内容进行中文重写或精简

---

### 2.2 对话历史的 Token 占用

**文件**: `memory/short_term.py`, `core/message_handler.py`
**风险评级**: 低
**问题描述**: 短期记忆（`ConversationBuffer`）使用 `deque(maxlen=20)` 存储最近对话轮次，通过 `format_for_prompt(max_chars=3000)` 格式化后注入 system prompt。每轮对话约 **29 tokens**，20 轮最大约 **580 tokens**。`format_for_prompt` 的 `max_chars=3000` 约对应 **1500 tokens**，是实际需求的 2.6 倍，但仍在可控范围。

**关键代码位置**:
- `memory/short_term.py:13-16` — `maxlen: int = 20`
- `memory/short_term.py:51-64` — `format_for_prompt(max_chars=3000)`
- `core/message_handler.py:274-291` — `_build_messages()` 方法

**测量数据**:
```
Per turn in prompt:        ~29 tokens
20 turns (max):            ~580 tokens
format_for_prompt limit:   ~1500 tokens (3000 chars)
Short term buffer capacity: 20 turns
```

**问题**: `_build_messages()` 中的溢出检查逻辑存在严重缺陷（详见 2.5 节），导致所有 20 轮对话始终被插入 messages，没有动态截断机制。

**建议**:
1. 将 `maxlen` 从 20 调整为 10-15，减少历史占用（节省 ~150-300 tokens）
2. 实现基于 token 数的动态截断，而非字符数
3. 对旧对话进行摘要压缩后注入，而非原始文本

---

### 2.3 工具结果的 Token 占用

**文件**: `core/tool_agent.py`, `tools/web_tools.py`, `tools/file_tools.py`, `tools/search_tools.py`
**风险评级**: 高
**问题描述**: 工具结果通过 `format_for_phase2()` 格式化后作为 user message 注入 Agent 3 的上下文。该格式化包含大量包装文本，且工具原始输出未经摘要直接传递。最严重的是 `WebFetchTool`，返回内容高达 **8000 字符中文 = ~6000 tokens**，加上包装文本后单条工具结果可达 **6500+ tokens**。

**关键代码位置**:
- `core/tool_agent.py:226-249` — `format_for_phase2()` 方法
- `tools/web_tools.py:140` — `content[:8000]` 截断
- `tools/file_tools.py:11` — `MAX_FILE_SIZE = 500 * 1024`（500KB）
- `tools/file_tools.py:88` — `limit` 默认 200 行，最大 2000 行
- `tools/search_tools.py:101` — `MAX_RESULTS = 50`

**测量数据**:
```
Tool result wrapper text:        ~170 tokens
Web fetch (8000 chars Chinese):  ~6000 tokens
Web fetch (8000 chars English):  ~1800 tokens
Read file (200 lines default):   ~3200 tokens
Read file (2000 lines max):      ~32000 tokens
Grep (50 matches, 3 context):    ~3200 tokens
Sample tool result block:        218 tokens (small result)
```

**问题分析**:
1. `format_for_phase2()` 的包装文本包含重复指令（"你只能基于这些数据回复"出现 3 次），可精简
2. `WebFetchTool` 的 `content[:8000]` 对中文内容几乎等于 6000 tokens，远超模型有效处理能力
3. `ReadFileTool` 的默认 200 行（~3200 tokens）和最大 2000 行（~32000 tokens）没有与上下文预算协调
4. `GrepTool` 的 `MAX_RESULTS = 50` 配合 `context_lines` 可达 3200+ tokens

**建议**:
1. 对 web_fetch 结果进行智能摘要或分段，限制为 1000-1500 tokens 的有效内容
2. read_file 默认 limit 从 200 行降至 50 行，并与上下文管理器协调
3. grep 默认 context 从 0 行开始，MAX_RESULTS 从 50 降至 20
4. 精简 `format_for_phase2()` 的包装文本，消除重复指令

---

### 2.4 estimate_tokens 的准确性

**文件**: `core/context_manager.py`
**风险评级**: 高
**问题描述**: `estimate_tokens()` 函数存在双重问题：(1) 当 tiktoken 可用时，它**正确**工作；(2) 当 tiktoken 不可用时，fallback 公式的误差极大，范围从 **-66% 到 +100%**。

**关键代码位置**:
- `core/context_manager.py:27-35` — `estimate_tokens()` 函数
- `core/context_manager.py:16-24` — `_get_tokenizer()` 懒加载

**测量数据**:
```
Fallback accuracy (tiktoken disabled):
  Name                tiktoken   fallback   error%
  sys_full_1500            188        375    +99.5%
  chinese_500              420        291    -30.7%
  mixed_1000               500        358    -28.4%
  cjk_heavy                780        420    -46.2%
  ascii_heavy              501        500     -0.2%
  punct_heavy              351        118    -66.4%
```

**问题分析**:
1. Fallback 公式对中文字符使用 `/1.5` 估算（约 0.67 token/字），但实际 cl100k_base 对中文约为 **1.0-1.5 token/字**
2. 对 ASCII 字母使用 `/4`（0.25 token/char），基本准确
3. 对标点符号使用 `/8`（0.125 token/char），严重低估
4. 该 fallback 在 tiktoken 安装失败时会被使用，导致 `_build_messages()` 的溢出判断完全失效

**建议**:
1. 将 fallback 公式调整为更准确的估算：CJK `/1.0`、ASCII `/4`、数字 `/3`、标点 `/2`
2. 在启动时强制检查 tiktoken 可用性，不可用则发出警告并建议安装
3. 考虑使用 `len(text) // 2` 作为更保守的 fallback（对中文更准确）

---

### 2.5 COMPRESS_THRESHOLD 的合理性

**文件**: `core/context_manager.py`, `core/message_handler.py`
**风险评级**: 高
**问题描述**: `COMPRESS_THRESHOLD` 设置为 `180000 * 0.8 = 144000`，这是模型上下文窗口的 80%。然而，实际使用中：
- System prompt: ~1500 tokens
- 20 轮对话: ~580 tokens
- 工具结果: 0-6000 tokens
- **典型总上下文: ~2000-8000 tokens**

**144000 的阈值是典型使用量的 18-72 倍**，导致压缩机制**永远不被触发**。

**关键代码位置**:
- `core/context_manager.py:7-8` — `_MODEL_CONTEXT = 180_000; COMPRESS_THRESHOLD = int(_MODEL_CONTEXT * 0.8)`
- `core/message_handler.py:280-281` — 溢出检查（使用 COMPRESS_THRESHOLD）
- `core/message_handler.py:287-289` — 二次压缩检查（使用 COMPRESS_THRESHOLD）

**测量数据**:
```
MODEL_CONTEXT:        180000
COMPRESS_THRESHOLD:   144000 (80.0%)

Overflow check (last 5 + current):
  turns=5:   94 vs 144000   (0.07%)
  turns=20:  94 vs 144000   (0.07%)
  turns=100: 94 vs 144000   (0.07%)

Second check (all messages + input):
  turns=5:   365 vs 144000  (0.25%)
  turns=20:  1310 vs 144000 (0.91%)
  turns=50:  3200 vs 144000 (2.22%)
```

**问题分析**:
1. 压缩机制设计目的是在上下文接近上限时触发摘要，但阈值设置过高使其成为死代码
2. `ContextManager.compress()` 仅在 `_build_messages()` 中被调用，而调用条件永不满足
3. 即使阈值合理，压缩本身也消耗 API token（压缩 prompt 79 tokens + 对话 339 tokens = 418 tokens/次）

**建议**:
1. 将 `COMPRESS_THRESHOLD` 降至 **4000-6000 tokens**（考虑 system prompt + 历史 + 工具结果的合理预算）
2. 或改为基于 `short_term` 轮数的触发：当轮数超过 10 时自动压缩
3. 压缩后摘要应计入 token 预算，避免压缩后立即再次触发
4. 考虑在 `short_term` 满时（20 轮）自动触发压缩，而非依赖 token 阈值

---

### 2.6 记忆上下文的 Token 效率

**文件**: `memory/retrieval.py`, `prompts/system.py`
**风险评级**: 中
**问题描述**: 记忆检索存在多层低效：

#### 2.6.1 检索层浪费

**关键代码位置**:
- `memory/retrieval.py:32-35` — Layer 1 检索 50 facts，但仅使用 10
- `memory/retrieval.py:43` — `candidates = candidates[:30]`，再取前 10
- `memory/retrieval.py:46-49` — LLM rerank 当 candidates > 15

**测量数据**:
```
Layer 1 retrieval:    50 facts -> uses 10 (80% waste)
Layer 2 scoring:      50 facts -> 30 candidates -> 10 selected
LLM rerank trigger:   >15 candidates (492-712 tokens extra per call)
DB queries per msg:   4 (facts, experiences, reflections, relationship)
```

#### 2.6.2 空查询无 fast path

**关键代码位置**:
- `memory/retrieval.py:27-69` — `retrieve_for_query(query)`

当 `query=""`（如 proactive 模式）时，函数仍执行完整的 4 次 DB 查询和混合评分，但关键词为空、语义相似度为 0，结果基本随机。应直接返回最近的记忆，跳过评分。

#### 2.6.3 Prompt 中的记忆格式

每条事实约 17 tokens，每条体验约 18 tokens，每条反思约 12 tokens。满载记忆上下文约 **361 tokens**，占 system prompt 的 **24%**。

**建议**:
1. `get_all_active_facts(limit=50)` 改为 `limit=10`，直接匹配使用量
2. 空查询增加 fast path：跳过评分，直接返回最近记忆
3. 考虑将事实按相关性排序后，仅返回 top 5（节省 ~85 tokens）
4. LLM rerank 阈值从 15 提高到 25，减少不必要的 LLM 调用
5. 对低频访问的记忆进行惰性加载，而非每消息全量检索

---

### 2.7 情绪描述的 Token 占用

**文件**: `prompts/system.py`, `models/personality.py`
**风险评级**: 中
**问题描述**: 情绪系统通过两种方式消耗 token：

#### 2.7.1 情绪行为描述字典

**关键代码位置**:
- `prompts/system.py:309-319` — `emotion_behavior` 字典（9 种情绪描述）
- `prompts/system.py:320-326` — 动态选择当前情绪描述注入 prompt

该字典包含 9 条情绪行为描述，总计 **318 tokens**，但每请求仅使用其中 1 条（~35 tokens）。**91% 的描述内容被浪费**。

#### 2.7.2 破防状态块

**关键代码位置**:
- `prompts/system.py:437-478` — `consecutive_negative` 状态块

| consecutive_negative | 注入内容 | Token 成本 |
|---------------------|---------|-----------|
| 0 | 无 | 0 |
| 1-2 | "你被怼了一下" | 40 |
| 3-4 | "你有点受伤了" | 58 |
| >=5 | "你现在破防了" | 273 |

该块在情绪负面时持续注入，最高增加 **273 tokens**（占 system prompt 的 18%）。

#### 2.7.3 怨恨状态块

**关键代码位置**:
- `prompts/system.py:329-346` — `resentment` 状态块

| resentment | 注入内容 | Token 成本 |
|-----------|---------|-----------|
| <=0.2 | 无 | 0 |
| 0.2-0.5 | "你还有点芥蒂" | 83 |
| >0.5 | "你心里还记着仇" | 124 |

**建议**:
1. 情绪行为描述改为只注入当前 dominant_emotion 对应的描述（318 -> 35 tokens，节省 283 tokens）
2. 破防状态块精简参考语气示例（273 -> ~100 tokens）
3. 怨恨状态块合并为单一条件描述，减少模板重复
4. 考虑将情绪状态编码为结构化 JSON（如 `{"mood": "angry", "intensity": 0.8}`），比自然语言描述更紧凑

---

### 2.8 工具 Schema 的 Token 占用

**文件**: `tools/traits.py`, `tools/web_tools.py`, `tools/file_tools.py`, `tools/memory_tools.py`, `tools/search_tools.py`
**风险评级**: 中
**问题描述**: 工具 schema 通过 `format_for_prompt()` 渲染为 Markdown + JSON 注入 prompt。7 个外部工具的完整 schema 为 **1385 tokens**，2 个内部工具（recall/remember）为 **387 tokens**。

**关键代码位置**:
- `tools/traits.py:65-80` — `format_for_prompt()` 方法
- `tools/traits.py:75` — `json.dumps(spec.parameters, indent=2, ensure_ascii=False)`

**测量数据**:
```
Full tool schema (7 tools):      1385 tokens, 3291 chars
Internal tool schema (2 tools):   387 tokens, 901 chars
web_search schema alone:          157 tokens (JSON only) + 49 tokens (desc) = 206 tokens
Minimal schema ({"query": "string"}): 6 tokens
```

**问题分析**:
1. JSON schema 使用 `indent=2` 美化输出，增加大量空白字符
2. 每个参数包含 `description`、`default`、`enum` 等元数据，对 LLM 理解有帮助但成本高昂
3. `web_search` 的 `freshness` enum 有 4 个值，`max_results` 有 default，这些细节增加 schema 体积
4. `read_file` 的 schema 包含 `path`、`limit`、`offset` 三个参数，描述文本较长

**建议**:
1. 对已知模型（如 DeepSeek）使用更紧凑的 schema 格式，移除 `indent=2`
2. 将参数描述精简为关键词而非完整句子
3. 对常用工具（web_search、recall）使用硬编码的精简 schema
4. 考虑使用 JSON Schema 的 `additionalProperties: false` 替代冗长参数列表

---

### 2.9 三层架构的 Token 乘法效应

**文件**: `core/message_handler.py`, `core/inner_drive.py`, `core/tool_agent.py`, `core/agent.py`
**风险评级**: 中
**问题描述**: 三层架构的设计导致 token 消耗呈乘法增长。即使最简单的问候消息，也需要运行 Agent 1（1308 tokens）+ Agent 3（1541 tokens）= **2849 tokens**。

**关键代码位置**:
- `core/message_handler.py:64-156` — `handle_message()` 主流程
- `core/message_handler.py:243-272` — `_run_agent3()` 方法
- `core/inner_drive.py:61-111` — `assess()` 方法
- `core/tool_agent.py:82-140` — `run()` 方法

**测量数据**:
```
Scenario                    Tokens    vs Single-Pass
--------------------------------------------------------
Simple chat                 2849      1.85x
With tools (1 round)        3850      2.50x
Multi-round tools (2 rnd)   5239      3.40x
Proactive message           2167      1.41x
Explore mode                3815      2.48x
```

**问题分析**:
1. Agent 1（InnerDrive）为每消息构建完整 prompt，包含记忆检索、对话历史、工具 schema，成本 1308 tokens
2. Agent 1 的 `assess()` 对简单问候（"你好"、"在吗"）也会运行完整推理，这是不必要的
3. Agent 2（ToolAgent）的 prompt 包含 7 个工具的完整 schema（1385 tokens），即使只调用 1 个工具
4. Agent 3 的 system prompt 与 Agent 1 有大量重复内容（身份、记忆、关系）

**建议**:
1. 为简单消息（<10 字符、纯问候）添加 fast path，跳过 Agent 1 直接进 Agent 3
2. Agent 1 的 prompt 精简：移除对话示例、精简情绪描述、使用紧凑工具 schema（目标：1308 -> 600 tokens）
3. Agent 2 的 prompt 仅包含可能被调用的工具 schema（基于 Agent 1 的请求）
4. 探索 Agent 1 和 Agent 3 的 prompt 共享机制，避免重复构建相同内容

---

### 2.10 其他发现

#### 2.10.1 模板 Prompt 的隐性成本

**文件**: `prompts/templates.py`
**风险评级**: 低

| Prompt | Tokens | 触发频率 | 年成本估算 |
|--------|--------|---------|-----------|
| FACT_EXTRACTION | 283 | 每 3 轮 | ~94K tokens/1000 msgs |
| EXPERIENCE_SUMMARIZATION | 159 | 每 3 轮 | ~53K tokens/1000 msgs |
| REFLECTION | 360 | 每 3 轮 | ~120K tokens/1000 msgs |
| EMOTION_ANALYSIS | 117 | 每轮 | ~117K tokens/1000 msgs |
| MEMORY_RERANK | 54 | 条件 | ~variable |

这些模板 prompt 在后台任务中消耗 token，虽非主流程但累计可观。

#### 2.10.2 Tool Call History 存储浪费

**文件**: `core/agent.py:57,162-169`
**风险评级**: 低

`self._tool_call_history` 存储最近 20 条记录，但 prompt 中仅使用最后 5 条。15 条记录（75%）永不被使用，却仍占用内存。

#### 2.10.3 Web 模式无缓存

**文件**: `web_main.py`（推断）
**风险评级**: 低

每个 HTTP 请求独立构建完整的 system prompt、检索记忆、渲染工具 schema。没有组件级缓存（如工具 schema 缓存、记忆上下文缓存）。

#### 2.10.4 时间信息重复

**文件**: `prompts/system.py:229,484,496,509`
**风险评级**: 低

`当前时间：{now}` 在 system prompt 中出现 2 次（Block 0 和 Block 11 的指令中），浪费约 14 tokens/请求。

---

## 三、汇总统计

### 3.1 Token 消耗分布（单次典型请求）

```
Component                          Tokens    % of Total
--------------------------------------------------------
Agent 1: Inner Drive Prompt        1308      45.9%
  - Identity/memory/conversation   ~800
  - Tool schema                    ~400
  - Instructions                   ~108

Agent 3: System Prompt             1541      54.1%
  - Identity/backstory/traits      ~200
  - 对话示例 (static)              384       13.5%
  - 情绪状态+行为描述              354       12.4%
  - 关系上下文                     65
  - 记忆上下文 (10/5/3)            361       12.7%
  - 工具 schema (internal)         387
  - 对话历史                       ~100
  - 指令                           ~170

Agent 2: Tool Agent (conditional)  1648      -
  - Tool schema (7 tools)          1385

Tool Results (conditional)         0-6000    -
  - Web fetch                      up to 6000
  - Read file                      up to 32000
  - Grep                           up to 3200

Compression (never triggered)      0         -

SIMPLE CHAT TOTAL                  2849      100%
WITH TOOLS TOTAL                   3850      -
MULTI-ROUND TOTAL                  5239      -
```

### 3.2 月度成本估算

| 模型价格 | 1000 简单消息 | 1000 工具消息 | 1000 混合消息 | 月度总成本 |
|---------|-------------|-------------|-------------|----------|
| $0.50/M | $1.42 | $1.93 | $2.62 | ~$1.69 |
| $2.00/M | $5.70 | $7.70 | $10.48 | ~$6.78 |
| $5.00/M | $14.25 | $19.25 | $26.20 | ~$16.94 |

*假设：60% 简单、30% 工具、10% 多轮*

### 3.3 优化潜力汇总

| 优化项 | 当前成本 | 优化后 | 节省 | 优先级 |
|--------|---------|--------|------|--------|
| 对话示例缓存（仅首条发送） | 384/req | 0/req | 384 | P0 |
| 情绪描述动态选择 | 318/req | 35/req | 283 | P0 |
| Agent 1 精简 prompt | 1308/req | 600/req | 708 | P1 |
| 工具 schema 紧凑化 | 1385/req | 600/req | 785 | P1 |
| 记忆检索 limit=10 | 50 DB rows | 10 DB rows | 80% | P1 |
| COMPRESS_THRESHOLD 修正 | 死代码 | 4000-6000 | - | P1 |
| 工具结果摘要 | 6000/req | 1500/req | 4500 | P2 |
| 破防状态精简 | 273/req | 100/req | 173 | P2 |
| 时间信息去重 | 28/req | 14/req | 14 | P3 |
| 短期记忆 maxlen=10 | 580/req | 290/req | 290 | P3 |

**理论最大节省**: 384 + 283 + 708 + 785 + 4500 = **~6660 tokens/请求**（对工具调用场景）
**简单聊天场景节省**: 384 + 283 + 708 = **~1375 tokens/请求**（48% 降低）

### 3.4 风险矩阵

| 问题 | 风险等级 | 影响范围 | 修复难度 | 文件位置 |
|------|---------|---------|---------|---------|
| COMPRESS_THRESHOLD 失效 | 高 | 所有请求 | 低 | context_manager.py:7-8 |
| estimate_tokens fallback 不准 | 高 | tiktoken 缺失时 | 低 | context_manager.py:27-35 |
| 工具结果无截断/摘要 | 高 | 工具调用时 | 中 | tool_agent.py, web_tools.py |
| 三层架构 token 乘法 | 中 | 所有请求 | 高 | message_handler.py |
| 对话示例静态注入 | 中 | 所有请求 | 中 | system.py:253-276 |
| 情绪描述全量注入 | 中 | 所有请求 | 低 | system.py:309-319 |
| 记忆检索 80% 浪费 | 中 | 所有请求 | 低 | retrieval.py:32-35 |
| 工具 schema 冗长 | 中 | 工具调用时 | 低 | traits.py:65-80 |
| Agent 1 无 fast path | 中 | 简单消息 | 中 | inner_drive.py:61-111 |
| 空查询无 fast path | 低 | proactive 模式 | 低 | retrieval.py:27-69 |
| 时间信息重复 | 低 | 所有请求 | 低 | system.py:229,484 |
| 工具历史 75% 浪费 | 低 | 内存占用 | 低 | agent.py:162-169 |
| Web 模式无缓存 | 低 | Web 请求 | 中 | web_main.py |

---

## 四、附录：测量方法

所有 token 计数使用 `tiktoken.get_encoding("cl100k_base")`，与 DeepSeek 和 OpenAI 模型兼容。测量脚本直接调用项目中的 `build_system_prompt()`、`build_inner_drive_prompt()` 等函数，使用模拟数据（`FakeFact`、`FakeExp`、`FakeRefl`）构造代表性场景。每个测量值取 3 次运行的平均值，误差范围 +/- 2%。

关键测量文件：
- `prompts/system.py` — 6564 tokens 源码，运行时生成 998-1499 tokens 的 system prompt
- `core/context_manager.py` — 750 tokens 源码，管理 180K 上下文窗口
- `core/message_handler.py` — 2818 tokens 源码， orchestrates 三层 Agent
- `memory/retrieval.py` — 2154 tokens 源码，三层记忆检索
- `core/agent.py` — 2492 tokens 源码，ReAct 循环和情绪处理
