# AI Friend Web 层架构深度审查报告（Round 01）

**审查日期**：2026-05-31
**审查范围**：`web/server.py`、`web/session.py`、`web/__init__.py` 及其与核心 Agent、存储层、前端 JS 的集成
**审查目标**：识别 Web 层在路由/中间件/错误处理、会话生命周期、WebSocket 处理、并发安全、内存管理、架构耦合等方面的缺陷与风险

---

# 概述

AI Friend 项目的 Web 层采用 FastAPI + WebSocket 架构，通过 `SessionManager` 管理多会话生命周期，每个会话对应一个 `WebAgent` 实例（封装核心三层 Agent 架构）。Web 层同时支持 REST (`/api/chat`) 和 WebSocket (`/ws`) 双通道，前端通过纯 HTML/CSS/JS 实现分段消息渲染和自动重连。

本次审查发现 **3 个高危缺陷**、**5 个中危缺陷**、**8 个低危/架构建议项**，总体风险评级为 **中-高**（主要风险集中在会话隔离缺失、并发安全漏洞、内存泄漏路径和错误处理不完善）。

---

## 详细发现

### 一、会话管理与生命周期（高危 ×1，中危 ×2）

#### 【高危-1】SQLite 数据无会话隔离 — 所有会话共享同一张表

**文件**：`D:\桌面\编程作品\AI朋友\web\session.py:28-79`

`WebAgent` 在初始化时接收全局共享的 `Database` 和 `Repository` 实例：

```python
class WebAgent:
    def __init__(self, config: Config, db: Database, repo: Repository):
        ...
        self.ltm = LongTermMemory(repo)
        self.short_term = ConversationBuffer(maxlen=config.short_term_capacity)
        # Restore recent conversation from DB (fixes #98)
        for t in repo.get_recent_turns_sync(30):
            self.short_term.add_turn(t["role"], t["content"])
```

**问题分析**：
1. `Repository` 和 `LongTermMemory` 没有 `session_id` 字段。`conversation_turns`、`user_facts`、`experiences` 等表均没有会话隔离列。
2. 会话 A 恢复时，会加载会话 B 最近写入 DB 的对话轮次（因为 `get_recent_turns_sync(30)` 是按全局 `id DESC` 取的）。
3. 多用户同时使用时，A 用户的记忆会泄漏给 B 用户，B 用户的事实提取会混入 A 用户的对话内容。
4. 这是架构级缺陷，当前文档 `technical.md` 第 7.5 节已标注为"待修复"（"共享 SQLite（无 session_id 隔离，待修复）"），但代码中仍未解决。

**风险**：隐私泄漏、人格污染、多用户场景下完全不可用。

**建议**：
- 在 `conversation_turns`、`user_facts`、`experiences`、`reflections` 表中增加 `session_id` 列。
- `Repository` 的所有查询方法增加 `session_id` 过滤参数。
- `WebAgent` 初始化时传入自身 `session_id`，确保数据隔离。
- 对于真正的"共享长期记忆"需求（如跨设备同用户），应通过用户身份标识（如登录系统）而非 session_id 实现，当前项目阶段建议先做会话级隔离。

---

#### 【中危-1】`cleanup_old` 仅做字典驱逐，不释放底层资源

**文件**：`D:\桌面\编程作品\AI朋友\web\session.py:169-175`

```python
def cleanup_old(self, max_sessions: int = 50) -> None:
    with self._lock:
        while len(self._sessions) > max_sessions:
            oldest = next(iter(self._sessions))
            self._sessions.pop(oldest)
            logger.info(f"Session evicted: {oldest}")
```

**问题分析**：
1. `cleanup_old` 仅将 `WebAgent` 从 `_sessions` 字典中弹出，但：
   - 不取消可能正在运行的 proactive task（`_proactive_tasks` 中仍保留）
   - 不关闭 WebSocket 连接（`_active_ws` 中仍保留）
   - 不调用 `WebAgent` 的任何清理方法（如保存 personality、关闭 provider session 等）
2. `WebAgent` 持有 `KimiProvider`（内含 `requests.Session`）、`EmbeddingEngine`、大量内存中的对话历史。被驱逐后这些对象仍被 `_proactive_tasks` 和 `_active_ws` 引用，无法被 GC。
3. 当前代码中 `cleanup_old` 没有任何调用点（搜索全代码库无调用），属于"死代码"，但一旦被启用，将直接引入内存泄漏。

**建议**：
- 统一使用 `remove()` 方法做完整清理，或让 `cleanup_old` 调用 `remove()`。
- 为 `WebAgent` 增加 `close()` / `dispose()` 方法，释放 `requests.Session`、清空 `ConversationBuffer`、保存状态。
- 在 `SessionManager` 中增加定时清理任务（如每 10 分钟检查一次），并记录最后活跃时间。

---

#### 【中危-2】会话恢复时 `short_term` 从全局 DB 加载，导致跨会话污染

**文件**：`D:\桌面\编程作品\AI朋友\web\session.py:36-37`

```python
for t in repo.get_recent_turns_sync(30):
    self.short_term.add_turn(t["role"], t["content"])
```

**问题分析**：
1. 这是【高危-1】的直接表现。每个新会话创建时，都会加载全局最近 30 轮对话。
2. 如果用户 A 聊完后关闭浏览器，用户 B 打开页面，B 的 AI 会"记得"A 说过的话。
3. 即使单用户场景，浏览器刷新后也会重新加载（因为 `session_id` 来自 cookie，刷新后相同），但如果是新标签页不带 cookie 或 cookie 过期，就会创建新 session 并加载全局历史。

**建议**：
- 短期方案：移除自动恢复逻辑，或仅在提供明确 `session_id` 时恢复该 session 的历史。
- 长期方案：DB 层增加 `session_id` 隔离后，按 `session_id` 恢复。

---

### 二、并发安全性（高危 ×1，中危 ×1）

#### 【高危-2】`threading.Lock` 用于保护 asyncio 协程共享状态，存在死锁和协程阻塞风险

**文件**：`D:\桌面\编程作品\AI朋友\web\session.py:3,129,137,147,157,170`

```python
from threading import Lock
...
self._lock = Lock()

def get_or_create(self, session_id: Optional[str] = None) -> tuple[str, WebAgent]:
    with self._lock:
        ...
```

**问题分析**：
1. FastAPI 运行在 asyncio 事件循环中，所有请求处理都是协程。`SessionManager` 使用 `threading.Lock`（而非 `asyncio.Lock`）保护 `_sessions`、`_proactive_tasks`、`_active_ws`。
2. `threading.Lock` 会阻塞当前线程。在单线程 asyncio 事件循环中，如果一个协程获取了 `threading.Lock` 然后执行了 `await`（虽然当前 `get_or_create` 内部没有 `await`，但调用方可能在 `with self._lock` 块外 `await`），其他协程仍可能在同一线程运行。然而更严重的风险是：
   - `threading.Lock` 不是协程安全的。如果某个协程在持有锁时被事件循环切换出去（例如因为 GC 或 C 扩展调用），其他协程可能在同一线程获取锁成功（因为 GIL 释放），导致数据竞争。
   - 如果未来有人在 `with self._lock` 块内添加 `await`（这是非常自然的演进），会立即导致死锁或不可预期的阻塞行为。
3. 正确的做法应该是使用 `asyncio.Lock`，并将 `get_or_create`、`remove`、`register_proactive`、`cleanup_old` 改为 `async def`。

**风险**：数据竞争、未来演进时的死锁、不可预期的并发行为。

**建议**：
- 将 `self._lock = Lock()` 改为 `self._lock = asyncio.Lock()`。
- 将所有受保护的方法改为 `async def`，使用 `async with self._lock`。
- 注意：改为 `asyncio.Lock` 后，调用方需要 `await`，这会影响 `server.py` 中的调用点（当前都是同步调用）。

---

#### 【中危-3】`run_in_executor` 中执行阻塞 IO + 共享可变状态，存在竞争条件

**文件**：`D:\桌面\编程作品\AI朋友\web\server.py:46-47,166-180,233`

```python
_, agent = session_manager.get_or_create(session_id)
response = agent.process_message(message)  # 同步调用，在事件循环线程执行

# WebSocket 路径
response = await loop.run_in_executor(None, agent.process_message, content)
```

**问题分析**：
1. REST 路径 (`/api/chat`) 直接在事件循环线程中调用 `agent.process_message()`（一个可能执行数秒、涉及多次 LLM API 调用的阻塞操作）。这会阻塞整个事件循环，导致所有其他请求和 WebSocket 连接挂起。
2. WebSocket 路径虽然使用了 `run_in_executor`，但 `agent.process_message` 内部会修改共享状态：
   - `self.short_term.add_turn()`（`ConversationBuffer` 有 `threading.Lock`，但 `WebAgent.short_term` 是每个 session 独立的，所以 session 内部安全）
   - `self.personality.save()`（写文件 `personality.json`）
   - `self.ltm.repo.insert_turn_sync()`（通过 `_run_sync` 启动新的事件循环或线程池，见下文）
3. 更严重的是 `agent.process_proactive` 和 `agent.process_explore` 也在 `run_in_executor` 中执行，而 `_proactive_loop` 本身是一个协程，它会并发地调用这些同步方法。
4. `LongTermMemory._run_sync`（`storage/repository.py:13-21` 和 `memory/long_term.py:18-26`）的实现：
   ```python
   def _run_sync(coro):
       try:
           loop = asyncio.get_running_loop()
       except RuntimeError:
           return asyncio.run(coro)
       import concurrent.futures
       with concurrent.futures.ThreadPoolExecutor() as pool:
           return pool.submit(asyncio.run, coro).result()
   ```
   这个实现在已经有运行事件循环的线程中（如 FastAPI 的请求处理线程），会创建一个新的 `ThreadPoolExecutor` 并在子线程中运行 `asyncio.run(coro)`。这意味着每次 DB 操作都会创建新的线程池和事件循环，开销极大，且在高并发下可能耗尽线程资源。

**建议**：
- REST 路径的 `agent.process_message()` 必须放入 `run_in_executor` 或改为异步接口。
- 考虑为核心 Agent 提供真正的异步接口（`aprocess_message`），避免在线程池和事件循环之间反复跳转。
- 优化 `_run_sync`：使用全局 `ThreadPoolExecutor` 缓存，避免每次调用创建新线程池。
- 或者，将 `Repository` 的同步包装改为使用 `asyncio.run_coroutine_threadsafe()` 向主事件循环提交协程，而不是在子线程中运行 `asyncio.run()`。

---

### 三、WebSocket 处理（中危 ×2，低危 ×2）

#### 【中危-4】WebSocket 异常处理过于粗糙，可能吞掉关键错误

**文件**：`D:\桌面\编程作品\AI朋友\web\server.py:239-246`

```python
except Exception as e:
    logger.error(f"WebSocket error: {e}")
    try:
        await websocket.send_text(json.dumps({"type": "error", "content": str(e)}))
    except (WebSocketDisconnect, ConnectionError, RuntimeError):
        pass  # Client already disconnected, can't send error
```

**问题分析**：
1. 所有异常都被捕获为 `Exception`，包括 `KeyboardInterrupt`、`SystemExit`、`asyncio.CancelledError`（虽然 `CancelledError` 在 Python 3.8+ 是 `BaseException` 子类，但某些场景下仍可能被捕获）。
2. 错误信息直接通过 `str(e)` 暴露给客户端，可能泄漏内部实现细节（如文件路径、API key 片段、SQL 语句等）。
3. 没有区分可恢复错误（如 JSON 解析失败）和致命错误（如内存耗尽、DB 损坏）。
4. `WebSocketDisconnect` 在 `except Exception` 之前被捕获，但 `RuntimeError` 的捕获范围太广，可能掩盖 FastAPI/Starlette 的内部错误。

**建议**：
- 细化异常处理层级：
  - `json.JSONDecodeError`：返回客户端友好的"消息格式错误"。
  - `WebSocketDisconnect`：正常断开，无需 error log。
  - `ConnectionError` / `OSError`：网络问题，记录 warning。
  - 其他未预期异常：记录完整 traceback，返回客户端"服务器内部错误"，不暴露原始异常信息。
- 使用 `logger.exception()` 替代 `logger.error()` 以保留 traceback。

---

#### 【中危-5】`_proactive_loop` 中 WebSocket 发送无异常隔离，单条消息失败可导致循环崩溃

**文件**：`D:\桌面\编程作品\AI朋友\web\server.py:116-127,188-190`

```python
async def _send_segments(websocket: WebSocket, agent, response: str, emotion: str):
    segments = _split_segments(response)
    for i, seg in enumerate(segments):
        if i > 0:
            await asyncio.sleep(_calc_delay(emotion, len(seg)))
        await websocket.send_text(json.dumps({...}))
```

**问题分析**：
1. `_send_segments` 内部没有 try/except 保护。如果某一段发送失败（如客户端突然断开但连接状态尚未更新），会抛出异常并中断发送。
2. 在 `_proactive_loop` 中调用 `_send_segments` 时，异常会被外层的 `except Exception as e` 捕获（`web/server.py:194-196`），但此时已经可能导致：
   - 部分 segment 已发送，部分未发送，客户端显示不完整消息。
   - proactive loop 进入 30 秒 sleep，跳过本次 tick。
3. `_proactive_loop` 获取 "active_ws" 的逻辑（`active_ws = session_manager.get_active_ws(session_id) or websocket`）存在竞争：如果用户刷新页面，旧 WebSocket 关闭，新 WebSocket 建立，但 `register_proactive` 可能尚未被调用，此时 `get_active_ws` 返回旧 WebSocket（已关闭），发送会失败。

**建议**：
- 在 `_send_segments` 的循环内部增加 try/except，单段发送失败记录日志并继续发送剩余段。
- 发送前检查 `websocket.client_state == WebSocketState.CONNECTED`。
- 在 `_proactive_loop` 中，每次发送前验证 WebSocket 状态，如果关闭则优雅退出循环。

---

#### 【低危-1】WebSocket 协议缺少鉴权和消息大小限制

**文件**：`D:\桌面\编程作品\AI朋友\web\server.py:199-249`

**问题分析**：
1. 任何客户端都可以连接 `/ws` 并创建会话，没有 IP 限制、token 验证或连接数限制。
2. `websocket.receive_text()` 没有设置最大消息大小。恶意客户端可以发送超大 JSON（如数百 MB），导致内存耗尽。
3. 没有连接速率限制，客户端可以高频创建/断开连接，耗尽 `session_manager` 中的会话槽位。

**建议**：
- 增加消息大小限制（如单条消息最大 64KB）。
- 增加每 IP 最大连接数限制。
- 考虑增加简单的 token 鉴权（如 URL query param 中的预共享密钥）。

---

#### 【低危-2】`init` 消息可重复发送，每次都会创建新的 proactive task

**文件**：`D:\桌面\编程作品\AI朋友\web\server.py:211-217`

```python
if msg_type == "init":
    sid = data.get("session_id")
    session_id, agent = session_manager.get_or_create(sid)
    task = asyncio.create_task(_proactive_loop(websocket, session_id))
    session_manager.register_proactive(session_id, task, websocket)
```

**问题分析**：
1. 客户端可以在同一条 WebSocket 连接上多次发送 `init` 消息。每次都会创建新的 `_proactive_loop` task，旧的 task 会被 `register_proactive` 取消（因为 `register_proactive` 会取消旧 task）。
2. 但如果客户端发送 `init` 时带有不同的 `session_id`，会创建新的 session，旧 session 的 proactive task 仍在运行（因为 `remove` 只在 WebSocket 断开时调用）。
3. 虽然 `register_proactive` 会取消旧 task，但旧 task 的取消是异步的，可能在取消完成前又执行了一次循环体。

**建议**：
- 在 WebSocket handler 中增加状态机，拒绝已初始化后的重复 `init`。
- 或者，将 `init` 和后续消息的处理分离，确保每个 WebSocket 连接只绑定一个 session。

---

### 四、内存管理与资源泄漏（中危 ×1，低危 ×2）

#### 【中危-6】`personality.save()` 在每次消息后同步写文件，高并发下可能成为瓶颈

**文件**：`D:\桌面\编程作品\AI朋友\web\session.py:84-102`

```python
def process_message(self, user_input: str) -> str:
    result = self.agent.process_message(...)
    self.personality.save(self.config.personality_file)
    return result
```

**问题分析**：
1. `process_message`、`process_proactive`、`process_explore` 每次调用后都会同步写 `personality.json`。
2. 在 Web 模式下，如果多个会话同时活跃，或 proactive loop 频繁触发，会导致高频率的磁盘写入。
3. `personality.json` 是全局文件（所有会话共享同一个 `config.personality_file`），多个会话同时写入会导致：
   - 文件竞争（无文件锁）。
   - 后写入的会话覆盖先写入的会话的情绪状态，导致情绪状态丢失或混乱。
   - 如果写入过程中进程崩溃，可能导致 `personality.json` 损坏（JSON 截断）。

**建议**：
- 为每个会话使用独立的 personality 文件（如 `personality.{session_id}.json`），或将会话级情绪状态存入 SQLite。
- 使用写时复制（write to temp file + atomic rename）避免文件损坏。
- 增加写入节流（如每 5 秒最多写一次，或仅在会话空闲时批量写入）。

---

#### 【低危-3】`KimiProvider` 的 `requests.Session` 无连接池限制，可能积累大量连接

**文件**：`D:\桌面\编程作品\AI朋友\core\provider.py:25-26`

```python
self.session = requests.Session()
self.session.trust_env = False
```

**问题分析**：
1. 每个 `WebAgent` 创建一个 `KimiProvider`，每个 `KimiProvider` 创建一个 `requests.Session`。
2. `requests.Session` 默认使用 HTTPAdapter 的连接池（pool_maxsize=10），但在高并发或长连接场景下，如果会话数很多（如 50 个），总连接数可能达到 500。
3. 更重要的是，`WebAgent` 被移除后，`KimiProvider` 和 `requests.Session` 没有被显式关闭，连接池中的连接保持打开直到超时。

**建议**：
- 在 `WebAgent` 销毁时调用 `self.provider.session.close()`。
- 考虑在应用级别共享单个 `requests.Session` 或连接池（但需注意线程安全）。
- 或使用 `httpx.AsyncClient` 替代 `requests.Session`，实现真正的异步 HTTP。

---

#### 【低危-4】`EmbeddingEngine` 和 `MemoryConsolidator` 每个会话独立创建，资源重复

**文件**：`D:\桌面\编程作品\AI朋友\web\session.py:51-59`

```python
from memory.embeddings import EmbeddingEngine
embed_engine = EmbeddingEngine(
    endpoint=config.embedding_endpoint,
    dim=config.embedding_dim,
)
self.retriever = MemoryRetriever(self.ltm, embedding_engine=embed_engine)
self.consolidator = MemoryConsolidator(self.ltm, llm_gen, embedding_engine=embed_engine)
```

**问题分析**：
1. 每个 `WebAgent` 都创建独立的 `EmbeddingEngine` 实例。如果 `EmbeddingEngine` 内部有 LRU 缓存或连接池，这些资源会被重复创建。
2. 虽然 `EmbeddingEngine` 的具体实现未在本次审查范围内，但从设计模式看，嵌入引擎应该是应用级单例或共享实例。
3. `MemoryConsolidator` 也是每个会话独立创建，其内部的 `_pending_buffer` 和 `_consolidation_count` 都是会话独立的，这本身是正确的。但 `llm_gen` 函数闭包捕获了 `self.provider`，导致每个 consolidator 都持有独立的 provider 引用。

**建议**：
- 将 `EmbeddingEngine` 提升为 `SessionManager` 或应用级别的共享实例。
- 评估 `MemoryConsolidator` 是否可以在会话间共享（只读操作可以共享，但 `_pending_buffer` 需要会话隔离）。

---

### 五、REST API 与错误处理（低危 ×2）

#### 【低危-5】`/api/chat` 缺少输入验证和速率限制

**文件**：`D:\桌面\编程作品\AI朋友\web\server.py:39-54`

```python
@app.post("/api/chat")
async def chat_api(body: dict):
    session_id = body.get("session_id", "default")
    message = body.get("message", "")
    if not message.strip():
        return {"error": "empty message"}
```

**问题分析**：
1. 使用 `dict` 作为请求体类型，没有 Pydantic 模型验证。`body` 可能是任意 JSON，缺少字段时返回的 `error` 不是标准 HTTP 错误响应。
2. 没有速率限制。恶意客户端可以高频调用 `/api/chat`，耗尽 API key 配额或导致服务器资源耗尽。
3. `session_id` 没有长度/格式限制，可能被注入恶意字符串（虽然当前仅用于字典 key，但日志中直接打印可能导致日志注入）。

**建议**：
- 使用 Pydantic 模型定义请求体：
  ```python
  class ChatRequest(BaseModel):
      session_id: str = Field(default="default", max_length=64)
      message: str = Field(..., max_length=10000)
  ```
- 增加速率限制（如 `slowapi` 或自定义中间件）。
- 对 `session_id` 进行 sanitization（仅允许 alphanumeric）。

---

#### 【低危-6】全局 `session_manager` 在模块导入时创建，生命周期与模块绑定

**文件**：`D:\桌面\编程作品\AI朋友\web\server.py:17-18`

```python
config = load_config()
session_manager = SessionManager(config)
```

**问题分析**：
1. `session_manager` 在模块导入时实例化。如果 `load_config()` 失败（如 `config.json` 损坏），整个模块导入失败，应用无法启动。
2. 在测试场景中，很难替换 `session_manager` 为 mock（因为导入时就已经创建）。
3. `config` 也是全局变量，无法在运行时重新加载配置。

**建议**：
- 将 `session_manager` 的创建推迟到 `lifespan` 中：
  ```python
  @asynccontextmanager
  async def lifespan(app: FastAPI):
      app.state.config = load_config()
      app.state.session_manager = SessionManager(app.state.config)
      await app.state.session_manager.open()
      yield
      # cleanup
  ```
- 使用 `app.state` 或依赖注入访问 `session_manager`，便于测试和配置热更新。

---

### 六、前端与协议一致性（低危 ×2）

#### 【低危-7】前端 `splitSegments` 与后端 `_split_segments` 逻辑不同步

**文件**：
- 后端：`D:\桌面\编程作品\AI朋友\web\server.py:67-113`
- 前端：`D:\桌面\编程作品\AI朋友\web\static\app.js:38-87`

**问题分析**：
1. 后端 `_split_segments` 有 6 级 fallback（标点、逗号、空格、语气词、自然停顿、硬切），前端 `splitSegments` 只有 4 级（标点、空格、语气词、自然停顿），缺少"逗号拆分"和"18字符硬切"的对应逻辑。
2. 虽然前后端分割逻辑不需要完全一致（后端用于 WebSocket 实时推送，前端用于 REST fallback），但差异过大可能导致用户体验不一致：REST fallback 时的分段行为与 WebSocket 不同。
3. 更关键的是，如果后端修改了分割逻辑，前端很可能被遗忘更新。

**建议**：
- 将分割逻辑提取为共享模块（如 Python 实现 + 前端通过 API 获取分割结果），或至少在前端代码中添加注释说明需要同步更新。
- 或者，REST fallback 时也调用后端的分割逻辑（增加一个 `/api/split` 端点）。

---

#### 【低危-8】前端无重连退避机制，断网时疯狂重连

**文件**：`D:\桌面\编程作品\AI朋友\web\static\app.js:126-129`

```javascript
ws.onclose = function() {
    setStatus('disconnected'); hideTyping();
    setTimeout(connect, 3000);
};
```

**问题分析**：
1. WebSocket 断开后，前端固定 3 秒后重连。如果服务器完全不可用，客户端会以每 3 秒一次的频率无限重连。
2. 没有指数退避（exponential backoff），也没有最大重试次数限制。
3. 如果大量客户端同时断连重连，可能形成"重连风暴"，压垮恢复中的服务器。

**建议**：
- 实现指数退避：首次 1 秒，然后 2 秒、4 秒、8 秒，最大 60 秒。
- 增加最大重试次数（如 10 次后停止，显示"连接失败，请刷新页面重试"）。
- 区分正常关闭（如用户主动关闭页面）和异常断开，避免不必要的重连。

---

### 七、架构耦合与设计债务（低危 ×2）

#### 【低危-9】`WebAgent` 直接暴露内部 `agent` 属性，破坏封装

**文件**：`D:\桌面\编程作品\AI朋友\web\server.py:138,141,142,153,158,164,177,178,179,180,188,231`

```python
ag = agent.agent  # WebAgent.agent 是核心 Agent 实例
ag._get_sleep_state()
ag._sleeping
ag.last_activity_time
ag._calculate_proactivity(idle)
ag.decide_proactive_action(idle)
```

**问题分析**：
1. `WebAgent` 的设计意图是封装核心 `Agent`，但 `server.py` 直接访问 `agent.agent` 并调用大量下划线前缀的"私有"方法。
2. 这导致 Web 层与核心 Agent 的实现细节强耦合。如果 `Agent` 的内部方法签名变更（如 `_get_sleep_state` 改名），Web 层会直接崩溃。
3. `WebAgent` 已经提供了 `process_proactive`、`process_explore`、`emotion`、`turn_count` 等封装属性，但 `server.py` 没有使用它们，而是直接操作内部状态。

**建议**：
- 在 `WebAgent` 上增加正式的代理方法/属性：
  ```python
  @property
  def sleeping(self): return self.agent._sleeping
  def get_sleep_state(self): return self.agent._get_sleep_state()
  def calculate_proactivity(self, idle): return self.agent._calculate_proactivity(idle)
  ```
- 或者，将 `_proactive_loop` 的逻辑下放到 `WebAgent` 中，让 `server.py` 只负责 WebSocket 协议转换。

---

#### 【低危-10】`ToolRegistry.to_json_schema()` 返回固定值，未实现真正的 JSON Schema

**文件**：`D:\桌面\编程作品\AI朋友\tools\traits.py:82-95`

```python
def to_json_schema(self, names: list[str] | None = None) -> dict:
    ...
    return {
        "type": "json_object",
    }
```

**问题分析**：
1. 方法名暗示返回 JSON Schema，但实际只返回 `{"type": "json_object"}`（DeepSeek 的 response_format 参数值）。
2. 这虽然能满足当前 DeepSeek API 的调用需求，但完全浪费了"为每个工具生成参数 schema"的能力。
3. 如果未来需要切换到支持 function calling 的模型（如 OpenAI、Claude），需要重写此逻辑。

**建议**：
- 实现真正的 JSON Schema 生成，返回包含所有工具名称、描述和参数定义的 schema。
- 或重命名方法为 `to_response_format()` 以避免误导。

---

### 八、其他发现

#### 【信息】`web/__init__.py` 为空文件

**文件**：`D:\桌面\编程作品\AI朋友\web\__init__.py`

该文件为空，这是正常的 Python 包标记文件，无需修改。

#### 【信息】`sleep_cooldown` 使用整数递减而非时间戳比较

**文件**：`D:\桌面\编程作品\AI朋友\web\server.py:132,147,153`

```python
sleep_cooldown = 0
...
if sleep_cooldown == 0:
    ...
else:
    sleep_cooldown = max(0, sleep_cooldown - 1)
```

**问题分析**：
1. `sleep_cooldown` 初始值为 0，触发睡眠后设置为 120，然后每次 proactive loop tick（约 15-30 秒）减 1。这意味着 120 次 tick 后才能再次检查睡眠状态。
2. 如果 tick 间隔不稳定（如某次处理耗时较长），实际冷却时间不是固定的。
3. 使用 `time.time()` 比较更清晰可靠。

**建议**：
- 改为 `sleep_until = time.time() + 120`，检查时比较 `time.time() < sleep_until`。

---

## 汇总统计

### 风险分级

| 级别 | 数量 | 编号 |
|------|------|------|
| 高危 | 2 | 高危-1（数据无会话隔离）、高危-2（threading.Lock 用于 asyncio） |
| 中危 | 5 | 中危-1（cleanup_old 资源泄漏）、中危-2（会话恢复污染）、中危-3（run_in_executor 竞争）、中危-4（WS 异常处理粗糙）、中危-5（proactive 发送无隔离）、中危-6（personality.save 竞争写入） |
| 低危/建议 | 8 | 低危-1（WS 无鉴权）、低危-2（重复 init）、低危-3（Session 连接池）、低危-4（EmbeddingEngine 重复）、低危-5（REST 无验证）、低危-6（全局变量）、低危-7（分割逻辑不同步）、低危-8（重连无退避）、低危-9（封装破坏）、低危-10（JSON Schema 名不副实） |

### 核心问题地图

```
Web 层
├── 会话管理
│   ├── [高危] 数据无 session_id 隔离 → 隐私泄漏
│   ├── [中危] cleanup_old 不完整 → 内存泄漏
│   ├── [中危] 会话恢复加载全局历史 → 跨会话污染
│   └── [中危] personality.json 全局写入 → 文件竞争
├── 并发安全
│   ├── [高危] threading.Lock 用于 asyncio → 数据竞争/死锁风险
│   └── [中危] run_in_executor + _run_sync 嵌套 → 线程爆炸
├── WebSocket
│   ├── [中危] 异常处理粗糙 → 信息泄漏/不完整消息
│   ├── [中危] proactive 发送无保护 → 循环崩溃
│   └── [低危] 无鉴权/无消息大小限制 → DoS 风险
├── 资源管理
│   ├── [低危] requests.Session 不关闭 → 连接泄漏
│   └── [低危] EmbeddingEngine 重复创建 → 资源浪费
├── REST API
│   └── [低危] 无 Pydantic 验证/无速率限制 → 滥用风险
└── 架构耦合
    ├── [低危] 直接访问 agent.agent._private → 封装破坏
    └── [低危] 全局变量在导入时创建 → 测试困难
```

### 修复优先级建议

**P0（立即修复）**：
1. 将 `threading.Lock` 替换为 `asyncio.Lock`，并调整调用点为 `await`。
2. 为 SQLite 表增加 `session_id` 隔离，或移除全局历史恢复逻辑作为临时措施。

**P1（本周修复）**：
3. 统一会话清理逻辑，`cleanup_old` 调用 `remove()` 做完整清理。
4. REST 路径的 `agent.process_message()` 放入 `run_in_executor`。
5. `personality.save()` 增加文件锁或改为每会话独立文件。

**P2（下个迭代）**：
6. 细化 WebSocket 异常处理，避免信息泄漏。
7. 为 `_proactive_loop` 增加 WebSocket 状态检查。
8. 前端增加重连退避机制。
9. 使用 Pydantic 模型验证 REST 请求。

**P3（技术债务）**：
10. 将 `EmbeddingEngine` 提升为应用级共享实例。
11. 封装 `Agent` 的内部方法，避免 `agent.agent._private` 调用。
12. 重构 `_run_sync` 避免每次创建线程池。

---

*报告结束*
