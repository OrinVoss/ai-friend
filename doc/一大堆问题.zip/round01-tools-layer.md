# AI Friend 项目工具层深度代码审查报告

**审查范围**：`tools/` 目录下全部 8 个文件（含 traits 基类与 7 个工具实现）  
**审查日期**：2026-05-31  
**审查人**：Claude Code  
**代码版本**：main 分支，commit `3c24cd3` 附近  
**关联模块**：`core/dispatcher.py`、`core/tool_agent.py`、`prompts/system.py`、`config.py`、`memory/`

---

## 一、概述

AI Friend 的工具层采用经典的 "Registry + Trait" 架构：`tools/traits.py` 定义 `Tool` 抽象基类、`ToolResult` 值对象、`ToolSpec` 描述符和 `ToolRegistry` 注册表；7 个具体工具分三类实现：

- **内部记忆工具**（Agent 1/3 可用）：`recall`、`remember`
- **外部文件工具**（Agent 2 可用）：`read_file`、`glob`、`grep`
- **外部网络/系统工具**（Agent 2 可用）：`web_search`、`web_fetch`、`music_play`、`notify`

工具层整体职责清晰，代码风格统一，但存在**架构设计缺陷、安全边界漏洞、重复代码、异常处理不一致、JSON Schema 生成不完整**等系统性问题。以下按文件逐条展开，并给出风险评级与修复建议。

---

## 二、详细发现

### 2.1 `tools/traits.py` — 基类与注册表设计

#### 2.1.1 `Tool.execute()` 签名不一致：同步与异步的混乱（高危）

**位置**：`tools/traits.py` 第 39-40 行

```python
async def execute(self, args: dict[str, Any]) -> ToolResult:
    raise NotImplementedError
```

基类将 `execute` 声明为 `async`，但实际工具实现中：

- `memory_tools.py`（RecallTool、RememberTool）：**同步** `def execute(...)`
- `file_tools.py`（ReadFileTool）：**同步** `def execute(...)`
- `search_tools.py`（GlobTool、GrepTool）：**同步** `def execute(...)`
- `web_tools.py`（WebSearchTool、WebFetchTool）：**同步** `def execute(...)`
- `music_tool.py`（MusicListTool、MusicPlayTool）：**同步** `def execute(...)`
- `notify_tool.py`（NotifyTool）：**同步** `def execute(...)`

**全部 8 个具体实现均为同步函数**，与基类的 `async` 签名不匹配。`core/dispatcher.py` 第 128-134 行不得不通过运行时反射（`inspect.iscoroutinefunction`）来分支处理：

```python
if inspect.iscoroutinefunction(tool.execute):
    result: ToolResult = asyncio.run(tool.execute(args))
else:
    result: ToolResult = tool.execute(args)
```

这带来了多重问题：

1. **类型系统欺骗**：静态类型检查器（mypy、pyright）会对所有子类报 "override signature mismatch" 错误。
2. **运行时开销**：`asyncio.run()` 在已存在事件循环的线程中（如 Web 模式的 asyncio 环境）会抛出 `RuntimeError: asyncio.run() cannot be called from a running event loop`。虽然当前 `dispatcher.py` 只在同步分支调用，但一旦某个子类真正实现 `async`，就会触发此异常。
3. **架构语义混乱**：基类承诺了异步契约，但整个继承树没有履行，导致后续开发者无法判断是否应该写 async。

**建议**：统一为同步接口 `def execute(self, args: dict[str, Any]) -> ToolResult`，删除基类的 `async` 修饰。如果未来确实需要异步工具（如网络 I/O 密集型），应通过 `AsyncTool` 子类或适配器模式扩展，而非破坏 Liskov 替换原则。

**风险评级**：高（架构债务 + 运行时隐患）

---

#### 2.1.2 `ToolRegistry.to_json_schema()` 实现残缺（高危）

**位置**：`tools/traits.py` 第 82-95 行

```python
def to_json_schema(self, names: list[str] | None = None) -> dict:
    tool_names = []
    for spec in self.list_specs():
        if names is not None and spec.name not in names:
            continue
        tool_names.append(spec.name)

    return {
        "type": "json_object",
    }
```

该函数名为 `to_json_schema`，但返回值只有一个 `{"type": "json_object"}`，完全没有包含任何工具名称列表、参数结构、枚举值或描述信息。`core/tool_agent.py` 第 106 行和第 182 行将其作为 `response_format` 传入 LLM 调用：

```python
resp = self._provider.generate(
    messages,
    stream=False,
    max_tokens=512,
    response_format=self._registry.to_json_schema(),
)
```

这意味着 LLM 在生成工具调用 JSON 时，**没有任何 schema 约束**，完全依赖 prompt 中的文本描述（`format_for_prompt()` 输出的 markdown）来推断参数结构。这会导致：

1. **参数类型错误率上升**：LLM 可能输出字符串而非数字、遗漏 required 字段、使用不存在的参数名。
2. **工具调用幻觉**：LLM 可能编造不存在的工具名称或参数，因为 JSON Schema 没有提供 `enum` 限制。
3. **DeepSeek `json_object` 模式的浪费**：DeepSeek 支持 `response_format={"type": "json_object"}` 配合 prompt 中的 schema 描述，但当前没有提供结构化 schema，使得 "structured output" 的优势无法发挥。

**建议**：`to_json_schema()` 应返回符合 OpenAI/DeepSeek 函数调用规范的 schema，例如：

```json
{
  "type": "object",
  "properties": {
    "calls": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "name": {"type": "string", "enum": ["web_search", "read_file", ...]},
          "arguments": {"type": "object"}
        },
        "required": ["name", "arguments"]
      }
    }
  },
  "required": ["calls"]
}
```

或者，如果项目计划使用 DeepSeek 的 `json_schema` 模式（当前因兼容性问题已回退到 `json_object`），应至少在每个工具的 `parameters_schema()` 中生成符合 JSON Schema Draft 7 的完整定义，并在 `to_json_schema()` 中聚合。

**风险评级**：高（直接影响工具调用准确率）

---

#### 2.1.3 `ToolRegistry` 缺少工具去重与覆盖保护（中危）

**位置**：`tools/traits.py` 第 56-57 行

```python
def register(self, tool: Tool) -> None:
    self._tools[tool.name()] = tool
```

注册时直接覆盖同名工具，没有警告或报错。如果两个模块意外注册了同名工具（如测试 mock 与真实实现），静默覆盖会导致难以调试的行为。

**建议**：增加覆盖检查：

```python
def register(self, tool: Tool) -> None:
    name = tool.name()
    if name in self._tools:
        logger.warning(f"Tool '{name}' already registered, overwriting")
    self._tools[name] = tool
```

**风险评级**：中

---

#### 2.1.4 `ToolResult` 缺少元数据与追踪能力（低危）

**位置**：`tools/traits.py` 第 6-17 行

```python
@dataclass
class ToolResult:
    success: bool
    output: str
```

`ToolResult` 仅包含成功标志和输出文本，缺少：
- 执行耗时（`elapsed_ms`）
- 原始异常信息（`exception`）
- 工具名称（`tool_name`）
- 输入参数快照（`arguments`）

`core/tool_agent.py` 的 `ToolCallRecord` 虽然补充了部分字段，但这是在调用层而非工具层记录的，导致工具内部产生的异常上下文丢失。

**建议**：扩展 `ToolResult`：

```python
@dataclass
class ToolResult:
    success: bool
    output: str
    elapsed_ms: float = 0.0
    exception: Optional[Exception] = None
```

**风险评级**：低（可观测性债务）

---

### 2.2 `tools/memory_tools.py` — 记忆工具

#### 2.2.1 `RecallTool` 直接调用私有方法 `_extract_keywords`（中危）

**位置**：`tools/memory_tools.py` 第 44 行

```python
keywords = self.retriever._extract_keywords(query)
```

`RecallTool` 通过 `self.retriever._extract_keywords(query)` 调用了 `MemoryRetriever` 的私有方法（单下划线命名）。这破坏了封装：

1. `MemoryRetriever._extract_keywords` 是内部实现细节，其分词逻辑、停用词表、正则表达式可能随时变更。
2. 工具层不应依赖记忆层的内部辅助方法；应通过公共 API 获取关键词，或工具层自行实现简单的分词。

**建议**：在 `MemoryRetriever` 中暴露公共方法 `extract_keywords(query: str) -> list[str]`，或 `RecallTool` 自行实现轻量级分词。

**风险评级**：中

---

#### 2.2.2 `RecallTool` 的 `experiences` 搜索使用关键词而非语义（低危）

**位置**：`tools/memory_tools.py` 第 46 行

```python
experiences = self.ltm.search_experiences(keywords, limit=3)
```

`RecallTool` 使用关键词列表搜索经历，而 `MemoryRetriever.retrieve_for_query()` 中在嵌入引擎可用时会使用语义搜索（` _search_experiences_semantic`）。`RecallTool` 作为 Agent 1/3 的入口，没有享受到语义搜索的精度提升，可能导致相关经历被遗漏。

**建议**：`RecallTool` 应通过 `MemoryRetriever.retrieve_for_query(query)` 统一检索，而非分别调用 `ltm.search_facts` 和 `ltm.search_experiences`，以确保三层检索逻辑的一致性。

**风险评级**：低（功能降级）

---

#### 2.2.3 `RememberTool` 的 `importance` 参数类型转换无异常处理（中危）

**位置**：`tools/memory_tools.py` 第 115 行

```python
importance = float(args.get("importance", 0.6))
```

如果 LLM 输出 `"importance": "高"` 或 `"importance": null`，`float()` 会抛出 `ValueError` 或 `TypeError`，导致整个工具执行失败并返回 500 类错误。

**建议**：增加安全转换：

```python
try:
    importance = float(args.get("importance", 0.6))
except (ValueError, TypeError):
    importance = 0.6
```

并增加范围裁剪：`importance = max(0.0, min(1.0, importance))`。

**风险评级**：中

---

#### 2.2.4 `RememberTool` 未校验 `category` 的 enum 值（低危）

**位置**：`tools/memory_tools.py` 第 111-112 行

```python
category = args.get("category", "preference")
```

虽然 `parameters_schema()` 中定义了 `enum: ["preference", "identity", "event", "relationship", "routine"]`，但 `execute()` 没有校验传入值是否在此范围内。LLM 可能输出 `"category": "hobby"`，此时会直接存入数据库，破坏数据一致性。

**建议**：增加校验：

```python
VALID_CATEGORIES = {"preference", "identity", "event", "relationship", "routine"}
if category not in VALID_CATEGORIES:
    category = "preference"  # 或返回失败
```

**风险评级**：低

---

### 2.3 `tools/file_tools.py` — 文件读取工具

#### 2.3.1 白名单路径检查存在目录遍历漏洞（高危）

**位置**：`tools/file_tools.py` 第 51-61 行

```python
def _path_in_allowed(filepath: str) -> str | None:
    resolved = os.path.abspath(filepath)
    for root in _get_allowed_roots():
        try:
            if resolved.startswith(os.path.abspath(root)):
                return resolved
        except Exception as e:
            logger.debug(f"Path check failed for root {root}: {e}")
            continue
    return None
```

该检查使用 `str.startswith()` 进行路径前缀匹配，存在经典的 **路径遍历绕过** 风险：

1. **符号链接攻击**：如果允许的路径内存在指向系统敏感目录的符号链接（如 `D:\桌面\编程作品\AI朋友\data\secret_link -> C:\Windows\System32`），`os.path.abspath` 不会解析符号链接，但后续 `os.path.exists` 和文件读取会跟随链接，导致越界访问。
2. **大小写与路径规范化问题**：Windows 路径不区分大小写，`os.path.abspath` 会规范化大小写，但如果传入 `..` 序列，`os.path.abspath` 会解析为父目录。例如，假设允许根目录是 `D:\桌面\编程作品\AI朋友`，传入 `D:\桌面\编程作品\AI朋友\..\..\Windows\System32\drivers\etc\hosts`，`os.path.abspath` 会解析为 `D:\Windows\System32\drivers\etc\hosts`，但 `startswith` 检查的是解析后的路径是否以允许根开头——这里 `D:\Windows...` 不会以 `D:\桌面...` 开头，所以**当前实现实际上能防御 `..` 穿越**。

然而，更隐蔽的攻击是：**通过符号链接或 junction point 在允许目录内创建指向外部目录的链接**。例如：

```powershell
mklink /D D:\桌面\编程作品\AI朋友\evil_link C:\Users\17040\.ssh
```

然后调用 `read_file` 传入 `evil_link\id_rsa`，`os.path.abspath` 返回 `D:\桌面\编程作品\AI朋友\evil_link\id_rsa`，`startswith` 检查通过，但 `open()` 实际读取的是 `C:\Users\17040\.ssh\id_rsa`。

**建议**：

1. 使用 `os.path.realpath()` 解析符号链接后再检查：

```python
def _path_in_allowed(filepath: str) -> str | None:
    resolved = os.path.realpath(os.path.abspath(filepath))
    for root in _get_allowed_roots():
        real_root = os.path.realpath(os.path.abspath(root))
        try:
            if resolved.startswith(real_root + os.sep):
                return resolved
        except Exception:
            continue
    return None
```

2. 确保路径分隔符匹配：`resolved.startswith(real_root + os.sep)` 防止 `C:\allowed` 匹配 `C:\allowed-evil`。

**风险评级**：高（安全漏洞）

---

#### 2.3.2 `_is_binary()` 的异常处理引用未定义变量 `path`（中危）

**位置**：`tools/file_tools.py` 第 26-28 行

```python
except Exception as e:
    logger.debug(f"Binary check failed for {path}: {e}")
    return False
```

函数参数名为 `filepath`，但日志中使用了未定义的 `path`，会导致 `NameError`。虽然被 `except Exception` 捕获，但日志记录本身会抛出异常，导致异常信息丢失，且可能触发嵌套异常处理。

**建议**：修正为 `filepath`。

**风险评级**：中（运行时错误）

---

#### 2.3.3 `ReadFileTool` 对目录的读取结果缺少安全过滤（中危）

**位置**：`tools/file_tools.py` 第 108-132 行

当传入路径是目录时，`ReadFileTool` 会列出目录内容，包括子目录和文件。虽然限制了显示数量（目录最多 30 个，文件最多 50 个），但没有对文件名进行任何过滤或转义。如果目录中包含以控制字符、换行符、Unicode 双向覆盖字符（如 U+202E）命名的文件，输出可能被注入到 prompt 中，导致 prompt injection 或显示混乱。

更关键的是，**目录列表会泄露目录结构**，即使单个文件受白名单保护，目录遍历本身也可能暴露敏感信息（如 `.env` 文件的存在）。

**建议**：

1. 对文件名进行安全过滤，移除或替换控制字符。
2. 考虑隐藏以 `.` 开头的隐藏文件（如 `.git`、`config.json`），或至少对敏感文件名进行模糊处理。
3. 在 `parameters_schema()` 中明确说明 "目录路径将返回目录列表"。

**风险评级**：中

---

#### 2.3.4 `TEXT_EXTENSIONS` 白名单过于宽松（低危）

**位置**：`tools/file_tools.py` 第 11-17 行

```python
TEXT_EXTENSIONS = {
    ".txt", ".md", ".py", ".rs", ".js", ".ts", ".json", ".xml", ".html",
    ".css", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf",
    ".csv", ".log", ".sh", ".bat", ".ps1", ".env", ".gitignore",
    ".java", ".cpp", ".c", ".h", ".hpp", ".go", ".rb", ".php",
    ".vue", ".svelte", ".jsx", ".tsx", ".sql", ".r", ".lua",
}
```

虽然名为 `TEXT_EXTENSIONS`，但 `.env`、`.gitignore`、`.ps1`、`.sh`、`.bat` 等扩展名对应的文件可能包含敏感信息（API 密钥、密码、私钥路径）。当前 `ReadFileTool` 仅通过白名单目录限制路径，但**不限制文件扩展名**——实际上 `_is_binary()` 检查后，任何非二进制文件都可读取，包括 `.env` 和 `.gitignore`。

**建议**：增加敏感扩展名黑名单，或在读取前对文件内容进行敏感信息扫描（如正则匹配 `API_KEY`、`password`、`SECRET` 等）。

**风险评级**：低（依赖白名单目录缓解）

---

#### 2.3.5 批量读取时 `offset` 和 `limit` 作用于每个文件，缺乏灵活性（低危）

**位置**：`tools/file_tools.py` 第 184-191 行

```python
for p in paths:
    r = self._read_one(p, limit, offset)
```

批量读取时，所有文件共享同一个 `limit` 和 `offset`。如果用户想读取文件 A 的前 50 行和文件 B 的后 50 行，无法通过一次调用完成。

**建议**：当前设计可接受，但应在文档中明确说明此限制。

**风险评级**：低

---

### 2.4 `tools/search_tools.py` — 文件搜索工具

#### 2.4.1 `_resolve_search_path()` 与 `_path_in_allowed()` 代码重复（中危）

**位置**：`tools/search_tools.py` 第 14-23 行

```python
def _resolve_search_path(search_path: str) -> str | None:
    resolved = os.path.abspath(search_path)
    for root in _get_allowed_roots():
        try:
            if resolved.startswith(os.path.abspath(root)):
                return resolved
        except Exception:
            pass
    return None
```

该函数与 `file_tools.py` 的 `_path_in_allowed()` 逻辑几乎完全一致，只是函数名和返回值语义不同。重复代码增加了维护成本，且两个函数的安全修复（如符号链接防御）需要同步修改，容易遗漏。

**建议**：将路径解析逻辑提取到 `tools/traits.py` 或独立的 `tools/security.py` 模块中，统一实现。

**风险评级**：中（维护债务）

---

#### 2.4.2 `GlobTool` 的 `fnmatch` 逻辑存在冗余判断（低危）

**位置**：`tools/search_tools.py` 第 68-75 行

```python
for fname in fnames:
    rel_path = os.path.join(rel_dir, fname) if rel_dir != "." else fname
    if fnmatch.fnmatch(rel_path, pattern):
        # Also match against just the filename for simple patterns
        pass
    if fnmatch.fnmatch(rel_path, pattern) or fnmatch.fnmatch(fname, pattern):
        ...
```

第一个 `if` 判断后接 `pass`，没有任何作用；第二个 `if` 重复了相同的匹配逻辑。这是明显的代码残留或合并冲突遗留。

**建议**：删除第一个无意义的 `if` 块。

**风险评级**：低

---

#### 2.4.3 `GrepTool` 的正则表达式安全性：ReDoS 风险（高危）

**位置**：`tools/search_tools.py` 第 158-161 行

```python
try:
    regex = re.compile(pattern, re.IGNORECASE if ignore_case else 0)
except re.error as e:
    return ToolResult.fail(f"正则表达式错误: {e}")
```

`GrepTool` 直接将用户（通过 LLM 中转）提供的正则表达式传递给 `re.compile()`。Python 的 `re` 模块使用回溯算法，某些模式会导致 **ReDoS（正则表达式拒绝服务）**，例如：

- `(a+)+$` 匹配 `"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa!"`
- `([a-zA-Z]+)*$` 匹配长字符串

攻击者可以通过构造恶意用户输入，诱导 LLM 生成危险正则，或 LLM 本身可能生成低效正则（如 `.*.*.*.*.*.*`），导致 `GrepTool` 在搜索大文件时 CPU 100% 卡死。

**建议**：

1. **限制正则复杂度**：使用 `regex` 库的 `regex.REVERSE` 或自定义超时机制（Python 3.11+ 的 `re` 不支持超时，但可通过 `signal` 或线程超时实现）。
2. **限制输入长度**：`pattern` 长度超过 200 字符时拒绝编译。
3. **限制匹配时间**：在独立线程中执行 `regex.search()`，设置超时（如 2 秒），超时时返回失败。
4. **使用更安全的匹配引擎**：如 `hyperscan` 或 `ripgrep` 的库绑定，它们使用 NFA/DFA 而非回溯，天然免疫 ReDoS。

**风险评级**：高（DoS 攻击面）

---

#### 2.4.4 `GrepTool` 的目录跳过逻辑过于粗糙（中危）

**位置**：`tools/search_tools.py` 第 169-170 行

```python
if any(skip in dirpath for skip in ["__pycache__", ".git", "node_modules", ".venv", "data"]):
    continue
```

该检查使用子字符串匹配（`"data" in dirpath`），可能导致误杀：

- 合法目录 `D:\桌面\编程作品\AI朋友\doc\data-modeling` 会被跳过，因为 `"data" in dirpath` 为真。
- 目录 `D:\桌面\编程作品\AI朋友\my_data` 也会被跳过。

**建议**：使用路径段级别的精确匹配：

```python
skip_names = {"__pycache__", ".git", "node_modules", ".venv", "data"}
if any(part in skip_names for part in dirpath.split(os.sep)):
    continue
```

但注意，`data` 作为通用名称，放在 skip 列表中过于激进。项目自身的 `data/` 目录（SQLite 数据库）确实不应被搜索，但应在文档中明确说明。

**风险评级**：中（功能缺陷）

---

#### 2.4.5 `GrepTool` 的 `MAX_RESULTS` 截断逻辑不清晰（低危）

**位置**：`tools/search_tools.py` 第 212-217 行

```python
if len(results) > self.MAX_RESULTS * 3:
    results.append(f"\n...(结果过多，已截断)")
    break
```

`MAX_RESULTS = 50`，但截断阈值是 `50 * 3 = 150` 行结果，且最终返回的是 `results[:50 * 4]`（即 200 行）。这些魔法数字缺乏注释说明，且 `MAX_RESULTS` 的语义（"最大结果数"）与实际行为不符。

**建议**：重命名常量并添加注释，或统一为单一阈值。

**风险评级**：低

---

### 2.5 `tools/web_tools.py` — 网络工具

#### 2.5.1 `_anysearch_api()` 的异常处理过于笼统（中危）

**位置**：`tools/web_tools.py` 第 16-35 行

```python
def _anysearch_api(tool_name: str, arguments: dict) -> dict:
    api_key = os.environ.get("ANYSEARCH_API_KEY", "")
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {"name": tool_name, "arguments": arguments},
    }
    session = requests.Session()
    session.trust_env = False
    resp = session.post(ANYSEARCH_ENDPOINT, json=payload, headers=headers, timeout=30)
    resp.raise_for_status()
    result = resp.json()
    if "error" in result:
        raise RuntimeError(result["error"].get("message", str(result["error"])))
    return result.get("result", {})
```

问题：

1. **每次调用创建新 Session**：`requests.Session()` 应在模块级别或类级别复用，以利用连接池。当前每次调用都新建 TCP 连接，增加延迟。
2. **`trust_env = False` 的位置**：虽然项目规范要求 `trust_env=False`，但这里是在函数内每次设置，不如在模块级别创建 session 并统一配置。
3. **JSON-RPC `id` 固定为 1**：不符合 JSON-RPC 规范，应使用递增或 UUID 的 `id`。
4. **异常类型粗糙**：`requests` 可能抛出 `ConnectionError`、`Timeout`、`HTTPError` 等，但调用方 `WebSearchTool.execute()` 和 `WebFetchTool.execute()` 都使用裸 `except Exception`，导致无法区分网络故障、API 错误、超时等不同场景。

**建议**：

```python
_session = requests.Session()
_session.trust_env = False

def _anysearch_api(tool_name: str, arguments: dict) -> dict:
    ...
    try:
        resp = _session.post(...)
        resp.raise_for_status()
    except requests.Timeout:
        raise ToolTimeoutError("AnySearch API 请求超时")
    except requests.ConnectionError:
        raise ToolNetworkError("无法连接到 AnySearch API")
    ...
```

**风险评级**：中

---

#### 2.5.2 `WebFetchTool` 的 URL 协议前缀补全存在逻辑缺陷（中危）

**位置**：`tools/web_tools.py` 第 127-128 行

```python
if not url.startswith(("http://", "https://")):
    url = "https://" + url
```

如果 LLM 输出 `url = "ftp://example.com/file.txt"`，该检查不会触发（因为以 `ftp://` 开头），但 AnySearch 的 `extract` API 可能不支持 FTP 协议，导致请求失败。更严重的是，如果 LLM 输出 `url = "javascript:alert(1)"` 或 `url = "file:///etc/passwd"`，`starts_with` 检查通过，这些危险协议会被传递给外部 API——虽然 AnySearch 服务端应会拒绝，但工具层没有进行协议白名单校验。

**建议**：增加协议白名单：

```python
if not url.startswith(("http://", "https://")):
    if "://" in url:
        return ToolResult.fail(f"不支持的 URL 协议: {url}")
    url = "https://" + url
```

**风险评级**：中

---

#### 2.5.3 `WebFetchTool` 返回内容截断无提示（低危）

**位置**：`tools/web_tools.py` 第 140 行

```python
return ToolResult.ok(f"{header}:\n```\n{content[:8000]}\n```")

```

内容超过 8000 字符时直接截断，但输出中没有告知用户 "内容已截断"。Agent 3 可能基于不完整内容做出错误判断。

**建议**：截断时添加提示：

```python
truncated = len(content) > 8000
suffix = "\n...(内容已截断)" if truncated else ""
return ToolResult.ok(f"{header}:\n```\n{content[:8000]}{suffix}\n```")
```

**风险评级**：低

---

#### 2.5.4 `WebSearchTool` 对 `freshness` 参数的处理不一致（低危）

**位置**：`tools/web_tools.py` 第 75、83-84 行

```python
freshness = args.get("freshness", "").strip() or None
...
if freshness:
    arguments["freshness"] = freshness
```

`parameters_schema()` 中 `freshness` 的类型是 `string`，`enum` 为 `["day", "week", "month", "year"]`，但 `execute()` 没有校验传入值是否在 enum 中。LLM 可能输出 `"freshness": "today"`，此时会直接传递给 AnySearch API，可能导致 API 400 错误。

**建议**：增加 enum 校验，非法值时忽略或返回失败。

**风险评级**：低

---

### 2.6 `tools/music_tool.py` — 音乐工具

#### 2.6.1 `MusicListTool` 的目录遍历深度限制失效（中危）

**位置**：`tools/music_tool.py` 第 64-77 行

```python
for root, dnames, fnames in os.walk(target):
    rel = os.path.relpath(root, MUSIC_DIR)
    for d in dnames:
        ...
    for f in fnames:
        ...
    break  # Only current dir, don't recurse
```

代码意图是 "只列出当前目录，不递归"，但 `os.walk` 的 `break` 只能停止当前生成器的迭代，如果 `target` 本身是深层子目录（如 `D:\音乐\古典\贝多芬`），`os.walk` 仍然会从该子目录开始遍历，且只遍历该目录本身（不继续深入）。这实际上是正确的行为，但注释 "Only current dir, don't recurse" 容易误导为 "不进入子目录"。

更关键的是，`MusicListTool` 的 `os.walk(target)` 在 `target` 是深层目录时，会列出该目录下的所有文件，包括嵌套子目录中的文件（因为 `break` 只停止继续深入，当前目录的文件仍会被列出）。实际上 `break` 在第一次迭代后就退出，所以确实只处理 `target` 目录本身。但 `dnames` 列表包含了所有直接子目录，这些子目录会被显示出来，用户可以通过 `path` 参数进一步进入。

**真正的问题**：`MusicListTool` 的安全检查 `target.startswith(os.path.abspath(MUSIC_DIR))` 与 `file_tools.py` 存在同样的符号链接风险。

**建议**：统一使用 `os.path.realpath()` 进行路径解析。

**风险评级**：中

---

#### 2.6.2 `MusicPlayTool` 使用 `os.startfile()` 存在命令注入风险（中危）

**位置**：`tools/music_tool.py` 第 152-153 行

```python
def _play(self, filepath: str, display_name: str) -> ToolResult:
    try:
        os.startfile(filepath)
        return ToolResult.ok(f"正在播放: {display_name}")
    except Exception as e:
        return ToolResult.fail(f"播放失败: {e}")
```

`os.startfile()` 在 Windows 上会使用文件关联打开文件。如果 `filepath` 指向一个 `.bat`、`.cmd`、`.ps1` 或 `.url` 文件（即使扩展名被伪装为 `.mp3`），`os.startfile()` 会执行它。虽然 `_is_audio()` 检查了扩展名，但：

1. 攻击者可以在 `D:\音乐` 目录中放置名为 `song.mp3.bat` 的文件（虽然 `_is_audio` 会拒绝，但如果通过符号链接绕过...）。
2. 更现实的场景：音乐目录中可能存在下载的 `.url` 文件或 `.lnk` 快捷方式，指向恶意程序。

**建议**：

1. 在 `_play()` 前增加 MIME 类型检查（通过 `python-magic` 库），确认文件头确实是音频格式。
2. 拒绝执行 `.bat`、`.cmd`、`.ps1`、`.url`、`.lnk` 等可执行/快捷方式文件，即使它们位于音乐目录中。

**风险评级**：中

---

#### 2.6.3 `MusicPlayTool` 的搜索匹配逻辑过于宽松（低危）

**位置**：`tools/music_tool.py` 第 132-133 行

```python
if _is_audio(f) and song.lower() in f.lower():
    matches.append(os.path.join(root, f))
```

使用子字符串匹配，搜索 `"a"` 会匹配所有包含字母 "a" 的歌曲，返回大量结果。虽然代码限制了最多 10 个匹配，但用户仍需进一步精确指定。

**建议**：可接受当前行为，但应在描述中说明 "支持部分匹配"。

**风险评级**：低

---

### 2.7 `tools/notify_tool.py` — 通知工具

#### 2.7.1 PowerShell 命令存在命令注入漏洞（高危）

**位置**：`tools/notify_tool.py` 第 50-58 行

```python
ps = f'''
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null
$template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
$textNodes = $template.GetElementsByTagName('text')
$textNodes.Item(0).AppendChild($template.CreateTextNode('{title}')) > $null
$textNodes.Item(1).AppendChild($template.CreateTextNode('{message}')) > $null
$toast = [Windows.UI.Notifications.ToastNotification]::new($template)
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('AI Friend').Show($toast)
'''
```

`title` 和 `message` 直接通过 f-string 插入到 PowerShell 脚本中，**没有任何转义**。如果 LLM 生成的 `title` 或 `message` 包含单引号 `'`，PowerShell 脚本会语法错误；如果包含更复杂的注入序列，可能执行任意 PowerShell 代码。

例如，如果 `title` 为 `'); [System.Diagnostics.Process]::Start('calc.exe'); #`，虽然当前代码结构是 `CreateTextNode('{title}')`，PowerShell 的 `CreateTextNode` 方法参数是字符串，但单引号会破坏字符串字面量：

```powershell
$textNodes.Item(0).AppendChild($template.CreateTextNode(''); [System.Diagnostics.Process]::Start('calc.exe'); #')) > $null
```

这会导致 PowerShell 执行 `calc.exe`。

**建议**：

1. **使用参数化传递**：通过 `subprocess.run` 的 `args` 列表传递参数，而非拼接字符串。但 PowerShell 的 `-Command` 模式难以完全避免拼接。
2. **严格转义单引号**：将 `title` 和 `message` 中的单引号替换为两个单引号（PowerShell 的转义方式）：

```python
def _escape_ps(s: str) -> str:
    return s.replace("'", "''")
```

3. **使用 `win11toast` 或 `plyer` 等 Python 库**：避免直接调用 PowerShell，使用原生 Python API 发送通知。

**风险评级**：高（命令注入）

---

#### 2.7.2 通知的 `duration` 参数被完全忽略（低危）

**位置**：`tools/notify_tool.py` 第 36-38 行、第 40-45 行

```python
duration = {
    "type": "integer",
    "description": "显示时长（秒），默认5秒",
    "default": 5,
},
```

`duration` 在 schema 中定义，但 `execute()` 完全没有使用它。Windows Toast 通知的显示时长由系统设置决定，PowerShell WinRT API 不支持直接设置显示时长（只能通过 `ToastNotification.ExpirationTime` 间接控制）。

**建议**：从 schema 中移除 `duration` 参数，或实现 `ExpirationTime` 设置。

**风险评级**：低（参数失效）

---

#### 2.7.3 通知发送在后台线程中，异常被静默吞掉（中危）

**位置**：`tools/notify_tool.py` 第 59-67 行

```python
def _show():
    ...
    try:
        subprocess.run(...)
    except Exception:
        pass

threading.Thread(target=_show, daemon=True).start()
```

异常被裸 `except Exception: pass` 捕获，且由于在线程中执行，调用方无法获知通知是否真正发送成功。如果 PowerShell 未安装、WinRT 组件不可用、或用户禁用了通知，失败信息完全丢失。

**建议**：

1. 使用 `threading.Event` 或 `concurrent.futures.ThreadPoolExecutor` 获取线程执行结果。
2. 至少记录异常日志：

```python
except Exception as e:
    logger.warning(f"Notification failed: {e}")
```

**风险评级**：中

---

### 2.8 跨文件架构问题

#### 2.8.1 工具层与 `core/dispatcher.py` 的循环依赖风险（中危）

**位置**：`core/dispatcher.py` 第 1-11 行

```python
from tools.traits import ToolRegistry, ToolResult
```

`tools/` 目录下的模块不应导入 `core/` 模块，但 `core/dispatcher.py` 导入了 `tools/traits`。虽然当前没有循环导入，但如果未来 `tools/traits.py` 需要引用 `core/` 中的某个类（如日志配置或异常定义），就会形成循环依赖。

**建议**：将 `ToolRegistry`、`ToolResult`、`ToolSpec` 等基础定义提取到独立的 `models/tools.py` 或 `protocols.py` 中，打破 `tools` 与 `core` 之间的直接依赖。

**风险评级**：中

---

#### 2.8.2 `core/tool_agent.py` 的 `ToolCallRecord.arguments` 始终为空（中危）

**位置**：`core/tool_agent.py` 第 116-122 行、第 193-200 行

```python
record = ToolCallRecord(
    name=r["name"],
    arguments={},  # 始终为空字典！
    success=r["success"],
    output=r["output"][:3000],
)
```

`ToolCallRecord` 的 `arguments` 字段被硬编码为空字典 `{}`，没有记录实际传入的参数。这导致：

1. **调试困难**：无法从日志中复现工具调用的完整上下文。
2. **审计缺失**：无法追踪 LLM 具体使用了哪些参数。
3. **重复调用检测失效**：如果记录了参数，可以检测 LLM 是否在重复相同的工具调用（如循环搜索）。

**建议**：将原始调用参数传入 `execute_tool_calls` 的返回结果中，或修改 `ToolCallRecord` 的构造逻辑。

**风险评级**：中

---

#### 2.8.3 `ToolAgentResult` 的 `has_results` 语义歧义（低危）

**位置**：`core/tool_agent.py` 第 38-41 行

```python
@property
def has_results(self) -> bool:
    return self.total_calls > 0
```

`has_results` 表示 "至少调用了一个工具"，而非 "至少有一个工具返回了成功结果"。这与属性名的直觉含义（"有结果"）不符。`any_success` 才表示有成功结果。

**建议**：重命名 `has_results` 为 `has_calls`，或修改语义为 `any_success`。

**风险评级**：低

---

#### 2.8.4 `EXTERNAL_TOOL_NAMES` 硬编码列表与注册表不同步（中危）

**位置**：`core/tool_agent.py` 第 15-18 行

```python
EXTERNAL_TOOL_NAMES = [
    "web_fetch", "web_search", "read_file", "glob", "grep",
    "music_play", "notify",
]
```

该列表硬编码了 Agent 2 可用的外部工具名称。如果新增工具（如 `image_search`）或重命名工具，需要同时修改此列表和工具实现文件，容易遗漏。

**建议**：

1. 在 `Tool` 基类中增加 `is_external: bool = False` 类属性，由每个工具自行声明。
2. `ToolAgent` 通过遍历注册表并过滤 `is_external` 来构建子注册表。

**风险评级**：中

---

#### 2.8.5 `config.py` 的 `allowed_read_paths` 包含相对路径 `.`（低危）

**位置**：`config.py` 第 32-38 行

```python
allowed_read_paths: list[str] = field(default_factory=lambda: [
    ".",
    "D:\\音乐",
    "D:\\桌面",
    "~/Documents",
    "~/Downloads",
])
```

`"D:\\桌面"` 是一个非常宽泛的路径，包含用户桌面上的所有文件，可能包括敏感文档、截图、下载的临时文件等。虽然这是用户主动配置的行为，但默认值过于宽松。

**建议**：默认值应仅包含项目目录，其他路径由用户显式配置。或在首次启动时提示用户确认。

**风险评级**：低（配置问题）

---

## 三、汇总统计

### 3.1 按风险等级统计

| 风险等级 | 数量 | 问题编号 |
|---------|------|---------|
| **高危** | 5 | 2.1.1（async/sync 混乱）、2.1.2（JSON Schema 残缺）、2.3.1（目录遍历）、2.4.3（ReDoS）、2.7.1（命令注入） |
| **中危** | 14 | 2.1.3（注册覆盖）、2.2.1（私有方法调用）、2.2.3（importance 转换）、2.3.2（未定义变量）、2.3.3（目录泄露）、2.4.1（代码重复）、2.4.2（fnmatch 冗余）、2.4.4（跳过逻辑粗糙）、2.5.1（异常笼统）、2.5.2（URL 协议）、2.6.1（符号链接）、2.6.2（startfile 风险）、2.7.3（异常静默）、2.8.1（循环依赖风险）、2.8.2（arguments 为空）、2.8.4（硬编码列表） |
| **低危** | 10 | 2.1.4（ToolResult 元数据）、2.2.2（语义搜索缺失）、2.2.4（category 校验）、2.3.4（扩展名宽松）、2.3.5（offset 共享）、2.4.5（魔法数字）、2.5.3（截断无提示）、2.5.4（freshness 校验）、2.6.3（匹配宽松）、2.7.2（duration 失效）、2.8.3（语义歧义）、2.8.5（默认路径宽松） |

### 3.2 按文件统计

| 文件 | 问题数 | 高危 | 中危 | 低危 |
|------|--------|------|------|------|
| `tools/traits.py` | 4 | 2 | 1 | 1 |
| `tools/memory_tools.py` | 4 | 0 | 2 | 2 |
| `tools/file_tools.py` | 5 | 1 | 2 | 2 |
| `tools/search_tools.py` | 5 | 1 | 2 | 2 |
| `tools/web_tools.py` | 4 | 0 | 2 | 2 |
| `tools/music_tool.py` | 3 | 0 | 2 | 1 |
| `tools/notify_tool.py` | 3 | 1 | 1 | 1 |
| `core/tool_agent.py` | 3 | 0 | 2 | 1 |
| `core/dispatcher.py` | 1 | 0 | 1 | 0 |
| `config.py` | 1 | 0 | 0 | 1 |

### 3.3 关键修复优先级

**P0（立即修复）**：
1. `tools/traits.py` 第 39 行：将 `async def execute` 改为 `def execute`，同步化基类。
2. `tools/traits.py` 第 82-95 行：实现完整的 `to_json_schema()`，提供工具枚举和参数结构。
3. `tools/file_tools.py` 第 51-61 行：使用 `os.path.realpath()` 防御符号链接目录遍历。
4. `tools/search_tools.py` 第 158-161 行：为 `re.compile()` 增加超时机制或复杂度限制，防御 ReDoS。
5. `tools/notify_tool.py` 第 50-58 行：对 `title`/`message` 进行 PowerShell 单引号转义，或改用 Python 原生通知库。

**P1（本周修复）**：
6. `tools/file_tools.py` 第 26-28 行：修正 `_is_binary()` 中的未定义变量 `path`。
7. `tools/search_tools.py` 第 14-23 行：提取统一的路径安全检查函数，消除与 `file_tools.py` 的重复。
8. `tools/web_tools.py` 第 16-35 行：复用 `requests.Session`，细化异常分类。
9. `core/tool_agent.py` 第 116-122 行：记录 `ToolCallRecord.arguments` 实际参数。
10. `tools/memory_tools.py` 第 44 行：避免调用 `MemoryRetriever._extract_keywords` 私有方法。

**P2（后续优化）**：
11. 统一 `ToolResult` 元数据字段（耗时、异常）。
12. 为 `GrepTool` 增加 `skip_names` 的精确路径匹配。
13. 为 `MusicPlayTool` 增加 MIME 类型校验。
14. 将 `EXTERNAL_TOOL_NAMES` 硬编码改为工具自声明属性。
15. 收紧 `config.py` 的默认 `allowed_read_paths`。

---

## 四、架构层面的反思

### 4.1 工具层缺乏统一的输入校验框架

当前每个工具的 `execute()` 都自行进行参数提取、类型转换和校验，导致大量重复代码（如 `args.get("xxx", "").strip()`、`int(args.get("limit", 200))` 等）。建议引入轻量级参数校验装饰器或基类方法，例如：

```python
class Tool:
    def validate(self, args: dict) -> tuple[dict, Optional[str]]:
        """Return (normalized_args, error_message)."""
        ...
```

### 4.2 安全边界分散在多个文件中

路径安全检查出现在 `file_tools.py` 和 `search_tools.py` 中，音乐目录检查在 `music_tool.py` 中，URL 协议检查在 `web_tools.py` 中。安全策略的分散导致：

- 新增工具时容易遗漏安全检查。
- 安全策略变更（如新增允许路径）需要修改多个文件。

建议提取 `tools/security.py` 模块，集中管理：

- `resolve_allowed_path(filepath, allowed_roots) -> Optional[Path]`
- `validate_url_protocol(url) -> bool`
- `sanitize_filename(name) -> str`

### 4.3 工具描述与 JSON Schema 的维护成本

当前每个工具需要手动维护 `description()` 和 `parameters_schema()` 两个方法。当参数变更时，容易遗漏同步更新。建议：

- 使用 Python 3.10+ 的 `dataclass` 或 Pydantic 模型定义参数结构，自动生成 JSON Schema。
- 或采用函数装饰器模式，将工具实现为普通函数，通过装饰器注册并推导 schema。

### 4.4 缺乏工具调用的可观测性

当前没有工具调用的追踪 ID、耗时统计、调用链记录。在调试 LLM 反复调用相同工具、或工具执行缓慢时，缺乏数据支撑。建议：

- 为每次工具调用生成 `trace_id`。
- 在 `ToolResult` 中记录 `elapsed_ms`。
- 在 `ToolAgentResult` 中记录每次调用的开始时间和结束时间。

---

## 五、结论

AI Friend 的工具层在功能实现上较为完整，覆盖了文件、网络、记忆、音乐、通知等核心场景，代码风格统一，日志记录充分。但存在以下系统性问题：

1. **架构债务**：`async` 基类与同步实现的矛盾、`to_json_schema()` 的残缺、`ToolCallRecord.arguments` 的缺失。
2. **安全漏洞**：目录遍历（符号链接）、ReDoS、PowerShell 命令注入、URL 协议绕过。
3. **重复代码**：路径安全检查在多个文件中重复实现。
4. **异常处理不一致**：部分工具使用裸 `except Exception`，部分工具完全忽略异常。
5. **参数校验薄弱**：enum 值、数值范围、类型转换缺乏统一防护。

建议按照 P0/P1/P2 优先级分阶段修复，优先处理安全漏洞和架构缺陷，再逐步完善可观测性和开发体验。
