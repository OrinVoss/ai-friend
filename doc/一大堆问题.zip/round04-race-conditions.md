# AI Friend 项目竞态条件与并发可靠性审查报告

**审查日期**: 2026-05-31
**审查范围**: web/session.py, memory/short_term.py, storage/database.py, core/agent.py, core/personality.py, web/server.py, core/message_handler.py, core/tool_agent.py, core/inner_drive.py, core/proactivity.py, core/sleep_manager.py, core/context_manager.py, memory/long_term.py, memory/consolidation.py, memory/retrieval.py, storage/repository.py, core/dispatcher.py, core/provider.py, memory/embeddings.py, tools/traits.py, config.py
**审查重点**: threading.Lock vs asyncio.Lock 混用、SessionManager 并发访问、personality.json 多会话写入竞争、_consecutive_negative 并发修改、turn_count 并发递增、_tool_call_history 并发追加、短期记忆 add_turn 锁范围、proactive task 与消息处理竞态

---

## 一、概述

AI Friend 项目采用混合并发模型：Web 层基于 FastAPI + asyncio（单线程事件循环），核心 Agent 层基于同步 Python（threading）。这种架构在 Web 模式下通过 `asyncio.get_event_loop().run_in_executor()` 将同步的 Agent 逻辑抛入线程池执行，从而形成了 **asyncio 事件循环线程** 与 **线程池工作线程** 并存的格局。审查发现，项目中的锁机制存在严重的类型不匹配问题：`SessionManager` 使用 `threading.Lock` 保护会话字典，但所有调用方都在 asyncio 事件循环中执行；`ConversationBuffer` 使用 `threading.Lock` 保护短期记忆，但 `add_turn` 操作在锁外创建 `Turn` 对象；`Database` 使用 `asyncio.Lock` 但 `Repository` 提供同步包装器 `_run_sync` 会创建新的线程池来运行协程，导致锁的上下文与执行上下文分离。此外，`personality.json` 文件写入完全没有锁保护，多会话同时保存会导致文件损坏；`_consecutive_negative`、`turn_count`、`_tool_call_history` 等 Agent 状态变量在 `run_in_executor` 抛入线程池后缺乏任何同步机制；`_proactive_loop` 与 `websocket_endpoint` 中的消息处理存在复杂的竞态关系，包括情绪状态并发修改、turn 编号跳跃、工具调用历史交叉污染等。

本报告将逐文件、逐函数地分析上述问题，给出风险评级（Critical / High / Medium / Low），并提供具体的文件路径和行号。

---

## 二、详细发现

### 2.1 threading.Lock vs asyncio.Lock 的系统性混用

#### 2.1.1 SessionManager 使用 threading.Lock 保护 asyncio 上下文中的共享状态

**文件**: `D:\桌面\编程作品\AI朋友\web\session.py`
**行号**: 第 3 行 `from threading import Lock`，第 129 行 `self._lock = Lock()`，第 136-144 行 `get_or_create()`，第 146-153 行 `remove()`，第 155-163 行 `register_proactive()`，第 169-174 行 `cleanup_old()`

`SessionManager` 是 Web 层的核心状态管理器，维护三个共享字典：`_sessions`（会话 ID → WebAgent 映射）、`_proactive_tasks`（会话 ID → asyncio.Task 映射）、`_active_ws`（会话 ID → WebSocket 映射）。它使用 `threading.Lock` 保护这些字典的所有访问。

问题分析：
- `SessionManager` 的所有方法（`get_or_create`, `remove`, `register_proactive`, `cleanup_old`）都是**同步函数**（没有 `async def`）。
- 但这些方法的所有调用方都在 **asyncio 事件循环线程** 中执行。例如 `web/server.py` 第 46 行 `_, agent = session_manager.get_or_create(session_id)`、`web/server.py` 第 213 行 `session_id, agent = session_manager.get_or_create(sid)`。
- 在 asyncio 单线程事件循环中，`threading.Lock` 虽然可以工作（因为 GIL 保证同一时刻只有一个协程在运行），但存在严重隐患：
  1. 如果某个协程在持有 `threading.Lock` 时发生 `await` 切换（虽然 `get_or_create` 内部没有 await，但调用链可能很长），其他协程仍然可以获取同一个 `threading.Lock`，因为 `threading.Lock` 不感知 asyncio 的协程切换。
  2. 更关键的是，`threading.Lock` 会阻塞整个 OS 线程。如果在 `run_in_executor` 的线程池中也需要访问 `SessionManager`（虽然当前代码没有直接这样做），会导致线程池线程被阻塞，降低并发性能。
  3. 最危险的是 `remove()` 方法第 150-151 行：`task.cancel()` 是在持有锁的情况下调用的。`task.cancel()` 是 asyncio 操作，虽然本身不会阻塞，但如果 task 的清理逻辑涉及其他锁，可能引发死锁。

风险评级：**High**

修复建议：将 `SessionManager` 的所有方法改为 `async def`，并将 `threading.Lock` 替换为 `asyncio.Lock`。或者，如果保持同步接口，应明确文档说明 `SessionManager` 只能在 asyncio 事件循环线程中调用，且 `threading.Lock` 在此场景下是"够用但不优雅"的。但考虑到 `cleanup_old` 可能被定时任务调用，最佳方案是统一使用 `asyncio.Lock`。

#### 2.1.2 ConversationBuffer 使用 threading.Lock 但锁范围不足

**文件**: `D:\桌面\编程作品\AI朋友\memory\short_term.py`
**行号**: 第 2 行 `import threading`，第 18 行 `_lock: threading.Lock = field(default_factory=threading.Lock)`，第 23-36 行 `add_turn()`

`ConversationBuffer` 使用 `threading.Lock` 保护 `_turns` 双端队列和 `_next_id` 计数器。`add_turn()` 方法的实现如下：

```python
def add_turn(self, role: str, content: str,
             metadata: Optional[dict] = None) -> Turn:
    turn = Turn(
        turn_id=self._next_id,
        role=role,
        content=content,
        timestamp=datetime.now(),
        metadata=metadata or {},
    )
    with self._lock:
        self._next_id += 1
        self._turns.append(turn)
```

问题分析：
- `Turn` 对象的创建在锁**外部**执行，其中 `turn_id=self._next_id` 读取了共享计数器。如果两个线程（或两个 `run_in_executor` 抛入的线程池任务）同时调用 `add_turn`，它们可能同时读取到相同的 `self._next_id` 值，导致生成两个具有相同 `turn_id` 的 `Turn` 对象。虽然 `_next_id` 的递增和 `append` 操作在锁内是原子的，但 `turn_id` 的分配不是。
- 在 Web 模式下，`add_turn` 可能从两个来源并发调用：
  1. `websocket_endpoint` 处理用户消息时，通过 `agent.process_message()` → `MessageHandler.handle_message()` → `a.short_term.add_turn("user", user_input)`（`web/server.py` 第 233 行）。
  2. `_proactive_loop` 中，主动回复通过 `agent.process_proactive()` → `MessageHandler.handle_proactive()` → `a._react_loop()` → 如果 `add_to_history=True` 则调用 `self.short_term.add_turn("assistant", final_text)`。但注意 `handle_proactive` 显式设置了 `add_to_history=False`（`message_handler.py` 第 187 行），所以 proactive 不会修改短期记忆。但 `handle_explore` 也设置了 `add_to_history=False`（第 235 行）。
  3. 然而，`Agent._react_loop()` 中第 173-174 行：`if add_to_history: self.short_term.add_turn("assistant", final_text)`。`handle_message` 调用 `_run_agent3` 时 `add_to_history=True`（第 271 行），而 `_run_agent3` 调用 `_react_loop` 也是 `add_to_history=True`（第 271 行）。所以用户消息处理会添加 assistant turn。
- 但更大的问题是：`ConversationBuffer` 的 `threading.Lock` 在 `run_in_executor` 的线程池上下文中是否有效？`run_in_executor` 将同步的 `process_message` 抛入线程池的**不同线程**中执行。`threading.Lock` 是 OS 级别的互斥锁，跨线程有效。所以在这个特定场景下，`threading.Lock` 比 `asyncio.Lock` 更适合保护跨线程共享状态。但问题在于 `SessionManager` 的锁和 `ConversationBuffer` 的锁是不同类型的，且 `SessionManager` 的锁在 asyncio 线程中持有，而 `ConversationBuffer` 的锁在线程池线程中持有——这本身不会直接导致死锁，但增加了心智负担。

风险评级：**Medium**（`turn_id` 重复分配的风险）

修复建议：将 `Turn` 对象的创建移入锁内，或者使用原子操作分配 `turn_id`：

```python
def add_turn(self, role: str, content: str,
             metadata: Optional[dict] = None) -> Turn:
    with self._lock:
        turn_id = self._next_id
        self._next_id += 1
        turn = Turn(
            turn_id=turn_id,
            role=role,
            content=content,
            timestamp=datetime.now(),
            metadata=metadata or {},
        )
        self._turns.append(turn)
    logger.debug(...)
    return turn
```

#### 2.1.3 Database 使用 asyncio.Lock 但 Repository 同步包装器破坏锁上下文

**文件**: `D:\桌面\编程作品\AI朋友\storage\database.py`
**行号**: 第 1 行 `import asyncio`，第 14 行 `self._lock = asyncio.Lock()`，第 26-39 行 `cursor()` 上下文管理器

**文件**: `D:\桌面\编程作品\AI朋友\storage\repository.py`
**行号**: 第 13-21 行 `_run_sync()`，第 29-30 行 `insert_turn_sync` / `get_recent_turns_sync`

`Database` 使用 `asyncio.Lock` 保护 SQLite 连接，这是正确的——因为 `Database` 的所有操作都在 asyncio 事件循环中执行。`cursor()` 上下文管理器在 `async with self._lock:` 中获取锁，确保同一时刻只有一个协程能访问数据库连接。

问题分析：
- `Repository` 提供了同步包装器 `_run_sync`，其定义为：

```python
def _run_sync(coro):
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return pool.submit(asyncio.run, coro).result()
```

- 这个函数在**已经存在运行中的事件循环**时（即 Web 模式下），会创建一个**新的 `ThreadPoolExecutor`**，并在其中调用 `asyncio.run(coro)` 来运行协程。
- 这意味着：当 `LongTermMemory` 的同步方法（如 `store_fact`）调用 `_run_sync(self._store_fact(...))` 时，协程会在**新的线程**中运行，而不是在原始的事件循环线程中运行。
- `asyncio.Lock` 是**协程级别的锁**，绑定到特定的事件循环。如果在事件循环 A 中创建了锁，在事件循环 B 中尝试获取同一个锁，行为是未定义的（实际上不会阻塞，因为两个事件循环独立运行）。
- 因此，当 `LongTermMemory` 的同步方法被多个 `run_in_executor` 的线程池任务并发调用时，每个任务可能创建自己的 `ThreadPoolExecutor` 来运行数据库协程，导致多个线程同时访问同一个 SQLite 连接，完全绕过了 `asyncio.Lock` 的保护。
- 虽然 SQLite 本身有文件级锁（WAL 模式下），但 `aiosqlite` 的连接对象不是线程安全的。多个线程同时使用同一个 `aiosqlite.Connection` 对象可能导致 `sqlite3.ProgrammingError: SQLite objects created in a thread can only be used in that same thread`。

风险评级：**Critical**

修复建议：
1. **方案 A（推荐）**: 彻底重构 `LongTermMemory` 和 `Repository`，移除 `_run_sync` 同步包装器，所有数据库操作保持为 `async` 方法。Web 层直接 `await` 这些异步方法。CLI 模式使用 `asyncio.run()` 运行主循环。
2. **方案 B**: 如果必须保留同步接口，使用 `threading.Lock` 保护数据库连接，并确保所有数据库操作都在同一线程中执行（例如使用 `queue` 将操作提交到专用数据库线程）。
3. **方案 C（临时缓解）**: 在 `_run_sync` 中不使用 `ThreadPoolExecutor`，而是使用 `asyncio.run_coroutine_threadsafe()` 将协程提交到原始事件循环执行，并等待结果。但这会导致线程池工作线程阻塞等待事件循环线程，可能降低性能。

#### 2.1.4 ContextManager._compressing 标志无锁保护

**文件**: `D:\桌面\编程作品\AI朋友\core\context_manager.py`
**行号**: 第 46 行 `self._compressing = False`，第 62-70 行 `compress()`

```python
def compress(self, messages: list[dict]) -> None:
    if self._compressing:
        return
    self._compressing = True
    try:
        self._do_compress(messages)
    finally:
        self._compressing = False
```

问题分析：
- `_compressing` 是一个简单的布尔标志，用于防止递归压缩。但它没有使用任何锁保护。
- 在 Web 模式下，如果两个用户消息同时触发压缩（虽然概率较低，因为压缩通常在上下文窗口接近阈值时触发），`self._compressing` 的检查-设置操作不是原子的。
- 更严重的是，`self._compressing = False` 在 `finally` 块中执行，但如果 `compress()` 被从 `run_in_executor` 抛入的线程调用，而另一个线程同时检查 `_compressing`，可能同时进入 `_do_compress`，导致 `self._short_term.clear()` 被调用两次，丢失对话历史。

风险评级：**Medium**

修复建议：使用 `threading.Lock` 保护 `_compressing` 的检查和设置（因为 `compress()` 是在线程池线程中执行的）。

---

### 2.2 SessionManager 中的并发访问问题

#### 2.2.1 get_or_create 返回的 WebAgent 引用被多协程共享

**文件**: `D:\桌面\编程作品\AI朋友\web\session.py`
**行号**: 第 136-144 行 `get_or_create()`

```python
def get_or_create(self, session_id: Optional[str] = None) -> tuple[str, WebAgent]:
    with self._lock:
        sid = session_id or uuid.uuid4().hex[:12]
        if sid not in self._sessions:
            logger.info(f"[session] create: {sid}")
            self._sessions[sid] = WebAgent(self.config, self.db, self.repo)
        else:
            logger.debug(f"[session] restore: {sid}")
        return sid, self._sessions[sid]
```

问题分析：
- `get_or_create()` 在持有锁的情况下创建 `WebAgent` 实例。`WebAgent` 的构造函数（第 28-79 行）执行了大量同步初始化工作，包括从数据库恢复对话历史（第 36-37 行 `for t in repo.get_recent_turns_sync(30): self.short_term.add_turn(...)`）。
- 虽然 `self._sessions[sid] = WebAgent(...)` 的赋值在锁内是原子的，但 `WebAgent` 实例一旦放入字典，多个协程可以同时获取到同一个引用。
- 在 `web/server.py` 中，同一个 session_id 可能同时被以下协程访问：
  1. `websocket_endpoint` 处理用户消息（第 230 行 `_, agent = session_manager.get_or_create(session_id)`）。
  2. `_proactive_loop` 中第 137 行 `_, agent = session_manager.get_or_create(session_id)`。
- 这两个协程获取到同一个 `WebAgent` 后，会分别通过 `run_in_executor` 调用 `agent.process_message()` 和 `agent.process_proactive()`，将操作抛入线程池的不同线程中执行。
- `WebAgent` 实例内部包含 `Personality`（共享 `EmotionalState`）、`ConversationBuffer`（有 `threading.Lock`）、`Agent`（无锁）等状态。这些状态会被两个线程并发修改。

风险评级：**High**

修复建议：
1. 为每个 `WebAgent` 实例添加一个 `threading.Lock`，确保同一时刻只有一个线程在执行该 Agent 的消息处理逻辑。
2. 或者，在 `SessionManager` 层面维护一个 "正在处理中" 的会话集合，避免对同一会话并发处理消息和主动回复。

#### 2.2.2 register_proactive 的 task.cancel() 可能引发异常

**文件**: `D:\桌面\编程作品\AI朋友\web\session.py`
**行号**: 第 155-163 行 `register_proactive()`

```python
def register_proactive(self, session_id: str, task, websocket) -> None:
    with self._lock:
        old_task = self._proactive_tasks.pop(session_id, None)
        if old_task:
            old_task.cancel()
        self._proactive_tasks[session_id] = task
        self._active_ws[session_id] = websocket
```

问题分析：
- 当用户重新连接（发送新的 `init` 消息）时，会创建新的 proactive task 并注册。旧的 task 会被 `cancel()`。
- `task.cancel()` 是异步操作，被 cancel 的 task 在下一次 `await` 时会抛出 `CancelledError`。但如果 old_task 正在 `run_in_executor` 中执行同步代码（如 `process_proactive`），`CancelledError` 不会立即抛出，而是等到 `run_in_executor` 返回后才会传播。
- 这意味着在 old_task 的同步代码执行期间，新的 task 可能已经开始运行，导致同一个 session 的两个 proactive task 同时执行。
- 此外，`old_task.cancel()` 后没有等待 task 实际结束（没有 `await old_task`），如果 old task 在清理阶段需要访问 `_sessions` 或 `_active_ws`，可能与新的 task 发生竞态。

风险评级：**High**

修复建议：
1. 在 `register_proactive` 中，如果存在 old_task，应先设置一个 "取消中" 标志，等待 old_task 完成后再注册新 task。
2. 或者，使用 `asyncio.shield` 保护关键操作，确保 cancel 不会中断正在执行的数据库写入或文件保存。

#### 2.2.3 cleanup_old 的会话驱逐无状态保存

**文件**: `D:\桌面\编程作品\AI朋友\web\session.py`
**行号**: 第 169-174 行 `cleanup_old()`

```python
def cleanup_old(self, max_sessions: int = 50) -> None:
    with self._lock:
        while len(self._sessions) > max_sessions:
            oldest = next(iter(self._sessions))
            self._sessions.pop(oldest)
            logger.info(f"Session evicted: {oldest}")
```

问题分析：
- `cleanup_old()` 直接驱逐最旧的会话，但**没有保存会话状态**（如 personality.json、数据库中的对话历史等）。
- 被驱逐的 `WebAgent` 实例可能正在处理消息（通过 `run_in_executor`），驱逐后该实例变为孤儿对象，但其线程池任务仍在运行。任务完成后尝试访问 `self.personality` 等属性仍然可以（因为对象还在内存中），但如果任务尝试通过 `session_manager` 访问其他资源（如 WebSocket），会失败。
- 更严重的是，如果 `cleanup_old` 在 proactive task 正在执行时驱逐了会话，proactive task 完成后可能尝试发送消息到已关闭的 WebSocket，引发异常。

风险评级：**Medium**

修复建议：
1. 在驱逐会话前，先取消该会话的 proactive task，并等待其完成。
2. 调用 `agent.personality.save()` 保存状态后再驱逐。
3. 或者，将 `cleanup_old` 改为标记过期机制，而不是立即删除，由定时任务在确认无活跃操作后再删除。

---

### 2.3 personality.json 多会话写入竞争

#### 2.3.1 WebAgent.process_message 直接保存 personality.json 无锁

**文件**: `D:\桌面\编程作品\AI朋友\web\session.py`
**行号**: 第 84-89 行 `process_message()`，第 91-97 行 `process_proactive()`，第 99-102 行 `process_explore()`

```python
def process_message(self, user_input: str) -> str:
    result = self.agent.process_message(
        user_input, on_token=self._on_token_callback,
    )
    self.personality.save(self.config.personality_file)
    return result
```

**文件**: `D:\桌面\编程作品\AI朋友\core\personality.py`
**行号**: 第 113-116 行 `save()`

```python
def save(self, path: str) -> None:
    logger.info(f"[personality] saved to: {path}")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
```

问题分析：
- `personality.json` 是**全局共享文件**，所有会话共享同一个文件路径（`config.personality_file`，默认 `"personality.json"`）。
- 当多个会话同时处理消息时，每个会话的 `process_message()` 都会调用 `self.personality.save()`，向同一个文件写入数据。
- `open(path, "w")` 的操作不是原子的：Python 先打开文件（截断为 0 字节），然后写入 JSON 数据。如果两个进程（或两个线程）同时执行此操作，可能出现以下情况：
  1. 线程 A 打开文件并截断。
  2. 线程 B 打开文件并截断。
  3. 线程 A 写入部分数据。
  4. 线程 B 写入完整数据。
  5. 线程 A 继续写入，覆盖线程 B 的部分数据。
  6. 最终文件是一个损坏的 JSON（混合了两个会话的情绪状态）。
- 在 Web 模式下，多个用户会话通过 `run_in_executor` 同时运行，每个都在线程池的不同线程中执行 `process_message()`，因此这种文件竞争是**必然发生**的（只要有并发请求）。
- 即使只有一个 WebSocket 连接，`_proactive_loop` 也可能在消息处理的同时触发主动回复，两者都会保存 personality.json。

风险评级：**Critical**

修复建议：
1. **文件级锁**: 使用 `filelock` 库或 `fcntl`（Unix）/ `msvcrt`（Windows）对 personality.json 加文件锁。
2. **原子写入**: 先写入临时文件，再用 `os.replace()` 原子替换目标文件。这不能解决数据覆盖问题（后写入的会覆盖先写入的），但可以避免文件损坏。
3. **会话隔离**: 每个会话使用独立的 personality 文件（如 `personality.{session_id}.json`），彻底消除竞争。
4. **数据库持久化**: 将情绪状态存入 SQLite 数据库（利用 WAL 模式和事务），而不是 JSON 文件。

#### 2.3.2 Personality.load 在 WebAgent 构造时读取，可能与并发写入冲突

**文件**: `D:\桌面\编程作品\AI朋友\web\session.py`
**行号**: 第 32 行 `self.personality = Personality.load(config.personality_file)`

问题分析：
- `WebAgent` 在构造时读取 `personality.json`。如果此时另一个会话正在写入该文件（`save()` 执行中），`load()` 可能读取到截断的或部分写入的文件内容。
- `load()` 方法第 93-94 行 `with open(path, encoding="utf-8") as f: data = json.load(f)` 没有异常处理来应对文件截断（虽然有 `json.JSONDecodeError` 的 catch，但如果文件被截断为空，`json.load` 会抛出 `JSONDecodeError`，返回默认的 `PersonalityConfig()`，导致该会话的情绪状态被重置为默认值）。

风险评级：**High**

修复建议：
1. 在 `load()` 中使用文件锁，确保读取时没有其他进程在写入。
2. 或者，在 `save()` 中实现原子写入（先写临时文件再 `os.replace`），确保读取时要么看到旧数据，要么看到新数据，不会看到半写状态。

---

### 2.4 _consecutive_negative 的并发修改

#### 2.4.1 Agent._process_emotion 中 _consecutive_negative 的读取-修改-写入非原子

**文件**: `D:\桌面\编程作品\AI朋友\core\agent.py`
**行号**: 第 52 行 `self.turn_count = 0`，第 73-79 行 `_consecutive_negative` 初始化，第 183-221 行 `_process_emotion()`，第 197-200 行 `_consecutive_negative` 修改

```python
def _process_emotion(self) -> None:
    ...
    if sentiment < -0.5:
        self._consecutive_negative += 1
    elif sentiment > 0.1:
        self._consecutive_negative = max(0, self._consecutive_negative - 1)
    ...
```

问题分析：
- `_consecutive_negative` 是 `Agent` 实例的属性，用于跟踪连续负面情绪的轮数。它在 `Agent.__init__` 中根据当前情绪状态初始化（第 73-79 行）。
- `_process_emotion()` 在 `_react_loop()` 的末尾被调用（第 180 行）。`_react_loop()` 通过 `run_in_executor` 在线程池线程中执行。
- 如果同一个 `WebAgent`（同一个 session）同时处理用户消息和主动回复，两个线程会并发执行 `_process_emotion()`，导致 `_consecutive_negative` 的递增/递减操作发生竞态。
- 例如：
  - 线程 A 读取 `_consecutive_negative = 2`。
  - 线程 B 读取 `_consecutive_negative = 2`。
  - 线程 A 计算 `2 + 1 = 3` 并写入。
  - 线程 B 计算 `2 + 1 = 3` 并写入。
  - 结果应该是 4，但实际是 3（丢失了一次递增）。
- 虽然 `handle_proactive` 和 `handle_explore` 设置了 `add_to_history=False`，但 `_process_emotion()` 仍然会被调用（因为 `skip_post_process=False` 是默认值，而 `handle_proactive` 没有传递 `skip_post_process`）。
- 等等，重新检查：`handle_proactive` 第 187 行 `return a._react_loop(messages, on_token, add_to_history=False)`，`_react_loop` 的默认参数 `skip_post_process=False`，所以 `_process_emotion()` **会被调用**。
- 这意味着主动回复也会修改 `_consecutive_negative` 和情绪状态，即使用户没有发送负面消息。

风险评级：**High**

修复建议：
1. 在 `Agent` 实例级别添加 `threading.Lock`，保护 `_consecutive_negative`、情绪状态、turn_count 等所有可变状态。
2. 或者，将 `handle_proactive` 和 `handle_explore` 的 `skip_post_process` 设为 `True`，避免主动回复修改情绪状态（因为主动回复没有用户输入可供分析情绪）。

---

### 2.5 turn_count 的并发递增

#### 2.5.1 _react_loop 中 turn_count 的非原子递增

**文件**: `D:\桌面\编程作品\AI朋友\core\agent.py`
**行号**: 第 52 行 `self.turn_count = 0`，第 175-177 行 `_react_loop()` 中的 turn_count 使用

```python
if final_text:
    if add_to_history:
        self.short_term.add_turn("assistant", final_text)
    self.ltm.repo.insert_turn_sync(self.turn_count, "assistant", final_text,
                              str(self.personality.emotion.to_dict()))
    self.turn_count += 1
```

问题分析：
- `turn_count` 用于标记对话轮次，并作为 `conversation_turns` 表的 `turn_number` 字段写入数据库。
- 在同一个 session 的并发处理中（消息处理 + 主动回复），两个线程可能同时读取相同的 `turn_count`，然后各自递增，导致：
  1. 数据库中出现两个相同的 `turn_number`。
  2. `turn_count` 只增加 1，而不是 2。
- 此外，`MessageHandler._run_agent3()` 第 251-252 行也会调用 `insert_turn_sync` 插入 user turn：

```python
a.ltm.repo.insert_turn_sync(a.turn_count, "user", user_input,
                       str(a.personality.emotion.to_dict()))
```

- 注意这里插入 user turn 时**没有递增** `turn_count`。`turn_count` 只在 `_react_loop` 中插入 assistant turn 后递增。这意味着 `turn_count` 实际上代表的是 assistant turn 的编号，而不是全局轮次编号。但 `_run_agent3` 使用 `a.turn_count` 作为 user turn 的 `turn_number`，而 `a.turn_count` 可能已经被另一个线程递增了。
- 例如：
  - 线程 A（用户消息）：`_run_agent3` 插入 user turn，turn_number = 5。
  - 线程 B（主动回复）：`_react_loop` 插入 assistant turn，turn_number = 5，然后 `turn_count += 1` → 6。
  - 线程 A 继续：`_react_loop` 插入 assistant turn，turn_number = 6（因为线程 B 已经递增了），然后 `turn_count += 1` → 7。
  - 结果：user turn 5 → assistant turn 5（主动回复）→ assistant turn 6（用户消息回复）。用户消息的 assistant turn 编号跳过了 5，且两个 assistant turn 的编号不连续。

风险评级：**High**

修复建议：
1. 使用 `threading.Lock` 保护 `turn_count` 的读取和递增，或者使用 `threading.atomic`（Python 中没有内置原子整数，但可以用 `lock` 模拟）。
2. 重新设计 turn 编号逻辑：user turn 和 assistant turn 应该使用统一的递增序列，或者使用数据库的自增 ID 作为主键，turn_number 仅作为逻辑分组标识。

---

### 2.6 _tool_call_history 的并发追加

#### 2.6.1 _react_loop 中 _tool_call_history 的列表操作非线程安全

**文件**: `D:\桌面\编程作品\AI朋友\core\agent.py`
**行号**: 第 57 行 `self._tool_call_history: list[dict] = []`，第 161-169 行 `_react_loop()` 中的追加和截断

```python
for r in results:
    self._tool_call_history.append({
        "name": r["name"],
        "success": r["success"],
        "output": r["output"][:200],
        "time": time.time(),
    })
if len(self._tool_call_history) > 20:
    self._tool_call_history = self._tool_call_history[-20:]
```

问题分析：
- `_tool_call_history` 是一个普通 Python 列表，用于记录最近的工具调用历史，供后续 prompt 注入。
- Python 列表的 `append` 操作在 CPython 中是线程安全的（因为 GIL 的存在，单个字节码操作是原子的），但 `len()` 检查和切片赋值 `self._tool_call_history = self._tool_call_history[-20:]` 不是原子的。
- 如果两个线程同时执行这段代码：
  - 线程 A 执行 `append`，列表长度变为 21。
  - 线程 B 执行 `append`，列表长度变为 22。
  - 线程 A 检查 `len() > 20`，条件为真，执行切片赋值，列表变为最后 20 个。
  - 线程 B 检查 `len() > 20`，条件为真（因为线程 A 已经截断了，但线程 B 可能看到的是 21 或 22，取决于 GIL 切换时机），执行切片赋值。
- 虽然列表操作在 CPython 中不太可能导致崩溃（因为 GIL 保护了内存访问），但在 PyPy 或其他 Python 实现中可能不安全。
- 更重要的是，`_tool_call_history` 的内容可能被另一个线程截断，导致当前线程追加的记录丢失。

风险评级：**Medium**

修复建议：使用 `threading.Lock` 保护 `_tool_call_history` 的所有操作，或者使用 `collections.deque(maxlen=20)` 替代列表（`deque` 的 `append` 在达到 maxlen 时会自动丢弃最旧元素，且 `append` 操作在 CPython 中是原子的）。

---

### 2.7 短期记忆 add_turn 的锁范围

#### 2.7.1 add_turn 中 Turn 创建在锁外，且锁不保护读取操作的一致性

**文件**: `D:\桌面\编程作品\AI朋友\memory\short_term.py`
**行号**: 第 23-36 行 `add_turn()`，第 38-40 行 `get_recent()`，第 51-64 行 `format_for_prompt()`

已在 2.1.2 中部分讨论。此处补充更多问题：

问题分析：
- `format_for_prompt()` 方法在锁内遍历 `_turns`，但 `estimate_tokens` 等外部调用可能在遍历过程中修改 `_turns`（虽然当前代码中 `format_for_prompt` 的调用方在锁内，但这不是由 `ConversationBuffer` 保证的）。
- `get_recent()` 返回 `list(self._turns)[-k:]`，这是一个浅拷贝。如果调用方在遍历返回的列表时，另一个线程修改了 `_turns`，列表中的 `Turn` 对象本身不会被修改（因为 `Turn` 是不可变的 dataclass），但列表长度和内容在返回后不会自动更新，这通常是可接受的。
- 更大的问题是：`ConversationBuffer` 的 `threading.Lock` 保护的是 `_turns` 和 `_next_id`，但 `WebAgent` 在构造时从数据库恢复历史（`session.py` 第 36-37 行）：

```python
for t in repo.get_recent_turns_sync(30):
    self.short_term.add_turn(t["role"], t["content"])
```

- `get_recent_turns_sync` 通过 `_run_sync` 在线程池中执行，而 `WebAgent` 的构造发生在 `SessionManager.get_or_create()` 中，持有 `SessionManager._lock`。此时 `add_turn` 获取 `ConversationBuffer._lock`，两个锁的获取顺序是：`SessionManager._lock` → `ConversationBuffer._lock`。如果其他地方以相反顺序获取这两个锁，可能导致死锁。当前代码中没有相反的顺序，但需要警惕未来的修改。

风险评级：**Medium**

修复建议：
1. 将 `Turn` 创建移入锁内（如 2.1.2 所述）。
2. 统一锁的获取顺序，并在代码注释中明确记录。

---

### 2.8 proactive task 与消息处理的竞态

#### 2.8.1 _proactive_loop 与 websocket_endpoint 并发修改 Agent 状态

**文件**: `D:\桌面\编程作品\AI朋友\web\server.py`
**行号**: 第 130-196 行 `_proactive_loop()`，第 199-249 行 `websocket_endpoint()`

问题分析：
- `_proactive_loop` 是一个无限循环的 asyncio task，每 15 秒检查一次是否需要主动回复。它通过 `run_in_executor` 调用同步的 Agent 方法（`decide_proactive_action`、`process_explore_with_intent`、`process_proactive_with_intent`）。
- `websocket_endpoint` 处理用户消息时，也通过 `run_in_executor` 调用 `agent.process_message()`（第 233 行）。
- 这两个执行路径会并发修改同一个 `Agent` 实例的以下状态：
  1. `last_activity_time`：`_proactive_loop` 第 188 行 `ag.last_activity_time = time.time()`，`websocket_endpoint` 第 231 行 `agent.agent.last_activity_time = time.time()`。虽然赋值本身是原子的，但两个线程可能基于旧的值做决策。
  2. `personality.emotion`（`EmotionalState`）：`_process_emotion()` 修改情绪状态，`_proactive_loop` 中的 `process_proactive` 也会调用 `_process_emotion()`（如 2.4.1 所述）。
  3. `turn_count`：如 2.5.1 所述。
  4. `_tool_call_history`：如 2.6.1 所述。
  5. `_sleeping`：`SleepManager.get_sleep_state()` 可能修改 `_sleeping`（`sleep_manager.py` 第 60-61 行、第 67-68 行、第 78 行、第 89 行），而 `_proactive_loop` 第 154 行检查 `ag._sleeping`。
  6. `personality.json` 文件：如 2.3.1 所述。

- 特别危险的场景：
  - 用户发送消息，`websocket_endpoint` 调用 `process_message()`。
  - 同时 `_proactive_loop` 判定需要主动回复，调用 `process_proactive()`。
  - `process_message()` 和 `process_proactive()` 同时执行 `_react_loop()`，两者都会调用 `provider.generate()`（`core/provider.py` 第 32-80 行）。`KimiProvider` 使用 `requests.Session`，`Session` 是线程安全的（可以安全地在多个线程中使用），但 `generate()` 方法内部修改的实例变量（如 `self.temperature`）如果存在，可能有问题。当前代码中没有在 `generate()` 中修改实例变量，所以 `KimiProvider` 本身是线程安全的。
  - 但 `_react_loop()` 中的 `messages` 列表是局部变量，不会冲突。问题在于 `_react_loop()` 对 `Agent` 实例状态的修改。

风险评级：**Critical**

修复建议：
1. **会话级互斥锁**: 为每个 `WebAgent` 实例添加一个 `threading.Lock`（或 `asyncio.Lock`），在 `SessionManager` 层面管理。任何对 `WebAgent` 的操作（消息处理、主动回复、探索）都必须先获取该锁。
2. **proactive 队列化**: 不要直接在 `_proactive_loop` 中执行主动回复，而是将主动回复请求放入队列，由 `websocket_endpoint` 在处理完用户消息后检查队列并执行。这样可以确保同一时刻只有一个操作在执行。
3. **状态分离**: 将 `EmotionalState` 设计为不可变的值对象，每次修改创建新的实例，通过原子引用替换更新。这可以消除情绪状态的并发修改问题（但需要大量重构）。

#### 2.8.2 _proactive_loop 中 get_active_ws 返回的 WebSocket 可能已关闭

**文件**: `D:\桌面\编程作品\AI朋友\web\server.py`
**行号**: 第 136 行 `active_ws = session_manager.get_active_ws(session_id) or websocket`

问题分析：
- `_proactive_loop` 使用 `session_manager.get_active_ws(session_id)` 获取当前活跃的 WebSocket。如果用户重新连接，`register_proactive` 会更新 `_active_ws`，但旧的 WebSocket 可能仍然处于打开状态（直到被垃圾回收或显式关闭）。
- 如果 `get_active_ws` 返回的是旧的 WebSocket（因为 `register_proactive` 的更新有竞态），`_send_segments` 会尝试向已关闭的 WebSocket 发送消息，引发 `WebSocketDisconnect` 或 `RuntimeError`。
- 更微妙的是，`or websocket` 回退使用了 `_proactive_loop` 创建时传入的 `websocket` 参数。如果用户已经断开并重新连接，这个 `websocket` 可能已经是旧连接，而 `get_active_ws` 返回新连接。但如果在 `get_active_ws` 和 `or websocket` 之间发生上下文切换，可能使用错误的连接。

风险评级：**Medium**

修复建议：
1. 在 `_send_segments` 中捕获 WebSocket 发送异常，并在发送前检查 WebSocket 的状态（`websocket.client_state`）。
2. 使用 `asyncio.Lock` 保护 `_active_ws` 的读取和更新。

#### 2.8.3 _proactive_loop 的 sleep_cooldown 和 cooldown 非线程安全

**文件**: `D:\桌面\编程作品\AI朋友\web\server.py`
**行号**: 第 131-132 行 `cooldown = 0; sleep_cooldown = 0`，第 141-153 行 sleep_cooldown 修改，第 159-161 行 cooldown 修改

问题分析：
- `cooldown` 和 `sleep_cooldown` 是 `_proactive_loop` 的局部变量，但 `_proactive_loop` 是 asyncio task，在单线程事件循环中运行，所以这些变量本身是协程安全的（不会被其他协程直接访问）。
- 但 `sleep_cooldown` 的递减（第 153 行 `sleep_cooldown = max(0, sleep_cooldown - 1)`）和 `cooldown` 的递减（第 160 行 `cooldown = max(0, cooldown - 1)`）是在 `await asyncio.sleep()` 之后执行的，由于 asyncio 的协作式调度，这些操作不会被中断，因此是安全的。
- 问题在于：`sleep_cooldown` 和 `cooldown` 的语义不够清晰。`sleep_cooldown` 以"循环迭代次数"为单位（每次循环减 1，而不是按时间），而 `cooldown` 也以迭代次数为单位。如果循环的 `sleep` 时间变化（如第 155 行 `await asyncio.sleep(30)`、第 161 行 `await asyncio.sleep(5)`、第 191 行 `await asyncio.sleep(15)`），实际的冷却时间与迭代次数不成正比，导致行为不可预测。

风险评级：**Low**

修复建议：将 `cooldown` 和 `sleep_cooldown` 改为基于时间戳的绝对时间检查，而不是计数器。

#### 2.8.4 proactive task 的异常处理可能吞掉重要错误

**文件**: `D:\桌面\编程作品\AI朋友\web\server.py`
**行号**: 第 192-196 行

```python
except Exception as e:
    logger.warning(f"Proactive error: {e}")
    await asyncio.sleep(30)
```

问题分析：
- `_proactive_loop` 捕获所有异常并继续循环。如果 proactive task 因为竞态条件导致数据损坏（如 `personality.json` 写入失败），错误被记录为 `warning` 级别，且循环继续。
- 这可能导致持续的半损坏状态，因为每次循环都会重试相同的操作。
- 此外，`except Exception` 也捕获了 `KeyboardInterrupt` 和 `SystemExit` 之外的几乎所有异常，包括 `MemoryError`、`RecursionError` 等应该终止程序的严重错误。

风险评级：**Medium**

修复建议：
1. 区分可恢复异常和不可恢复异常。对于数据库连接错误、文件系统错误等，应增加退避时间并限制重试次数；对于 `MemoryError` 等，应重新抛出。
2. 在多次连续失败后，取消 proactive task 并通知用户。

---

### 2.9 其他并发相关问题

#### 2.9.1 execute_tool_calls 中 asyncio.run 的嵌套调用问题

**文件**: `D:\桌面\编程作品\AI朋友\core\dispatcher.py`
**行号**: 第 128-134 行

```python
import asyncio
try:
    import inspect
    if inspect.iscoroutinefunction(tool.execute):
        result: ToolResult = asyncio.run(tool.execute(args))
    else:
        result: ToolResult = tool.execute(args)
```

问题分析：
- `execute_tool_calls` 在 `run_in_executor` 的线程池线程中被调用（因为 `process_message` 在 `run_in_executor` 中执行）。
- 如果 `tool.execute` 是异步函数，`asyncio.run()` 会创建一个新的事件循环并运行协程。但 `asyncio.run()` 不能在已经存在运行中的事件循环的线程中调用（会抛出 `RuntimeError: asyncio.run() cannot be called from a running event loop`）。
- 在 `run_in_executor` 的线程中，通常没有运行中的事件循环，所以 `asyncio.run()` 可以工作。但如果某个工具的内部实现也使用了 `run_in_executor` 或创建了线程池，可能引发嵌套事件循环的问题。
- 更严重的是，如果 `execute_tool_calls` 在原始的事件循环线程中被调用（例如 CLI 模式下），且某个工具是异步的，`asyncio.run()` 会失败，因为 CLI 模式的主线程已经有运行中的事件循环。
- 实际上，CLI 模式的 `Agent.run()` 调用 `CliController.run()`，如果 `CliController` 也使用了 asyncio，这个问题就会触发。

风险评级：**High**

修复建议：
1. 将 `execute_tool_calls` 改为 `async def`，统一使用 `await` 调用异步工具。
2. 或者，使用 `asyncio.get_event_loop().run_until_complete()` 替代 `asyncio.run()`，并处理事件循环已存在的情况。

#### 2.9.2 MemoryConsolidator._pending_buffer 无锁保护

**文件**: `D:\桌面\编程作品\AI朋友\memory\consolidation.py`
**行号**: 第 25 行 `self._pending_buffer: list = []`，第 44-45 行 `add_pending()`，第 47-81 行 `consolidate()`

问题分析：
- `MemoryConsolidator` 维护 `_pending_buffer` 列表，用于暂存待合并的对话轮次。
- `add_pending()` 直接 `append`，`consolidate()` 直接 `clear()`。这两个方法可能在不同线程中被调用：
  - `add_pending()` 在 `_process_emotion()` 中被调用（`agent.py` 第 217 行）。
  - `consolidate()` 也在 `_process_emotion()` 中被调用（`agent.py` 第 218 行）。
  - 但 `_process_emotion()` 本身在 `run_in_executor` 的线程中执行，且同一个 session 可能同时有多个 `_process_emotion()` 在执行（消息处理 + 主动回复）。
- 虽然 `add_pending` 和 `consolidate` 在当前代码中总是在同一个 `_process_emotion` 调用中顺序执行（第 217-218 行），但如果未来代码修改导致它们在不同线程中并发执行，`_pending_buffer` 的 `append` 和 `clear` 操作可能发生竞态。

风险评级：**Low**（当前代码路径下不会触发，但未来修改有风险）

修复建议：使用 `threading.Lock` 保护 `_pending_buffer` 的操作。

#### 2.9.3 EmbeddingCache 无锁保护

**文件**: `D:\桌面\编程作品\AI朋友\memory\embeddings.py`
**行号**: 第 86-117 行 `EmbeddingCache`

问题分析：
- `EmbeddingCache` 使用 `OrderedDict` 实现 LRU 缓存，但没有使用任何锁。
- `get()` 和 `set()` 操作修改 `_cache`（`move_to_end`、`popitem`）。如果多个线程同时访问 `EmbeddingCache`（例如 `MemoryRetriever._hybrid_score()` 和 `_search_experiences_semantic()` 在不同线程中被调用），`OrderedDict` 的内部状态可能损坏。
- Python 的 `OrderedDict` 不是线程安全的。虽然 `move_to_end` 和 `__setitem__` 在 CPython 中可能是原子的（因为 GIL），但 `popitem` 和 `__setitem__` 的组合不是原子的。

风险评级：**Medium**

修复建议：使用 `threading.Lock` 保护 `EmbeddingCache` 的所有操作，或者使用 `functools.lru_cache`（它是线程安全的）。

#### 2.9.4 SleepManager._sleeping 的并发修改

**文件**: `D:\桌面\编程作品\AI朋友\core\sleep_manager.py`
**行号**: 第 19 行 `self._sleeping = self._load_sleep_state()`，第 60-61 行、第 67-68 行、第 78 行、第 89 行修改 `_sleeping`

问题分析：
- `_sleeping` 是一个布尔标志，被 `_proactive_loop` 读取（`web/server.py` 第 154 行 `if ag._sleeping:`），被 `SleepManager.get_sleep_state()` 修改。
- `get_sleep_state()` 在 `_proactive_loop` 中通过 `run_in_executor` 在线程池线程中调用（`web/server.py` 第 142 行 `should_sleep, msg = ag._get_sleep_state()`）。
- 同时，`SleepManager` 的 `_save_sleep_state()` 方法（第 33-38 行）向文件写入睡眠状态，但没有锁保护。
- 如果两个线程同时调用 `get_sleep_state()`（例如两个不同的 session 共享同一个 `SleepManager`？不，每个 `Agent` 有自己的 `SleepManager`），但同一个 session 的 `_proactive_loop` 和 `websocket_endpoint` 不会直接调用 `get_sleep_state()`，只有 `_proactive_loop` 调用。
- 但 `_sleeping` 的修改和读取不是原子的。如果 `_proactive_loop` 在 `get_sleep_state()` 执行期间检查 `ag._sleeping`，可能读取到中间状态（虽然布尔赋值在 CPython 中是原子的，但 `_save_sleep_state()` 的文件操作不是）。

风险评级：**Low**

修复建议：使用 `threading.Lock` 保护 `_sleeping` 的修改和 `_save_sleep_state()` 的文件操作。

#### 2.9.5 ProactivityManager 的 rate limit 状态无锁保护

**文件**: `D:\桌面\编程作品\AI朋友\core\proactivity.py`
**行号**: 第 18-19 行 `self._last_explore_time: float = 0; self._last_chat_time: float = 0`，第 94-115 行 `check_rate_limit()`

问题分析：
- `_last_explore_time` 和 `_last_chat_time` 在 `check_rate_limit()` 中被读取和修改。`check_rate_limit()` 在 `_proactive_loop` 中通过 `run_in_executor` 调用。
- 如果同一个 session 的 `_proactive_loop` 同时触发 explore 和 chat（虽然代码逻辑上不会，因为每次循环只选择一个 action），或者如果未来代码修改允许多个 proactive task 同时运行，rate limit 状态可能被并发修改。
- 当前代码路径下风险较低，因为 `_proactive_loop` 是单线程的 asyncio task，且 `check_rate_limit` 的调用在 `run_in_executor` 返回后才继续，同一时刻只有一个 `check_rate_limit` 在执行。

风险评级：**Low**

修复建议：使用 `threading.Lock` 保护 rate limit 状态的修改，以应对未来的并发扩展。

---

## 三、汇总统计

### 3.1 风险等级分布

| 风险等级 | 数量 | 问题编号 |
|---------|------|---------|
| Critical | 3 | 2.1.3（Database asyncio.Lock 被 _run_sync 破坏）、2.3.1（personality.json 多会话写入竞争）、2.8.1（proactive task 与消息处理并发修改 Agent 状态） |
| High | 6 | 2.1.1（SessionManager threading.Lock 在 asyncio 中）、2.2.1（get_or_create 返回共享引用）、2.2.2（register_proactive task.cancel 竞态）、2.3.2（Personality.load 与并发写入冲突）、2.4.1（_consecutive_negative 并发修改）、2.5.1（turn_count 并发递增）、2.9.1（execute_tool_calls 中 asyncio.run 嵌套） |
| Medium | 8 | 2.1.2（ConversationBuffer 锁范围不足）、2.1.4（ContextManager._compressing 无锁）、2.2.3（cleanup_old 无状态保存）、2.6.1（_tool_call_history 并发追加）、2.7.1（add_turn 锁范围）、2.8.2（get_active_ws WebSocket 已关闭）、2.8.4（proactive 异常吞掉错误）、2.9.3（EmbeddingCache 无锁） |
| Low | 4 | 2.8.3（cooldown 计数器非时间戳）、2.9.2（MemoryConsolidator._pending_buffer 无锁）、2.9.4（SleepManager._sleeping 并发修改）、2.9.5（ProactivityManager rate limit 无锁） |

### 3.2 问题类别分布

| 类别 | 数量 | 涉及文件 |
|------|------|---------|
| 锁类型混用 | 3 | web/session.py, memory/short_term.py, storage/database.py |
| 文件写入竞争 | 2 | web/session.py, core/personality.py |
| 状态变量并发修改 | 5 | core/agent.py, core/sleep_manager.py, core/proactivity.py, core/context_manager.py |
| 任务生命周期管理 | 3 | web/session.py, web/server.py |
| 数据库访问安全 | 2 | storage/database.py, storage/repository.py |
| 缓存/缓冲区安全 | 3 | memory/short_term.py, memory/consolidation.py, memory/embeddings.py |
| 事件循环嵌套 | 1 | core/dispatcher.py |

### 3.3 核心建议优先级

**P0（立即修复）**:
1. 为 `personality.json` 添加文件锁或原子写入，或改为每个会话独立文件。
2. 修复 `Repository._run_sync` 创建独立线程池的问题，统一数据库访问的线程模型。
3. 为每个 `WebAgent` 添加会话级互斥锁，禁止同一会话的消息处理和主动回复并发执行。

**P1（本轮修复）**:
4. 将 `SessionManager` 的 `threading.Lock` 替换为 `asyncio.Lock`，并统一为 `async def` 方法。
5. 修复 `ConversationBuffer.add_turn()` 中 `turn_id` 在锁外分配的问题。
6. 使用 `threading.Lock` 保护 `Agent` 的 `_consecutive_negative`、`turn_count`、`_tool_call_history` 等状态。
7. 修复 `execute_tool_calls` 中 `asyncio.run()` 的嵌套调用问题。

**P2（后续优化）**:
8. 为 `EmbeddingCache` 添加线程安全保护。
9. 改进 `SleepManager` 和 `ProactivityManager` 的状态保护。
10. 重构 `ContextManager._compressing` 为线程安全标志。

---

## 四、附录：关键代码路径的竞态场景时序图

### 场景 1：两个会话同时保存 personality.json

```
时间轴 →
会话 A: open("personality.json", "w") → 截断文件 → 写入 {"valence": 0.5, ...}
会话 B:                          open("personality.json", "w") → 截断文件 → 写入 {"valence": -0.2, ...}
结果: 文件内容可能是混合的无效 JSON
```

### 场景 2：消息处理与主动回复并发修改 turn_count

```
时间轴 →
用户消息线程: insert_turn_sync(turn=5, "user", ...) → _react_loop() → insert_turn_sync(turn=5, "assistant", ...) → turn_count += 1 (→ 6)
主动回复线程:                          _react_loop() → insert_turn_sync(turn=5, "assistant", ...) → turn_count += 1 (→ 6)
结果: 数据库中有两个 turn_number=5 的 assistant turn，turn_count 只增加到 6（应为 7）
```

### 场景 3：_run_sync 创建独立事件循环绕过 asyncio.Lock

```
时间轴 →
事件循环线程: Database._lock = asyncio.Lock() (绑定到事件循环 A)
线程池线程 1: _run_sync(self._store_fact()) → 创建 ThreadPoolExecutor → asyncio.run(coro) → 新事件循环 B
线程池线程 2: _run_sync(self._store_fact()) → 创建 ThreadPoolExecutor → asyncio.run(coro) → 新事件循环 C
结果: 线程 1 和线程 2 同时进入 Database.cursor()，各自的事件循环 B/C 都成功获取 Database._lock（因为锁绑定到事件循环 A），导致并发访问 SQLite 连接
```

---

*报告结束*
