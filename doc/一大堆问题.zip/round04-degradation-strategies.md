# 第4轮：错误处理与可靠性审查报告 —— 降级策略专项

> 审查日期：2026-05-31
> 审查范围：AI Friend 项目全栈错误处理与降级策略
> 审查文件：memory/embeddings.py, core/provider.py, memory/retrieval.py, core/agent.py, tools/traits.py 及关联模块

---

# 概述

AI Friend 是一个三层 Agent 架构的 AI 陪伴应用，核心链路为：Agent 1（InnerDrive）决策 → Agent 2（ToolAgent）执行外部工具 → Agent 3（Roleplay）情感表达。系统依赖多个外部和内部子系统：DeepSeek/Kimi API、本地 llama-server 嵌入引擎、SQLite 长期记忆、AnySearch 网络搜索 API、文件系统、WebSocket 通信等。

本次审查聚焦**降级策略（Degradation Strategies）**：当某个子系统失败时，系统是否能优雅降级、保持核心功能可用、避免级联故障。审查覆盖以下八个维度：

1. 嵌入引擎失败时的优雅降级（EmbeddingEngine）
2. API 失败时的行为
3. 记忆检索失败时的降级
4. 工具失败时的降级
5. 情绪系统失败时的降级
6. 压缩失败时的降级
7. 是否有断路器模式
8. 降级后的用户体验

---

# 详细发现

---

## 1. 嵌入引擎失败时的优雅降级（EmbeddingEngine）

### 1.1 健康检查与条件分支

**文件**：`memory/embeddings.py`，行 74-83

```python
def health_check(self) -> bool:
    try:
        resp = self._session.get(
            self._endpoint.replace("/embeddings", "/health"),
            timeout=5,
        )
        return resp.status_code == 200
    except Exception:
        return False
```

**分析**：`health_check()` 在每次检索前被调用，通过探测 `/health` 端点判断嵌入服务是否可用。若不可用，系统会回退到纯关键词检索。这是一个正确的降级入口。

**文件**：`memory/retrieval.py`，行 39-42

```python
if self._embed and self._embed.health_check():
    candidates = self._hybrid_score(query, hot_facts, keywords)
else:
    candidates = self._score_facts(hot_facts, keywords, query)
```

**风险点**：
- `health_check()` 每次查询都执行一次 HTTP GET，增加了延迟（虽然 timeout=5s，但网络抖动时仍可能阻塞）。**没有缓存健康状态**，也没有指数退避或熔断逻辑。如果嵌入服务持续不可用，每次查询都会浪费 5 秒（或超时时间）。
- `encode()` 方法（行 24-50）在失败时直接抛出异常，由调用方捕获。但 `_hybrid_score()` 和 `_search_experiences_semantic()` 内部也有 try-except 捕获（行 111-115、144-147），确保单次嵌入失败不会崩溃整个检索流程。

### 1.2 嵌入失败的内层捕获

**文件**：`memory/retrieval.py`，行 111-115

```python
try:
    query_vec = self._embed.encode_single(query)
except Exception as e:
    logger.warning(f"[retrieval] embed failed, fallback to keyword: {e}")
    return self._score_facts(candidates, keywords, query)
```

**分析**：`_hybrid_score()` 中，如果查询嵌入失败，立即回退到 `_score_facts()`（纯关键词评分）。这是正确的降级行为。但注意：**候选事实的嵌入向量（`c.embedding`）反序列化失败时，只是静默忽略**（行 123-127）：

```python
try:
    vec = EmbeddingEngine.bytes_to_vec(bytes(c.embedding))
    semantic = float(np.dot(vec, query_vec))
except Exception:
    pass
```

**风险**：如果数据库中存储的嵌入向量损坏或维度不匹配，`semantic` 保持 0.0，该候选事实仅依赖 keyword 得分排序。这不会导致崩溃，但可能导致排序质量下降。**没有日志记录此类静默失败**，难以排查数据质量问题。

### 1.3 EmbeddingCache 的容错

**文件**：`memory/embeddings.py`，行 86-117

`EmbeddingCache` 是一个 LRU 缓存，使用 SHA-256 哈希作为键。缓存操作（get/set/invalidate）全部是纯内存操作，没有 I/O，因此不会失败。但缓存**没有持久化**，进程重启后丢失，这属于设计选择而非缺陷。

**风险评级**：**中**
- 有降级路径（关键词回退），但健康检查缺乏缓存和熔断。
- 向量损坏静默忽略，缺乏监控。

---

## 2. API 失败时的行为

### 2.1 Provider 层的重试策略

**文件**：`core/provider.py`，行 32-80

```python
def generate(self, messages: list[dict], ...):
    last_error = None
    for attempt in range(3):
        try:
            return self._do_request(chat_url, payload, stream, on_token)
        except requests.exceptions.ConnectionError as e:
            last_error = e
            wait = 2 ** attempt
            logger.warning(f"[api] connection error attempt={attempt+1}/3 retry_in={wait}s: {e}")
            time.sleep(wait)
        except requests.exceptions.HTTPError as e:
            last_error = e
            if e.response.status_code < 500:
                raise
            wait = 2 ** attempt
            ...
        except (requests.exceptions.ChunkedEncodingError,
                requests.exceptions.StreamConsumedError) as e:
            ...

    logger.error(f"[api] failed after 3 retries: {last_error}")
    raise ConnectionError(f"API request failed after 3 retries: {last_error}")
```

**分析**：
- 实现了**3 次重试 + 指数退避**（1s, 2s, 4s）。
- 对 4xx HTTP 错误（如 400 Bad Request、401 Unauthorized、429 Rate Limit）**直接抛出，不重试**。这是正确的，因为客户端错误重试无益。
- 对连接错误、5xx 错误、流编码错误进行重试。
- **缺少对 429 Too Many Requests 的特殊处理**：没有读取 `Retry-After` 头，也没有更长的退避。
- **超时设置**：`timeout=180` 秒（默认）。对于流式响应，这是合理的；但对于非流式的小请求，180 秒过长，失败检测太慢。

### 2.2 API 失败的上层处理

**文件**：`core/cli_controller.py`，行 198-205、219-226

```python
try:
    full_response = a.provider.generate(messages, stream=False, max_tokens=384)
except ConnectionError as e:
    if a.ui:
        a.ui.display.print_error(f"网络连接失败：{e}")
    a._reset_react()
    a.state = AgentState.REFLECT
    return
```

**分析**：CLI 路径对 `ConnectionError` 有捕获，会打印错误并回到 REFLECT 状态。但：
- **只捕获 `ConnectionError`**。如果 API 返回 400/401/403/429，抛出的是 `requests.exceptions.HTTPError`，CLI 没有捕获，会导致状态机崩溃（被外层 `except Exception` 捕获，打印错误后回到 IDLE）。
- **Web 路径**（`web/server.py`）没有显式捕获 API 异常。`agent.process_message()` 内部如果抛出 `HTTPError`，会一路向上传播到 WebSocket 的 `except Exception` 块（行 241），然后尝试发送错误消息给客户端。但发送时如果连接已断开，又会触发 `WebSocketDisconnect`。

**文件**：`web/server.py`，行 241-246

```python
except Exception as e:
    logger.error(f"WebSocket error: {e}")
    try:
        await websocket.send_text(json.dumps({"type": "error", "content": str(e)}))
    except (WebSocketDisconnect, ConnectionError, RuntimeError):
        pass
```

**风险**：Web 客户端收到的错误消息是原始异常字符串（如 `"API request failed after 3 retries: ..."`），**没有用户友好的降级提示**。用户可能看到技术错误信息而非"我现在有点卡，稍等一下"之类的友好表达。

### 2.3 流式响应中断的处理

**文件**：`core/provider.py`，行 107-127

```python
for line in resp.iter_lines(decode_unicode=True):
    if not line:
        continue
    if line.startswith("data: "):
        data_str = line[6:]
        if data_str.strip() == "[DONE]":
            break
        try:
            o = json.loads(data_str)
            ...
        except json.JSONDecodeError:
            continue
```

**分析**：流式解析中对 `json.JSONDecodeError` 是 `continue`（跳过损坏的行）。但如果流在 `[DONE]` 之前被中断（如网络断开），`full_response` 会包含已接收的部分内容，**不会报错**，而是返回不完整的内容。这在 `_do_request` 层面没有检测，调用方（`cli_controller.py`）也不会知道响应是否完整。

**风险评级**：**高**
- 4xx 错误未在 CLI 中优雅处理，可能导致用户体验中断。
- 流式响应中断无检测，可能返回截断内容。
- Web 路径缺乏 API 错误的友好包装。

---

## 3. 记忆检索失败时的降级

### 3.1 三层检索架构的降级

**文件**：`memory/retrieval.py`，行 27-69

```python
def retrieve_for_query(self, query: str) -> MemoryContext:
    # Layer 1: hot memory (always included)
    hot_facts = self.ltm.get_all_active_facts(limit=50)
    recent_experiences = self.ltm.get_recent_experiences(limit=5)
    reflections = self.ltm.get_recent_reflections(limit=3)
    relationship = self.ltm.get_relationship()

    # Layer 2: hybrid or keyword scoring
    keywords = self._extract_keywords(query)
    if self._embed and self._embed.health_check():
        candidates = self._hybrid_score(query, hot_facts, keywords)
    else:
        candidates = self._score_facts(hot_facts, keywords, query)
    ...
```

**分析**：
- **Layer 1（Hot Memory）** 不依赖嵌入，总是执行。即使嵌入服务完全宕机，也能返回最近的事实、经历、反思和关系数据。
- **Layer 2（混合检索）** 在嵌入不可用时回退到 `_score_facts()`（纯关键词评分）。
- **Layer 3（按需回忆 `[回忆: xxx]`）** 完全基于关键词搜索，不依赖嵌入。

### 3.2 LLM 重排序失败

**文件**：`memory/retrieval.py`，行 204-225

```python
def _llm_rerank(self, query: str, candidates: list[UserFact], ...):
    try:
        result = self.llm_rerank_fn(prompt)
        if not result or result.strip().upper() == "NONE":
            return None
        indices = [int(x.strip()) for x in result.split(",") if x.strip().isdigit()]
        return indices[:max_candidates]
    except Exception as e:
        logger.warning(f"LLM rerank failed: {e}")
        return None
```

**分析**：LLM 重排序失败时返回 `None`，调用方（行 46-49）会保留原始候选列表，不做重排序。这是正确的降级行为。

### 3.3 长期记忆数据库失败的传播

**文件**：`memory/long_term.py`，行 17-26

```python
@staticmethod
def _run_sync(coro):
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return pool.submit(asyncio.run, coro).result()
```

**分析**：`LongTermMemory` 的所有同步方法都通过 `_run_sync()` 包装异步数据库操作。如果数据库连接断开或 SQLite 损坏，异常会原样抛出到调用方（如 `Agent._run_agent3()`）。

**文件**：`core/agent.py`，行 249

```python
mem_ctx = a.retriever.retrieve_for_query(user_input)
```

**风险**：如果 SQLite 数据库损坏或锁定，`retrieve_for_query()` 会抛出异常，导致整个消息处理流程中断。`Agent.process_message()` 和 `MessageHandler.handle_message()` **没有 try-except 包裹检索步骤**。这意味着：
- CLI 路径：异常被 `CliController.run()` 的外层 `except Exception` 捕获，打印错误后回到 IDLE（行 81-86）。
- Web 路径：异常传播到 `web/server.py` 的 `except Exception`，发送错误给客户端。

**没有针对数据库失败的专门降级**：比如返回空的 `MemoryContext` 继续对话。

**风险评级**：**高**
- 数据库失败会导致整轮对话失败，而非优雅降级到无记忆模式。
- 嵌入降级路径完善，但底层存储缺乏隔离。

---

## 4. 工具失败时的降级

### 4.1 工具执行层的统一错误封装

**文件**：`tools/traits.py`，行 6-17

```python
@dataclass
class ToolResult:
    success: bool
    output: str

    @staticmethod
    def ok(output: str) -> "ToolResult":
        return ToolResult(success=True, output=output)

    @staticmethod
    def fail(error: str) -> "ToolResult":
        return ToolResult(success=False, output=error)
```

**分析**：所有工具统一返回 `ToolResult`，包含 `success` 标志和 `output` 字符串。这确保了工具内部错误不会向上抛出异常，而是以结构化结果返回。这是优秀的降级基础设计。

### 4.2 工具注册表的安全查询

**文件**：`tools/traits.py`，行 59-60

```python
def get(self, name: str) -> Optional[Tool]:
    return self._tools.get(name)
```

**分析**：`ToolRegistry.get()` 对未知工具返回 `None`。`execute_tool_calls()`（`core/dispatcher.py`，行 118-125）会将其标记为失败：

```python
tool = tool_registry.get(name)
if tool is None:
    logger.warning(f"Unknown tool: {name}")
    results.append({
        "name": name,
        "success": False,
        "output": f"未知工具: {name}",
    })
    continue
```

**风险评级**：**低**
- 未知工具被安全拒绝，不会导致崩溃。

### 4.3 单个工具执行异常捕获

**文件**：`core/dispatcher.py`，行 128-146

```python
try:
    import inspect
    if inspect.iscoroutinefunction(tool.execute):
        result: ToolResult = asyncio.run(tool.execute(args))
    else:
        result: ToolResult = tool.execute(args)
    results.append({"name": name, "success": result.success, "output": result.output})
except Exception as e:
    logger.error(f"Tool {name} execution error: {e}")
    results.append({"name": name, "success": False, "output": str(e)})
```

**分析**：每个工具的执行都被 try-except 包裹，即使工具内部抛出未预料的异常，也不会中断其他工具的执行。这是正确的降级行为。

### 4.4 Agent 2 的多轮重试与重新决策

**文件**：`core/tool_agent.py`，行 142-224

`ToolAgent.run_with_request()` 实现了单轮内最多 3 次重试（max_retries=3）。如果全部失败，`last_failure` 被记录并返回。

**文件**：`core/message_handler.py`，行 98-141

```python
while round_num < MAX_AGENT2_ROUNDS and drive_result.needs_external_tools:
    ...
    tracker = ToolAttemptTracker()
    tool_result = self._tool_agent.run_with_request(request_text)
    tracker.total_attempts += 1
    track_failures(tracker, tool_result)

    # In-round retries on failure
    while tracker.can_retry_in_round and not tool_result.any_success:
        tracker.retry_count += 1
        ...
        tool_result = self._tool_agent.run_with_request(request_text)

    if tool_result and not tool_result.any_success:
        # All retries failed -- Agent 1 re-decide
        if tracker.can_start_new_round:
            logger.info(f"[msg] agent1: re-decide after failures")
            drive_result = self._inner_drive.re_decide(user_input, tracker.failure_log)
        else:
            break
```

**分析**：这是项目中最完善的降级机制之一：
- **单轮重试**：Agent 2 内部 3 次重试。
- **跨轮重新决策**：Agent 1 在工具全部失败后，可以重新决策（换工具、换策略或放弃）。
- **Tracker 限制**：最多 3 轮 × 3 次重试 = 9 次尝试（`ToolAttemptTracker`，`core/tool_agent.py`，行 48-66）。

**风险点**：
- `re_decide()` 本身也依赖 LLM API。如果 API 本身不稳定，`re_decide()` 也可能失败，但 `InnerDriveAgent.re_decide()`（`core/inner_drive.py`，行 217-264）没有 try-except 包裹 `provider.generate()` 调用。如果 API 在此时抛出 `ConnectionError`，异常会向上传播。
- `ToolAttemptTracker` 的 `can_start_new_round` 检查 `total_attempts < 9`，但 `round_number` 只在 `MessageHandler` 中递增，Tracker 本身不跟踪轮次。实际上 `can_start_new_round` 的逻辑是 `round_number < 3 and total_attempts < 9`，但 `round_number` 初始为 0 且从未在 `MessageHandler` 中被更新到 Tracker 上。查看 `MessageHandler` 代码，Tracker 是每次循环新创建的，`round_number` 始终为 0，所以 `can_start_new_round` 实际上只检查 `total_attempts < 9`。但由于 Tracker 在每次循环中重新创建，`total_attempts` 也始终为 1 或 2（重试次数）。**这意味着 `can_start_new_round` 永远为 True**，Agent 1 的 re-decide 会在每次失败后被调用，直到 `MAX_AGENT2_ROUNDS`（3）耗尽。

这实际上是正确的行为（由外层 `round_num` 控制），但 Tracker 的内部状态与外层循环不一致，属于**设计上的语义混淆**。

### 4.5 具体工具的降级行为

#### 4.5.1 Web 工具

**文件**：`tools/web_tools.py`，行 81-97、121-143

```python
def execute(self, args: dict[str, Any]) -> ToolResult:
    ...
    try:
        result = _anysearch_api("search", arguments)
        ...
    except Exception as e:
        logger.warning(f"Web search failed: {e}")
        return ToolResult.fail(f"搜索失败: {e}")
```

**分析**：Web 搜索和网页获取工具在 AnySearch API 失败时返回 `ToolResult.fail()`，错误信息包含原始异常。Agent 2 会将此失败信息返回给 Agent 1/3，LLM 可以在回复中告知用户"搜索失败了"。这是合理的降级。

**风险**：`_anysearch_api()`（行 16-35）使用 `requests.Session()` 但没有复用 session（每次调用新建），且**没有重试机制**。AnySearch 作为外部服务，网络抖动可能导致单次失败。建议增加重试。

#### 4.5.2 文件工具

**文件**：`tools/file_tools.py`

`ReadFileTool` 对多种错误情况返回友好的 `ToolResult.fail()`：
- 路径超出允许范围（行 102）
- 文件不存在（行 105）
- 无权限（行 112、148）
- 文件过大（行 139）
- 二进制文件（行 142）
- 读取失败（行 150）

**分析**：文件工具的错误处理非常完善，每种边界情况都有明确的错误消息。但 `_get_allowed_roots()`（行 31-48）在 `config.json` 解析失败时回退到项目目录，这是正确的降级。

#### 4.5.3 记忆工具

**文件**：`tools/memory_tools.py`

`RecallTool` 和 `RememberTool` 在数据库操作失败时，异常会向上传播（因为 `ltm.search_facts()` 等使用 `_run_sync()`，异常直接抛出）。但 `execute()` 方法本身没有 try-except 包裹。如果 SQLite 锁定或损坏，记忆工具会导致整个 Agent 2 执行失败。

**风险评级**：**中**
- 工具执行层有统一异常捕获，但记忆工具的数据库异常可能穿透。
- Web 工具缺少重试。

---

## 5. 情绪系统失败时的降级

### 5.1 情绪分析失败

**文件**：`core/agent.py`，行 183-221

```python
def _process_emotion(self) -> None:
    sentiment, sharing, energy = 0.1, False, 0.5
    last_user_turn = ""
    try:
        all_turns = self.short_term.get_all()
        for t in reversed(all_turns):
            if t.role == "user":
                last_user_turn = t.content
                break
        sentiment, sharing, energy = self.consolidator.analyze_sentiment(last_user_turn)
    except (json.JSONDecodeError, ValueError, KeyError) as e:
        logger.warning(f"Sentiment analysis parse error: {e}")

    if sentiment < -0.5:
        self._consecutive_negative += 1
    ...
```

**分析**：`_process_emotion()` 对情绪分析的解析错误有捕获，使用默认值 `sentiment=0.1, sharing=False, energy=0.5` 继续执行。这是正确的降级：情绪分析失败不会中断对话流程，只是情绪更新可能不准确。

**风险点**：
- `self.consolidator.analyze_sentiment()`（`memory/consolidation.py`，行 83-96）内部也有 try-except，返回 `(0.0, False, 0.5)`。双重保护是合理的。
- 但如果 `analyze_sentiment()` 本身抛出非解析类异常（如 `ConnectionError` 因为 LLM API 失败），`Agent._process_emotion()` **没有捕获**。`ConnectionError` 会向上传播。

### 5.2 情绪状态计算的鲁棒性

**文件**：`models/personality.py`，行 72-130

`EmotionalState.dominant_emotion` 属性通过计算多个情绪维度的得分来确定主导情绪。所有计算都是纯数学运算（比较、乘法、取最大值），**不依赖外部 I/O**，因此不会失败。

**文件**：`models/personality.py`，行 175-208

```python
def shift(self, delta_v: float, delta_a: float, primary_deltas: Optional[dict[str, float]] = None) -> None:
    inertia_factor = 1.0 - self.inertia
    delta_v *= inertia_factor
    delta_a *= inertia_factor

    self.valence = max(-1.0, min(1.0, self.valence + delta_v))
    self.arousal = max(0.0, min(1.0, self.arousal + delta_a))
    ...
```

**分析**：`shift()` 和 `decay()` 方法都是纯本地计算，使用 `max/min` 钳制边界值。即使输入异常（如 `NaN`），`max/min` 也能处理（虽然 `NaN` 比较行为特殊）。**没有输入验证**：如果 `delta_v` 是 `NaN` 或 `inf`，情绪状态会被污染并持久化到 `personality.json`。

### 5.3 情绪事件记录

**文件**：`models/personality.py`，行 239-262

```python
def record_emotion_event(self, trigger: str, context: str = "") -> None:
    dom = self.dominant_emotion
    primary_intensity = max(...)
    if primary_intensity < 0.6:
        logger.debug(f"[emotion] event_skip: intensity={primary_intensity:.2f} < 0.6")
        return
    event = {"timestamp": time.time(), ...}
    self.emotion_events.append(event)
    ...
```

**分析**：`record_emotion_event()` 是纯内存操作，不会失败。但 `emotion_events` 列表可能无限增长（虽然代码限制了 20 条）。

### 5.4 人格加载失败

**文件**：`core/personality.py`，行 88-111

```python
@classmethod
def load(cls, path: str) -> "Personality":
    if not os.path.exists(path):
        config = PersonalityConfig()
        return cls(config)
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        logger.warning(f"Failed to load personality from {path}: {e}")
        return cls(PersonalityConfig())
    ...
```

**分析**：人格文件加载失败时，使用默认 `PersonalityConfig()` 创建新的人格。这是正确的降级：即使 `personality.json` 损坏，AI 也能以默认人格启动。

**风险评级**：**低**
- 情绪系统本地计算为主，失败点少。
- 情绪分析有双重保护，但 API 异常可能穿透。

---

## 6. 压缩失败时的降级

### 6.1 压缩的递归保护

**文件**：`core/context_manager.py`，行 62-70

```python
def compress(self, messages: list[dict]) -> None:
    """Public entry point — thin wrapper with recursion guard."""
    if self._compressing:
        return
    self._compressing = True
    try:
        self._do_compress(messages)
    finally:
        self._compressing = False
```

**分析**：`compress()` 有递归守卫 `_compressing`。如果压缩过程中再次触发压缩（如因为 token 估算逻辑问题），会直接返回，避免无限递归。这是正确的保护。

### 6.2 压缩失败的内层捕获

**文件**：`core/context_manager.py`，行 87-98

```python
try:
    result = self._provider.generate(
        [{"role": "user", "content": CONTEXT_COMPRESS_PROMPT.format(conversation=text)}],
        stream=False,
    )
    if result.strip():
        self._compressed_summary = result.strip()
        self._estimated_tokens_used = 0
        self._short_term.clear()
        logger.info(f"Context compressed: {self._compressed_summary[:80]}")
except Exception as e:
    logger.warning(f"Compression failed: {e}")
```

**分析**：压缩失败时，异常被捕获并记录日志，但**没有恢复机制**：
- `self._compressed_summary` 保持旧值（如果有）或空字符串。
- `self._estimated_tokens_used` 不被重置。
- `messages` 列表中的历史消息不会被清除。

**风险**：如果压缩反复失败（如 API 长期不可用），上下文窗口会持续膨胀。`ContextManager` 的 token 估算是基于字符的启发式算法，可能低估实际 token 数。当上下文接近 180K 上限时，API 可能返回 413 Payload Too Large，而系统没有针对此错误的专门处理。

### 6.3 Token 估算的降级

**文件**：`core/context_manager.py`，行 27-35

```python
def estimate_tokens(text: str) -> int:
    tok = _get_tokenizer()
    if tok:
        return len(tok.encode(text, disallowed_special=()))
    cjk = sum(1 for c in text if '一' <= c <= '鿿' or '　' <= c <= '〿')
    ascii_chars = sum(1 for c in text if c.isascii() and c.isalpha())
    digits = sum(1 for c in text if c.isdigit())
    other = len(text) - cjk - ascii_chars - digits
    return max(1, int(cjk / 1.5 + ascii_chars / 4 + digits / 3 + other / 8))
```

**分析**：`tiktoken` 不可用时，使用字符级启发式估算。这是正确的降级。但启发式公式对中文的估算（CJK / 1.5）在 modern tokenizer（如 cl100k_base）中通常偏低（中文约 1-1.5 token/字），可能导致实际 token 数超出阈值后才触发压缩。

**风险评级**：**中**
- 压缩失败不会崩溃，但缺乏恢复和告警。
- Token 估算在 tiktoken 不可用时可能不够准确。

---

## 7. 是否有断路器模式

### 7.1 断路器模式缺失

**结论：项目中完全没有实现断路器（Circuit Breaker）模式。**

审查了以下关键位置：
- `core/provider.py`：有重试，无断路器。
- `memory/embeddings.py`：有健康检查，无断路器。
- `tools/web_tools.py`：无重试，无断路器。
- `core/dispatcher.py`：无断路器。
- `core/tool_agent.py`：有重试计数，无断路器。

**什么是断路器**：当某个外部服务（如 API、嵌入服务、AnySearch）连续失败达到一定阈值时，暂时停止调用该服务，直接走降级路径，避免持续消耗资源并加速响应。

**当前行为 vs 理想行为**：

| 场景 | 当前行为 | 理想行为（断路器） |
|------|---------|------------------|
| 嵌入服务连续 10 次失败 | 每次查询仍尝试 `health_check()` | 5 次失败后标记为 OPEN，直接走关键词检索 |
| API 连续 5 次 500 错误 | 每次请求仍重试 3 次 | 3 次失败后标记为 OPEN，直接返回友好错误 |
| AnySearch 连续失败 | 每次搜索直接失败 | 标记为 OPEN，告知用户"暂时无法搜索" |

**风险评级**：**高**
- 缺乏断路器意味着故障服务会持续被调用，浪费资源、增加延迟、加重故障方负载。

---

## 8. 降级后的用户体验

### 8.1 CLI 路径的用户体验

**文件**：`core/cli_controller.py`，行 81-86

```python
except Exception as e:
    logger.error(f"Error in state {a.state}: {e}", exc_info=True)
    if a.ui:
        a.ui.display.print_error(str(e))
    time.sleep(1)
    a.state = AgentState.IDLE
```

**分析**：CLI 路径的外层异常处理会打印原始错误字符串。对于技术用户可能足够，但对于普通用户：
- 看到 `"API request failed after 3 retries: ..."` 而非"网络有点问题，我稍后再试~"。
- 看到数据库错误时，没有建议用户检查磁盘空间或重启。

**文件**：`core/cli_controller.py`，行 200-205、221-226

API `ConnectionError` 被捕获后，打印 `"网络连接失败：{e}"` 并回到 REFLECT 状态。用户输入的消息**没有被回复**，轮次也没有增加（因为 `_finish_react_response()` 没有被调用）。这意味着用户发送消息后，AI 只是静默失败，没有给出任何回应。

**风险**：用户在 API 失败时完全得不到反馈，体验极差。

### 8.2 Web 路径的用户体验

**文件**：`web/server.py`，行 241-246

```python
except Exception as e:
    logger.error(f"WebSocket error: {e}")
    try:
        await websocket.send_text(json.dumps({"type": "error", "content": str(e)}))
    except (WebSocketDisconnect, ConnectionError, RuntimeError):
        pass
```

**分析**：Web 路径会发送 `{"type": "error", "content": str(e)}` 给前端。但前端（`web/static/index.html`）需要正确处理这种错误消息才能展示给用户。如果前端只处理 `type=segment` 和 `type=done`，错误消息会被忽略。

**文件**：`web/server.py`，行 192-196

```python
except Exception as e:
    logger.warning(f"Proactive error: {e}")
    await asyncio.sleep(30)
```

**分析**：主动行为循环（proactive loop）中的异常被捕获后，只是记录日志并休眠 30 秒。这不会直接影响用户，但如果 proactive loop 频繁崩溃，用户可能永远收不到主动消息。

### 8.3 睡眠状态的用户体验

**文件**：`core/agent.py`，行 68-70

```python
if a._sleeping:
    a.last_activity_time = time.time()
    return random.choice(["zzz...ZZZ...💤", "Zzzz...[翻身]", "zzzz...（小声梦话）", "Zzz...💤"])
```

**分析**：AI 在睡眠状态时，对用户输入返回固定的睡眠表情。这是合理的降级：即使内部系统有问题，睡眠状态提供了一个统一的、可预期的响应模式。

### 8.4 工具失败后的 LLM 回复质量

**文件**：`core/dispatcher.py`，行 153-169

```python
def format_tool_results(results: list[dict]) -> str:
    parts = []
    for r in results:
        tag = "成功" if r["success"] else "失败"
        parts.append(
            f'<tool_result name="{r["name"]}">\n'
            f"工具 {r['name']} 执行{tag}:\n"
            f"{r['output']}\n"
            f"</tool_result>"
        )
    parts.append(
        "=== 铁律 ===\n"
        "以上是工具返回的真实内容。你必须逐字如实汇报，不得编造、不得润色、不得添加原文没有的信息。\n"
        "工具说没找到就说没找到，工具返回什么就说什么。你添加的每一个字都必须是工具确实返回了的。"
    )
    return "\n".join(parts)
```

**分析**：工具失败时，失败信息（如 `"搜索失败: Connection timeout"`）会被注入到 Agent 3 的提示中。LLM 可以基于这些信息告知用户工具失败了。但**提示中没有明确要求 LLM 在工具失败时道歉或解释**，LLM 可能直接说"我搜索了一下，没找到"（实际上搜索失败了），这与事实不符。

**风险评级**：**中**
- CLI 路径 API 失败时完全无响应。
- Web 路径错误消息可能未被前端处理。
- 工具失败后的提示缺乏对 LLM 的明确指引。

---

# 汇总统计

## 风险评级分布

| 风险等级 | 数量 | 涉及模块 |
|---------|------|---------|
| **高** | 4 | API 失败处理、数据库失败传播、断路器缺失、CLI 无响应 |
| **中** | 5 | 嵌入健康检查、Web 工具重试、记忆工具异常、压缩恢复、用户体验 |
| **低** | 2 | 工具注册表安全、情绪系统本地计算 |

## 降级策略覆盖矩阵

| 子系统 | 有降级 | 降级类型 | 有断路器 | 用户体验友好 |
|--------|--------|---------|---------|-------------|
| 嵌入引擎 | 是 | 关键词回退 | 否 | 是（透明） |
| API（Provider） | 部分 | 重试+抛异常 | 否 | 否（CLI 无响应） |
| 记忆检索 | 是 | 关键词回退 | 否 | 是（透明） |
| 工具执行 | 是 | 错误封装+重试 | 否 | 部分 |
| 情绪系统 | 是 | 默认值 | N/A | 是（透明） |
| 上下文压缩 | 部分 | 静默忽略 | N/A | 部分 |
| 数据库 | 否 | 异常穿透 | 否 | 否 |
| 睡眠/梦境 | 是 | 静默忽略 | N/A | 是 |

## 关键缺陷清单

1. **【高】数据库失败导致整轮对话崩溃**（`memory/long_term.py`, `core/agent.py`）
   - `retrieve_for_query()` 和 `ltm.store_fact()` 等没有 try-except，SQLite 异常会中断对话。
   - 建议：在 `Agent.process_message()` 或 `MessageHandler` 层包裹记忆操作，失败时返回空记忆上下文。

2. **【高】API 4xx 错误在 CLI 中未优雅处理**（`core/cli_controller.py`）
   - 只捕获 `ConnectionError`，`HTTPError`（400/401/429）会穿透到外层异常处理。
   - 建议：统一捕获 `requests.exceptions.RequestException`，并给用户友好提示。

3. **【高】CLI 路径 API 失败时完全无响应**（`core/cli_controller.py`）
   - `ConnectionError` 被捕获后回到 REFLECT 状态，不调用 `_finish_react_response()`，用户收不到任何回复。
   - 建议：在捕获异常后，生成一条默认回复（如"网络有点问题，我稍后再试~"）并加入历史。

4. **【高】项目中完全无断路器模式**
   - 建议：为 API、嵌入服务、AnySearch 实现简单的内存断路器（连续失败 N 次后进入 OPEN 状态，持续 M 秒）。

5. **【中】嵌入健康检查无缓存**（`memory/embeddings.py`）
   - 每次查询都执行 HTTP GET。
   - 建议：缓存健康状态 10-30 秒，减少延迟。

6. **【中】Web 工具（AnySearch）无重试**（`tools/web_tools.py`）
   - 建议：增加 2 次重试 + 指数退避。

7. **【中】压缩失败无恢复机制**（`core/context_manager.py`）
   - 建议：压缩失败时，强制截断历史消息（保留最近 N 条）而非什么都不做。

8. **【中】工具失败后的提示缺乏 LLM 指引**（`core/dispatcher.py`）
   - 建议：在 `format_tool_results()` 中增加对失败情况的明确指引，要求 LLM 如实告知用户工具失败。

9. **【低】情绪状态可能被 NaN/inf 污染**（`models/personality.py`）
   - 建议：在 `shift()` 和 `decay()` 中增加 `math.isfinite()` 检查。

10. **【低】流式响应中断无检测**（`core/provider.py`）
    - 建议：在返回前检查响应是否以 `[DONE]` 结束，或增加完整性标记。

---

*本报告由 AI Friend 项目第4轮审查生成，聚焦降级策略。建议优先修复高优先级缺陷（#1-#4），再逐步完善中优先级项。*
