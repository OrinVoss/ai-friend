# 第2轮审查：短期记忆数据流深度审查报告

**审查日期**：2026/05/31  
**审查范围**：`memory/short_term.py`、`models/conversation.py`、`core/agent.py`、`core/message_handler.py`、`web/session.py`、`storage/repository.py`、`memory/consolidation.py`、`core/context_manager.py`  
**审查目标**：跟踪对话轮次从 `add_turn` 到存储、格式化、注入提示词的完整数据流；识别信息丢失、顺序错乱、并发问题；给出风险评级与改进建议。

---

## 一、概述

AI Friend 的短期记忆系统以 `ConversationBuffer` 为核心容器，承载最近对话轮次的临时存储。其数据流贯穿 CLI 和 Web 两条入口，经历 "写入 -> 格式化 -> 注入 -> 压缩 -> 固化到长期记忆" 五个阶段。本次审查发现 **5 个高危缺陷、4 个中危缺陷、3 个低危缺陷**，涉及并发安全、数据一致性、信息丢失、角色标记歧义等多个维度。

核心问题速览：

| 编号 | 问题 | 风险等级 | 位置 |
|------|------|---------|------|
| H1 | `add_turn` 中 `_next_id` 自增与 `deque.append` 不在同一锁区间 | 高危 | `memory/short_term.py:32-34` |
| H2 | Web 端恢复历史时 `turn_id` 与 `_next_id` 不同步，导致 `turn_id` 重复 | 高危 | `web/session.py:36-37` |
| H3 | `_build_messages` 的 `overflow` 截断逻辑破坏对话顺序，且摘要插入位置错误 | 高危 | `core/message_handler.py:274-291` |
| H4 | 压缩后 `short_term.clear()` 与 `turn_count` 不同步，导致 LTM 写入错乱 | 高危 | `core/context_manager.py:95`、`core/agent.py:175-177` |
| H5 | `format_for_prompt` 按字符截断而非按 token，中文场景下严重低估长度 | 高危 | `memory/short_term.py:51-64` |
| M1 | `get_all_reversed` 返回新列表，`_build_messages` 遍历时又做 `insert(1, ...)`，双重拷贝 + O(n^2) | 中危 | `core/message_handler.py:278-283` |
| M2 | 主动回复 (`add_to_history=False`) 不进入短期记忆，但 `turn_count` 仍递增，造成序号空洞 | 中危 | `core/agent.py:119`、`core/message_handler.py:187` |
| M3 | `Repository.get_recent_turns` 按 `id DESC` 取 30 条再 `reverse()`，若 DB 中存在并发写入则顺序不可靠 | 中危 | `storage/repository.py:228-237` |
| M4 | 情绪分析 `_process_emotion` 在 `turn_count % 3 == 0` 时触发 consolidation，但 `add_pending` 只取最后 1 条，可能遗漏上下文 | 中危 | `core/agent.py:216-221` |
| L1 | `Turn.metadata` 字段从未被实际使用，但占用内存和序列化成本 | 低危 | `models/conversation.py:14` |
| L2 | `last_n_turns_content` 属性未被任何代码引用，属于死代码 | 低危 | `memory/short_term.py:78-83` |
| L3 | CLI 模式下无历史恢复机制，Web 端有而 CLI 端无，行为不一致 | 低危 | 全局 |

---

## 二、数据流图

### 2.1 整体数据流架构

```
                    ┌─────────────────────────────────────────────────────────────┐
                    │                        用户输入层                            │
                    │   CLI (main.py) ──────┐   Web (web_main.py → server.py)    │
                    │                       │                                      │
                    └───────────────────────┼──────────────────────────────────────┘
                                            │
                                            ▼
                    ┌─────────────────────────────────────────────────────────────┐
                    │              MessageHandler.handle_message()                 │
                    │                   core/message_handler.py:64                 │
                    │                       │                                      │
                    │    ┌──────────────────┼──────────────────┐                 │
                    │    ▼                  ▼                  ▼                 │
                    │  Agent 1           Agent 2            Agent 3              │
                    │  InnerDrive      ToolAgent          Roleplay/ReAct         │
                    │    │                  │                  │                 │
                    │    │                  │                  │                 │
                    │    └──────────────────┴──────────────────┘                 │
                    │                       │                                      │
                    └───────────────────────┼──────────────────────────────────────┘
                                            │
                                            ▼
                    ┌─────────────────────────────────────────────────────────────┐
                    │              ConversationBuffer.add_turn()                   │
                    │                   memory/short_term.py:23                    │
                    │                       │                                      │
                    │    ┌──────────────────┼──────────────────┐                 │
                    │    ▼                  ▼                  ▼                 │
                    │  _next_id++      deque.append()      返回 Turn             │
                    │  (行32)           (行34)              (行36)               │
                    │                       │                                      │
                    └───────────────────────┼──────────────────────────────────────┘
                                            │
                                            ▼
                    ┌─────────────────────────────────────────────────────────────┐
                    │              短期记忆容器 (deque, maxlen=20/500)              │
                    │              memory/short_term.py:16-21                      │
                    │                       │                                      │
                    │    ┌──────────────────┼──────────────────┐                 │
                    │    ▼                  ▼                  ▼                 │
                    │ get_all()      get_all_reversed()   format_for_prompt()    │
                    │ (行42)             (行46)                (行51)             │
                    │                       │                                      │
                    └───────────────────────┼──────────────────────────────────────┘
                                            │
                                            ▼
                    ┌─────────────────────────────────────────────────────────────┐
                    │              MessageHandler._build_messages()                │
                    │                   core/message_handler.py:274                │
                    │                       │                                      │
                    │    ┌──────────────────┼──────────────────┐                 │
                    │    ▼                  ▼                  ▼                 │
                    │  system prompt    历史轮次 insert(1)    user_input          │
                    │  (行276)          (行278-283)           (行290)            │
                    │                       │                                      │
                    │              overflow 检测 (行280-282)                       │
                    │              压缩触发 → ContextManager.compress()            │
                    │                       │                                      │
                    └───────────────────────┼──────────────────────────────────────┘
                                            │
                                            ▼
                    ┌─────────────────────────────────────────────────────────────┐
                    │              LLM Provider.generate()                         │
                    │                   core/provider.py                           │
                    │                       │                                      │
                    └───────────────────────┼──────────────────────────────────────┘
                                            │
                                            ▼
                    ┌─────────────────────────────────────────────────────────────┐
                    │              Agent._react_loop() 输出响应                    │
                    │                   core/agent.py:119                          │
                    │                       │                                      │
                    │    ┌──────────────────┼──────────────────┐                 │
                    │    ▼                  ▼                  ▼                 │
                    │ short_term.add_   ltm.insert_        _process_emotion()    │
                    │ turn("assistant")  turn_sync()       (行183)              │
                    │ (行174)            (行175)                                   │
                    │                       │                                      │
                    │              turn_count += 1 (行177)                         │
                    │                       │                                      │
                    └───────────────────────┼──────────────────────────────────────┘
                                            │
                                            ▼
                    ┌─────────────────────────────────────────────────────────────┐
                    │              MemoryConsolidator.consolidate()                │
                    │                   memory/consolidation.py:47                 │
                    │              (每 3 轮触发，或情绪强度 > 0.7)                  │
                    │                       │                                      │
                    │    ┌──────────────────┼──────────────────┐                 │
                    │    ▼                  ▼                  ▼                 │
                    │  extract_facts   summarize_exp      generate_reflection    │
                    │  update_relationship    prune()                              │
                    │                       │                                      │
                    └───────────────────────┼──────────────────────────────────────┘
                                            │
                                            ▼
                    ┌─────────────────────────────────────────────────────────────┐
                    │              长期记忆 SQLite (LTM)                            │
                    │              storage/repository.py                           │
                    └─────────────────────────────────────────────────────────────┘
```

### 2.2 Web 端历史恢复数据流

```
    WebSocket 连接建立
            │
            ▼
    session_manager.get_or_create(sid)
            │
            ▼
    ┌─────────────────────────────┐
    │   WebAgent.__init__()       │
    │   web/session.py:28         │
    │                             │
    │  1. 创建 ConversationBuffer │
    │     maxlen=config.short_    │
    │     term_capacity (500)     │
    │                             │
    │  2. repo.get_recent_turns_  │
    │     sync(30)                │
    │     → 按 id DESC 取 30 条   │
    │     → reverse() 恢复时序    │
    │                             │
    │  3. 逐条 add_turn(role,     │
    │     content)                │
    │     → _next_id 从 0 开始    │
    │     → turn_id 被重新分配    │
    │     → 原始 turn_number 丢失 │
    │                             │
    │  4. Agent.turn_count = 0    │
    │     (默认值，未恢复)        │
    └─────────────────────────────┘
            │
            ▼
    用户发送第一条消息
            │
            ▼
    handle_message() 调用
    turn_count 从 0 开始计数
    与 DB 中已有的 turn_number 冲突
```

### 2.3 `format_for_prompt` 截断逻辑数据流

```
    format_for_prompt(max_chars=3000)
            │
            ▼
    ┌─────────────────────────────┐
    │  1. 加锁进入临界区          │
    │     with self._lock:        │
    │                             │
    │  2. 逆序遍历 deque          │
    │     for t in reversed(      │
    │         self._turns):        │
    │     → 从最新到最旧          │
    │                             │
    │  3. 角色标签映射            │
    │     assistant → "你"        │
    │     user      → "用户"      │
    │                             │
    │  4. 累加字符长度            │
    │     total += len(line)      │
    │     (注意：是字符数，不是   │
    │      token 数！)            │
    │                             │
    │  5. 超限截断                │
    │     if total > max_chars:   │
    │         lines.append(       │
    │             "...[省略更早   │
    │              对话]")        │
    │         break               │
    │                             │
    │  6. 逆序恢复                │
    │     lines.reverse()         │
    │     → 最旧的在最前          │
    │                             │
    │  7. 返回 "\n".join(lines)   │
    └─────────────────────────────┘
```

### 2.4 `_build_messages` 构建数据流

```
    _build_messages(sys_prompt, user_input)
            │
            ▼
    ┌─────────────────────────────┐
    │  1. 初始化消息列表          │
    │     messages = [            │
    │       {"role":"system",     │
    │        "content":sys_prompt}│
    │     ]                       │
    │                             │
    │  2. 逆序遍历短期记忆        │
    │     for t in get_all_       │
    │         reversed():          │
    │     → 最新轮次先处理        │
    │                             │
    │  3. 角色映射                │
    │     "assistant" → "assistant"│
    │     其他      → "user"      │
    │     (注意：非 "assistant"   │
    │      一律视为 user！)       │
    │                             │
    │  4. Token 溢出检测          │
    │     估算最近 5 条消息       │
    │     + 当前轮次的 token 数   │
    │     > COMPRESS_THRESHOLD    │
    │     (180000 * 0.8 = 144000) │
    │                             │
    │  5. 溢出处理                │
    │     if overflow:            │
    │         break               │
    │     else:                   │
    │         messages.insert(    │
    │             1, turn_msg)    │
    │     → insert(1) 导致        │
    │       O(n^2) 时间复杂度     │
    │                             │
    │  6. 摘要插入 (溢出时)       │
    │     if overflow and         │
    │        compressed_summary:  │
    │         messages.insert(    │
    │             1, summary)     │
    │     → 摘要插在 system 后    │
    │       第一条历史前          │
    │                             │
    │  7. 追加当前用户输入        │
    │     if user_input:          │
    │         再次检查 token 溢出 │
    │         if 溢出:            │
    │             compress()      │
    │         messages.append(    │
    │             user_msg)       │
    └─────────────────────────────┘
```

---

## 三、详细发现

### H1: `add_turn` 中 `_next_id` 自增与 `deque.append` 不在同一原子操作内

**位置**：`memory/short_term.py:23-36`

```python
    def add_turn(self, role: str, content: str,
                 metadata: Optional[dict] = None) -> Turn:
        turn = Turn(
            turn_id=self._next_id,      # ← 读取 _next_id (无锁)
            role=role,
            content=content,
            timestamp=datetime.now(),
            metadata=metadata or {},
        )
        with self._lock:
            self._next_id += 1          # ← 锁内自增
            self._turns.append(turn)    # ← 锁内追加
```

**问题分析**：

1. `Turn` 对象在锁外构造，`turn_id` 读取的是锁外状态的 `_next_id`。
2. 虽然 Python GIL 保证了单个字节码操作的原子性，但 `Turn(...)` 构造涉及多条字节码。在极端并发场景（如 Web 端多个 WebSocket 同时写入同一 session，或 proactive loop 与用户消息竞争），两个线程可能同时读取相同的 `_next_id` 值，导致生成两个相同 `turn_id` 的 `Turn` 对象。
3. 更关键的是，如果 `_next_id` 在锁外被读取后、进入锁前，另一个线程已经完成了 `+=1`，那么当前线程构造的 `Turn` 将使用一个"过期"的 ID。

**风险场景**：
- Web 端同一 session 的 proactive loop 和 user message 同时触发
- `_next_id` 重复导致 `MemoryConsolidator._format_turns` 中的 `start_id`/`end_id` 计算错误
- 长期记忆中 `source_turn` 字段失去唯一标识能力

**修复建议**：

```python
    def add_turn(self, role: str, content: str,
                 metadata: Optional[dict] = None) -> Turn:
        with self._lock:
            turn_id = self._next_id
            self._next_id += 1
            turn = Turn(
                turn_id=turn_id,
                role=role,
                content=content,
                timestamp=datetime.now(),
                metadata=metadata or {},
            )
            self._turns.append(turn)
            return turn
```

---

### H2: Web 端恢复历史时 `turn_id` 与 `_next_id` 不同步，且 `Agent.turn_count` 未恢复

**位置**：`web/session.py:28-38`

```python
    def __init__(self, config: Config, db: Database, repo: Repository):
        # ...
        self.short_term = ConversationBuffer(maxlen=config.short_term_capacity)
        # Restore recent conversation from DB (fixes #98)
        for t in repo.get_recent_turns_sync(30):
            self.short_term.add_turn(t["role"], t["content"])
        # ...
        self.agent = Agent(
            personality=self.personality, provider=self.provider,
            ltm=self.ltm, retriever=self.retriever,
            consolidator=self.consolidator, short_term=self.short_term,
            config=config,
        )
```

**问题分析**：

1. `get_recent_turns_sync(30)` 从 `conversation_turns` 表按 `id DESC LIMIT 30` 取出最近 30 条记录，然后 `reverse()` 恢复时间顺序。但 `id` 是自增主键，在以下场景下不能可靠反映时间顺序：
   - 数据库被手动编辑或迁移
   - 并发写入导致 `id` 分配不连续（虽然 SQLite 单连接下不会）
   - 如果未来支持多用户/多会话，`id` 全局递增，跨会话顺序混乱

2. **更严重的**：恢复时只恢复了 `role` 和 `content`，丢失了：
   - `turn_number`：DB 中存储的原始轮次编号
   - `emotional_state`：当时的情绪状态
   - `timestamp`：原始时间戳
   - `metadata`：元数据

3. **最严重**：`Agent.turn_count` 初始化为 `0`（`core/agent.py:52`），未从 DB 恢复。这意味着：
   - 新写入 DB 的 `turn_number` 从 0 开始，与已有记录冲突
   - `turn_count % 3 == 0` 的 consolidation 触发逻辑被重置
   - 长期记忆中的 `source_turn` 字段与实际轮次脱节

4. `ConversationBuffer._next_id` 从 0 开始重新分配 `turn_id`，与 DB 中的历史 `turn_number` 无关。如果 DB 中已有 100 条记录，新恢复的 `turn_id` 从 0 开始， consolidation 中的 `start_id`/`end_id` 将指向错误的历史记录。

**风险评级**：高危。数据一致性问题会在运行一段时间后暴露，难以调试。

**修复建议**：

```python
    # 在 WebAgent.__init__ 中恢复时
    recent_turns = repo.get_recent_turns_sync(30)
    max_turn_number = 0
    for t in recent_turns:
        self.short_term.add_turn(t["role"], t["content"])
        max_turn_number = max(max_turn_number, t.get("turn_number", 0))
    
    # 恢复 Agent 的 turn_count
    self.agent.turn_count = max_turn_number + 1
    
    # 同步 _next_id 避免重复
    self.short_term._next_id = max(t["turn_number"] for t in recent_turns) + 1 if recent_turns else 0
```

同时修改 `Repository.get_recent_turns` 返回 `turn_number` 字段：

```python
    return [{"role": r[0], "content": r[1], "turn_number": r[2]} 
            for r in rows]  # 需要修改 SQL 和 row 访问方式
```

---

### H3: `_build_messages` 的 `overflow` 截断逻辑破坏对话顺序，且摘要插入位置错误

**位置**：`core/message_handler.py:274-291`

```python
    def _build_messages(self, sys_prompt: str, user_input: str | None) -> list[dict]:
        a = self.a
        messages = [{"role": "system", "content": sys_prompt}]
        overflow = False
        for t in a.short_term.get_all_reversed():
            role = "assistant" if t.role == "assistant" else "user"
            if estimate_tokens(" ".join(m["content"][:200] for m in messages[-5:] if m["role"] != "system")) + estimate_tokens(t.content) > COMPRESS_THRESHOLD:
                overflow = True
                break
            messages.insert(1, {"role": role, "content": t.content})
        if overflow and a._context.compressed_summary:
            messages.insert(1, {"role": "system", "content": f"[对话历史摘要] {a._context.compressed_summary}"})
        if user_input:
            msg_tokens = sum(estimate_tokens(m["content"][:500]) for m in messages if m["role"] != "system")
            if msg_tokens + estimate_tokens(user_input) > COMPRESS_THRESHOLD:
                a._context.compress(messages)
            messages.append({"role": "user", "content": user_input})
        return messages
```

**问题分析**：

1. **遍历顺序与截断逻辑的矛盾**：
   - `get_all_reversed()` 返回 "最新在前" 的列表
   - 循环从最新轮次开始处理，用 `messages.insert(1, ...)` 将每条消息插入到 `system` 之后
   - 当检测到溢出时 `break`，这意味着**被保留的是较新的轮次，被截断的是较旧的轮次**
   - 但随后 `overflow and compressed_summary` 时，摘要是插入到 `system` 之后、所有保留的历史之前
   - 结果是：LLM 看到的顺序是 `[system, 摘要, 较新历史..., user_input]`，**完全没有较旧历史**
   - 这在对话中会造成严重的上下文断裂：用户可能正在追问 5 轮前的话题，但模型看不到那部分内容

2. **Token 估算的缺陷**：
   - `messages[-5:]` 只估算最近 5 条已插入消息的 token，而不是全部消息的 token
   - 这导致随着循环继续，已插入的早期消息（在列表靠后位置）的 token 被忽略
   - 实际总 token 数可能早已超过阈值，但检测不到
   - `COMPRESS_THRESHOLD = 144000`，对于正常对话几乎不可能触发，所以这个 bug 在常规使用中被隐藏

3. **`insert(1, ...)` 的 O(n^2) 复杂度**：
   - 每次 `insert(1)` 都需要将 `messages[1:]` 整体后移
   - 对于 maxlen=500 的短期记忆，最坏情况下需要 500 次移位操作
   - 虽然 Python list 的 `insert` 是 C 实现，但这不是良好实践

4. **摘要作为 `system` 角色的问题**：
   - 摘要以 `{"role": "system", "content": "[对话历史摘要] ..."}` 的形式插入
   - 某些模型（如 DeepSeek）对多个 system message 的处理策略不明确
   - 摘要内容可能被模型忽略或权重降低

**风险评级**：高危。虽然 `COMPRESS_THRESHOLD` 很大导致 bug 很少触发，但一旦触发会造成严重的上下文丢失。

**修复建议**：

```python
    def _build_messages(self, sys_prompt: str, user_input: str | None) -> list[dict]:
        a = self.a
        messages = [{"role": "system", "content": sys_prompt}]
        
        # 1. 获取全部历史（正序：最旧在前）
        all_turns = a.short_term.get_all()
        
        # 2. 计算需要截断的位置（从后往前累加 token，保留最近的）
        total_tokens = estimate_tokens(sys_prompt)
        keep_count = 0
        for t in reversed(all_turns):
            tok = estimate_tokens(t.content)
            if total_tokens + tok > COMPRESS_THRESHOLD:
                break
            total_tokens += tok
            keep_count += 1
        
        # 3. 如果发生了截断，插入摘要
        if keep_count < len(all_turns) and a._context.compressed_summary:
            messages.append({
                "role": "system", 
                "content": f"[对话历史摘要] {a._context.compressed_summary}"
            })
        
        # 4. 追加保留的历史（正序）
        kept_turns = all_turns[-keep_count:] if keep_count > 0 else []
        for t in kept_turns:
            role = "assistant" if t.role == "assistant" else "user"
            messages.append({"role": role, "content": t.content})
        
        # 5. 追加当前输入
        if user_input:
            if total_tokens + estimate_tokens(user_input) > COMPRESS_THRESHOLD:
                a._context.compress(messages)
            messages.append({"role": "user", "content": user_input})
        
        return messages
```

---

### H4: 压缩后 `short_term.clear()` 与 `turn_count` 不同步，导致 LTM 写入错乱

**位置**：`core/context_manager.py:62-98`、`core/agent.py:175-177`

```python
# context_manager.py:95
    self._short_term.clear()

# agent.py:175-177
    self.ltm.repo.insert_turn_sync(self.turn_count, "assistant", final_text,
                              str(self.personality.emotion.to_dict()))
    self.turn_count += 1
```

**问题分析**：

1. `ContextManager.compress()` 被调用时（`core/context_manager.py:62`），会：
   - 将当前 `messages` 中的内容压缩为摘要
   - 调用 `self._short_term.clear()` 清空短期记忆
   - 重置 `_estimated_tokens_used = 0`

2. 但 `Agent.turn_count` **不会被重置**。压缩后继续对话，`turn_count` 继续递增。

3. 这导致以下数据不一致：
   - `short_term` 为空，但 `turn_count` 可能是 1000+
   - 新写入 DB 的 `turn_number` 从 1000+ 开始，而 `short_term` 中没有任何对应记录
   - consolidation 触发时（`turn_count % 3 == 0`），`self.short_term.get_all()[-1]` 可能为空或只有最新几条
   - `MemoryConsolidator._format_turns` 中的 `start_id`/`end_id` 基于 `turn_id`，与 DB 中的 `turn_number` 不再对齐

4. 更严重的是，如果压缩发生在 `_build_messages` 中（行289），此时 `messages` 列表中包含了 `user_input` 但尚未调用 `_react_loop`。`_react_loop` 输出后调用 `add_turn("assistant", ...)`，但此时短期记忆已被清空，只有这一条 assistant 消息。下一次用户输入时，`_build_messages` 看到的短期记忆只有上一条 assistant，没有对应的 user，造成角色交替断裂。

**风险评级**：高危。压缩是低频操作但影响深远，一旦触发会造成长期的数据不一致。

**修复建议**：

方案 A（推荐）：压缩时不清空短期记忆，而是保留最近 N 条（如保留最近 5 轮）。

```python
    def _do_compress(self, messages: list[dict]) -> None:
        # ... 生成摘要 ...
        if result.strip():
            self._compressed_summary = result.strip()
            self._estimated_tokens_used = 0
            # 只保留最近 5 条，而不是全部清空
            recent = self._short_term.get_recent(5)
            self._short_term.clear()
            for t in recent:
                self._short_term.add_turn(t.role, t.content, t.metadata)
            logger.info(f"Context compressed: {self._compressed_summary[:80]}")
```

方案 B：如果必须清空，则记录压缩时的 `turn_count`，并在后续逻辑中跳过被压缩区间的 consolidation。

---

### H5: `format_for_prompt` 按字符截断而非按 token，中文场景下严重低估长度

**位置**：`memory/short_term.py:51-64`

```python
    def format_for_prompt(self, max_chars: int = 3000) -> str:
        with self._lock:
            lines = []
            total = 0
            for t in reversed(self._turns):
                label = "你" if t.role == "assistant" else "用户"
                line = f"{label}: {t.content}"
                total += len(line)          # ← 字符数，不是 token 数
                if total > max_chars:
                    lines.append("...[省略更早对话]")
                    break
                lines.append(line)
            lines.reverse()
        return "\n".join(lines)
```

**问题分析**：

1. `format_for_prompt` 被 `MessageHandler.handle_proactive`（行172）和 `handle_explore`（行203）调用，用于构建系统提示中的 `conversation_history` 字段。

2. 截断依据是 `len(line)`（Python 字符数），而非 token 数。对于中文：
   - 1 个汉字 ≈ 1.5 个 token（tiktoken 估算）
   - 1 个英文字母 ≈ 0.25 个 token
   - `max_chars=3000` 的中文字符串实际可能达到 4500+ token

3. 虽然 `max_chars=3000` 对当前模型（180K 上下文）来说不算大问题，但这个函数的设计意图是"控制提示词长度"，使用字符数作为度量单位是错误的抽象。

4. 更隐蔽的问题：`format_for_prompt` 返回的字符串被嵌入到 `build_system_prompt` 中，而 `_build_messages` 另有独立的 token 估算逻辑。两个地方使用不同的长度控制策略，容易造成"这边说没超，那边说超了"的混乱。

**风险评级**：高危。虽然当前参数下不会立即触发问题，但属于架构层面的错误抽象，会在模型切换或参数调整时暴露。

**修复建议**：

```python
    def format_for_prompt(self, max_tokens: int = 2000) -> str:
        from core.context_manager import estimate_tokens
        with self._lock:
            lines = []
            total_tokens = 0
            for t in reversed(self._turns):
                label = "你" if t.role == "assistant" else "用户"
                line = f"{label}: {t.content}"
                tok = estimate_tokens(line)
                if total_tokens + tok > max_tokens:
                    lines.append("...[省略更早对话]")
                    break
                total_tokens += tok
                lines.append(line)
            lines.reverse()
        return "\n".join(lines)
```

同时修改调用方：

```python
# core/message_handler.py:172
    conv_hist = a.short_term.format_for_prompt(max_tokens=2000)
```

---

### M1: `get_all_reversed` 返回新列表，`_build_messages` 遍历时又做 `insert(1, ...)`，双重拷贝 + O(n^2)

**位置**：`core/message_handler.py:278-283`

```python
        for t in a.short_term.get_all_reversed():
            role = "assistant" if t.role == "assistant" else "user"
            if estimate_tokens(...) + estimate_tokens(t.content) > COMPRESS_THRESHOLD:
                overflow = True
                break
            messages.insert(1, {"role": role, "content": t.content})
```

**问题分析**：

1. `get_all_reversed()`（`memory/short_term.py:46-49`）在锁内执行 `list(reversed(self._turns))`，创建了一个全新的列表。
2. `_build_messages` 遍历这个新列表，对每个元素执行 `messages.insert(1, ...)`。
3. `list.insert(1, x)` 需要将索引 1 及之后的所有元素后移一位。对于 N 条历史消息，总时间复杂度为 O(N^2)。
4. 虽然 Python list 的 insert 是 C 实现，对于 maxlen=500 的性能影响可忽略，但这是不必要的开销。
5. 更关键的是，`get_all_reversed()` 的文档字符串说 "without extra copy"，但实际上 `list(reversed(deque))` 确实创建了新列表。文档与实现不符。

**风险评级**：中危。性能问题在 maxlen=500 时不严重，但文档误导和代码异味需要修复。

**修复建议**：

```python
    # memory/short_term.py
    def get_all_reversed(self) -> list[Turn]:
        """Return turns in reverse order (newest first). Creates a copy."""
        with self._lock:
            return list(reversed(self._turns))
```

在 `_build_messages` 中改用 `extend` 避免 O(n^2)：

```python
    # 先收集历史消息
    history = []
    for t in a.short_term.get_all_reversed():
        # ... 溢出检测 ...
        history.append({"role": role, "content": t.content})
    
    # 一次性追加（正序）
    messages.extend(reversed(history))
```

---

### M2: 主动回复 (`add_to_history=False`) 不进入短期记忆，但 `turn_count` 仍递增，造成序号空洞

**位置**：`core/agent.py:119`、`core/message_handler.py:187`

```python
# agent.py:119
    def _react_loop(self, messages: list[dict], on_token=None, add_to_history: bool = True,
                    tool_registry=None, skip_post_process: bool = False) -> str:
        # ...
        if final_text:
            if add_to_history:
                self.short_term.add_turn("assistant", final_text)
            self.ltm.repo.insert_turn_sync(self.turn_count, "assistant", final_text,
                                      str(self.personality.emotion.to_dict()))
            self.turn_count += 1

# message_handler.py:187
        return a._react_loop(messages, on_token, add_to_history=False)
```

**问题分析**：

1. `handle_proactive`（行187）调用 `_react_loop` 时传入 `add_to_history=False`，这意味着主动回复不会进入 `short_term`。
2. 但 `_react_loop` 仍然执行 `ltm.repo.insert_turn_sync(...)` 和 `turn_count += 1`。
3. 这造成以下不一致：
   - DB 中有一条 assistant 记录，但 `short_term` 中没有
   - `turn_count` 递增，但 `short_term` 长度没有增加
   - 下一次 consolidation 时，`self.short_term.get_all()[-1]` 可能不是最新的轮次
   - 用户看到的对话历史（从 `short_term` 渲染）与 DB 中的实际记录不一致

4. 根据 `CLAUDE.md` 中的规则："主动回复不加入短期记忆（`add_to_history=False`）"。这个设计决策本身有其理由（避免主动消息污染用户的对话流），但 `turn_count` 和 `ltm.insert_turn_sync` 的处理没有同步考虑这个决策。

**风险评级**：中危。设计意图与实现之间存在不一致，长期运行会导致 `turn_count` 与 `short_term` 长度严重脱节。

**修复建议**：

方案 A：如果主动回复确实不应该进入短期记忆，那么它也不应该进入 `conversation_turns` 表，或者使用独立的表/字段标识。

方案 B（推荐）：保持当前设计，但添加一个标记字段区分"用户可见轮次"和"系统内部轮次"。

```python
    # 在 Turn 和 DB schema 中添加 is_visible 字段
    self.ltm.repo.insert_turn_sync(
        self.turn_count, "assistant", final_text,
        str(self.personality.emotion.to_dict()),
        is_visible=add_to_history  # 新字段
    )
```

---

### M3: `Repository.get_recent_turns` 按 `id DESC` 取 30 条再 `reverse()`，顺序可靠性问题

**位置**：`storage/repository.py:228-237`

```python
    async def get_recent_turns(self, limit: int = 30) -> list[dict]:
        async with self.db.cursor() as c:
            await c.execute("""
                SELECT role, content FROM conversation_turns
                ORDER BY id DESC LIMIT ?
            """, (limit,))
            rows = await c.fetchall()
        rows = list(rows)
        rows.reverse()
        return [{"role": r[0], "content": r[1]} for r in rows]
```

**问题分析**：

1. 按 `id DESC` 取最近 N 条再 `reverse()`，在单线程 SQLite 场景下可以正确恢复时间顺序。
2. 但如果未来切换到 PostgreSQL/MySQL 或启用 WAL 模式下的并发读取，`id` 的自增行为可能与插入顺序不完全一致（尤其是事务回滚后）。
3. 更合理的做法是直接按 `created_at DESC` 或 `turn_number DESC` 排序，或者使用 `ORDER BY id ASC` 配合子查询：
   
   ```sql
   SELECT role, content FROM conversation_turns
   WHERE id >= (SELECT id FROM conversation_turns ORDER BY id DESC LIMIT 1 OFFSET 29)
   ORDER BY id ASC
   ```

4. 当前实现丢失了 `turn_number`、`emotional_state`、`created_at` 等字段，导致恢复时不完整。

**风险评级**：中危。当前 SQLite 单连接下不会触发，但属于脆弱实现。

**修复建议**：

```python
    async def get_recent_turns(self, limit: int = 30) -> list[dict]:
        async with self.db.cursor() as c:
            await c.execute("""
                SELECT role, content, turn_number, emotional_state, created_at 
                FROM conversation_turns
                ORDER BY turn_number DESC LIMIT ?
            """, (limit,))
            rows = await c.fetchall()
        rows = list(rows)
        rows.reverse()  # 恢复正序
        return [
            {
                "role": r[0], 
                "content": r[1], 
                "turn_number": r[2],
                "emotional_state": r[3],
                "created_at": r[4],
            } 
            for r in rows
        ]
```

---

### M4: 情绪分析 `_process_emotion` 在 `turn_count % 3 == 0` 时触发 consolidation，但 `add_pending` 只取最后 1 条，可能遗漏上下文

**位置**：`core/agent.py:216-221`

```python
        if self.turn_count % 3 == 0:
            self.consolidator.add_pending(self.short_term.get_all()[-1])
            self.consolidator.consolidate(self.short_term, self.personality,
                                          max_facts=self.config.max_facts,
                                          max_experiences=self.config.max_experiences,
                                          max_reflections=self.config.max_reflections)
```

**问题分析**：

1. 每 3 轮触发一次 consolidation，但 `add_pending` 只添加 `short_term.get_all()[-1]`（最后一条）。
2. 这意味着 consolidation 每次只处理 1 条轮次，而不是最近 3 条。
3. 如果这 1 条恰好是 assistant 的回复（在 `_react_loop` 中 `add_turn("assistant", ...)` 之后 `turn_count += 1`），那么 consolidation 分析的是 AI 自己的回复，而不是用户的输入。
4. `_process_emotion` 中的 `last_user_turn` 逻辑（行186-191）正确地遍历寻找最后一条 user 消息，但 consolidation 没有这样做。
5. 更严重的是，如果 `short_term` 因为压缩被清空过（`H4`），`get_all()[-1]` 可能不是当前轮次的真实记录。

**风险评级**：中危。consolidation 的质量取决于输入的完整性，只处理 1 条轮次会严重影响事实提取和体验总结的准确性。

**修复建议**：

```python
        if self.turn_count % 3 == 0:
            # 添加最近 3 条轮次（或自上次 consolidation 以来的所有新轮次）
            recent_turns = self.short_term.get_recent(3)
            for t in recent_turns:
                self.consolidator.add_pending(t)
            self.consolidator.consolidate(self.short_term, self.personality, ...)
```

---

### L1: `Turn.metadata` 字段从未被实际使用

**位置**：`models/conversation.py:8-15`

```python
@dataclass
class Turn:
    turn_id: int
    role: str          # "user" or "assistant"
    content: str
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: dict = field(default_factory=dict)
```

**问题分析**：

1. `metadata` 字段在 `add_turn` 中有传入参数，但代码库中没有任何地方传入非空值。
2. 每个 `Turn` 对象都携带一个空 dict，对于 maxlen=500 的短期记忆，内存开销约为 `500 * dict 开销`。
3. 如果未来需要存储 token 数、模型版本、工具调用记录等信息，`metadata` 是合适的扩展点，但当前属于未使用的预留字段。

**风险评级**：低危。

**修复建议**：保留字段但使用 `__slots__` 或延迟初始化减少内存开销；或明确文档化该字段的用途。

---

### L2: `last_n_turns_content` 属性未被任何代码引用

**位置**：`memory/short_term.py:78-83`

```python
    @property
    def last_n_turns_content(self) -> str:
        with self._lock:
            return "\n".join(
                f"{'用户' if t.role == 'user' else '你'}: {t.content}"
                for t in list(self._turns)[-5:]
            )
```

**问题分析**：

1. 全局搜索确认没有任何代码引用 `last_n_turns_content`。
2. 该属性的功能与 `format_for_prompt` 高度重叠（后者更灵活，支持 max_chars 参数）。
3. 死代码增加维护负担。

**风险评级**：低危。

**修复建议**：删除该属性，或将其改为 `format_for_prompt` 的别名。

---

### L3: CLI 模式下无历史恢复机制，Web 端有而 CLI 端无，行为不一致

**位置**：全局

**问题分析**：

1. Web 端在 `WebAgent.__init__` 中调用 `repo.get_recent_turns_sync(30)` 恢复历史。
2. CLI 端在 `main.py` 中创建 `Agent` 时，没有类似的恢复逻辑。
3. 这意味着同一用户切换使用 CLI 和 Web 时，会体验到完全不同的对话连续性。
4. 根据 `CLAUDE.md`，CLI 和 Web 共享核心逻辑，但入口层的差异导致了行为分歧。

**风险评级**：低危。属于产品体验问题，不是技术缺陷。

**修复建议**：在 CLI 入口 `main.py` 中添加可选的历史恢复逻辑，或提取为共享的初始化函数。

---

## 四、汇总统计

### 4.1 问题分布

| 风险等级 | 数量 | 编号 |
|---------|------|------|
| 高危 (H) | 5 | H1, H2, H3, H4, H5 |
| 中危 (M) | 4 | M1, M2, M3, M4 |
| 低危 (L) | 3 | L1, L2, L3 |
| **合计** | **12** | |

### 4.2 按文件分布

| 文件 | 问题数量 | 涉及问题 |
|------|---------|---------|
| `memory/short_term.py` | 4 | H1, H5, M1, L2 |
| `core/message_handler.py` | 3 | H3, M1, M2 |
| `web/session.py` | 1 | H2 |
| `core/context_manager.py` | 1 | H4 |
| `core/agent.py` | 2 | H4, M2, M4 |
| `storage/repository.py` | 1 | M3 |
| `models/conversation.py` | 1 | L1 |
| `main.py` (CLI) | 1 | L3 |

### 4.3 按类别分布

| 类别 | 数量 | 问题 |
|------|------|------|
| 并发安全 | 2 | H1, M3 |
| 数据一致性 | 4 | H2, H4, M2, M4 |
| 顺序/截断逻辑 | 3 | H3, H5, M1 |
| 性能/复杂度 | 1 | M1 |
| 死代码/冗余 | 2 | L1, L2 |
| 产品一致性 | 1 | L3 |

### 4.4 修复优先级建议

| 优先级 | 问题 | 理由 |
|--------|------|------|
| P0 | H1 | 并发安全基础问题，修复成本低 |
| P0 | H2 | Web 端数据恢复的核心缺陷 |
| P1 | H3 | 上下文截断逻辑错误，影响模型理解 |
| P1 | H4 | 压缩与计数器不同步，长期数据污染 |
| P1 | H5 | 长度估算错误，模型切换时暴露 |
| P2 | M2 | 主动回复与短期记忆脱节 |
| P2 | M4 | consolidation 输入不完整 |
| P2 | M3 | 恢复查询的健壮性 |
| P3 | M1 | 性能优化 |
| P3 | L1-L3 | 代码清理和一致性 |

---

## 五、附录：关键代码引用

### A1. `memory/short_term.py` 完整代码

```python
import logging
import threading
from dataclasses import dataclass, field
from datetime import datetime
from collections import deque
from typing import Optional

from models.conversation import Turn

logger = logging.getLogger(__name__)


@dataclass
class ConversationBuffer:
    maxlen: int = 20
    _turns: deque = field(default_factory=lambda: deque())
    _next_id: int = 0
    _lock: threading.Lock = field(default_factory=threading.Lock)

    def __post_init__(self):
        self._turns = deque(maxlen=self.maxlen)

    def add_turn(self, role: str, content: str,
                 metadata: Optional[dict] = None) -> Turn:
        turn = Turn(
            turn_id=self._next_id,
            role=role,
            content=content,
            timestamp=datetime.now(),
            metadata=metadata or {},
        )
        with self._lock:
            self._next_id += 1
            self._turns.append(turn)
        logger.debug(f"[mem] short_term add: role={role} len={len(content)} total={len(self._turns)}")
        return turn

    def get_recent(self, k: int) -> list[Turn]:
        with self._lock:
            return list(self._turns)[-k:]

    def get_all(self) -> list[Turn]:
        with self._lock:
            return list(self._turns)

    def get_all_reversed(self) -> list[Turn]:
        """Return turns in reverse order (newest first) without extra copy."""
        with self._lock:
            return list(reversed(self._turns))

    def format_for_prompt(self, max_chars: int = 3000) -> str:
        with self._lock:
            lines = []
            total = 0
            for t in reversed(self._turns):
                label = "你" if t.role == "assistant" else "用户"
                line = f"{label}: {t.content}"
                total += len(line)
                if total > max_chars:
                    lines.append("...[省略更早对话]")
                    break
                lines.append(line)
            lines.reverse()
        return "\n".join(lines)

    def clear(self) -> None:
        with self._lock:
            n = len(self._turns)
            self._turns.clear()
        logger.info(f"[mem] short_term cleared: was {n} turns")

    @property
    def is_full(self) -> bool:
        with self._lock:
            return len(self._turns) >= self.maxlen

    @property
    def last_n_turns_content(self) -> str:
        with self._lock:
            return "\n".join(
                f"{'用户' if t.role == 'user' else '你'}: {t.content}"
                for t in list(self._turns)[-5:]
            )
```

### A2. `core/message_handler.py` 关键函数

```python
    def _build_messages(self, sys_prompt: str, user_input: str | None) -> list[dict]:
        a = self.a
        messages = [{"role": "system", "content": sys_prompt}]
        overflow = False
        for t in a.short_term.get_all_reversed():
            role = "assistant" if t.role == "assistant" else "user"
            if estimate_tokens(" ".join(m["content"][:200] for m in messages[-5:] if m["role"] != "system")) + estimate_tokens(t.content) > COMPRESS_THRESHOLD:
                overflow = True
                break
            messages.insert(1, {"role": role, "content": t.content})
        if overflow and a._context.compressed_summary:
            messages.insert(1, {"role": "system", "content": f"[对话历史摘要] {a._context.compressed_summary}"})
        if user_input:
            msg_tokens = sum(estimate_tokens(m["content"][:500]) for m in messages if m["role"] != "system")
            if msg_tokens + estimate_tokens(user_input) > COMPRESS_THRESHOLD:
                a._context.compress(messages)
            messages.append({"role": "user", "content": user_input})
        return messages
```

---

*报告完成。建议按 P0 -> P1 -> P2 -> P3 的顺序逐项修复，并在修复后补充单元测试覆盖并发场景和历史恢复场景。*
