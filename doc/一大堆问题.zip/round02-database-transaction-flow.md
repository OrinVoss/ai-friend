# AI Friend 项目 Round 02：数据库存储事务数据流深度审查报告

**审查日期：** 2026/05/31  
**审查范围：** `storage/database.py`、`storage/repository.py`、`memory/consolidation.py`、`core/agent.py`（`_process_emotion` 中的数据库操作）及相关调用链  
**审查目标：** 跟踪数据从应用层到 Repository 到 Database 到 SQLite 的完整事务流，检查异步/同步一致性、事务边界、连接生命周期、批量操作效率、Schema 初始化、数据完整性约束、WAL 模式配置、并发控制，识别数据丢失、不一致、性能瓶颈风险。  
**报告字数：** 约 6500 字

---

## 概述

AI Friend 项目采用三层存储架构：应用层（Agent / MemoryConsolidator / MemoryRetriever）通过 `LongTermMemory` 调用 `Repository`，`Repository` 再操作 `Database` 中封装的 `aiosqlite` 连接。数据库使用 SQLite，启用了 WAL（Write-Ahead Logging）模式和 FOREIGN KEYS。整个系统的数据流覆盖了对话轮次（conversation_turns）、用户事实（user_facts）、经历（experiences）、反思（reflections）和关系指标（relationship_metrics）五张核心表。

本次审查发现，该存储层在设计上存在**严重的异步/同步混用问题**、**事务边界过度拆分导致的性能瓶颈**、**连接生命周期管理在 Web 多会话场景下的共享风险**，以及**批量嵌入更新中的连接管理缺陷**。同时，Schema 迁移机制简陋、缺乏版本号追踪、部分关键字段缺少 NOT NULL 约束，可能在长期运行中导致数据完整性问题。

以下将逐层展开分析。

---

## 数据流图

### 整体事务流拓扑

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              应用层 (Application)                            │
│  ┌─────────────┐  ┌─────────────────┐  ┌─────────────────────────────────┐  │
│  │  CLI main   │  │  Web server.py  │  │  core/agent.py _process_emotion │  │
│  │  (单线程)    │  │  (多会话/多WS)   │  │  (每3轮触发consolidation)        │  │
│  └──────┬──────┘  └────────┬────────┘  └────────────────┬────────────────┘  │
│         │                  │                            │                   │
│         ▼                  ▼                            ▼                   │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                    SessionManager / WebAgent                         │   │
│  │         (共享同一个 Database 实例 和 Repository 实例)                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│         │                                                                  │
│         ▼                                                                  │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                    LongTermMemory (sync wrapper)                     │   │
│  │   store_fact() ──▶ _run_sync() ──▶ await repo.upsert_fact()         │   │
│  │   store_experience() ──▶ _run_sync() ──▶ await repo.insert_experience│   │
│  │   ...                                                                │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│         │                                                                  │
│         ▼                                                                  │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         Repository                                   │   │
│  │   所有方法使用: async with self.db.cursor() as c:                    │   │
│  │   cursor() 上下文管理器: 自动 commit / rollback                        │   │
│  │   例外: bulk_update_embeddings() 也使用 cursor()                     │   │
│  │   例外: _embed_new_items() 直接操作 conn (绕过 cursor)                │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│         │                                                                  │
│         ▼                                                                  │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                          Database                                    │   │
│  │   aiosqlite.Connection (单连接, 全局 asyncio.Lock)                    │   │
│  │   PRAGMA journal_mode=WAL                                            │   │
│  │   PRAGMA foreign_keys=ON                                             │   │
│  │   get_connection() 返回裸 conn (无锁, 无自动提交)                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│         │                                                                  │
│         ▼                                                                  │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                          SQLite 文件                                 │   │
│  │   WAL 模式: -wal 和 -shm 文件                                       │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 关键调用链：一次用户消息的数据库写入

```
用户输入 ──▶ Agent.process_message()
    │
    ├──▶ MessageHandler.handle_message()
    │       │
    │       ├──▶ short_term.add_turn("user", input)     [内存, 无DB]
    │       │
    │       ├──▶ _run_agent3()
    │       │       │
    │       │       ├──▶ ltm.repo.insert_turn_sync(turn_count, "user", input, emotion_dict)
    │       │       │       └──▶ _run_sync(repo.insert_turn(...))
    │       │       │               └──▶ await repo.insert_turn()
    │       │       │                       └──▶ async with db.cursor() as c:
    │       │       │                               await c.execute(INSERT conversation_turns)
    │       │       │                               [自动 commit]
    │       │       │
    │       │       └──▶ _react_loop() → 生成 assistant 回复
    │       │               │
    │       │               └──▶ short_term.add_turn("assistant", reply)  [内存]
    │       │               └──▶ ltm.repo.insert_turn_sync(turn_count, "assistant", reply, emotion)
    │       │                       └──▶ [同上, 第二次 INSERT]
    │       │
    │       └──▶ _process_emotion()
    │               │
    │               ├──▶ consolidator.analyze_sentiment()  [LLM调用, 无DB]
    │               │
    │               ├──▶ personality.apply_emotional_shift()  [内存状态变更]
    │               │
    │               ├──▶ personality.emotion.record_emotion_event()  [内存事件列表]
    │               │
    │               └──▶ if turn_count % 3 == 0:
    │                       ├──▶ consolidator.add_pending(turn)  [内存缓冲]
    │                       └──▶ consolidator.consolidate()
    │                               │
    │                               ├──▶ _extract_facts() ──▶ ltm.store_fact() ──▶ repo.upsert_fact()
    │                               ├──▶ _summarize_experience() ──▶ ltm.store_experience() ──▶ repo.insert_experience()
    │                               ├──▶ _generate_reflection() ──▶ ltm.store_reflection() ──▶ repo.insert_reflection()
    │                               ├──▶ _update_relationship() ──▶ ltm.update_relationship() ──▶ repo.upsert_relationship()
    │                               ├──▶ _prune() ──▶ repo.prune_facts/experiences/reflections()
    │                               └──▶ _embed_new_items() ──▶ [直接conn查询 + repo.bulk_update_embeddings()]
    │
    └──▶ [返回响应给用户]
```

### 事务边界示意图

```
时间轴 ──────────────────────────────────────────────────────────────▶

用户消息处理:
├─[TX1: insert_turn user]────┤
                              ├─[TX2: insert_turn assistant]────┤
                                                                   ├─[TX3: upsert_fact]────┤
                                                                                            ├─[TX4: insert_experience]────┤
                                                                                                                         ├─[TX5: insert_reflection]────┤
                                                                                                                                                          ├─[TX6: upsert_relationship]────┤
                                                                                                                                                                                           ├─[TX7: prune_facts]────┤
                                                                                                                                                                                                                    ├─[TX8: prune_experiences]────┤
                                                                                                                                                                                                                                               ├─[TX9: prune_reflections]────┤
                                                                                                                                                                                                                                                                          ├─[TX10: bulk_update_embeddings]────┤

问题: 一次 consolidation 产生 10+ 个独立事务, 无原子性保证
```

---

## 详细发现

### 1. 异步/同步混用：严重的设计缺陷

#### 1.1 问题描述

整个数据访问层（Repository）设计为**纯异步**（所有方法均为 `async def`），但上层调用者大量使用**同步包装器** `_run_sync()` 来调用这些异步方法。

#### 1.2 关键代码位置

**`storage/repository.py` 第 13-22 行：**

```python
def _run_sync(coro):
    """Run coroutine in a thread-safe way for sync callers."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return pool.submit(asyncio.run, coro).result()
```

**`memory/long_term.py` 第 18-26 行：**

```python
@staticmethod
def _run_sync(coro):
    """Run coroutine in a thread-safe way for sync callers."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return pool.submit(asyncio.run, coro).result()
```

**`memory/long_term.py` 第 95-105 行（同步代理方法）：**

```python
def store_fact(self, *a, **kw): return self._run_sync(self._store_fact(*a, **kw))
def search_facts(self, *a, **kw): return self._run_sync(self._search_facts(*a, **kw))
# ... 所有方法都是这种模式
```

**`core/agent.py` 第 175-177 行：**

```python
self.ltm.repo.insert_turn_sync(self.turn_count, "assistant", final_text,
                          str(self.personality.emotion.to_dict()))
```

#### 1.3 风险分析

| 风险点 | 严重程度 | 说明 |
|--------|----------|------|
| 线程池开销 | **高** | 每次同步调用都创建 `ThreadPoolExecutor`，在 consolidation 时可能连续创建 10+ 个线程池，造成严重的线程创建/销毁开销 |
| 嵌套事件循环 | **高** | `pool.submit(asyncio.run, coro)` 在已有事件循环的线程中启动新的事件循环，可能引发 `RuntimeError: asyncio.run() cannot be called from a running event loop` |
| 死锁风险 | **中** | `asyncio.get_running_loop()` 获取当前循环后，若该循环已被阻塞等待线程池结果，可能形成循环依赖 |
| 性能瓶颈 | **高** | 每个数据库操作都经历：同步调用 → 线程池提交 → 新事件循环 → aiosqlite 异步执行 → 结果返回，延迟放大数倍 |

#### 1.4 具体场景验证

在 Web 模式下（`web_main.py`），FastAPI 已经运行在 `asyncio` 事件循环中。当 `Agent._react_loop()`（同步方法）调用 `ltm.repo.insert_turn_sync()` 时：

1. `_run_sync()` 捕获到正在运行的事件循环
2. 创建 `ThreadPoolExecutor`
3. 在线程中调用 `asyncio.run(coro)`
4. 该线程启动新的事件循环执行 aiosqlite 操作
5. 主线程阻塞等待 `pool.submit(...).result()`

这意味着**每个数据库写操作都会阻塞一个线程**，在高并发 Web 场景下会迅速耗尽线程池资源。

#### 1.5 建议

**风险评级：严重（CRITICAL）**

1. **短期缓解**：将 `_run_sync` 中的 `ThreadPoolExecutor` 改为单例模式，避免重复创建
2. **中期重构**：将 Agent 层核心方法改为 `async def`，消除同步包装层
3. **长期方案**：提供真正的同步数据库连接（如 `sqlite3` 直连）供同步调用者使用，或完全异步化应用层

---

### 2. 事务边界：过度拆分导致原子性丧失

#### 2.1 问题描述

`Database.cursor()` 上下文管理器为**每个数据库操作创建独立事务**，自动 `commit` 或 `rollback`。这意味着一个业务逻辑单元（如 consolidation）中的多个写操作被拆分为多个独立事务，缺乏原子性保证。

#### 2.2 关键代码位置

**`storage/database.py` 第 26-39 行：**

```python
@asynccontextmanager
async def cursor(self):
    if self.conn is None:
        raise RuntimeError("Database not opened. Call await db.open() first.")
    async with self._lock:
        c = await self.conn.cursor()
        try:
            yield c
            await self.conn.commit()      # <-- 每个 cursor() 退出时自动 commit
        except aiosqlite.Error:
            await self.conn.rollback()    # <-- 仅回滚当前 cursor 的操作
            raise
        finally:
            await c.close()
```

#### 2.3 事务拆分示例

以 `MemoryConsolidator.consolidate()`（`memory/consolidation.py` 第 47-81 行）为例：

```
consolidate() 调用链中的独立事务:
├─ _extract_facts() ──▶ ltm.store_fact() ──▶ [TX: upsert_fact]
├─ _summarize_experience() ──▶ ltm.store_experience() ──▶ [TX: insert_experience]
├─ _generate_reflection() ──▶ ltm.store_reflection() ──▶ [TX: insert_reflection]
├─ _update_relationship() ──▶ ltm.update_relationship() ──▶ [TX: upsert_relationship]
├─ _prune() ──▶ repo.prune_facts() ──▶ [TX: prune_facts]
├─ _prune() ──▶ repo.prune_experiences() ──▶ [TX: prune_experiences]
├─ _prune() ──▶ repo.prune_reflections() ──▶ [TX: prune_reflections]
└─ _embed_new_items() ──▶ repo.bulk_update_embeddings() ──▶ [TX: bulk_update_embeddings]
```

**共 8+ 个独立事务，无原子性。**

#### 2.4 数据不一致风险场景

假设 consolidation 执行到 `_prune_facts()` 后发生异常：

1. `upsert_fact` 已提交 — 新事实已写入
2. `insert_experience` 已提交 — 新经历已写入
3. `insert_reflection` 已提交 — 新反思已写入
4. `upsert_relationship` 已提交 — 关系已更新
5. `prune_facts` 已提交 — 部分事实被标记为 `is_active=0`
6. `prune_experiences` 异常 — **未执行**
7. `prune_reflections` 未执行
8. `bulk_update_embeddings` 未执行

结果：数据库处于**部分更新状态**，事实已被剪枝但经历和反思未被剪枝，嵌入向量也未更新。

#### 2.5 建议

**风险评级：高（HIGH）**

1. **引入显式事务接口**：在 `Database` 类中增加 `transaction()` 上下文管理器，允许跨多个 Repository 操作共享事务
2. **Consolidation 原子化**：将 `consolidate()` 中的所有写操作包裹在一个事务中
3. **保存点（Savepoint）**：对于长时间运行的 consolidation，使用 SQLite SAVEPOINT 实现子事务，允许部分回滚

---

### 3. 连接生命周期管理：单连接共享风险

#### 3.1 问题描述

`Database` 类维护**单一 `aiosqlite.Connection` 实例**，通过全局 `asyncio.Lock` 实现串行化访问。在 Web 多会话场景下，所有会话共享同一个连接。

#### 3.2 关键代码位置

**`storage/database.py` 第 11-16 行：**

```python
class Database:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._lock = asyncio.Lock()
        self.conn: aiosqlite.Connection | None = None
```

**`web/session.py` 第 131-135 行：**

```python
async def open(self):
    self.db = Database(self.config.db_path)
    await self.db.open()
    self.repo = Repository(self.db)
```

**`web/session.py` 第 141 行：**

```python
self._sessions[sid] = WebAgent(self.config, self.db, self.repo)
```

所有 `WebAgent` 实例共享同一个 `db` 和 `repo`。

#### 3.3 风险分析

| 风险点 | 严重程度 | 说明 |
|--------|----------|------|
| 单连接瓶颈 | **高** | 所有会话的数据库操作串行执行，无法利用 SQLite WAL 模式的并发读取能力 |
| 连接状态污染 | **中** | 若某会话设置了 PRAGMA 或临时状态，会影响其他会话 |
| 连接泄漏 | **低** | `Database.close()` 仅在 CLI 的 `finally` 中调用，Web 端在服务器关闭时才会关闭 |
| 长时间事务阻塞 | **高** | 若某操作持有锁时间过长（如批量嵌入），会阻塞所有其他会话的数据库访问 |

#### 3.4 Web 端具体风险

在 `web/server.py` 的 WebSocket 处理中：

```python
# web/server.py 第 233 行
response = await loop.run_in_executor(None, agent.process_message, content)
```

`process_message()` 是同步方法，内部会多次调用 `insert_turn_sync()`，每次都会：

1. 创建 `ThreadPoolExecutor`
2. 在线程中执行 `asyncio.run()`
3. 竞争 `Database._lock`
4. 执行 aiosqlite 操作

多个 WebSocket 连接同时处理消息时，会形成**多线程竞争单个 asyncio.Lock** 的局面，实际串行度取决于锁的获取顺序，但线程创建开销巨大。

#### 3.5 建议

**风险评级：高（HIGH）**

1. **连接池化**：使用 `aiosqlite` 的连接池或自行实现连接池，允许并发读取
2. **读写分离**：利用 WAL 模式特性，读操作使用只读连接，写操作使用主连接
3. **每会话连接**：考虑为每个 Web 会话分配独立的数据库连接（注意文件锁限制）
4. **连接健康检查**：增加连接存活检测和自动重连机制

---

### 4. 批量操作效率：嵌入更新存在严重性能问题

#### 4.1 问题描述

`MemoryConsolidator._embed_new_items()`（`memory/consolidation.py` 第 255-297 行）实现了批量嵌入编码，但在数据库操作层面存在两个效率问题。

#### 4.2 关键代码位置

**`memory/consolidation.py` 第 255-297 行：**

```python
def _embed_new_items(self) -> None:
    if not self._embed or not self._embed.health_check():
        return

    from memory.embeddings import EmbeddingEngine
    try:
        with self.ltm.repo.db.get_connection() as conn:   # <-- 问题1: 直接获取裸连接
            all_updates = []

            for table, text_cols in [
                ("user_facts", ["category", "fact_key", "fact_value"]),
                ("experiences", ["summary", "emotional_tone", "tags"]),
                ("reflections", ["content"]),
            ]:
                col_list = ", ".join(text_cols)
                rows = conn.execute(                               # <-- 问题2: 同步execute
                    f"SELECT id, {col_list} FROM {table} "
                    "WHERE embedding IS NULL LIMIT 50"
                ).fetchall()
                # ... 编码逻辑 ...

            if all_updates:
                for tbl in ["user_facts", "experiences", "reflections"]:
                    tbl_updates = [(rid, emb) for t, rid, emb in all_updates if t == tbl]
                    if tbl_updates:
                        self.ltm.repo.bulk_update_embeddings(tbl, tbl_updates)
```

#### 4.3 问题分析

**问题 1：`get_connection()` 绕过锁和事务管理**

`Database.get_connection()`（`storage/database.py` 第 41-45 行）：

```python
def get_connection(self):
    """Return connection for direct use (bulk operations). Caller must manage locking."""
    if self.conn is None:
        raise RuntimeError("Database not opened.")
    return self.conn
```

这里直接返回裸连接，**没有获取 `_lock`**。虽然 `conn.execute()` 在 aiosqlite 中是同步方法（因为 `aiosqlite.Connection` 包装了 `sqlite3.Connection`），但这段代码存在严重问题：

- `with self.ltm.repo.db.get_connection() as conn:` 这种用法是错误的 — `get_connection()` 返回的是连接对象，不是上下文管理器
- 实际上 `with` 语句会调用 `conn.__enter__()`，对于 `aiosqlite.Connection` 这不会做任何事
- 查询操作没有获取 `self._lock`，可能与 `cursor()` 上下文中的写操作并发，导致 SQLite "database is locked" 错误

**问题 2：混合同步/异步查询**

`_embed_new_items()` 是 `MemoryConsolidator` 的同步方法（被 `_run_sync` 调用链触发），但内部直接调用 `conn.execute()` — 这是**同步的 `sqlite3` 方法**，在异步环境中直接阻塞事件循环。

#### 4.4 `bulk_update_embeddings` 的事务问题

**`storage/repository.py` 第 189-197 行：**

```python
async def bulk_update_embeddings(self, table: str, updates: list[tuple[int, bytes]]):
    if not updates:
        return
    async with self.db.cursor() as c:
        await c.executemany(
            f"UPDATE {table} SET embedding = ?, embedding_version = 1 WHERE id = ?",
            [(emb, rid) for rid, emb in updates],
        )
        logger.debug(f"[db] bulk_embed: updated {len(updates)} rows in {table}")
```

虽然使用了 `executemany`，但每次 `bulk_update_embeddings` 调用仍然是一个**独立事务**。如果三个表都有更新，会产生三个独立事务。

#### 4.5 建议

**风险评级：高（HIGH）**

1. **移除 `get_connection()` 的滥用**：所有数据库操作应通过 `cursor()` 上下文管理器进行
2. **将 `_embed_new_items` 改为异步**：使用 `async with self.ltm.repo.db.cursor()` 执行查询
3. **合并批量更新**：将三个表的嵌入更新合并为一个事务
4. **增加批量大小限制**：当前 `LIMIT 50` 可能过小，考虑可配置化

---

### 5. Schema 初始化和版本管理：缺乏系统性

#### 5.1 问题描述

`Database.initialize()` 实现了表创建和简单的列迁移，但缺乏正式的版本管理机制。

#### 5.2 关键代码位置

**`storage/database.py` 第 47-134 行：**

```python
async def initialize(self) -> None:
    async with self.cursor() as c:
        await c.executescript("""
            CREATE TABLE IF NOT EXISTS schema_version (
                version INTEGER PRIMARY KEY,
                applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            -- 创建五张核心表 ...
        """)

        for table, column, col_type, default_val in [
            ("user_facts", "importance", "REAL", "0.5"),
            ("experiences", "importance", "REAL", "0.5"),
            ("reflections", "is_active", "INTEGER", "1"),
            ("user_facts", "embedding", "BLOB", "NULL"),
            ("user_facts", "embedding_version", "INTEGER", "0"),
            ("experiences", "embedding", "BLOB", "NULL"),
            ("experiences", "embedding_version", "INTEGER", "0"),
            ("reflections", "embedding", "BLOB", "NULL"),
            ("reflections", "embedding_version", "INTEGER", "0"),
        ]:
            await c.execute(f"PRAGMA table_info({table})")
            rows = await c.fetchall()
            columns = [row[1] for row in rows]
            if column not in columns:
                await c.execute(f"ALTER TABLE {table} ADD COLUMN {column} {col_type} DEFAULT {default_val}")
                logger.info(f"Schema migration: added {table}.{column}")
```

#### 5.3 问题分析

| 问题 | 说明 |
|------|------|
| `schema_version` 表未使用 | 创建了 `schema_version` 表，但从未插入版本号，无法追踪当前 schema 版本 |
| 迁移逻辑简陋 | 仅支持添加列，不支持：修改列类型、删除列、创建索引、数据迁移 |
| 无迁移历史记录 | 无法回滚迁移，也无法查看已应用的迁移 |
| 并发初始化风险 | 多个进程同时启动时可能同时执行 `CREATE TABLE IF NOT EXISTS` 和 `ALTER TABLE` |

#### 5.4 建议

**风险评级：中（MEDIUM）**

1. **实现版本号追踪**：在 `schema_version` 表中插入当前版本号
2. **引入迁移框架**：考虑使用 `alembic` 或自研简单的迁移系统
3. **幂等性保证**：确保所有迁移操作可重复执行无副作用
4. **索引管理**：为高频查询字段添加索引（如 `user_facts.is_active`, `experiences.is_archived`）

---

### 6. 数据完整性约束：部分缺失

#### 6.1 Schema 约束检查

| 表名 | 字段 | 约束 | 评价 |
|------|------|------|------|
| `user_facts` | `category`, `fact_key`, `fact_value` | `NOT NULL` | 正确 |
| `user_facts` | `category`, `fact_key` | `UNIQUE` | 正确 |
| `experiences` | `summary` | `NOT NULL` | 正确 |
| `experiences` | `emotional_tone`, `significance`, `tags` | 无约束 | 可接受 |
| `reflections` | `content` | `NOT NULL` | 正确 |
| `reflections` | `insight_type`, `significance` | 无约束 | 可接受 |
| `relationship_metrics` | `dimension` | `PRIMARY KEY` | 正确 |
| `conversation_turns` | `turn_number`, `role`, `content` | `NOT NULL` | 正确 |
| `conversation_turns` | `role` | `CHECK(role IN ('user', 'assistant'))` | 正确 |

#### 6.2 缺失的约束

| 表名 | 建议添加的约束 | 原因 |
|------|----------------|------|
| `user_facts` | `CHECK(confidence >= 0 AND confidence <= 1)` | 置信度应在 [0,1] 范围内 |
| `user_facts` | `CHECK(importance >= 0 AND importance <= 1)` | 重要性应在 [0,1] 范围内 |
| `experiences` | `CHECK(significance >= 0 AND significance <= 1)` | 显著性应在 [0,1] 范围内 |
| `reflections` | `CHECK(significance >= 0 AND significance <= 1)` | 显著性应在 [0,1] 范围内 |
| `relationship_metrics` | `CHECK(value >= 0 AND value <= 1)` | 关系值应在 [0,1] 范围内 |
| `conversation_turns` | `CHECK(turn_number >= 0)` | 轮次号不应为负 |
| 所有表 | `FOREIGN KEY` | 当前无外键关系，但 `source_turn` 等字段可引用 `conversation_turns.id` |

#### 6.3 外键约束现状

虽然设置了 `PRAGMA foreign_keys=ON`（`storage/database.py` 第 22 行），但所有表之间**没有任何 FOREIGN KEY 定义**。这意味着：

- `user_facts.source_turn` 可以引用不存在的 `conversation_turns.id`
- `experiences.turn_range_start/end` 可以引用不存在的轮次
- 删除 `conversation_turns` 记录不会级联删除相关事实

#### 6.4 建议

**风险评级：中（MEDIUM）**

1. **添加 CHECK 约束**：确保数值字段在有效范围内
2. **考虑添加外键**：在 `user_facts.source_turn` 和 `experiences.turn_range_start/end` 上添加外键约束（注意性能影响）
3. **应用层校验**：在 Repository 层增加参数校验，作为数据库约束的补充

---

### 7. WAL 模式配置和并发控制

#### 7.1 WAL 模式配置

**`storage/database.py` 第 21 行：**

```python
await self.conn.execute("PRAGMA journal_mode=WAL")
```

#### 7.2 WAL 模式优势

- 读操作不会阻塞写操作
- 写操作不会阻塞读操作
- 崩溃恢复更快

#### 7.3 未配置的 WAL 相关 PRAGMA

| PRAGMA | 当前配置 | 建议 | 说明 |
|--------|----------|------|------|
| `journal_mode` | WAL | 保持 | 已启用 |
| `wal_autocheckpoint` | 默认 (1000页) | 考虑调小 | 控制 WAL 文件大小 |
| `synchronous` | 默认 (FULL) | 考虑 NORMAL | 平衡性能和持久性 |
| `busy_timeout` | 未设置 | 设置 5000ms | 避免 "database is locked" |
| `cache_size` | 未设置 | 考虑设置 | 提升查询性能 |
| `temp_store` | 默认 | 考虑 MEMORY | 减少临时文件 I/O |

#### 7.4 并发控制现状

当前并发控制完全依赖 `Database._lock`（`asyncio.Lock`）：

```python
async with self._lock:
    c = await self.conn.cursor()
    # ... 操作 ...
```

这意味着：

- 即使启用了 WAL 模式，**所有数据库操作仍然串行化**
- WAL 模式的并发读取优势被完全浪费
- 单连接 + 单锁 = 实际上等同于单线程访问

#### 7.5 建议

**风险评级：中（MEDIUM）**

1. **设置 `busy_timeout`**：避免并发访问时的锁等待错误
2. **调整 `synchronous`**：在 Web 场景下使用 `NORMAL` 提升写入性能
3. **移除不必要的全局锁**：对于纯读操作，在 WAL 模式下可以安全地并发执行
4. **考虑连接池**：让 SQLite 的 WAL 模式真正发挥作用

---

### 8. 数据丢失风险

#### 8.1 对话轮次写入时机

**`core/agent.py` 第 251-252 行（Agent 3 中）：**

```python
a.ltm.repo.insert_turn_sync(a.turn_count, "user", user_input,
                     str(a.personality.emotion.to_dict()))
```

用户输入的 `insert_turn` 发生在 Agent 3 开始之前，即在 Agent 1（InnerDrive）和 Agent 2（ToolAgent）执行之后。如果 Agent 1/2 阶段发生异常，**用户输入不会被记录到数据库**。

**`core/agent.py` 第 175-177 行（Agent 3 回复后）：**

```python
self.ltm.repo.insert_turn_sync(self.turn_count, "assistant", final_text,
                          str(self.personality.emotion.to_dict()))
self.turn_count += 1
```

Assistant 回复的 `insert_turn` 在 `_react_loop` 成功返回后执行。如果 `insert_turn_sync` 失败（如数据库锁定），`turn_count` 仍然递增，导致**轮次号与数据库记录不一致**。

#### 8.2 情绪事件未持久化

**`core/agent.py` 第 212-215 行：**

```python
self.personality.emotion.record_emotion_event(
    trigger=last_user_turn[:100] if last_user_turn else "",
    context=last_user_turn[:200] if last_user_turn else "",
)
```

情绪事件仅记录在内存中的 `personality.emotion` 对象，**从未写入数据库**。进程重启后所有情绪历史丢失。

#### 8.3 短期记忆未持久化

`ConversationBuffer`（`memory/short_term.py`）完全基于内存的 `deque`。Web 端虽然在 `WebAgent.__init__` 中从数据库恢复了最近 30 轮对话，但：

- 新加入的轮次在 `short_term` 满（默认 20 条）后会被丢弃
- 被丢弃的轮次不会自动写入长期存储
- 只有每 3 轮触发的 `consolidator.add_pending()` 才会将最后一轮加入待处理缓冲

#### 8.4 建议

**风险评级：高（HIGH）**

1. **提前写入用户输入**：在 `handle_message()` 开头就写入 `conversation_turns`
2. **原子性更新 turn_count**：将 `insert_turn` 和 `turn_count += 1` 放在同一个事务中
3. **持久化情绪事件**：添加 `emotion_events` 表，定期将情绪事件刷盘
4. **短期记忆溢出处理**：当 `deque` 满时，将溢出的旧记录异步写入数据库

---

### 9. 性能瓶颈识别

#### 9.1 瓶颈 1：同步包装器开销

每次 `_run_sync()` 调用：

- 创建 `ThreadPoolExecutor`（约 1-5ms）
- 提交任务到线程池（约 0.5ms）
- 线程中启动 `asyncio.run()`（约 2-5ms）
- 竞争 `asyncio.Lock`（等待时间不确定）
- 执行实际 SQL（约 0.1-1ms）
- 返回结果

**单次数据库操作总延迟：5-20ms+**，而实际 SQL 执行仅 0.1-1ms。

#### 9.2 瓶颈 2：Consolidation 中的多次 LLM 调用

`MemoryConsolidator.consolidate()` 每次触发时：

1. `_extract_facts()` — 1 次 LLM 调用
2. `_summarize_experience()` — 1 次 LLM 调用（条件触发）
3. `_generate_reflection()` — 1 次 LLM 调用
4. `analyze_sentiment()` — 1 次 LLM 调用（在 `_update_relationship` 中）

**每次 consolidation 最多 4 次 LLM 调用**，加上 8+ 次数据库事务，整体延迟可能达到数秒。

#### 9.3 瓶颈 3：嵌入编码的串行化

`_embed_new_items()` 中：

```python
vecs = self._embed.encode(texts)  # 批量编码, 但受网络/服务器性能限制
for (tbl, rid), vec in zip(targets, vecs):
    all_updates.append((tbl, rid, EmbeddingEngine.vec_to_bytes(vec)))
```

虽然 `encode()` 支持批量，但：

- 查询无嵌入项时是逐表查询（3 次查询）
- 更新时是逐表调用 `bulk_update_embeddings()`（3 次事务）
- 嵌入服务器不可用时会阻塞 consolidation 流程

#### 9.4 瓶颈 4：Pruning 的计数查询

`prune_facts()`（`storage/repository.py` 第 241-258 行）：

```python
async def prune_facts(self, max_count: int) -> int:
    async with self.db.cursor() as c:
        await c.execute("SELECT COUNT(*) FROM user_facts WHERE is_active = 1")
        row = await c.fetchone()
        count = row[0]
        if count <= max_count:
            return 0
        # ... UPDATE ...
```

每次剪枝都执行 `COUNT(*)`，对于大数据集（如数万条事实）可能较慢。建议：

- 使用 `SELECT COUNT(*) FROM (SELECT 1 FROM ... LIMIT max_count+1)` 提前终止
- 或维护计数器在内存中

---

### 10. 其他发现

#### 10.1 `get_recent_turns` 的列选择问题

**`storage/repository.py` 第 228-237 行：**

```python
async def get_recent_turns(self, limit: int = 30) -> list[dict]:
    async with self.db.cursor() as c:
        await c.execute("""
            SELECT role, content FROM conversation_turns
            ORDER BY id DESC LIMIT ?
        """, (limit,))
        rows = await c.fetchall()
    rows = list(rows)
    rows.reverse()
    return [{"role": r[0], "content": r[1]} for r in rows]
```

- 使用 `id DESC` 排序，假设 `id` 是单调递增的。这在 `AUTOINCREMENT` 下成立，但如果手动插入或删除记录可能不成立
- 建议使用 `created_at DESC` 或 `turn_number DESC`
- `turn_number` 在 `insert_turn` 中被传入，但未在查询中使用

#### 10.2 `turn_number` 的潜在重复

**`storage/repository.py` 第 218-226 行：**

```python
async def insert_turn(self, turn_number: int, role: str, content: str,
                      emotional_state: Optional[str] = None) -> int:
    async with self.db.cursor() as c:
        await c.execute("""
            INSERT INTO conversation_turns (turn_number, role, content, emotional_state)
            VALUES (?, ?, ?, ?)
        """, (turn_number, role, content, emotional_state))
        return c.lastrowid
```

`turn_number` 没有 `UNIQUE` 约束，也没有递增校验。如果 `Agent.turn_count` 因某种原因回退或重置，可能插入重复的 `turn_number`。

#### 10.3 `relationship_metrics` 的默认值硬编码

**`storage/database.py` 第 111-115 行：**

```python
INSERT OR IGNORE INTO relationship_metrics (dimension, value) VALUES
    ('trust', 0.3),
    ('familiarity', 0.3),
    ('intimacy', 0.3),
    ('playfulness', 0.3);
```

默认值 0.3 在 Schema 和应用层多处硬编码，建议集中配置。

#### 10.4 `embedding_version` 的用途不明

所有表的 `embedding_version` 字段默认值为 0，插入时设为 1，但代码中没有根据版本号进行任何逻辑判断或迁移处理。

---

## 汇总统计

### 风险评级汇总

| 序号 | 问题类别 | 风险评级 | 影响范围 | 修复优先级 |
|------|----------|----------|----------|------------|
| 1 | 异步/同步混用（`_run_sync` 线程池开销） | **严重 (CRITICAL)** | 全系统 | P0 |
| 2 | 事务边界过度拆分（原子性丧失） | **高 (HIGH)** | consolidation | P0 |
| 3 | 连接生命周期管理（单连接共享） | **高 (HIGH)** | Web 多会话 | P0 |
| 4 | 批量操作效率（嵌入更新） | **高 (HIGH)** | consolidation | P1 |
| 8 | 数据丢失风险（turn_count 不一致、情绪事件未持久化） | **高 (HIGH)** | 数据完整性 | P1 |
| 5 | Schema 版本管理缺失 | **中 (MEDIUM)** | 长期维护 | P2 |
| 6 | 数据完整性约束缺失 | **中 (MEDIUM)** | 数据质量 | P2 |
| 7 | WAL 模式配置不足 | **中 (MEDIUM)** | 并发性能 | P2 |
| 9 | 性能瓶颈（LLM 调用、COUNT(*)） | **中 (MEDIUM)** | 响应延迟 | P2 |
| 10 | 其他代码质量问题 | **低 (LOW)** | 可维护性 | P3 |

### 代码位置引用汇总

| 文件路径 | 关键行号 | 关联问题 |
|----------|----------|----------|
| `storage/database.py` | 11-16, 26-39, 41-45 | 连接管理、事务边界、裸连接暴露 |
| `storage/database.py` | 47-134 | Schema 初始化、版本管理 |
| `storage/database.py` | 21-22 | WAL 模式、外键 |
| `storage/repository.py` | 13-22 | `_run_sync` 同步包装器 |
| `storage/repository.py` | 28-30 | `insert_turn_sync` 同步代理 |
| `storage/repository.py` | 34-68 | `upsert_fact` 独立事务 |
| `storage/repository.py` | 189-197 | `bulk_update_embeddings` 事务问题 |
| `storage/repository.py` | 241-258 | `prune_facts` COUNT(*) 性能 |
| `memory/long_term.py` | 18-26, 95-105 | 同步包装层 |
| `memory/consolidation.py` | 47-81 | consolidation 事务拆分 |
| `memory/consolidation.py` | 255-297 | `_embed_new_items` 裸连接问题 |
| `core/agent.py` | 175-177 | assistant turn 写入 |
| `core/agent.py` | 212-222 | 情绪事件、consolidation 触发 |
| `core/agent.py` | 251-252 | user turn 写入时机 |
| `web/session.py` | 131-135, 141 | 共享 Database/Repository |
| `web/server.py` | 233 | `run_in_executor` 调用同步方法 |

### 核心问题数量

- **严重问题**：1 个（异步/同步混用）
- **高风险问题**：4 个（事务边界、连接管理、批量操作、数据丢失）
- **中风险问题**：4 个（Schema 管理、约束、WAL 配置、性能）
- **低风险问题**：3 个（代码质量、硬编码、排序逻辑）

### 建议的紧急修复项（P0）

1. **统一异步/同步调用模式**：
   - 方案 A：将 Agent 核心流程改为 `async def`，Web 端直接 await，CLI 端使用 `asyncio.run()`
   - 方案 B：为同步调用者提供 `sqlite3` 直连的同步 Repository

2. **引入显式事务接口**：
   ```python
   # 建议的 Database 接口
   @asynccontextmanager
   async def transaction(self):
       async with self._lock:
           try:
               yield self.conn
               await self.conn.commit()
           except:
               await self.conn.rollback()
               raise
   ```

3. **Consolidation 原子化**：
   - 将所有 consolidation 写操作包裹在单个事务中
   - 使用 SAVEPOINT 实现子事务，允许部分回滚

4. **修复 `_embed_new_items`**：
   - 移除 `get_connection()` 的直接使用
   - 改为异步方法，通过 `cursor()` 执行查询
   - 将三个表的更新合并为一个事务

---

## 结论

AI Friend 项目的存储层在功能上已覆盖核心需求，但在**架构设计层面存在根本性的异步/同步混用问题**，这导致了严重的性能瓶颈和潜在的运行时错误。同时，**事务边界的过度拆分**使得数据一致性在异常场景下无法保证，**单连接共享**限制了 Web 端的并发能力。

建议优先处理 P0 级别的问题，尤其是统一异步/同步调用模式和引入显式事务接口，这两项改动将显著改善系统的可靠性、性能和可维护性。中低风险问题可在后续迭代中逐步解决。

---

*报告生成时间：2026/05/31*  
*审查者：Claude Code*  
*审查方法：静态代码分析、调用链追踪、架构模式评估*
