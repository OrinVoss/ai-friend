# AI Friend 项目配置管理系统深度审查报告

**审查日期**：2026-05-31
**审查范围**：`config.py`、`config.json`、`config.example.json` 及全项目配置使用链路
**审查人员**：Claude Code（深度代码审查专家）
**项目路径**：`D:\桌面\编程作品\AI朋友`
**Git 分支**：main（最新 commit: 3c24cd3）

---

## 1. 概述

### 1.1 审查目标

本次审查聚焦于 AI Friend 项目的配置管理系统，涵盖配置定义、加载逻辑、验证机制、敏感信息处理、热更新支持、类型安全及架构问题。配置管理是任何生产级应用的基石，其健壮性直接决定了系统的可部署性、安全性和可维护性。

### 1.2 总体评估

当前配置管理系统处于"功能可用但工程化不足"的状态。系统具备基本的配置分层能力（默认值 → JSON 文件 → 环境变量），能够支撑 CLI 和 Web 双端的运行需求。然而，在类型安全、配置验证、敏感信息保护、热更新机制、文档一致性等方面存在显著缺陷。部分问题已在 2026-05-28 的代码审查中被识别，但截至本次审查，仍有大量问题处于"部分修复"或"未修复"状态。

**总体风险评级：中高（B-/C+）**

| 维度 | 评分 | 风险等级 | 说明 |
|------|------|----------|------|
| 配置加载逻辑 | 55/100 | 中 | 环境变量覆盖已实现但覆盖范围有限，类型转换缺失 |
| 配置验证 | 20/100 | 高 | 零验证，无效值直接透传导致运行时错误 |
| 敏感信息处理 | 40/100 | 高 | API Key 明文存储在 JSON 中，日志脱敏逻辑有缺陷 |
| 热更新支持 | 10/100 | 高 | 完全缺失，Web 端配置修改需重启 |
| 类型安全 | 45/100 | 中 | dataclass 提供基础类型提示但无运行时校验 |
| 架构设计 | 50/100 | 中 | 单例式全局配置，模块级加载导致测试困难 |
| 文档一致性 | 60/100 | 中 | 文档与代码存在不一致，example 文件严重过时 |

### 1.3 最关键发现 Top 5

1. **API Key 明文硬编码于 config.json（严重安全风险）**：`config.json:3` 包含真实有效的 DeepSeek API Key `sk-618d33e37dde45d5904b94838b779c64`，该文件虽在 `.gitignore` 中，但明文存储在本地磁盘上，任何获得文件系统访问权限的攻击者均可直接获取密钥。

2. **配置验证完全缺失（高工程风险）**：`load_config()` 函数在加载 JSON 文件和环境变量时，对值的内容、类型、范围不做任何校验。用户可在 `config.json` 中将 `api_timeout` 设为 `"not_a_number"`，系统将在首次 API 调用时才抛出异常，且错误信息难以定位。

3. **config.example.json 严重过时（文档风险）**：`config.example.json` 仅包含 7 个字段，而实际 `Config` dataclass 定义了 28 个字段。新用户复制 example 文件后，21 个字段将使用代码中的硬编码默认值，其中包含多个平台相关路径（如 `D:\音乐`、`D:\桌面`），在 Linux/macOS 上直接运行将产生不可预期的行为。

4. **Web 端模块级配置加载导致无法热更新（架构缺陷）**：`web/server.py:17` 在模块导入时调用 `config = load_config()`，这意味着配置在 Python 进程启动时被冻结。修改 `config.json` 后必须重启 uvicorn 进程才能生效，对于长运行的 Web 服务极不友好。

5. **环境变量覆盖范围有限且类型转换缺失（功能缺陷）**：`config.py:64-76` 仅支持 5 个环境变量映射，大量关键配置（如 `temperature`、`max_tokens`、`web_port`、`embedding_endpoint`）无法通过环境变量设置。同时，环境变量值始终以字符串形式写入 dataclass 字段，导致 `web_port` 等整型字段被赋值为字符串 `"8000"`，可能在后续使用中报错。

---

## 2. 详细发现

### 2.1 配置加载逻辑审查

#### 2.1.1 加载优先级与分层设计

**文件**：`D:\桌面\编程作品\AI朋友\config.py`，第 48-78 行

```python
def load_config(path: str = CONFIG_PATH) -> Config:
    cfg = Config()                          # 第 1 层：dataclass 默认值
    if os.path.exists(path):
        ...
        for k, v in data.items():           # 第 2 层：JSON 文件覆盖
            if hasattr(cfg, k):
                setattr(cfg, k, v)
    ...
    for env_var, attr in env_map.items():   # 第 3 层：环境变量覆盖
        val = os.environ.get(env_var, "")
        if val:
            setattr(cfg, attr, val)
    return cfg
```

**分析**：

配置加载采用三层优先级设计：默认值 → JSON 文件 → 环境变量。这一设计与项目文档 `doc/technical.md:994` 中描述的"优先级：环境变量（计划中） > config.json > Config dataclass"基本一致，但文档中标注环境变量为"计划中"，而实际代码已实现部分环境变量支持，存在文档与代码不同步的问题。

**问题 1：环境变量优先级声明与实现不一致**

`doc/technical.md:994` 明确标注"环境变量（计划中）"，暗示该功能尚未实现。但 `config.py:63-76` 已实现 5 个环境变量的读取。这种不一致会导致开发者产生困惑，误以为环境变量功能不可用，从而继续将敏感信息写入 `config.json`。

**建议**：更新 `doc/technical.md` 第 994 行，将"（计划中）"移除，并列出已支持的环境变量列表。

**问题 2：JSON 文件加载无 schema 校验**

`config.py:54-56` 使用简单的 `hasattr` + `setattr` 循环将 JSON 数据注入 dataclass：

```python
for k, v in data.items():
    if hasattr(cfg, k):
        setattr(cfg, k, v)
```

这一实现存在以下隐患：

- **多余字段静默忽略**：JSON 中的拼写错误（如 `api_tiemout`）将被静默忽略，用户无法得知配置未生效。
- **类型不匹配无警告**：JSON 中的 `api_timeout: "180"`（字符串）将被直接赋给声明为 `int` 的字段，Python 的动态类型不会立即报错，但后续在 `KimiProvider.__init__` 中传入 `timeout="180"` 时，`requests` 库可能接受字符串（进行隐式转换），也可能在某些场景下报错。
- **嵌套结构不支持**：当前设计仅支持扁平键值对，未来若需要嵌套配置（如 `api: { endpoint: ..., key: ... }`），必须重构整个加载逻辑。

**建议**：引入 `pydantic` 或 `marshmallow` 进行 schema 校验，或在 `load_config()` 中增加类型检查和未知字段警告。

**问题 3：环境变量映射范围过窄**

`config.py:64-70` 仅定义了 5 个环境变量映射：

```python
env_map = {
    "DEEPSEEK_API_KEY": "api_key",
    "DEEPSEEK_API_ENDPOINT": "api_endpoint",
    "DEEPSEEK_API_MODEL": "api_model",
    "AI_FRIEND_DB_PATH": "db_path",
    "AI_FRIEND_LOG_LEVEL": "log_level",
}
```

大量对部署和运维至关重要的配置无法通过环境变量设置，包括但不限于：

| 配置项 | 场景 | 当前状态 |
|--------|------|----------|
| `temperature` | 调整模型创造性 | 不支持 |
| `max_tokens` | 控制输出长度 | 不支持 |
| `web_port` | 容器部署端口映射 | 不支持 |
| `web_host` | 绑定地址安全控制 | 不支持 |
| `api_timeout` | 慢网络环境调整 | 不支持 |
| `embedding_endpoint` | 使用远程嵌入服务 | 不支持 |
| `short_term_capacity` | 内存受限环境 | 不支持 |
| `proactive_min_idle` | 调整主动行为频率 | 不支持 |

**建议**：扩展 `env_map` 以覆盖所有配置项，或采用自动映射策略（如将所有大写配置名自动映射为环境变量）。

**问题 4：环境变量值无类型转换**

`config.py:72-76` 中，环境变量值始终以原始字符串形式赋值：

```python
val = os.environ.get(env_var, "")
if val:
    setattr(cfg, attr, val)
```

这意味着：

- `AI_FRIEND_DB_PATH=./data/db.sqlite` → `cfg.db_path = "./data/db.sqlite"`（正确）
- `WEB_PORT=8080` → `cfg.web_port = "8080"`（错误，应为 `int`）
- `TEMPERATURE=0.5` → `cfg.temperature = "0.5"`（错误，应为 `float`）
- `SHORT_TERM_CAPACITY=1000` → `cfg.short_term_capacity = "1000"`（错误，应为 `int`）

虽然 Python 的动态类型允许字符串在某些场景下替代数字（如 `"8080"` 在字符串拼接中可用），但在 `web_main.py:16` 中：

```python
port = getattr(config, 'web_port', 8000)
```

`uvicorn.run(port="8080")` 是否会报错取决于 uvicorn 的内部实现。更安全的做法是进行显式类型转换。

**建议**：在 `Config` dataclass 中增加 `__post_init__` 方法，或在 `load_config()` 的末尾统一进行类型转换和校验。

---

### 2.2 配置验证与默认值审查

#### 2.2.1 零验证现状

**文件**：`D:\桌面\编程作品\AI朋友\config.py`，第 9-43 行

`Config` dataclass 定义了 28 个字段，但没有任何运行时验证机制：

```python
@dataclass
class Config:
    api_endpoint: str = "https://api.deepseek.com"
    api_key: str = ""  # can be overridden by DEEPSEEK_API_KEY env var
    api_model: str = "deepseek-v4-flash"
    api_timeout: int = 180
    thinking: str = "disabled"
    reasoning_effort: str = ""
    personality_file: str = "personality.json"
    db_path: str = "data/ai_friend.db"
    short_term_capacity: int = 500
    consolidation_interval: int = 5
    proactive_min_idle: float = 180.0
    proactive_max_interval: float = 600.0
    typing_speed: float = 0.005
    temperature: float = 0.8
    max_tokens: int = 512
    max_facts: int = 200
    max_experiences: int = 100
    max_reflections: int = 50
    web_host: str = "0.0.0.0"
    web_port: int = 8000
    log_level: str = "INFO"
    allowed_read_paths: list[str] = field(default_factory=lambda: [
        ".",
        "D:\\音乐",
        "D:\\桌面",
        "~/Documents",
        "~/Downloads",
    ])
    embedding_endpoint: str = "http://localhost:8080/v1/embeddings"
    embedding_dim: int = 512
    embedding_cache_size: int = 1000
```

**问题 5：数值范围无约束**

以下字段具有明确的业务含义范围，但代码未做任何约束：

| 字段 | 合理范围 | 恶意/错误输入示例 | 后果 |
|------|----------|-------------------|------|
| `temperature` | 0.0 ~ 2.0 | `-1.0` 或 `5.0` | API 返回 400 错误 |
| `max_tokens` | 1 ~ 8192 | `0` 或 `-100` | API 返回 400 错误 |
| `api_timeout` | 1 ~ 600 | `0` 或 `99999` | 立即超时或无限挂起 |
| `web_port` | 1 ~ 65535 | `99999` 或 `-1` | uvicorn 启动失败 |
| `short_term_capacity` | 10 ~ 10000 | `1` 或 `1000000` | 内存溢出或记忆功能失效 |
| `embedding_dim` | 64 ~ 4096 | `0` 或 `-1` | 嵌入计算崩溃 |

**建议**：在 `load_config()` 中增加验证逻辑，或使用 `pydantic.Field` 的 `ge`、`le` 约束。

**问题 6：字符串枚举值无校验**

```python
thinking: str = "disabled"
reasoning_effort: str = ""
log_level: str = "INFO"
```

`thinking` 字段在 DeepSeek API 中仅支持 `"disabled"` 或 `"enabled"`，`reasoning_effort` 支持 `""`、`"low"`、`"medium"`、`"high"`，`log_level` 应为标准 logging 级别之一。当前实现允许任意字符串，错误值将在 API 调用时才暴露。

**建议**：将 `thinking` 和 `reasoning_effort` 改为 `Literal` 类型，并在加载时校验。

**问题 7：路径默认值包含 Windows 绝对路径**

```python
allowed_read_paths: list[str] = field(default_factory=lambda: [
    ".",
    "D:\\音乐",
    "D:\\桌面",
    "~/Documents",
    "~/Downloads",
])
```

`D:\音乐` 和 `D:\桌面` 是开发者个人电脑的绝对路径。当项目部署到 Linux 服务器或 Docker 容器时，这些路径不存在，但 `tools/file_tools.py:38-42` 会尝试解析它们：

```python
for p in getattr(cfg, 'allowed_read_paths', []):
    if p == ".":
        paths.append(project)
    else:
        paths.append(os.path.abspath(os.path.expanduser(p)))
```

在 Linux 上，`os.path.abspath("D:\\音乐")` 会返回 `/current/working/dir/D:\音乐`，这是一个不存在的路径，虽不会直接导致错误，但会污染允许读取路径列表。

**建议**：将平台相关路径从默认值中移除，改为通过 `config.json` 或环境变量在部署时注入。

---

### 2.3 敏感信息处理审查

#### 2.3.1 API Key 存储方式

**文件**：`D:\桌面\编程作品\AI朋友\config.json`，第 3 行

```json
{
  "api_endpoint": "https://api.deepseek.com",
  "api_key": "sk-618d33e37dde45d5904b94838b779c64",
  ...
}
```

**问题 8：API Key 明文存储在 JSON 文件中**

`config.json` 中直接包含真实 API Key。虽然 `.gitignore:8` 已将 `config.json` 排除在版本控制之外，但密钥仍以明文形式存储在本地文件系统中：

- 任何获得文件系统访问权限的进程均可读取该文件
- 备份软件、云同步工具（OneDrive、Dropbox）可能自动上传该文件
- 在共享开发环境中，其他用户可能读取该文件
- 屏幕截图、录屏软件可能意外捕获配置文件内容

**建议**：
1. **首选方案**：将 API Key 从 `config.json` 中移除，强制通过 `DEEPSEEK_API_KEY` 环境变量提供。在 `load_config()` 中，若 `api_key` 为空且环境变量未设置，打印警告并退出。
2. **备选方案**：使用 `keyring` 库将 API Key 存储在操作系统的密钥管理服务中（Windows Credential Manager、macOS Keychain、Linux Secret Service）。
3. **过渡方案**：在 `config.json` 中保留 `api_key` 字段，但值为空字符串，并在文档中明确标注"请勿在此填写真实密钥"。

#### 2.3.2 日志脱敏逻辑

**文件**：`D:\桌面\编程作品\AI朋友\config.py`，第 72-75 行

```python
val = os.environ.get(env_var, "")
if val:
    masked = "***" if "KEY" in env_var else val
    logger.info(f"[config] env override: {env_var}={masked}")
    setattr(cfg, attr, val)
```

**问题 9：日志脱敏逻辑过于简单**

当前脱敏逻辑仅检查环境变量名是否包含子串 `"KEY"`：

```python
masked = "***" if "KEY" in env_var else val
```

这一实现存在以下问题：

- **假阴性**：若未来增加 `DEEPSEEK_SECRET` 或 `OPENAI_TOKEN` 等环境变量，这些值将明文打印到日志中。
- **假阳性**：若存在 `KEYBOARD_LAYOUT` 等不含敏感信息但包含 `"KEY"` 的环境变量，其值将被不必要地掩码。
- **JSON 加载无脱敏**：`config.py:57` 在加载 JSON 文件时打印 `logger.info(f"[config] loaded from: {path}")`，未显示配置内容，这是正确的。但如果用户开启 DEBUG 级别日志，其他模块可能打印完整的 `Config` 对象。

**建议**：
1. 维护一个敏感字段名列表（如 `api_key`、`secret`、`token`、`password`），对字段名进行匹配脱敏。
2. 在 `save_config()` 中增加对 `api_key` 的特殊处理，确保写入文件时若密钥非空，打印警告。

#### 2.3.3 API Key 在内存中的生命周期

**文件**：`D:\桌面\编程作品\AI朋友\core\provider.py`，第 12-30 行

```python
class KimiProvider:
    def __init__(self, endpoint: str, api_key: str, model: str, ...):
        self.endpoint = endpoint.rstrip("/")
        self.api_key = api_key
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        })
```

API Key 被存储为 `KimiProvider` 实例的属性，并通过 `requests.Session` 的 headers 持久化。这意味着：

- Key 在 Python 进程的整个生命周期中存在于内存中
- 若进程发生 core dump 或内存转储，Key 可能被泄露
- 无法在不重启进程的情况下轮换（rotate）API Key

**建议**：对于高安全要求的场景，考虑使用 `requests` 的 `auth` 参数或自定义 `HTTPAdapter`，在每次请求时动态获取密钥。

---

### 2.4 配置热更新支持审查

#### 2.4.1 完全缺失的热更新机制

**文件**：`D:\桌面\编程作品\AI朋友\web\server.py`，第 17 行

```python
config = load_config()
session_manager = SessionManager(config)
```

**问题 10：Web 端配置在模块导入时冻结**

`web/server.py` 在模块级别调用 `load_config()`，配置对象在 uvicorn worker 启动时被创建，并在整个进程生命周期中保持不变。修改 `config.json` 后，必须重启 uvicorn 才能生效。

对于以下场景，这造成了显著的操作负担：

- **调整日志级别**：运维人员希望在不中断服务的情况下将 `log_level` 从 `INFO` 调整为 `DEBUG` 以排查问题。当前必须重启服务，导致所有 WebSocket 连接断开。
- **调整主动行为参数**：修改 `proactive_min_idle` 或 `proactive_max_interval` 以调整 AI 主动发起对话的频率。重启将丢失所有会话状态。
- **更换模型**：从 `deepseek-v4-flash` 切换到 `deepseek-v4` 进行 A/B 测试。重启导致用户体验中断。

**建议**：
1. **短期方案**：在 `web/server.py` 的 API 端点中，每次请求前重新调用 `load_config()`，或至少为关键配置项（如 `log_level`、`temperature`）提供重新加载机制。
2. **中期方案**：实现配置监听器（使用 `watchdog` 库监视 `config.json` 的修改时间戳），在文件变化时自动重新加载配置。
3. **长期方案**：将配置分为"静态配置"（启动时加载，如 `db_path`、`web_port`）和"动态配置"（运行时热更新，如 `log_level`、`temperature`、`proactive_min_idle`），并分别管理。

#### 2.4.2 CLI 端无热更新需求但存在设计惯性

CLI 端（`main.py`）每次启动时重新加载配置，不存在热更新需求。但 `main.py:29` 中的配置对象被传递给 `Agent`，而 `Agent` 又将其传递给 `CliController`、`MessageHandler` 等多个子组件。若未来 CLI 端需要支持配置重载（如通过 `/reload` 命令），当前的设计将导致大量引用需要更新。

**建议**：在 `Agent` 中封装配置访问接口（如 `agent.get_config()`），而非直接传递 `Config` 对象，为未来热更新预留扩展点。

---

### 2.5 类型安全审查

#### 2.5.1 dataclass 的基础类型提示

`Config` 使用 Python 的 `@dataclass` 装饰器，为所有字段提供了静态类型提示。这在开发阶段（配合 IDE 或 `mypy`）能够提供良好的类型检查支持。

**问题 11：运行时类型不安全**

Python 的类型提示仅在静态分析时生效，运行时完全忽略。`load_config()` 中的 `setattr(cfg, k, v)` 可以绕过所有类型约束：

```python
# 以下代码在运行时完全合法，但类型错误
cfg.api_timeout = "not_an_int"      # int 字段被赋值为 str
cfg.temperature = [1, 2, 3]         # float 字段被赋值为 list
cfg.allowed_read_paths = "just_a_string"  # list[str] 字段被赋值为 str
```

这些错误不会在配置加载时暴露，而是在后续使用配置时以难以诊断的方式崩溃。

**建议**：引入 `pydantic.BaseModel` 替代 `@dataclass`，利用其运行时类型校验能力：

```python
from pydantic import BaseModel, Field, validator

class Config(BaseModel):
    api_endpoint: str = "https://api.deepseek.com"
    api_key: str = ""
    api_model: str = "deepseek-v4-flash"
    api_timeout: int = Field(default=180, ge=1, le=600)
    temperature: float = Field(default=0.8, ge=0.0, le=2.0)
    max_tokens: int = Field(default=512, ge=1, le=8192)
    web_port: int = Field(default=8000, ge=1, le=65535)
    log_level: str = "INFO"
    
    @validator("log_level")
    def validate_log_level(cls, v):
        if v not in {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}:
            raise ValueError(f"Invalid log_level: {v}")
        return v
```

#### 2.5.2 `allowed_read_paths` 的 list[str] 类型

`Config.allowed_read_paths` 使用 `field(default_factory=...)` 提供默认值，这在 dataclass 中是正确的方式（避免可变默认参数的陷阱）。但 `tools/file_tools.py:38` 在访问该字段时使用了 `getattr`：

```python
for p in getattr(cfg, 'allowed_read_paths', []):
```

这种防御式编程是合理的，因为 `file_tools.py` 在 `load_config()` 失败时会回退到项目目录。但如果 `Config` 的字段名发生变化（如重命名为 `read_paths`），`getattr` 的静默回退将掩盖错误。

**建议**：在 `file_tools.py` 中使用类型导入而非动态获取：

```python
from config import Config

def _get_allowed_roots() -> list[str]:
    try:
        cfg = load_config()
        paths = cfg.allowed_read_paths  # 类型安全，拼写错误将在静态检查时暴露
        ...
```

---

### 2.6 架构问题审查

#### 2.6.1 全局单例式配置模式

**文件**：`D:\桌面\编程作品\AI朋友\web\server.py`，第 17 行

```python
config = load_config()
```

**问题 12：模块级全局变量导致测试困难**

`web/server.py` 在模块级别创建全局 `config` 对象。这在单元测试中造成了严重困难：

- 测试无法在不修改全局状态的情况下使用不同的配置
- 并行测试可能相互干扰（一个测试修改 `config.json`，另一个测试读取到意外值）
- `tests/real_api/conftest.py:9-14` 中的 `_has_api_key()` 函数不得不导入 `load_config` 并实际读取文件系统，增加了测试的耦合度

**建议**：将配置加载推迟到请求处理时，或通过依赖注入（FastAPI 的 `Depends`）传递配置对象。

#### 2.6.2 `tools/file_tools.py` 的重复配置加载

**文件**：`D:\桌面\编程作品\AI朋友\tools\file_tools.py`，第 31-48 行

```python
def _get_allowed_roots() -> list[str]:
    try:
        from config import load_config
        cfg = load_config()
        paths = []
        ...
```

`file_tools.py` 在每次调用 `_get_allowed_roots()` 时（即每次 `read_file` 工具执行时）都重新加载配置文件。虽然配置文件通常很小，读取开销可忽略，但这种设计模式存在以下问题：

- **不一致性**：若 `web/server.py` 在启动时加载的配置与 `file_tools.py` 在运行时加载的配置不同（因为 `config.json` 被修改），同一进程内的不同组件将使用不同的配置值。
- **I/O 开销**：在高并发场景下，频繁的磁盘读取可能成为瓶颈。
- **异常处理复杂**：`file_tools.py` 必须处理 `load_config()` 失败的情况，并回退到默认路径，增加了代码复杂度。

**建议**：将 `allowed_read_paths` 作为 `ReadFileTool` 的初始化参数传入，由调用方（`main.py` 或 `web/session.py`）提供配置值。

#### 2.6.3 `save_config()` 的设计缺陷

**文件**：`D:\桌面\编程作品\AI朋友\config.py`，第 81-83 行

```python
def save_config(cfg: Config, path: str = CONFIG_PATH) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump({k: getattr(cfg, k) for k in cfg.__dataclass_fields__}, f, indent=2, ensure_ascii=False)
```

**问题 13：`save_config()` 将 API Key 写回磁盘**

若程序在运行时修改了 `api_key`（如通过管理界面轮换密钥），`save_config()` 会将新密钥明文写回 `config.json`。这与安全最佳实践相悖：密钥应只读，不应由应用程序回写。

**问题 14：`save_config()` 未使用**

通过全局搜索发现，`save_config()` 函数在项目中没有任何调用点。这是一个"死代码"，增加了维护负担。

**建议**：
1. 若确实需要保存配置，应排除敏感字段（如 `api_key`），或将其替换为占位符。
2. 若 `save_config()` 确实无用，应将其删除以减少代码表面积。

#### 2.6.4 `config.example.json` 严重过时

**文件**：`D:\桌面\编程作品\AI朋友\config.example.json`

```json
{
  "api_endpoint": "https://api.deepseek.com",
  "api_key": "your-api-key-here",
  "api_model": "deepseek-v4-flash",
  "thinking": "disabled",
  "max_tokens": 512,
  "temperature": 0.8
}
```

`config.example.json` 仅包含 7 个字段，而 `Config` dataclass 定义了 28 个字段。缺失的 21 个字段包括：

- `api_timeout`
- `reasoning_effort`
- `personality_file`
- `db_path`
- `short_term_capacity`
- `consolidation_interval`
- `proactive_min_idle`
- `proactive_max_interval`
- `typing_speed`
- `max_facts`
- `max_experiences`
- `max_reflections`
- `web_host`
- `web_port`
- `log_level`
- `allowed_read_paths`
- `embedding_endpoint`
- `embedding_dim`
- `embedding_cache_size`

**后果**：

- 新用户复制 `config.example.json` 为 `config.json` 后，21 个字段将使用代码中的硬编码默认值
- `README.md:18` 中的安装说明"`cp config.example.json config.json`"引导用户创建一个不完整的配置文件
- `doc/architecture.md:18` 同样建议"`cp config.example.json config.json`"

**建议**：更新 `config.example.json` 以包含所有字段，并为每个字段添加注释说明其用途和合理取值范围。

---

### 2.7 跨文件一致性问题

#### 2.7.1 `config.json` 与 `Config` dataclass 字段不一致

**文件**：`D:\桌面\编程作品\AI朋友\config.json`

对比 `config.json` 和 `Config` dataclass，发现以下不一致：

| 字段 | config.json 值 | Config 默认值 | 差异说明 |
|------|---------------|--------------|----------|
| `proactive_min_idle` | `600.0` | `180.0` | JSON 覆盖为更长空闲时间 |
| `proactive_max_interval` | `1800.0` | `600.0` | JSON 覆盖为更长间隔 |
| `allowed_read_paths` | 未设置 | 包含 `D:\音乐`、`D:\桌面` | 实际运行时缺失 |
| `embedding_endpoint` | 未设置 | `http://localhost:8080/v1/embeddings` | 实际运行时缺失 |
| `embedding_dim` | 未设置 | `512` | 实际运行时缺失 |
| `embedding_cache_size` | 未设置 | `1000` | 实际运行时缺失 |

`proactive_min_idle` 和 `proactive_max_interval` 在 `config.json` 中的值（600.0 / 1800.0）与 `Config` 默认值（180.0 / 600.0）差异巨大。这种差异是否有意为之？文档中未做任何说明。

#### 2.7.2 `doc/technical.md` 配置示例与代码不一致

**文件**：`D:\桌面\编程作品\AI朋友\doc\technical.md`，第 996-1018 行

文档中的配置示例包含了 `proactive_min_idle: 180.0` 和 `proactive_max_interval: 600.0`，这与 `Config` 默认值一致，但与 `config.json` 的实际值（600.0 / 1800.0）不一致。

---

### 2.8 安全审计补充

#### 2.8.1 `.gitignore` 对 `config.json` 的排除

**文件**：`D:\桌面\编程作品\AI朋友\.gitignore`，第 7-8 行

```
# Config with keys
config.json
```

`.gitignore` 正确排除了 `config.json`，这是良好的安全实践。但存在以下隐患：

- **Git 历史泄露**：若 `config.json` 曾被意外提交到 git，即使后续加入 `.gitignore`，密钥仍将永久存在于 git 历史中。
- **备份文件泄露**：`config.json.bak`、`config.json~` 等备份文件未被排除。
- **其他配置文件**：`config.local.json`、`config.prod.json` 等变体未被排除。

**建议**：扩展 `.gitignore` 以覆盖更多配置文件变体：

```gitignore
# Config with keys
config.json
config.*.json
!config.example.json
*.json.bak
*.json~
```

#### 2.8.2 `personality.json` 中的潜在敏感信息

虽然 `personality.json` 未被本次审查重点覆盖，但需注意该文件包含用户的情感交互历史（`emotion_events`），可能涉及用户隐私。当前 `personality.json` 未被 `.gitignore` 排除，存在被意外提交的风险。

---

### 2.9 测试相关审查

#### 2.9.1 配置系统的测试覆盖

通过全局搜索，未发现任何专门针对 `config.py` 的单元测试。`tests/` 目录中的测试文件（如 `test_cli_controller.py`、`test_agent_proactive.py`）使用 mock 配置对象，未测试实际的配置加载逻辑。

**缺失的测试场景**：

- JSON 文件不存在时的默认行为
- JSON 文件存在但包含无效 JSON 时的错误处理
- 环境变量覆盖的正确性
- 环境变量值类型不匹配时的行为
- 未知字段的静默忽略行为
- `save_config()` 的序列化正确性

**建议**：在 `tests/` 目录下新增 `test_config.py`，覆盖上述场景。

#### 2.9.2 `tests/real_api/conftest.py` 的配置依赖

**文件**：`D:\桌面\编程作品\AI朋友\tests\real_api\conftest.py`，第 8-14 行

```python
def _has_api_key() -> bool:
    from config import load_config
    try:
        cfg = load_config()
        return bool(cfg.api_key and cfg.api_key != "your-api-key-here")
    except Exception:
        return False
```

该函数在测试收集阶段实际调用 `load_config()`，读取文件系统。若 `config.json` 不存在或损坏，测试将被跳过，且跳过原因不明确。

**建议**：将配置加载推迟到 `setUpClass` 中，并在跳过测试时打印明确的诊断信息。

---

## 3. 汇总统计

### 3.1 问题清单

| 编号 | 问题描述 | 风险等级 | 文件位置 | 状态 |
|------|----------|----------|----------|------|
| 1 | 环境变量优先级声明与实现不一致 | 低 | `doc/technical.md:994` | 文档过期 |
| 2 | JSON 文件加载无 schema 校验 | 中 | `config.py:54-56` | 未修复 |
| 3 | 环境变量映射范围过窄 | 中 | `config.py:64-70` | 部分修复 |
| 4 | 环境变量值无类型转换 | 高 | `config.py:72-76` | 未修复 |
| 5 | 数值范围无约束 | 高 | `config.py:9-43` | 未修复 |
| 6 | 字符串枚举值无校验 | 中 | `config.py:15-16, 31` | 未修复 |
| 7 | 路径默认值包含 Windows 绝对路径 | 中 | `config.py:32-38` | 未修复 |
| 8 | API Key 明文存储在 JSON 文件中 | 严重 | `config.json:3` | 未修复 |
| 9 | 日志脱敏逻辑过于简单 | 中 | `config.py:74` | 部分修复 |
| 10 | Web 端配置在模块导入时冻结 | 高 | `web/server.py:17` | 未修复 |
| 11 | 运行时类型不安全 | 中 | `config.py:54-56` | 未修复 |
| 12 | 模块级全局变量导致测试困难 | 中 | `web/server.py:17` | 未修复 |
| 13 | `save_config()` 将 API Key 写回磁盘 | 高 | `config.py:81-83` | 未修复 |
| 14 | `save_config()` 未使用（死代码） | 低 | `config.py:81-83` | 未修复 |
| 15 | `config.example.json` 严重过时 | 中 | `config.example.json` | 未修复 |
| 16 | `config.json` 与 `Config` 默认值不一致 | 低 | `config.json`, `config.py` | 未说明 |
| 17 | 文档配置示例与代码不一致 | 低 | `doc/technical.md:996-1018` | 文档过期 |
| 18 | `.gitignore` 备份文件覆盖不足 | 低 | `.gitignore` | 未修复 |
| 19 | 配置系统零单元测试 | 高 | `tests/` | 缺失 |
| 20 | `file_tools.py` 重复加载配置 | 中 | `tools/file_tools.py:31-48` | 未修复 |

### 3.2 风险分布

| 风险等级 | 数量 | 占比 |
|----------|------|------|
| 严重 | 1 | 5% |
| 高 | 6 | 30% |
| 中 | 10 | 50% |
| 低 | 3 | 15% |

### 3.3 修复优先级建议

**P0（立即修复）**：
- 问题 8：从 `config.json` 中移除 API Key，强制通过环境变量提供
- 问题 4：为环境变量值增加类型转换
- 问题 5：增加配置数值范围校验

**P1（本周修复）**：
- 问题 10：为 Web 端实现配置热更新或至少按请求重新加载
- 问题 15：更新 `config.example.json` 以包含所有字段
- 问题 19：为配置系统编写单元测试
- 问题 13/14：修复或移除 `save_config()`

**P2（本月修复）**：
- 问题 2：引入 schema 校验（如 pydantic）
- 问题 9：改进日志脱敏逻辑
- 问题 7：移除平台相关的默认路径
- 问题 20：消除 `file_tools.py` 的重复配置加载

**P3（ backlog ）**：
- 问题 1/17：更新文档以与代码保持一致
- 问题 12：重构全局配置为依赖注入模式
- 问题 18：扩展 `.gitignore`

---

## 4. 具体修复建议

### 4.1 推荐引入 pydantic 进行配置管理

将 `Config` dataclass 迁移至 `pydantic.BaseModel`，可获得以下收益：

- 运行时类型校验
- 字段约束（`ge`, `le`, `regex` 等）
- 环境变量自动读取（`pydantic-settings`）
- JSON 序列化/反序列化
- 更好的错误信息

```python
from pydantic import BaseModel, Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

class Config(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="AI_FRIEND_",
        json_file="config.json",
        json_file_encoding="utf-8",
    )
    
    api_endpoint: str = "https://api.deepseek.com"
    api_key: str = Field(default="", description="DeepSeek API Key. Prefer DEEPSEEK_API_KEY env var.")
    api_model: str = "deepseek-v4-flash"
    api_timeout: int = Field(default=180, ge=1, le=600)
    thinking: str = Field(default="disabled", pattern=r"^(disabled|enabled)$")
    reasoning_effort: str = Field(default="", pattern=r"^(|low|medium|high)$")
    personality_file: str = "personality.json"
    db_path: str = "data/ai_friend.db"
    short_term_capacity: int = Field(default=500, ge=10, le=10000)
    consolidation_interval: int = Field(default=5, ge=1, le=100)
    proactive_min_idle: float = Field(default=180.0, ge=0)
    proactive_max_interval: float = Field(default=600.0, ge=0)
    typing_speed: float = Field(default=0.005, ge=0)
    temperature: float = Field(default=0.8, ge=0.0, le=2.0)
    max_tokens: int = Field(default=512, ge=1, le=8192)
    max_facts: int = Field(default=200, ge=0)
    max_experiences: int = Field(default=100, ge=0)
    max_reflections: int = Field(default=50, ge=0)
    web_host: str = "0.0.0.0"
    web_port: int = Field(default=8000, ge=1, le=65535)
    log_level: str = Field(default="INFO", pattern=r"^(DEBUG|INFO|WARNING|ERROR|CRITICAL)$")
    allowed_read_paths: list[str] = Field(default_factory=lambda: ["."])
    embedding_endpoint: str = "http://localhost:8080/v1/embeddings"
    embedding_dim: int = Field(default=512, ge=64, le=4096)
    embedding_cache_size: int = Field(default=1000, ge=0)
```

### 4.2 环境变量命名规范

建议统一环境变量命名前缀，避免与系统环境变量冲突：

| 当前名称 | 建议名称 | 说明 |
|----------|----------|------|
| `DEEPSEEK_API_KEY` | `AI_FRIEND_API_KEY` 或保留 `DEEPSEEK_API_KEY` | 密钥 |
| `DEEPSEEK_API_ENDPOINT` | `AI_FRIEND_API_ENDPOINT` | 端点 |
| `DEEPSEEK_API_MODEL` | `AI_FRIEND_API_MODEL` | 模型 |
| `AI_FRIEND_DB_PATH` | 保留 | 数据库路径 |
| `AI_FRIEND_LOG_LEVEL` | 保留 | 日志级别 |
| （新增） | `AI_FRIEND_WEB_PORT` | Web 端口 |
| （新增） | `AI_FRIEND_TEMPERATURE` | 温度 |
| （新增） | `AI_FRIEND_MAX_TOKENS` | 最大 token |
| （新增） | `AI_FRIEND_API_TIMEOUT` | 超时 |
| （新增） | `AI_FRIEND_EMBEDDING_ENDPOINT` | 嵌入端点 |

### 4.3 安全配置检查清单

- [ ] `config.json` 中 `api_key` 为空字符串或占位符
- [ ] `.gitignore` 排除所有配置文件变体
- [ ] 日志中不打印任何包含 `api_key`、`secret`、`token` 的配置值
- [ ] 提供 `DEEPSEEK_API_KEY` 环境变量作为首选配置方式
- [ ] 在 `load_config()` 中，若 `api_key` 为空，打印明确警告并建议设置环境变量
- [ ] 考虑使用 `keyring` 库存储密钥

---

## 5. 结论

AI Friend 项目的配置管理系统在功能层面能够支撑当前应用运行，但在工程化、安全性和可维护性方面存在显著不足。最严重的问题是 API Key 的明文存储和配置验证的完全缺失，这两个问题若在生产环境中暴露，将直接导致安全事件和运行时故障。

建议将配置系统的重构列为当前 sprint 的 P0 优先级任务，优先引入 `pydantic` 进行 schema 校验和类型安全，同时强制 API Key 通过环境变量提供。在此基础上，逐步完善热更新机制、测试覆盖和文档一致性，将配置管理系统从"功能可用"提升至"生产就绪"的水平。

---

*报告生成时间：2026-05-31*
*审查工具：Claude Code 深度代码审查*
*关联文档：doc/technical.md、doc/architecture.md、doc/code-review-report-2026-05-28.md*
