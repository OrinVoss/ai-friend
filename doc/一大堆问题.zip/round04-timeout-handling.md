# AI Friend 项目第4轮审查：错误处理与可靠性 —— 超时处理专项

**审查日期**：2026-05-31  
**审查范围**：core/provider.py、tools/web_tools.py、tools/web_fetch.py（不存在，已合并入web_tools.py）、memory/embeddings.py、config.py、storage/database.py、storage/repository.py、core/agent.py、core/tool_agent.py、core/inner_drive.py、core/dispatcher.py、tools/file_tools.py、tools/search_tools.py、tools/music_tool.py、tools/notify_tool.py、web/server.py、web/session.py、memory/long_term.py、memory/short_term.py、memory/retrieval.py、memory/consolidation.py、core/context_manager.py、core/sleep_manager.py、core/proactivity.py、core/message_handler.py  
**审查人**：Claude Code  
**总风险评级**：高（存在多处关键超时缺陷，可能导致系统级阻塞、用户体验劣化、资源泄漏）

---

## 一、概述

本次审查聚焦 AI Friend 项目的超时处理机制，覆盖 API 请求、外部工具调用、嵌入模型服务、数据库操作、WebSocket 通信等全链路。通过对 20 余个核心文件的逐行分析，发现项目在超时处理方面存在系统性薄弱：大量关键路径缺乏超时保护，已有超时参数设置不合理，超时后的降级行为不完整，且多处存在"静默阻塞"风险。具体而言，API 请求的 180 秒统一超时在流式场景下虽可接受，但连接超时与读取超时未分离；外部工具（AnySearch、文件搜索、音乐播放）普遍缺乏独立的执行超时；嵌入模型超时硬编码且未处理降级；数据库操作完全依赖 aiosqlite 的默认行为（无超时）；Web 端的 run_in_executor 调用将同步阻塞代码丢入线程池但无超时控制。这些问题在高负载、网络抖动或下游服务故障时，将导致整个 Agent 状态机冻结、WebSocket 连接无响应、内存持续增长，最终引发服务不可用。

---

## 二、详细发现

### 2.1 API 请求超时（core/provider.py）

#### 2.1.1 超时参数设置与合理性

**文件**：`core/provider.py`，第 12-26 行

```python
class KimiProvider:
    def __init__(self, endpoint: str, api_key: str, model: str,
                 temperature: float = 0.8, max_tokens: int = 2048,
                 thinking: Optional[str] = None,
                 reasoning_effort: Optional[str] = None,
                 timeout: int = 180):
```

**发现**：`timeout=180` 作为单一参数传递给 `requests.Session.post()` 的 `timeout` 参数。根据 requests 库文档，当 `timeout` 为单个浮点数时，它同时作为"连接超时"和"读取超时"使用。这意味着：

- **连接超时 = 180 秒**：如果 DNS 解析或 TCP 三次握手失败，系统会等待整整 3 分钟才抛出 `ConnectionError`。这在网络分区或 API 服务端宕机时是不可接受的——用户会经历 3 分钟的无响应黑屏。
- **读取超时 = 180 秒**：在流式（stream=True）场景下，该值表示两次从底层 socket 读取数据之间的最大间隔。对于长文本生成（如 2048 tokens 的 deepseek-v4-flash），180 秒是合理的；但对于非流式短请求，180 秒过于宽松。

**风险评级**：中-高  
**根因**：连接超时与读取超时未分离。  
**建议**：将 `timeout` 拆分为 `connect_timeout`（建议 10-15 秒）和 `read_timeout`（建议 180-300 秒，流式场景下可更长）。代码应改为：

```python
resp = self.session.post(
    url,
    json=payload,
    stream=True,
    timeout=(self.connect_timeout, self.read_timeout),
)
```

#### 2.1.2 流式响应的读取超时隐患

**文件**：`core/provider.py`，第 107-127 行

```python
full_response = []
for line in resp.iter_lines(decode_unicode=True):
    if not line:
        continue
    if line.startswith("data: "):
        ...
```

**发现**：`iter_lines()` 在生成器内部会触发底层 socket 读取。如果 API 服务端在发送部分数据后"挂起"（例如服务器进程僵死、网络中间件保持连接但不转发数据），`iter_lines()` 将阻塞在 socket 读取上，直到 180 秒读取超时触发。在此期间：

- **CLI 模式**：用户看不到任何输出，光标静止，无法判断是"正在思考"还是"已经卡死"。
- **Web 模式**：WebSocket 的 `_send_segments` 协程被阻塞，无法发送心跳或分段消息，前端可能因超时而断开连接。

更严重的是，`iter_lines()` 的默认 `chunk_size` 为 512 字节，对于中文流式输出，如果服务端以字符为单位发送，`iter_lines()` 可能频繁触发小读取，每次读取都受 180 秒保护，但累积的"空等"时间会很长。

**风险评级**：中  
**建议**：在 `iter_lines()` 循环外层增加一个"整体流式时间上限"（如 300 秒），使用 `signal.alarm`（Unix）或 `threading.Timer`（跨平台）进行软中断，或在协程环境中使用 `asyncio.wait_for` 包装整个生成流程。

#### 2.1.3 重试逻辑中的超时未重置

**文件**：`core/provider.py`，第 57-80 行

```python
for attempt in range(3):
    try:
        return self._do_request(chat_url, payload, stream, on_token)
    except requests.exceptions.ConnectionError as e:
        last_error = e
        wait = 2 ** attempt
        logger.warning(f"[api] connection error attempt={attempt+1}/3 retry_in={wait}s: {e}")
        time.sleep(wait)
```

**发现**：重试时每次都会重新调用 `_do_request`，而 `_do_request` 内部每次都会新建 `session.post()` 调用，因此每次重试都有独立的 180 秒超时窗口。这在逻辑上是正确的。但问题在于：

- **未捕获 `requests.exceptions.Timeout`**：如果超时是 `requests.exceptions.ReadTimeout` 或 `ConnectTimeout`，它们不会被上述 `except` 块捕获，而是直接向上抛出，导致重试机制失效。
- **4xx 错误直接抛出**：对于 HTTP 400（Bad Request），代码在第 67-68 行直接 `raise`，这是正确的（客户端错误不应重试）。但对于 429（Rate Limit），当前代码将其视为 500+ 错误进行重试，实际上 429 应读取 `Retry-After` 头进行智能退避，而非固定指数退避。

**风险评级**：高  
**根因**：`Timeout` 异常未纳入重试逻辑，导致网络瞬断场景下重试机制形同虚设。  
**建议**：

1. 增加 `except requests.exceptions.Timeout as e:` 分支，将其与 `ConnectionError` 同等处理（指数退避重试）。
2. 对 429 状态码进行特殊处理，读取响应头中的 `Retry-After` 值。

#### 2.1.4 超时后的异常传播与用户体验

**文件**：`core/provider.py`，第 79-80 行

```python
logger.error(f"[api] failed after 3 retries: {last_error}")
raise ConnectionError(f"API request failed after 3 retries: {last_error}")
```

**发现**：所有重试耗尽后，抛出 `ConnectionError`。该异常在调用链中的处理情况：

- **Agent._react_loop**（`core/agent.py` 第 127-133 行）：直接调用 `self.provider.generate()`，未捕获 `ConnectionError`，异常将向上传播至 `MessageHandler.handle_message()`。
- **MessageHandler.handle_message**（`core/message_handler.py` 第 64-156 行）：未捕获 `ConnectionError`，异常继续向上。
- **Web 模式**（`web/server.py` 第 40-54 行）：`chat_api` 调用 `agent.process_message()`，未捕获异常，FastAPI 会将其转换为 500 Internal Server Error，但用户只会看到"服务器内部错误"，无法得知是 API 超时。
- **CLI 模式**（`core/cli_controller.py`，未在本次审查范围内，但从架构推断）：异常会直接打印 traceback，用户体验差。

**风险评级**：中  
**建议**：在 `KimiProvider.generate()` 的调用方（如 `Agent._react_loop` 和 `MessageHandler`）增加对 `ConnectionError` 和 `Timeout` 的捕获，返回友好的错误消息（如"AI 服务暂时不可用，请稍后重试"），并记录详细日志供运维排查。

---

### 2.2 工具执行超时

#### 2.2.1 AnySearch API 超时（web_search / web_fetch）

**文件**：`tools/web_tools.py`，第 16-35 行

```python
def _anysearch_api(tool_name: str, arguments: dict) -> dict:
    """Call AnySearch JSON-RPC 2.0 API."""
    api_key = os.environ.get("ANYSEARCH_API_KEY", "")
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {"name": tool_name, "arguments": arguments},
    }
    session = requests.Session()
    session.trust_env = False
    resp = session.post(ANYSEARCH_ENDPOINT, json=payload, headers=headers, timeout=30)
    resp.raise_for_status()
    ...
```

**发现**：

- **timeout=30 秒**：对于搜索和网页提取操作，30 秒是合理的。但同样存在连接超时与读取超时未分离的问题。如果 AnySearch 的 DNS 解析失败，用户将等待 30 秒才收到错误。
- **Session 未复用**：每次调用 `_anysearch_api` 都新建 `requests.Session()`，导致 TCP 连接无法复用（Keep-Alive 失效），增加了每次调用的 TCP 握手时间。虽然对单次调用影响有限，但在 Agent 2 的多轮工具调用中（最多 3 轮 × 3 重试 = 9 次调用），累积延迟显著。
- **无重试机制**：AnySearch API 调用失败（超时、5xx）后，直接抛出异常，由 `WebSearchTool.execute()` 和 `WebFetchTool.execute()` 的 `except Exception` 捕获并返回 `ToolResult.fail`。这意味着 Agent 2 的 `ToolAttemptTracker` 重试机制不会触发——因为工具层已经"吞掉"了异常，返回了一个"失败"的 `ToolResult`。

**风险评级**：中  
**建议**：

1. 将 `timeout=30` 拆分为 `(5, 30)`，连接超时 5 秒，读取超时 30 秒。
2. 将 `session` 提升为模块级单例，复用 TCP 连接。
3. 在 `_anysearch_api` 内部增加对 `requests.exceptions.Timeout` 和 `ConnectionError` 的重试（如 2 次），或在工具层让原始异常向上传播，由 Agent 2 的统一重试机制处理。

#### 2.2.2 文件搜索工具超时（glob / grep）

**文件**：`tools/search_tools.py`

**发现**：`GlobTool.execute()`（第 55-94 行）和 `GrepTool.execute()`（第 143-223 行）均使用 `os.walk()` 遍历文件系统，**没有任何超时保护**。在以下场景中，工具调用将无限期阻塞：

- **GlobTool**：搜索根目录包含大量文件（如 `D:\桌面` 有数十万文件），`os.walk()` 可能耗时数分钟。
- **GrepTool**：在大型目录中搜索正则表达式，如果匹配文件多或文件大，循环可能长时间运行。虽然代码限制了单文件大小（500KB）和结果数量（50 个匹配），但 `os.walk()` 本身的遍历时间无上限。

**风险评级**：高  
**根因**：CPU 密集型/IO 密集型同步操作无超时。  
**建议**：

1. 使用 `signal.alarm`（Unix）或 `threading.Timer` 在工具执行前设置闹钟，超时后抛出异常。
2. 更优雅的做法是将 `GlobTool` 和 `GrepTool` 改为异步实现（`aiofiles` + `asyncio.wait_for`），或在 `execute()` 中使用 `concurrent.futures.ThreadPoolExecutor` 并设置 `future.result(timeout=...)`。
3. 限制 `os.walk()` 的最大遍历深度或最大文件数。

#### 2.2.3 文件读取工具超时（read_file）

**文件**：`tools/file_tools.py`，第 99-191 行

**发现**：`ReadFileTool._read_one()` 使用同步 `open()` 读取文件，无超时。虽然单文件大小被限制在 500KB，且行数限制在 2000 行，读取本身通常很快（<100ms），但在以下场景仍可能阻塞：

- **网络文件系统**：如果 `allowed_read_paths` 包含网络映射驱动器（如 `\\server\share`），`open()` 可能因网络问题阻塞数分钟。
- **管道/设备文件**：如果路径指向一个命名管道或特殊设备，`read()` 可能无限阻塞。

**风险评级**：低-中  
**建议**：对 `open()` 调用增加超时保护，或使用非阻塞 IO。

#### 2.2.4 音乐播放工具超时

**文件**：`tools/music_tool.py`，第 150-155 行

```python
def _play(self, filepath: str, display_name: str) -> ToolResult:
    try:
        os.startfile(filepath)
        return ToolResult.ok(f"正在播放: {display_name}")
    except Exception as e:
        return ToolResult.fail(f"播放失败: {e}")
```

**发现**：`os.startfile()` 在 Windows 上调用 ShellExecute，通常立即返回（异步启动播放器）。但如果文件位于网络共享且播放器需要预加载，`os.startfile()` 可能阻塞。更严重的是，`MusicPlayTool.execute()` 中的文件搜索（第 130-136 行）使用 `os.walk(MUSIC_DIR)` 遍历音乐目录，如果目录庞大，搜索时间无上限。

**风险评级**：低  
**建议**：为 `os.walk()` 搜索阶段增加超时限制（如 10 秒）。

#### 2.2.5 通知工具超时

**文件**：`tools/notify_tool.py`，第 47-67 行

```python
def _show():
    ps = f'...'
    try:
        subprocess.run(
            ['powershell', '-NoProfile', '-Command', ps],
            capture_output=True, timeout=10,
        )
    except Exception:
        pass

t = threading.Thread(target=_show, daemon=True)
t.start()
```

**发现**：这是项目中**唯一正确使用超时**的外部工具调用！`subprocess.run(timeout=10)` 确保 PowerShell 进程不会无限挂起。且通知在后台线程中执行，不阻塞主流程。这是良好的实践，值得其他工具借鉴。

**风险评级**：低（正面案例）

---

### 2.3 嵌入模型超时（memory/embeddings.py）

#### 2.3.1 超时硬编码且无降级

**文件**：`memory/embeddings.py`，第 13-23 行

```python
class EmbeddingEngine:
    def __init__(self, endpoint: str = "http://localhost:8080/v1/embeddings",
                 dim: int = 512, timeout: int = 30):
        self._endpoint = endpoint.rstrip("/")
        self._dim = dim
        self._timeout = timeout
        self._session = requests.Session()
        self._session.trust_env = False
```

**发现**：

- **timeout=30 秒**：作为 `EmbeddingEngine.__init__` 的默认参数，在 `web/session.py` 第 52-55 行实例化时未覆盖，因此使用 30 秒。
- **连接超时与读取超时未分离**：与 API 请求相同的问题。
- **超时后无降级**：`encode()` 方法（第 24-50 行）在超时后抛出异常，由调用方 `MemoryRetriever._hybrid_score()`（`memory/retrieval.py` 第 111-115 行）捕获：

```python
try:
    query_vec = self._embed.encode_single(query)
except Exception as e:
    logger.warning(f"[retrieval] embed failed, fallback to keyword: {e}")
    return self._score_facts(candidates, keywords, query)
```

这是项目中**罕见的正确降级行为**——嵌入失败时回退到纯关键词匹配。但降级只发生在 `MemoryRetriever` 层，对于 `MemoryConsolidator._embed_new_items()`（`memory/consolidation.py` 第 255-297 行），超时异常会被 `except Exception` 捕获并记录日志，导致该批次嵌入失败，但不会阻塞后续流程。

**风险评级**：中  
**建议**：

1. 将 `timeout` 拆分为 `connect_timeout`（5 秒）和 `read_timeout`（30 秒）。
2. 在 `encode()` 内部增加重试机制（如 2 次），因为 llama-server 可能在启动初期不稳定。
3. 考虑在 `encode()` 中使用 `session.post(..., timeout=(connect, read))`。

#### 2.3.2 健康检查超时不一致

**文件**：`memory/embeddings.py`，第 74-83 行

```python
def health_check(self) -> bool:
    try:
        resp = self._session.get(
            self._endpoint.replace("/embeddings", "/health"),
            timeout=5,
        )
        return resp.status_code == 200
    except Exception:
        return False
```

**发现**：健康检查使用 `timeout=5`，这是合理的。但 `replace("/embeddings", "/health")` 是一种脆弱的 URL 构造方式——如果端点路径不以 `/embeddings` 结尾（如用户配置了 `http://localhost:8080/v1/embeddings/` 带斜杠），替换将失败，导致健康检查请求发送到错误 URL，返回 404，进而误判为服务不可用。虽然这属于 URL 构造 bug，但与超时处理密切相关：如果健康检查因 URL 错误而超时，系统会错误地禁用语义搜索，导致所有检索降级为关键词匹配，显著降低 AI 的上下文理解能力。

**风险评级**：中  
**建议**：使用 `urllib.parse.urljoin()` 或手动拼接 `/health` 路径，而非字符串替换。

---

### 2.4 数据库操作超时

#### 2.4.1 aiosqlite 默认无超时

**文件**：`storage/database.py`，第 11-23 行

```python
class Database:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._lock = asyncio.Lock()
        self.conn: aiosqlite.Connection | None = None

    async def open(self) -> None:
        os.makedirs(os.path.dirname(self.db_path) or ".", exist_ok=True)
        self.conn = await aiosqlite.connect(self.db_path)
        self.conn.row_factory = aiosqlite.Row
        await self.conn.execute("PRAGMA journal_mode=WAL")
        await self.conn.execute("PRAGMA foreign_keys=ON")
        await self.initialize()
```

**发现**：`aiosqlite.connect()` 和 `execute()` 均使用 SQLite 的默认行为，**没有任何超时参数**。SQLite 是文件级数据库，通常操作很快（毫秒级），但在以下场景可能阻塞：

- **WAL 模式下的并发写入**：如果另一个进程持有写锁，当前连接的 `execute()` 将阻塞，直到锁释放。在极端情况下（如另一个进程崩溃未释放锁），阻塞可能持续数秒甚至更久。
- **磁盘 IO 饱和**：如果系统磁盘繁忙（如正在进行大文件拷贝），SQLite 的 fsync 操作可能延迟。
- **数据库文件位于网络存储**：如果 `db_path` 指向网络驱动器（如 NAS），所有文件 IO 都受网络延迟影响。

**风险评级**：中  
**建议**：

1. 在 `aiosqlite.connect()` 中设置 `timeout` 参数（如 `timeout=10.0`），该参数控制 SQLite 的 busy timeout，即等待锁释放的最大时间。
2. 在关键操作（如 `cursor()` 上下文管理器）外层使用 `asyncio.wait_for()`，为整个事务设置软超时。

#### 2.4.2 Repository 层无超时封装

**文件**：`storage/repository.py`

**发现**：所有 Repository 方法（`upsert_fact`、`search_facts`、`insert_experience` 等）均直接调用 `async with self.db.cursor()`，未设置任何超时。虽然单个操作通常很快，但在以下场景可能累积阻塞：

- **批量嵌入更新**（`bulk_update_embeddings`，第 189-197 行）：使用 `executemany()` 更新大量行，如果数据量大，可能耗时数秒。
- **Schema 迁移**（`Database.initialize()`，第 47-134 行）：在启动时执行大量 `ALTER TABLE`，如果数据库文件大，可能耗时较长。

**风险评级**：低-中  
**建议**：在 `Repository` 的关键方法（尤其是批量操作）外层使用 `asyncio.wait_for()` 封装。

#### 2.4.3 同步包装器的线程池阻塞

**文件**：`memory/long_term.py`，第 17-26 行

```python
@staticmethod
def _run_sync(coro):
    """Run coroutine in a thread-safe way for sync callers."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return pool.submit(asyncio.run, coro).result()
```

**发现**：`_run_sync` 是 `LongTermMemory` 所有同步方法的底层实现。它使用 `ThreadPoolExecutor` 在一个新线程中运行 `asyncio.run(coro)`，然后调用 `.result()` 阻塞等待完成。**该 `.result()` 调用没有任何超时参数**。如果底层的 SQLite 操作阻塞（如上述的锁等待），`ThreadPoolExecutor` 的线程将被永久占用，且调用方（通常是主线程或 Agent 状态机）将无限期阻塞。

更严重的是，每次调用 `_run_sync` 都新建一个 `ThreadPoolExecutor`（`with ... as pool`），这意味着：

- 如果短时间内有大量同步调用（如 Agent 3 的情绪处理同时触发记忆存储和关系更新），会创建大量线程，增加上下文切换开销。
- 如果某个线程因数据库阻塞而无法退出，`with` 语句的 `__exit__` 将等待所有线程完成，进一步放大阻塞。

**风险评级**：高  
**根因**：线程池无超时，且线程池生命周期管理不当。  
**建议**：

1. 使用模块级单例 `ThreadPoolExecutor`，限制最大线程数（如 `max_workers=4`）。
2. 在 `.result()` 调用中增加超时：`pool.submit(...).result(timeout=10.0)`。
3. 考虑将 `LongTermMemory` 的所有调用方改为异步，彻底消除 `_run_sync` 的需求。

---

### 2.5 Web 端超时

#### 2.5.1 run_in_executor 无超时

**文件**：`web/server.py`，第 46-54 行、第 167-180 行

```python
@app.post("/api/chat")
async def chat_api(body: dict):
    ...
    response = agent.process_message(message)
    ...

# 在 _proactive_loop 中
intent = await loop.run_in_executor(
    None, ag.decide_proactive_action, idle
)
response = await loop.run_in_executor(
    None, agent.process_explore_with_intent, intent
)
```

**发现**：`chat_api` 是异步端点，但直接调用同步的 `agent.process_message()`，这会阻塞事件循环！虽然 FastAPI 运行在 ASGI 服务器上，但如果在异步函数中调用同步代码，整个事件循环会被阻塞，导致其他请求无法处理。

在 `_proactive_loop` 中，代码正确地使用了 `loop.run_in_executor()` 将同步调用委托给线程池，但**没有设置超时**。如果 `agent.process_message()` 或 `decide_proactive_action()` 因 API 超时（180 秒）或数据库阻塞而挂起，`run_in_executor` 的 Future 将永远不会完成，`_proactive_loop` 协程将永远等待，导致：

- **该 session 的主动行为循环永久冻结**，无法发送新的主动消息。
- **线程池中的线程被永久占用**，如果多个 session 同时触发，线程池耗尽，所有新请求被拒绝。

**风险评级**：高  
**根因**：`run_in_executor` 缺少 `asyncio.wait_for()` 包装。  
**建议**：

1. 对所有 `run_in_executor` 调用使用 `asyncio.wait_for()` 包装：

```python
try:
    response = await asyncio.wait_for(
        loop.run_in_executor(None, agent.process_message, message),
        timeout=60.0,
    )
except asyncio.TimeoutError:
    logger.error("Agent processing timed out")
    return {"error": "AI 响应超时，请稍后重试"}
```

2. 将 `agent.process_message()` 重构为真正的异步方法，消除 `run_in_executor` 的需求。

#### 2.5.2 WebSocket 无消息超时

**文件**：`web/server.py`，第 199-249 行

```python
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    ...
    while True:
        raw = await websocket.receive_text()
        ...
```

**发现**：`websocket.receive_text()` 会永远等待客户端发送消息，没有设置任何超时。虽然这在聊天场景下通常是期望行为（保持长连接），但缺乏"心跳检测"机制：

- 如果客户端网络断开（如 WiFi 切换、手机锁屏），TCP 连接可能处于"半开"状态，服务端无法感知，继续占用 session 资源。
- 没有 `ping/pong` 机制（虽然客户端可以发送 `ping` 消息，但服务端未主动发送 ping）。

**风险评级**：中  
**建议**：

1. 使用 `asyncio.wait_for(websocket.receive_text(), timeout=300.0)` 设置接收超时，超时后关闭连接，让客户端重连。
2. 或启用 Starlette/FastAPI 的自动 ping/pong（如果底层支持），或在循环中定期发送 ping 帧。

---

### 2.6 其他超时相关缺陷

#### 2.6.1 ContextManager.compress() 无超时

**文件**：`core/context_manager.py`，第 72-98 行

```python
def _do_compress(self, messages: list[dict]) -> None:
    ...
    try:
        result = self._provider.generate(
            [{"role": "user", "content": CONTEXT_COMPRESS_PROMPT.format(conversation=text)}],
            stream=False,
        )
        ...
    except Exception as e:
        logger.warning(f"Compression failed: {e}")
```

**发现**：上下文压缩调用 `provider.generate()`，使用默认的 180 秒超时。如果压缩触发时 API 已经不稳定，压缩操作将阻塞 180 秒。由于压缩是在 `_build_messages` 中触发的（`core/message_handler.py` 第 287-289 行），这将直接导致用户消息处理延迟 3 分钟。

**风险评级**：中  
**建议**：为压缩操作设置更短的超时（如 30 秒），并在超时后跳过压缩（直接截断历史消息）。

#### 2.6.2 SleepManager.generate_dream() 无超时

**文件**：`core/sleep_manager.py`，第 96-119 行

```python
def generate_dream(self) -> str:
    try:
        ...
        dream = self._provider.generate(
            [{"role": "user", "content": prompt}],
            stream=False, max_tokens=100,
        )
        ...
    except Exception:
        logger.debug("[dream] generation failed")
        return ""
```

**发现**：梦境生成调用 `provider.generate()`，使用默认 180 秒超时。梦境生成是在 `_proactive_loop` 中通过 `run_in_executor` 调用的（`web/server.py` 第 151 行），如果 API 超时，将阻塞主动行为循环 3 分钟。虽然异常被捕获并返回空字符串，但 3 分钟的阻塞已经造成了伤害。

**风险评级**：中  
**建议**：为梦境生成设置更短的超时（如 20 秒），因为梦境是"锦上添花"功能，不应影响核心流程。

#### 2.6.3 MemoryConsolidator 的 LLM 调用无超时

**文件**：`memory/consolidation.py`

**发现**：`analyze_sentiment()`（第 83-96 行）、`_extract_facts()`（第 98-125 行）、`_summarize_experience()`（第 127-167 行）、`_generate_reflection()`（第 169-223 行）均通过 `self.llm()` 调用 LLM，而 `self.llm` 是在 `web/session.py` 第 48-49 行定义的：

```python
def llm_gen(prompt, temperature=0.2):
    return self.provider.generate([{"role": "user", "content": prompt}], stream=False)
```

这意味着所有记忆整合操作都使用默认的 180 秒超时。记忆整合通常在后台触发（如每 3 轮对话一次），如果 API 不稳定，整合操作将阻塞 3 分钟。在 CLI 模式下，这会直接冻结 UI；在 Web 模式下，如果整合是在 `run_in_executor` 中执行的，会占用线程池线程。

**风险评级**：中  
**建议**：为记忆整合的 LLM 调用设置更短的超时（如 30 秒），因为整合是后台任务，失败不应影响主流程。

#### 2.6.4 Proactive loop 的 sleep 间隔不合理

**文件**：`web/server.py`，第 130-196 行

```python
async def _proactive_loop(websocket: WebSocket, session_id: str):
    ...
    await asyncio.sleep(15)
    ...
    await asyncio.sleep(5)
    ...
    await asyncio.sleep(30)
```

**发现**：主动行为循环使用固定 sleep 间隔，没有动态退避机制。如果某次循环因 API 超时而阻塞（通过 `run_in_executor`），sleep 间隔不会生效——阻塞发生在 `sleep` 之前。更严重的是，如果 `run_in_executor` 的 Future 永不完成（如线程死锁），循环将永久冻结，且 `except Exception`（第 194-196 行）无法捕获，因为异常发生在另一个线程中。

**风险评级**：高  
**根因**：`run_in_executor` 无超时，且异常跨线程传播不可靠。  
**建议**：

1. 对所有 `run_in_executor` 使用 `asyncio.wait_for()`。
2. 在 `_proactive_loop` 的最外层增加一个" watchdog "机制：如果某次循环迭代超过 60 秒，强制取消任务并记录错误。

---

## 三、汇总统计

### 3.1 超时问题分布

| 模块 | 文件 | 问题数量 | 最高风险评级 |
|------|------|----------|-------------|
| API 客户端 | core/provider.py | 4 | 高 |
| Web 工具 | tools/web_tools.py | 3 | 中 |
| 文件工具 | tools/file_tools.py | 1 | 低-中 |
| 搜索工具 | tools/search_tools.py | 2 | 高 |
| 音乐工具 | tools/music_tool.py | 1 | 低 |
| 通知工具 | tools/notify_tool.py | 0（正面案例） | 低 |
| 嵌入引擎 | memory/embeddings.py | 2 | 中 |
| 数据库 | storage/database.py | 2 | 中 |
| 数据仓库 | storage/repository.py | 1 | 低-中 |
| 长期记忆 | memory/long_term.py | 1 | 高 |
| Web 服务器 | web/server.py | 3 | 高 |
| 上下文管理 | core/context_manager.py | 1 | 中 |
| 睡眠管理 | core/sleep_manager.py | 1 | 中 |
| 记忆整合 | memory/consolidation.py | 1 | 中 |
| **总计** | **15 个文件** | **23** | **高** |

### 3.2 风险评级汇总

| 风险评级 | 数量 | 占比 | 典型问题 |
|----------|------|------|----------|
| 高 | 5 | 21.7% | run_in_executor 无超时、线程池阻塞、搜索工具无超时、API Timeout 未重试、 proactive loop 冻结 |
| 中 | 12 | 52.2% | 连接/读取超时未分离、数据库无 busy timeout、嵌入超时硬编码、WebSocket 无心跳、压缩/梦境/整合无独立超时 |
| 低-中 | 4 | 17.4% | 文件读取网络路径阻塞、音乐搜索遍历无上限、Repository 批量操作无超时 |
| 低 | 2 | 8.7% | 通知工具（正面案例）、健康检查 URL 构造问题 |

### 3.3 关键缺陷 TOP 5

1. **TOP 1 - web/server.py run_in_executor 无超时（风险：高）**
   - 影响：Web 端所有同步 Agent 调用（process_message、proactive、explore）均通过 run_in_executor 执行，无超时导致线程池线程永久占用，多 session 场景下线程池耗尽，服务完全不可用。
   - 修复优先级：P0

2. **TOP 2 - core/provider.py Timeout 异常未纳入重试（风险：高）**
   - 影响：API 读取超时（ReadTimeout）和连接超时（ConnectTimeout）未被重试逻辑捕获，直接向上抛出，导致用户请求失败，且无法利用指数退避恢复。
   - 修复优先级：P0

3. **TOP 3 - memory/long_term.py 线程池无超时（风险：高）**
   - 影响：`_run_sync` 每次调用都新建 ThreadPoolExecutor 且 `.result()` 无超时，数据库阻塞时主线程永久冻结，且线程泄漏。
   - 修复优先级：P0

4. **TOP 4 - tools/search_tools.py 文件搜索无超时（风险：高）**
   - 影响：`GlobTool` 和 `GrepTool` 使用 `os.walk()` 遍历文件系统，无超时保护。在大目录或网络路径下，工具调用可能阻塞数分钟，且由于工具在 Agent 2 的 ReAct 循环中同步执行，会阻塞整个 Agent 状态机。
   - 修复优先级：P1

5. **TOP 5 - web/server.py WebSocket 无接收超时/心跳（风险：中-高）**
   - 影响：客户端断网后半开连接永久占用 session 资源，无主动检测机制，导致内存泄漏和 session 数无限增长。
   - 修复优先级：P1

---

## 四、修复建议汇总

### 4.1 立即修复（P0）

1. **core/provider.py**：
   - 将 `timeout` 拆分为 `connect_timeout` 和 `read_timeout`。
   - 在重试逻辑中增加 `except requests.exceptions.Timeout` 分支。

2. **web/server.py**：
   - 对所有 `run_in_executor` 调用使用 `asyncio.wait_for()` 包装，设置合理的整体超时（如 60 秒）。
   - `chat_api` 端点也应使用 `run_in_executor` 或重构为异步。

3. **memory/long_term.py**：
   - 使用模块级单例 `ThreadPoolExecutor(max_workers=4)`。
   - 在 `.result()` 中增加 `timeout=10.0`。

### 4.2 短期修复（P1）

4. **tools/search_tools.py**：
   - 为 `GlobTool` 和 `GrepTool` 增加执行超时（如使用 `signal.alarm` 或 `ThreadPoolExecutor` + `future.result(timeout=...)`）。
   - 限制 `os.walk()` 的最大深度或文件数。

5. **web/server.py**：
   - 为 WebSocket `receive_text()` 设置超时，或启用自动 ping/pong。
   - 在 `_proactive_loop` 中增加 watchdog 机制。

6. **tools/web_tools.py**：
   - 将 `timeout=30` 拆分为 `(5, 30)`。
   - 将 `requests.Session()` 提升为模块级单例。

### 4.3 中期优化（P2）

7. **storage/database.py**：
   - 在 `aiosqlite.connect()` 中设置 `timeout=10.0`（busy timeout）。

8. **memory/embeddings.py**：
   - 修复 `health_check()` 的 URL 构造逻辑。
   - 在 `encode()` 中增加重试机制。

9. **core/context_manager.py、core/sleep_manager.py、memory/consolidation.py**：
   - 为非核心 LLM 调用（压缩、梦境、整合）设置更短的独立超时（20-30 秒）。

### 4.4 长期架构改进

10. **全面异步化**：将 Agent 核心流程（Agent 1/2/3 的 `assess()`、`run()`、`_react_loop()`）重构为异步方法，消除 `run_in_executor` 和 `_run_sync` 的需求，从根本上解决线程池阻塞问题。

11. **超时配置中心化**：在 `config.py` 中增加统一的超时配置项（`api_connect_timeout`、`api_read_timeout`、`tool_timeout`、`db_timeout`、`embed_timeout`），避免各模块硬编码。

---

## 五、附录：关键代码行号索引

| 文件 | 行号 | 问题描述 |
|------|------|----------|
| core/provider.py | 16 | timeout=180 单一参数 |
| core/provider.py | 57-80 | 重试逻辑缺少 Timeout 捕获 |
| core/provider.py | 87-92 | session.post timeout 未拆分 |
| core/provider.py | 107-127 | iter_lines 无整体超时保护 |
| tools/web_tools.py | 28-30 | Session 未复用，timeout 未拆分 |
| tools/search_tools.py | 55-94 | GlobTool os.walk 无超时 |
| tools/search_tools.py | 143-223 | GrepTool os.walk 无超时 |
| tools/file_tools.py | 144-150 | open() 无超时 |
| tools/music_tool.py | 130-136 | os.walk 无超时 |
| tools/notify_tool.py | 60-65 | 正面案例：subprocess.run(timeout=10) |
| memory/embeddings.py | 16-20 | timeout 硬编码 |
| memory/embeddings.py | 31-34 | encode() timeout 未拆分 |
| memory/embeddings.py | 74-83 | health_check URL 构造脆弱 |
| storage/database.py | 19 | aiosqlite.connect 无 timeout |
| storage/repository.py | 189-197 | bulk_update_embeddings 无超时 |
| memory/long_term.py | 17-26 | _run_sync 线程池无超时 |
| web/server.py | 46-54 | chat_api 同步调用阻塞事件循环 |
| web/server.py | 167-180 | run_in_executor 无超时 |
| web/server.py | 206-207 | receive_text 无超时 |
| core/context_manager.py | 88-91 | compress() 使用默认 180s 超时 |
| core/sleep_manager.py | 107-110 | generate_dream() 使用默认 180s 超时 |
| memory/consolidation.py | 83-96 | analyze_sentiment() 使用默认 180s 超时 |

---

*本报告基于 2026-05-31 的代码快照生成。建议在修复后重新运行本审查流程，验证修复效果。*
