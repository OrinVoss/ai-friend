# AI Friend 上下文管理数据流深度审查报告（Round 02）

**审查日期**：2026-05-31  
**审查范围**：`core/context_manager.py`、`core/message_handler.py`（`_build_messages`）、`core/agent.py`（`_react_loop`）、`prompts/system.py`（`build_system_prompt`）  
**审查目标**：跟踪上下文从构建到膨胀、压缩、注入的完整数据流，识别信息丢失、压缩质量、token 浪费等风险  
**风险评级**：**高危**（存在多处可能导致上下文窗口溢出、信息丢失、压缩死循环的缺陷）

---

# 概述

AI Friend 项目采用三层 Agent 架构（Agent 1 内驱推理 → Agent 2 工具执行 → Agent 3 人格表达），所有 Agent 共享同一个 LLM Provider（DeepSeek API）。上下文管理的核心职责由 `ContextManager`（`core/context_manager.py`）承担，负责 token 估算、阈值监控和对话历史压缩。`MessageHandler._build_messages()` 负责将 system prompt、对话历史、工具结果组装为最终发送给 LLM 的 messages 列表。`Agent._react_loop()` 在 Agent 3 阶段执行 ReAct 迭代，不断追加 assistant/user 消息到同一 messages 列表中。

本次审查发现 **2 个高危缺陷**、**5 个中危缺陷**、**6 个低危/架构建议项**，总体风险评级为 **高危**。核心问题集中在：

1. **压缩逻辑缺陷**：`ContextManager.compress()` 在压缩后不清除已注入的工具结果消息，导致压缩后的 messages 列表仍包含原始长对话，压缩形同虚设。
2. **Token 估算严重失准**：`estimate_tokens()` 对中文的估算比实际低 30%-50%，且 `_build_messages()` 的溢出检测逻辑存在边界错误，导致压缩触发时机不可预测。
3. **System Prompt 过度膨胀**：`build_system_prompt()` 生成的 system prompt 在典型场景下可达 3000-5000 tokens，占用了 180K 上下文窗口中不可忽略的比例，但压缩阈值计算时未扣除 system prompt 占用。
4. **工具结果注入导致二次膨胀**：Agent 2 返回的工具结果（单条可达 6000 字符/数千 tokens）被作为 user 消息插入 messages，`_react_loop()` 迭代中还会追加工具执行结果，进一步加速上下文膨胀。
5. **压缩质量不可控**：压缩 prompt 要求 100-150 字摘要，但压缩输入被截断至 8000 字符，且使用独立的 LLM 调用生成摘要，摘要质量无法验证，关键信息（如用户明确指令、情感事件）可能丢失。

---

## 数据流图

### 全局上下文数据流（单轮对话）

```
用户输入
    │
    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│  Agent 1: InnerDrive.assess()                                           │
│  ─────────────────────────                                              │
│  build_inner_drive_prompt() → sys_prompt (~2000-4000 tokens)            │
│  messages = [system, user]                                              │
│  provider.generate() → 决策输出                                          │
│  [可选] 内部工具(recall/remember) → messages += [assistant, user]        │
└─────────────────────────────────────────────────────────────────────────┘
    │
    ▼ 需要外部工具？
   否 ──────────────────────→ Agent 3（跳过 Agent 2）
    │
   是
    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│  Agent 2: ToolAgent.run_with_request()                                  │
│  ───────────────────────────────────                                    │
│  build_tool_agent_prompt() → sys_prompt (~200 tokens)                   │
│  messages = [system, user]                                              │
│  provider.generate() → JSON 工具调用                                     │
│  execute_tool_calls() → results                                         │
│  messages += [assistant, user(tool_results)]                            │
│  [循环] 最多 5 次迭代，每次追加 2 条消息                                  │
└─────────────────────────────────────────────────────────────────────────┘
    │
    ▼ tool_records (格式化后的工具结果文本)
    │
    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│  Agent 3: MessageHandler._run_agent3()                                  │
│  ───────────────────────────────────                                    │
│  build_system_prompt() → sys_prompt (~3000-6000 tokens)                 │
│    ├─ 当前时间                                                          │
│    ├─ 人格/情绪/关系状态                                                 │
│    ├─ 长期记忆(facts+experiences+reflections)                            │
│    ├─ 对话示例                                                          │
│    ├─ 情绪行为指令                                                       │
│    ├─ 怨恨/破防状态                                                      │
│    ├─ 工具调用历史                                                       │
│    ├─ 最近对话 (conv_hist, ~3000 chars)                                  │
│    └─ compressed_summary (如有)                                          │
│                                                                         │
│  _build_messages(sys_prompt, user_input)                                │
│    ├─ messages = [system]                                               │
│    ├─ 遍历 short_term (逆序)，逐条插入 messages[1]                       │
│    │   溢出检测: estimate_tokens(last5) + estimate_tokens(turn)         │
│    │   > COMPRESS_THRESHOLD (144000) ? break                            │
│    ├─ overflow 且 compressed_summary 存在?                              │
│    │   → messages.insert(1, system("[对话历史摘要] ..."))                │
│    ├─ user_input tokens + msg_tokens > COMPRESS_THRESHOLD?              │
│    │   → a._context.compress(messages)                                  │
│    └─ messages.append(user_input)                                       │
│                                                                         │
│  工具结果注入:                                                            │
│    if tool_records: messages.insert(-1, user(tool_records))             │
│                                                                         │
│  Agent._react_loop(messages)                                            │
│    ├─ provider.generate(messages) → response                            │
│    ├─ parse_tool_calls(response) → (cleaned, calls)                     │
│    ├─ 无工具调用 → final_text = cleaned, break                          │
│    ├─ 有工具调用 → messages += [assistant(resp), user(tool_results)]    │
│    │   [循环] 最多 _max_tool_iterations (10) 次                          │
│    └─ final_text → short_term.add_turn("assistant", ...)                │
└─────────────────────────────────────────────────────────────────────────┘
```

### 压缩触发逻辑详细数据流

```
_build_messages() 中的溢出检测
─────────────────────────────────

阶段 A: 插入历史对话
  for t in short_term.get_all_reversed():        # 从最新到最旧
      role = "assistant" if t.role == "assistant" else "user"

      # 检测逻辑（第280行）
      estimate_tokens(" ".join(
          m["content"][:200] for m in messages[-5:] if m["role"] != "system"
      )) + estimate_tokens(t.content) > COMPRESS_THRESHOLD ?

      # 问题: messages[-5:] 在循环初期不足5条，取的是已插入的最新消息
      # 问题: 每次只检测 "当前已插入的最后5条 + 下一条"，不是累计总量
      # 问题: 未包含 system prompt 的 token 消耗

      if overflow:
          break
      messages.insert(1, {"role": role, "content": t.content})

阶段 B: 插入摘要（如果溢出且存在 compressed_summary）
  if overflow and a._context.compressed_summary:
      messages.insert(1, {"role": "system",
                          "content": f"[对话历史摘要] {a._context.compressed_summary}"})

阶段 C: 检测是否需要压缩（在追加 user_input 前）
  msg_tokens = sum(estimate_tokens(m["content"][:500]) for m in messages if m["role"] != "system")
  if msg_tokens + estimate_tokens(user_input) > COMPRESS_THRESHOLD:
      a._context.compress(messages)    # ← 调用 ContextManager.compress()

阶段 D: 追加当前输入
  messages.append({"role": "user", "content": user_input})

阶段 E: 工具结果注入（在 _run_agent3 中，第268-269行）
  if tool_records:
      messages.insert(-1, {"role": "user", "content": tool_records})
      # 注意: 此时工具结果可能极长（web_fetch 返回整页 HTML）
      # 但压缩已在阶段 D 完成，工具结果注入后不再检查阈值
```

### ContextManager.compress() 内部数据流

```
ContextManager.compress(messages)
│
├─ 递归守卫: if self._compressing: return
├─ self._compressing = True
│
├─ _do_compress(messages):
│   ├─ 过滤 role == "system" 的消息
│   ├─ 每条内容截断至 500 字符（超长加 "..."）
│   ├─ 格式化为 "用户: xxx" / "你: xxx"
│   ├─ 总文本截断至 8000 字符（取最后 8000）
│   │
│   ├─ 构建压缩 prompt:
│   │   CONTEXT_COMPRESS_PROMPT.format(conversation=text)
│   │   → "请将以下对话压缩为一段简洁的对话历史摘要..."
│   │
│   ├─ provider.generate([user_msg(压缩prompt)], stream=False)
│   │   → result (100-150 字摘要)
│   │
│   ├─ if result.strip():
│   │       self._compressed_summary = result.strip()
│   │       self._estimated_tokens_used = 0
│   │       self._short_term.clear()          # ← 清空短期记忆！
│   │       logger.info(...)
│   │
│   └─ except Exception: logger.warning(...)
│
└─ self._compressing = False

# 关键问题: compress() 接收 messages 参数，但:
#   1. 只从中读取内容生成摘要
#   2. 生成的摘要存入 self._compressed_summary
#   3. 清空 self._short_term
#   4. 但不清除传入的 messages 列表中的历史消息！
#   5. _build_messages() 在 compress() 返回后继续使用同一个 messages 列表
```

---

## 详细发现

### 一、压缩逻辑缺陷（高危 ×2）

#### 【高危-1】`compress()` 不清除传入的 `messages` 列表，压缩后原始长对话仍被发送给 LLM

**文件**：`D:\桌面\编程作品\AI朋友\core\context_manager.py:62-98`

**代码分析**：

```python
# context_manager.py:62-98
class ContextManager:
    def compress(self, messages: list[dict]) -> None:
        if self._compressing:
            return
        self._compressing = True
        try:
            self._do_compress(messages)
        finally:
            self._compressing = False

    def _do_compress(self, messages: list[dict]) -> None:
        parts = []
        for m in messages:
            if m["role"] == "system":
                continue
            content = m["content"]
            if len(content) > 500:
                content = content[:500] + "..."
            parts.append(f"{'用户' if m['role'] == 'user' else '你'}: {content}")
        text = "\n".join(parts)
        # ... 调用 LLM 生成摘要 ...
        if result.strip():
            self._compressed_summary = result.strip()
            self._estimated_tokens_used = 0
            self._short_term.clear()          # 清空短期记忆
```

**问题分析**：

1. `compress()` 接收 `messages` 列表，但仅从中读取内容生成摘要。摘要生成后存入 `self._compressed_summary`，同时清空 `self._short_term`。
2. **致命缺陷**：`compress()` **没有修改传入的 `messages` 列表**。`_build_messages()` 在调用 `a._context.compress(messages)` 后，继续使用同一个 `messages` 列表（第289行调用 compress，第290行 append user_input）。
3. 这意味着：即使压缩被触发，`messages` 列表中仍然包含所有原始的长对话消息。压缩的唯一效果是清空了 `short_term`（影响下一轮对话），但当前轮次的 LLM 请求仍然携带完整的、未压缩的对话历史。
4. 更严重的是，`_build_messages()` 在压缩后还会 append 当前 user_input，然后 `_run_agent3()` 再 insert 工具结果。最终发送给 LLM 的 messages 列表长度完全没有减少。

**风险**：压缩机制完全失效。当对话历史累积到阈值时，每次请求都会触发一次无意义的 LLM 压缩调用（消耗 API tokens 和时间），但实际发送的上下文仍在持续增长，最终必然导致 API 返回 413/400 错误（上下文长度超限）。

**建议**：
- `compress()` 应返回新的 messages 列表，或就地修改传入的列表：移除所有非 system 的历史消息，仅保留 system prompt 和新生成的摘要消息。
- 修改后的逻辑应为：
  ```python
  def compress(self, messages: list[dict]) -> None:
      # ... 生成摘要 ...
      # 就地清理 messages：只保留 system 消息
      messages[:] = [m for m in messages if m["role"] == "system"]
      # 插入摘要作为 system 消息
      if self._compressed_summary:
          messages.insert(1, {"role": "system",
                              "content": f"[对话历史摘要] {self._compressed_summary}"})
  ```

---

#### 【高危-2】`_build_messages()` 的溢出检测逻辑存在边界错误，压缩触发时机不可预测

**文件**：`D:\桌面\编程作品\AI朋友\core\message_handler.py:274-291`

**代码分析**：

```python
# message_handler.py:280-282
for t in a.short_term.get_all_reversed():
    role = "assistant" if t.role == "assistant" else "user"
    if estimate_tokens(" ".join(m["content"][:200] for m in messages[-5:] if m["role"] != "system")) + estimate_tokens(t.content) > COMPRESS_THRESHOLD:
        overflow = True
        break
    messages.insert(1, {"role": role, "content": t.content})
```

**问题分析**：

1. **检测对象错误**：`messages[-5:]` 取的是 messages 列表的最后 5 条。但在循环初期，messages 中只有 `[system]`，随后每次 `insert(1, ...)` 将新消息插入到索引 1 的位置。因此 `messages[-5:]` 实际上取的是**最近插入的 5 条历史消息**（即最新的对话），而不是**全部已插入消息**。
2. **检测逻辑错误**：条件判断的是 `"最近5条消息的 content 前200字符拼接" + "当前这条消息的完整 content"` 是否超过阈值。这不是累计 token 数的判断，而是一种奇怪的"滑动窗口"判断。它可能导致：
   - 早期消息被跳过检测（因为 `messages[-5:]` 始终只关注最新5条）
   - 某条特别长的消息单独触发溢出，但前面已经插入了很多消息，累计早已超标
3. **阈值常量使用错误**：`COMPRESS_THRESHOLD = 144_000`（180K 的 80%）。但 `_build_messages()` 中的检测比较的是 `estimate_tokens(...)` 的返回值与 144000 的比较。由于 `estimate_tokens()` 对中文严重低估（见下文），实际 token 数可能已经达到 20 万，但估算值仍显示 8 万，不会触发压缩。
4. **未包含 system prompt**：`build_system_prompt()` 生成的 system prompt 在典型场景下为 3000-6000 tokens（中文），但溢出检测完全忽略了这部分占用。

**风险**：压缩可能在上下文已经严重溢出后才触发，或者永远不该触发的时候触发（因为检测逻辑错误）。在极端情况下，单轮请求可能直接超出模型上下文上限，导致 API 报错。

**建议**：
- 改为累计 token 估算：维护一个 `total_tokens` 变量，每次插入消息后累加 `estimate_tokens(t.content)`。
- 将 system prompt 的 token 消耗计入初始值。
- 明确区分 "警告阈值"（如 120K，开始考虑压缩）和 "强制压缩阈值"（如 160K，必须压缩）。

---

### 二、Token 估算失准（中危 ×2）

#### 【中危-1】`estimate_tokens()` 对中文文本的估算严重偏低

**文件**：`D:\桌面\编程作品\AI朋友\core\context_manager.py:27-35`

**代码分析**：

```python
# context_manager.py:27-35
def estimate_tokens(text: str) -> int:
    tok = _get_tokenizer()
    if tok:
        return len(tok.encode(text, disallowed_special=()))
    cjk = sum(1 for c in text if '一' <= c <= '鿿' or '　' <= c <= '〿')
    ascii_chars = sum(1 for c in text if c.isascii() and c.isalpha())
    digits = sum(1 for c in text if c.isdigit())
    other = len(text) - cjk - ascii_chars - digits
    return max(1, int(cjk / 1.5 + ascii_chars / 4 + digits / 3 + other / 8))
```

**问题分析**：

1. **回退估算公式的问题**：当 `tiktoken` 不可用时（如未安装），回退公式将 CJK 字符按 `1/1.5 ≈ 0.67` tokens/字计算。但 DeepSeek 使用的 tokenizer（基于 Qwen 或类似）对中文的实际编码约为 **0.6-0.8 tokens/字**，取决于具体字符。这个估算看似合理，但存在以下问题：
   - 未考虑中英混合时的边界效应（英文单词在中文文本中通常被单独编码）。
   - `other` 类别（标点、空格、特殊符号）按 `1/8 = 0.125` tokens/字符计算，严重偏低。实际上标点和空格通常各占 1 token。
2. **`tiktoken` 编码的问题**：即使 `tiktoken` 可用，`cl100k_base` 是 GPT-4 的编码器，与 DeepSeek 的 tokenizer 并不完全相同。DeepSeek 的 tokenizer 对中文的压缩率通常比 `cl100k_base` 更高（即相同中文字符数，DeepSeek 的 token 数更少），但差异不大（约 5-10%）。
3. **更严重的问题**：`_build_messages()` 中多处使用 `estimate_tokens(m["content"][:200])` 和 `estimate_tokens(m["content"][:500])`，只估算内容的前 200/500 字符，而不是完整内容。这导致长消息（如工具结果、长用户输入）的 token 消耗被严重低估。

**实测估算偏差**：

假设一段典型的中文对话（含标点、少量英文）：
- 1000 中文字符
- `estimate_tokens()` 回退估算：`1000 / 1.5 ≈ 667` tokens
- 实际 DeepSeek tokenizer：`1000 * 0.7 ≈ 700` tokens（接近）
- 但如果包含 200 个标点：`estimate_tokens` 将标点算入 `other`，`200 / 8 = 25` tokens
- 实际标点通常各 1 token：`200` tokens
- **偏差：低估约 175 tokens（25%）**

对于工具结果（如 `web_fetch` 返回的 HTML），含有大量 `<div>`、`<p>`、英文标签等：
- 1000 字符的 HTML
- `estimate_tokens()`：`ascii_chars / 4 + other / 8 ≈ 250 + 50 = 300` tokens
- 实际：HTML 标签每个通常 1-3 tokens，英文单词平均 1.3 tokens/词
- **偏差：可能低估 50% 以上**

**风险**：token 估算系统性偏低导致压缩阈值形同虚设，上下文可能在"估算安全"的情况下实际溢出。

**建议**：
- 如果项目使用 DeepSeek API，应优先使用 DeepSeek 的 tokenizer（可通过其 Python SDK 或在线工具获取）。
- 至少修正回退公式：`other` 类别应按 1 token/字符计算（标点和空格都是 1 token）。
- `_build_messages()` 中的溢出检测应使用完整内容长度，而非 `[:200]` 或 `[:500]` 截断。

---

#### 【中危-2】`_build_messages()` 多处截断内容后估算，长消息 token 消耗被隐藏

**文件**：`D:\桌面\编程作品\AI朋友\core\message_handler.py:280, 287`

**代码分析**：

```python
# 第280行：溢出检测时只取 messages[-5:] 的 content[:200]
estimate_tokens(" ".join(m["content"][:200] for m in messages[-5:] if m["role"] != "system"))

# 第287行：计算 msg_tokens 时只取 content[:500]
msg_tokens = sum(estimate_tokens(m["content"][:500]) for m in messages if m["role"] != "system")
```

**问题分析**：

1. 在循环插入历史对话时，检测条件只查看已插入消息的前 200 字符。如果某条历史消息本身有 2000 字符，其 token 消耗可能高达 1500+，但检测时只估算前 200 字符（约 150 tokens）。
2. 在最终检测（阶段 C）时，`msg_tokens` 只累加各消息的前 500 字符。如果 messages 中包含一条 6000 字符的工具结果，实际 token 消耗约 4000+，但估算只按 500 字符计算（约 350 tokens），**低估约 3650 tokens**。
3. 这种截断估算的设计意图可能是"性能优化"，但在上下文管理中，这完全破坏了阈值检测的可靠性。

**风险**：长消息（尤其是工具结果）的 token 消耗被系统性隐藏，导致阈值检测失效。

**建议**：
- 移除所有 `[:200]` 和 `[:500]` 截断，使用完整内容进行 token 估算。
- 如果性能是顾虑，可以缓存每条消息的 token 估算值（`ConversationBuffer` 的 `Turn` 对象中增加 `estimated_tokens` 字段）。

---

### 三、System Prompt 与 Token 分配（中危 ×2）

#### 【中危-3】`build_system_prompt()` 生成的 system prompt 过大，且未计入阈值计算

**文件**：`D:\桌面\编程作品\AI朋友\prompts\system.py:211-520`

**问题分析**：

1. `build_system_prompt()` 构建的 prompt 包含以下大块内容：
   - 人格定义（名字、特质、说话风格、背景故事、兴趣）
   - 对话示例（5 组示例，每组 2-3 种回复变体）
   - 当前情绪状态（含 15 种情绪的描述映射、VAD 值、行为指令）
   - 怨恨状态（条件注入）
   - 情绪事件记忆（最多 3 条未解决事件）
   - 关系上下文（4 个维度）
   - 长期记忆（最多 10 条 facts、5 条 experiences、3 条 reflections）
   - 梦境（条件注入）
   - 压缩摘要（如有）
   - 可用工具说明（含示例）
   - 工具调用历史（最多 5 条）
   - 最近对话（`conversation_history`，传入参数）
   - 破防状态指令（条件注入，大量文本）
   - 最终指令块

2. 估算典型场景下的 system prompt 大小：
   - 人格定义：约 200 字 → ~150 tokens
   - 对话示例：约 800 字 → ~600 tokens
   - 情绪状态：约 400 字 → ~300 tokens
   - 长期记忆（10 facts + 5 experiences）：约 1000 字 → ~750 tokens
   - 关系 + 工具历史 + 其他：约 500 字 → ~400 tokens
   - **总计：约 3000-3500 tokens**

3. 在 `_build_messages()` 的所有阈值检测中，system prompt 的 token 消耗**完全未被计入**。`messages` 初始为 `[{"role": "system", "content": sys_prompt}]`，但后续所有 `estimate_tokens()` 调用都通过 `if m["role"] != "system"` 过滤掉了 system 消息。

**风险**：system prompt 实际占用 3000+ tokens，但阈值计算假设它为 0。这意味着当估算值显示"还有 10K 余量"时，实际余量可能只有 7K。

**建议**：
- 在 `_build_messages()` 开始时计算 `system_tokens = estimate_tokens(sys_prompt)`，并将其作为 `total_tokens` 的初始值。
- 考虑为 system prompt 设置预算上限（如 max 4000 tokens），对动态内容（如 facts、experiences）进行截断或优先级排序。

---

#### 【中危-4】`conversation_history` 在 system prompt 和 messages 中重复出现

**文件**：`D:\桌面\编程作品\AI朋友\prompts\system.py:433-434`、`core/message_handler.py:254, 274-283`

**代码分析**：

```python
# prompts/system.py:433-434
blocks.append("=== 最近对话 ===")
blocks.append(conversation_history or "(还没有对话)")

# message_handler.py:254
conv_hist = a.short_term.format_for_prompt(max_chars=3000)

# message_handler.py:274-283
for t in a.short_term.get_all_reversed():
    role = "assistant" if t.role == "assistant" else "user"
    # ... 插入到 messages 中 ...
```

**问题分析**：

1. `build_system_prompt()` 接收 `conversation_history` 参数（`short_term.format_for_prompt(max_chars=3000)`），将其作为文本块嵌入 system prompt。
2. 同时，`_build_messages()` 遍历 `short_term.get_all_reversed()`，将每条 turn 作为独立的 user/assistant 消息插入 messages 列表。
3. 这意味着**同一段对话历史在最终的 LLM 请求中出现了两次**：
   - 一次在 system prompt 中（格式化的文本块）
   - 一次在 messages 的对话消息序列中
4. 这种重复不仅浪费 token（相同的对话内容被编码两次），还可能让模型困惑（"为什么 system 里有一段对话，messages 里又有同样的对话？"）。

**风险**：token 浪费（重复内容约占 10-20% 的总上下文），可能降低模型对消息结构的理解。

**建议**：
- 二选一：要么将对话历史放在 system prompt 中（适合少量历史），要么放在 messages 中（适合完整历史）。不要两者同时存在。
- 推荐方案：移除 system prompt 中的 `conversation_history` 块，仅保留 messages 中的对话序列。system prompt 中可以用一句话提示"请参考前面的对话历史"。

---

### 四、工具结果注入后的上下文膨胀（中危 ×1）

#### 【中危-5】工具结果在压缩后注入，且注入后不再检查阈值，导致单轮溢出

**文件**：`D:\桌面\编程作品\AI朋友\core\message_handler.py:268-269`、`core/tool_agent.py:226-249`

**代码分析**：

```python
# message_handler.py:268-269
if tool_records:
    messages.insert(-1, {"role": "user", "content": tool_records})

# tool_agent.py:242-244
parts.append(
    f"[工具 {i}] {r.name}（{status}，{entry_count} 条结果）:\n"
    f"{r.output[:6000]}\n"
)
```

**问题分析**：

1. 工具结果在 `_run_agent3()` 中注入，时间点是在 `_build_messages()` 完成之后（即压缩逻辑已经执行）。
2. `tool_records` 的构建逻辑：`format_for_phase2()` 将每个工具记录的 `output[:6000]` 拼接成一大段文本。如果 Agent 2 执行了 3 个工具，每个输出 6000 字符，总工具结果可达 18000+ 字符，约合 **12000+ tokens**。
3. 注入后，`messages` 列表的总 token 数可能瞬间从"压缩后的安全值"跃升到"超出模型上限"。但代码中没有任何后续检查。
4. 更危险的是，`Agent._react_loop()` 在 Agent 3 阶段还会执行内部工具（recall/remember），每次工具调用会追加 `assistant` 消息和 `user` 消息（工具结果），进一步膨胀上下文。

**风险**：单轮对话中，工具结果可能直接将上下文推过 180K 上限，导致 API 返回 400/413 错误。由于错误处理在 `provider.py` 中只重试连接错误，HTTP 400 会直接抛出异常，导致对话中断。

**建议**：
- 在工具结果注入前，检查 `current_tokens + estimate_tokens(tool_records)` 是否超过阈值。
- 如果超过，对工具结果进行截断或摘要（优先保留成功工具的结果，失败工具的详细错误信息可以截断）。
- 在 `format_for_phase2()` 中增加总长度限制（如单轮工具结果总计不超过 8000 tokens）。

---

### 五、压缩质量与信息丢失（低危 ×3）

#### 【低危-1】压缩输入被截断至 8000 字符，早期对话信息必然丢失

**文件**：`D:\桌面\编程作品\AI朋友\core\context_manager.py:85-86`

**代码分析**：

```python
# context_manager.py:85-86
if len(text) > 8000:
    text = text[-8000:]
```

**问题分析**：

1. 压缩逻辑在将对话历史拼接为文本后，如果总长度超过 8000 字符，直接截取最后 8000 字符作为压缩输入。
2. 这意味着**超过 8000 字符的早期对话完全被丢弃**，不会进入压缩摘要。
3. 如果用户在对话早期给出了关键指令（如"请记住我是医生，不要给我医疗建议"），而后续对话较长，这条关键指令可能在压缩后丢失。
4. 8000 字符约等于 5000-6000 tokens（中文），对于 180K 的上下文窗口来说，这个截断值过于保守。压缩输入应该尽可能多地保留原始内容，或者采用分层压缩策略（先压缩早期对话，再与近期对话合并）。

**建议**：
- 将 8000 字符限制提升至 30000-40000 字符（约 20K-25K tokens），或根据实际上下文余量动态计算。
- 或者，采用分层压缩：将对话分为"近期"（保留完整）和"远期"（压缩为摘要），而不是全部扔进一个压缩 prompt。

---

#### 【低危-2】压缩摘要长度要求（100-150 字）过短，无法承载复杂对话的关键信息

**文件**：`D:\桌面\编程作品\AI朋友\prompts\system.py:11-19`

**代码分析**：

```python
# prompts/system.py:11-19
CONTEXT_COMPRESS_PROMPT = """请将以下对话压缩为一段简洁的对话历史摘要。
保留重要信息：用户的关键事实、讨论过的话题、情感变化。
摘要在100-150字之间，用第三人称。

对话：
{conversation}

摘要：
"""
```

**问题分析**：

1. 压缩 prompt 要求摘要控制在 100-150 字之间。对于 8000 字符（约 20-30 轮对话）的输入，150 字的摘要信息密度极高。
2. LLM 在执行这种高度压缩时，通常会：
   - 保留话题名称，丢弃具体细节
   - 保留情感走向，丢弃具体事件
   - 可能完全遗漏用户的关键声明或约束
3. 压缩摘要在后续轮次中作为 system prompt 的一部分注入（`[对话历史摘要] xxx`），但 system prompt 本身已经很长，摘要的权重可能被稀释。

**建议**：
- 增加摘要长度限制至 300-500 字，允许更详细的信息保留。
- 或者，采用结构化摘要（如 JSON 格式），明确保留：讨论话题列表、用户关键声明、未完成任务、情感状态变化。

---

#### 【低危-3】压缩失败时无降级策略，`compressed_summary` 保持旧值或为空

**文件**：`D:\桌面\编程作品\AI朋友\core\context_manager.py:97-98`

**代码分析**：

```python
# context_manager.py:97-98
except Exception as e:
    logger.warning(f"Compression failed: {e}")
```

**问题分析**：

1. 如果压缩调用失败（如 API 超时、网络错误），`compress()` 仅记录 warning，不做任何处理。
2. 此时 `self._compressed_summary` 保持之前的值（可能是过期的旧摘要），或者为空（如果从未压缩成功过）。
3. 在 `_build_messages()` 中，如果 `overflow` 为 True 但 `compressed_summary` 为空，不会插入摘要消息（第284行：`if overflow and a._context.compressed_summary:`）。这意味着对话历史被截断，但没有摘要补充，信息完全丢失。
4. 如果 `compressed_summary` 是旧值，后续轮次会基于过期的摘要继续对话，可能导致上下文脱节。

**建议**：
- 压缩失败时，应尝试简单的启发式摘要（如保留最近 3 轮对话，丢弃更早的）。
- 或者，标记压缩失败状态，在下一轮对话中优先重试压缩。
- 至少应在压缩失败时清空 `short_term`（与压缩成功时一致），避免"半压缩"状态。

---

### 六、_react_loop 中的上下文膨胀（低危 ×2）

#### 【低危-4】`Agent._react_loop()` 迭代中追加消息但无 token 检查，长 ReAct 链可能溢出

**文件**：`D:\桌面\编程作品\AI朋友\core\agent.py:119-181`

**代码分析**：

```python
# agent.py:127-170
for _idx in range(self._max_tool_iterations):  # 最多 10 次
    resp = self.provider.generate(messages, ...)
    cleaned, calls = parse_tool_calls(resp)
    if not calls:
        final_text = cleaned
        break
    messages.append({"role": "assistant", "content": resp})
    results = execute_tool_calls(registry, calls)
    messages.append({"role": "user", "content": format_tool_results(results)})
```

**问题分析**：

1. `_react_loop()` 是 Agent 3 的核心循环，处理内部工具调用（recall/remember）。每次迭代追加 2 条消息（assistant 的原始响应 + user 的工具结果）。
2. 如果模型在某一轮陷入循环（如反复调用 recall 查找不存在的信息），10 次迭代可能追加 20 条消息，每条消息数百至数千 tokens。
3. 循环内部没有任何 token 计数或阈值检查。即使初始 messages 在阈值内，迭代过程中也可能溢出。
4. 工具结果 `format_tool_results()` 包含铁律提示（"以上是工具返回的真实内容..."），每次迭代都重复这段文本，进一步浪费 token。

**建议**：
- 在每次迭代开始时检查当前 messages 的 token 数，如果超过阈值则强制 break。
- 对工具结果进行截断（如单条工具结果不超过 1000 tokens）。
- 考虑将"铁律"提示从每次迭代的工具结果中移除，改为在 system prompt 中声明一次。

---

#### 【低危-5】`_react_loop()` 的 stream 参数在迭代中切换，首条消息 streaming 但后续不流式

**文件**：`D:\桌面\编程作品\AI朋友\core\agent.py:129-133`

**代码分析**：

```python
# agent.py:129-133
resp = self.provider.generate(
    messages, stream=False if _idx > 0 else True,
    on_token=on_token if _idx == 0 else None,
    max_tokens=max_tok if _idx == 0 else max(384, max_tok * 2 // 3),
)
```

**问题分析**：

1. 只有 `_idx == 0`（第一次迭代）时启用 streaming，后续迭代都使用 `stream=False`。
2. 这意味着如果 Agent 3 在第一轮输出中调用了工具（如 recall），用户会看到第一轮响应的流式输出（可能是空或部分文本），然后连接暂停（等待工具执行），接着第二轮非流式响应直接返回完整文本。
3. 从用户体验角度，这种"流式→暂停→一次性输出"的切换很突兀。但从上下文管理角度，这不是严重问题。
4. 更关键的是：`stream=False` 时，`provider.generate()` 会等待完整响应后才返回。如果响应较长（如模型在工具调用前输出了大量推理文本），会阻塞更久，且这些文本全部计入上下文。

**建议**：
- 统一 streaming 行为，或至少在后续迭代中也使用 streaming（即使不传递 `on_token`）。
- 在 `_react_loop()` 中增加对 assistant 响应长度的限制（如超过 2000 tokens 则截断）。

---

### 七、其他发现（低危 ×1）

#### 【低危-6】`ContextManager` 的 `estimated_tokens_used` 属性未被实际使用

**文件**：`D:\桌面\编程作品\AI朋友\core\context_manager.py:38-60`

**代码分析**：

```python
# context_manager.py:38-60
class ContextManager:
    def __init__(self, provider, short_term: ConversationBuffer):
        self._estimated_tokens_used: int = 0

    @property
    def estimated_tokens(self) -> int:
        return self._estimated_tokens_used

    def reset_estimate(self, count: int) -> None:
        self._estimated_tokens_used = count

    def add_estimate(self, tokens: int) -> None:
        self._estimated_tokens_used += tokens
```

**问题分析**：

1. `ContextManager` 维护了 `_estimated_tokens_used` 字段，提供了 `reset_estimate()` 和 `add_estimate()` 方法，但在整个代码库中**没有任何调用点**使用这些方法。
2. `_build_messages()` 中的 token 估算都是临时计算的，不更新 `ContextManager` 的状态。
3. 压缩成功后（第94行），`self._estimated_tokens_used = 0` 被设置，但这只是将未使用的字段归零。

**风险**：无直接风险，但属于设计债务。如果未来计划使用 `ContextManager` 进行全局 token 追踪，需要重新设计其接口。

**建议**：
- 要么移除未使用的字段和方法，简化 `ContextManager`。
- 要么将其整合到 `_build_messages()` 中，让 `ContextManager` 成为真正的"token 预算管理员"，在每次构建消息时更新和检查预算。

---

## 汇总统计

### 风险分级

| 级别 | 数量 | 编号 | 核心问题 |
|------|------|------|----------|
| 高危 | 2 | 高危-1、高危-2 | 压缩逻辑完全失效（不清除 messages）、溢出检测边界错误 |
| 中危 | 5 | 中危-1~5 | Token 估算失准、system prompt 未计入、对话历史重复、工具结果注入后无检查 |
| 低危 | 6 | 低危-1~6 | 压缩输入截断过短、摘要长度过短、压缩失败无降级、ReAct 链无 token 检查、stream 切换、未使用字段 |

### 核心问题地图

```
上下文管理数据流
│
├─ 构建阶段 (_build_messages)
│   ├── [高危] compress() 不清除 messages → 压缩形同虚设
│   ├── [高危] 溢出检测逻辑错误 → 压缩触发时机不可预测
│   ├── [中危] system prompt 未计入 token 预算 → 实际余量被高估 3000+
│   ├── [中危] 对话历史在 system + messages 中重复 → token 浪费 10-20%
│   └── [中危] 截断估算 [:200]/[:500] → 长消息 token 被隐藏
│
├─ 膨胀阶段 (工具结果注入 + ReAct 迭代)
│   ├── [中危] 工具结果在压缩后注入，注入后无检查 → 单轮溢出风险
│   └── [低危] _react_loop 迭代无 token 检查 → 长 ReAct 链可能溢出
│
├─ 压缩阶段 (ContextManager.compress)
│   ├── [低危] 输入截断至 8000 字符 → 早期信息丢失
│   ├── [低危] 摘要限制 100-150 字 → 信息密度过高，关键细节丢失
│   ├── [低危] 压缩失败无降级 → 可能进入"半压缩"状态
│   └── [中危] 回退 token 估算公式偏差 → 系统性低估 20-50%
│
└─ 注入阶段 (system prompt 组装)
    ├── [中危] build_system_prompt 过大 (3000+ tokens) → 挤压对话空间
    └── [低危] ContextManager.estimated_tokens 未使用 → 设计债务
```

### 修复优先级建议

**P0（立即修复）**：
1. **修复 `compress()` 使其真正清理 messages 列表**。压缩后应移除所有非 system 的历史消息，仅保留 system prompt 和摘要。
2. **重写 `_build_messages()` 的溢出检测逻辑**。使用累计 token 估算（含 system prompt），移除 `[:200]`/`[:500]` 截断。

**P1（本周修复）**：
3. **修正 `estimate_tokens()` 回退公式**。将 `other / 8` 改为 `other * 1.0` 或更合理的估算。
4. **移除 system prompt 中的 `conversation_history` 重复内容**。仅在 messages 中保留对话序列。
5. **在工具结果注入前增加 token 检查**。如果工具结果过长，进行截断或摘要。

**P2（下个迭代）**：
6. **增加压缩失败降级策略**。失败时保留最近 3 轮对话，丢弃更早的。
7. **提升压缩输入限制**。从 8000 字符提升至 30000+，或动态计算。
8. **增加 `_react_loop()` 的 token 检查**。每轮迭代前检查预算，超限时强制 break。
9. **为 `build_system_prompt()` 设置预算上限**。对动态内容（facts、experiences）按优先级截断。

**P3（技术债务）**：
10. 清理 `ContextManager` 中未使用的 `estimated_tokens_used` 相关代码。
11. 考虑引入真正的 tokenizer（如 DeepSeek 官方 tokenizer）替代估算。
12. 评估是否将压缩摘要改为结构化格式（JSON），提升信息保留率。

---

### 附录：关键代码行号速查

| 文件 | 行号 | 内容 |
|------|------|------|
| `core/context_manager.py` | 7-8 | `_MODEL_CONTEXT = 180_000; COMPRESS_THRESHOLD = 144_000` |
| `core/context_manager.py` | 27-35 | `estimate_tokens()` 实现 |
| `core/context_manager.py` | 62-98 | `ContextManager.compress()` 和 `_do_compress()` |
| `core/context_manager.py` | 85-86 | 压缩输入截断至 8000 字符 |
| `core/context_manager.py` | 93-95 | 压缩成功后清空 short_term，但不清理 messages |
| `core/message_handler.py` | 254 | `conv_hist = a.short_term.format_for_prompt(max_chars=3000)` |
| `core/message_handler.py` | 268-269 | 工具结果注入 messages |
| `core/message_handler.py` | 274-291 | `_build_messages()` 完整实现 |
| `core/message_handler.py` | 280 | 溢出检测（只取 messages[-5:] 的 [:200]） |
| `core/message_handler.py` | 284-285 | 溢出后插入 compressed_summary |
| `core/message_handler.py` | 287-289 | 最终 token 检测（只取 [:500]）和 compress() 调用 |
| `core/agent.py` | 119-181 | `_react_loop()` 完整实现 |
| `core/agent.py` | 129-133 | stream 参数在迭代中切换 |
| `core/agent.py` | 159-170 | 每次迭代追加 assistant + user 消息 |
| `prompts/system.py` | 11-19 | `CONTEXT_COMPRESS_PROMPT` |
| `prompts/system.py` | 211-520 | `build_system_prompt()` 完整实现 |
| `prompts/system.py` | 401-404 | compressed_summary 注入 system prompt |
| `prompts/system.py` | 433-434 | conversation_history 注入 system prompt |
| `core/tool_agent.py` | 242-244 | 工具结果单条截断至 6000 字符 |
| `memory/short_term.py` | 51-64 | `format_for_prompt()` 实现 |

---

*报告结束*
