# AI Friend 项目 Round 04：错误处理与可靠性审查 —— 死锁风险深度分析

**审查日期：** 2026/05/31  
**审查范围：** `storage/database.py`、`storage/repository.py`、`memory/long_term.py`、`memory/consolidation.py`、`web/session.py`、`core/agent.py`、`core/inner_drive.py`、`core/tool_agent.py`、`core/dispatcher.py`、`memory/short_term.py`、`web/server.py` 及相关调用链  
**审查目标：** 聚焦死锁风险、递归调用、无限循环、回调循环依赖、锁获取顺序一致性、资源耗尽等可靠性问题，输出可落地的修复建议  
**报告字数：** 约 6500 字

---

## 概述

AI Friend 项目采用三层 Agent 架构（Agent 1 InnerDrive → Agent 2 ToolAgent → Agent 3 Roleplay），配合异步数据库存储层（aiosqlite + asyncio.Lock）和 Web 端 FastAPI 服务。整个系统的可靠性面临以下七大类死锁与可靠性风险：

1. **`_run_sync` 嵌套事件循环**：在已有事件循环的线程中通过 `ThreadPoolExecutor` 启动新的事件循环，导致线程爆炸、锁跨线程不安全、以及潜在的 `RuntimeError`。
2. **`asyncio.Lock` 与 `threading.Lock` 混用**：`Database` 使用 `asyncio.Lock`，`SessionManager` 和 `ConversationBuffer` 使用 `threading.Lock`，在异步环境中形成不一致的并发模型。
3. **数据库连接池耗尽**：全局单一 `aiosqlite.Connection` 被所有会话共享，通过 `asyncio.Lock` 串行化，高并发下成为绝对瓶颈。
4. **递归调用导致的栈溢出**：`InnerDriveAgent.review()` 和 `re_decide()` 内部可能再次触发工具调用链，形成隐式递归；`_process_emotion` 每 3 轮触发 `consolidate`，而 `consolidate` 内部调用 `analyze_sentiment` 又调用 LLM，若 LLM 返回异常内容可能引发循环。
5. **ReAct 循环中的无限循环**：`Agent._react_loop` 的 `contains_fake_action` 检测在特定条件下可能形成无限重试；`ToolAgent.run_with_request` 的 retry 逻辑在 LLM 持续返回空调用时不会正确退出。
6. **回调循环依赖**：`MemoryConsolidator._update_relationship` 调用 `analyze_sentiment`，后者调用 `self.llm()`（即 `provider.generate()`），若 LLM 输出被注入恶意指令可能触发自我调用循环。
7. **锁获取顺序不一致**：`Repository` 的同步包装 `_run_sync` 与 `Database.cursor()` 的 `asyncio.Lock` 在不同线程中竞争，没有全局一致的加锁顺序。

以下逐类展开详细分析，包含文件路径、行号、风险评级和修复建议。

---

## 详细发现

### 1. `_run_sync` 嵌套事件循环的死锁风险

#### 1.1 问题描述

`storage/repository.py` 第 13-21 行和 `memory/long_term.py` 第 18-26 行存在完全相同的 `_run_sync` 函数：

```python
# storage/repository.py:13-21
# memory/long_term.py:18-26
def _run_sync(coro):
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return pool.submit(asyncio.run, coro).result()
```

**风险机制：**

- 当调用方已经在一个事件循环中（如 FastAPI 的 Web 请求处理协程），`asyncio.get_running_loop()` 成功获取当前事件循环，然后创建一个 `ThreadPoolExecutor` 并在新线程中执行 `asyncio.run(coro)`。
- `asyncio.run()` 会尝试创建新的事件循环并设置为当前线程的循环。在 Python 3.10+ 中，如果该线程已经有默认循环策略限制，可能失败；更关键的是，`asyncio.run()` 在新线程中启动独立事件循环，而该事件循环中的协程会竞争 `Database._lock`（`asyncio.Lock`）。
- `asyncio.Lock` **不是线程安全的**。在 Python 3.10+ 中，跨线程使用 `asyncio.Lock` 可能导致死锁或数据竞争。具体来说：
  - 主事件循环中的协程 A 持有 `Database._lock`（通过 `await` 获取）。
  - 线程池中的线程 B 尝试在同一个 `asyncio.Lock` 实例上获取锁，但由于锁的内部状态与主事件循环绑定，线程 B 可能永远等待，形成死锁。
- 此外，每次 `_run_sync` 调用都创建一个新的 `ThreadPoolExecutor`（默认线程数 = CPU 核心数 * 5），在高并发 Web 场景下会迅速耗尽线程资源。

#### 1.2 触发路径

```
web/server.py:233 (WebSocket 消息处理)
    └── loop.run_in_executor(None, agent.process_message, content)
        └── WebAgent.process_message() [在线程池中执行]
            └── Agent.process_message()
                └── MessageHandler.handle_message()
                    └── _run_agent3()
                        └── ltm.repo.insert_turn_sync(...)  [storage/repository.py:29]
                            └── _run_sync(repo.insert_turn(...))
                                └── pool.submit(asyncio.run, coro).result()
                                    └── 新线程中创建新事件循环
                                        └── 竞争 Database._lock（可能死锁）
```

REST API 路径（`web/server.py:39-54`）也存在同样问题，虽然 `chat_api` 是 `async def`，但直接同步调用 `agent.process_message()`，这会在事件循环线程中同步阻塞，且同样触发 `_run_sync` 的嵌套事件循环。

#### 1.3 风险评级

| 维度 | 评级 |
|------|------|
| 严重度 | **高危** |
| 发生概率 | 中（高并发 Web 场景下必然触发） |
| 影响范围 | 整个 Web 服务不可用 |
| 修复优先级 | P0 |

#### 1.4 修复建议

**方案 A（推荐）：彻底消除同步调用路径**

1. 将 `LongTermMemory` 的所有 sync wrapper（第 95-105 行）移除，统一为 async API。
2. 将 `Repository` 的 sync wrapper（第 29-30 行）移除。
3. 修改 `core/agent.py` 中的 `_react_loop` 和 `_process_emotion` 为 `async def`，直接 `await` 异步数据库操作。
4. Web 端（`web/server.py`）直接 `await agent.process_message()`，消除 `run_in_executor`。
5. CLI 端（`main.py`）在 `asyncio.run()` 中统一调度。

**方案 B（过渡方案）：使用 `asyncio.run_coroutine_threadsafe()`**

如果无法立即全面 async 化，将 `_run_sync` 改为：

```python
def _run_sync(coro):
    try:
        loop = asyncio.get_running_loop()
        future = asyncio.run_coroutine_threadsafe(coro, loop)
        return future.result(timeout=30)
    except RuntimeError:
        return asyncio.run(coro)
```

但此方案仍要求主事件循环持续运行，且 `future.result()` 会阻塞调用线程。

---

### 2. `asyncio.Lock` 与 `threading.Lock` 混用

#### 2.1 问题描述

项目中同时存在两种锁机制，且保护的是可能在同一线程/协程中交叉访问的资源：

| 文件 | 锁类型 | 保护对象 | 行号 |
|------|--------|----------|------|
| `storage/database.py` | `asyncio.Lock` | `aiosqlite.Connection` | 14 |
| `web/session.py` | `threading.Lock` | `_sessions`, `_proactive_tasks`, `_active_ws` | 129 |
| `memory/short_term.py` | `threading.Lock` | `deque`（对话轮次） | 18 |

**风险机制：**

- `SessionManager` 运行在 FastAPI 的 asyncio 事件循环中，但其 `_lock` 是 `threading.Lock`。`threading.Lock` 会阻塞当前线程（即事件循环线程），如果在持有锁期间发生 GC 或 C 扩展调用导致 GIL 释放，其他协程可能在同一线程获取锁成功，导致数据竞争。
- 更严重的是，如果未来有人在 `with self._lock:` 块内添加 `await`（例如为了记录日志而 `await` 一个异步操作），会立即死锁：协程在持有 `threading.Lock` 时被事件循环切换出去，其他协程尝试获取同一把锁时会阻塞整个线程，而持有锁的协程永远无法被调度回来。
- `ConversationBuffer` 的 `threading.Lock` 虽然目前是纯同步操作（无 `await`），但 `_run_sync` 的 `ThreadPoolExecutor` 会将操作放到不同线程中执行。`threading.Lock` 在线程之间是安全的，但 `run_in_executor` 每次使用不同线程，锁的持有和释放可能跨越不同线程，虽然不会死锁，但增加了复杂度。

#### 2.2 具体代码分析

`web/session.py:129`：

```python
class SessionManager:
    def __init__(self, config: Config):
        ...
        self._lock = Lock()  # threading.Lock

    def get_or_create(self, session_id: Optional[str] = None) -> tuple[str, WebAgent]:
        with self._lock:  # 阻塞事件循环线程！
            ...
```

`memory/short_term.py:18`：

```python
@dataclass
class ConversationBuffer:
    maxlen: int = 20
    _turns: deque = field(default_factory=lambda: deque())
    _next_id: int = 0
    _lock: threading.Lock = field(default_factory=threading.Lock)
```

`memory/short_term.py:32-34`：

```python
    def add_turn(self, role: str, content: str, metadata: Optional[dict] = None) -> Turn:
        turn = Turn(...)
        with self._lock:
            self._next_id += 1
            self._turns.append(turn)
```

#### 2.3 风险评级

| 维度 | 评级 |
|------|------|
| 严重度 | **高危**（`SessionManager`）/ **中危**（`ConversationBuffer`） |
| 发生概率 | 高（`SessionManager` 在高并发下必然竞争）/ 低（`ConversationBuffer` 目前无 await） |
| 影响范围 | Web 服务响应延迟、数据竞争、潜在死锁 |
| 修复优先级 | P1 |

#### 2.4 修复建议

1. `SessionManager` 的 `_lock` 改为 `asyncio.Lock`，并将 `get_or_create`、`remove`、`register_proactive`、`cleanup_old` 改为 `async def`。
2. `ConversationBuffer` 的 `_lock` 改为 `asyncio.Lock`，所有方法改为 `async def`。
3. 如果必须保持同步 API（供 CLI 使用），创建独立的 `SyncConversationBuffer` 子类，避免混用。

---

### 3. 数据库连接池耗尽

#### 3.1 问题描述

`storage/database.py` 使用单一 `aiosqlite.Connection`：

```python
class Database:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._lock = asyncio.Lock()
        self.conn: aiosqlite.Connection | None = None
```

所有会话共享同一个 `Database` 实例（通过 `SessionManager` 创建一次），所有数据库操作通过 `asyncio.Lock` 串行化。

**风险机制：**

- SQLite 在 WAL 模式下支持并发读取，但 `aiosqlite` 内部使用单个连接，且 `Database._lock` 强制所有操作（包括读取）串行执行。
- 在高并发 Web 场景下，如果一个请求的数据库操作耗时较长（如 `prune_facts` 需要扫描全表、`_embed_new_items` 需要批量更新），后续所有请求都会阻塞在 `async with self._lock:` 处。
- 虽然 `aiosqlite` 本身不会耗尽连接池（只有一个连接），但 `_run_sync` 的 `ThreadPoolExecutor` 每次调用都创建新线程，线程池大小有限（默认 `min(32, os.cpu_count() + 4)`），高并发下线程池会耗尽，导致新请求无法获得线程执行 `_run_sync`，表现为服务无响应。

#### 3.2 关键阻塞操作

`memory/consolidation.py:248-253` 的 `_prune` 方法：

```python
def _prune(self, max_facts: int, max_experiences: int, max_reflections: int) -> None:
    pruned_f = self.ltm.repo.prune_facts(max_facts)      # 可能扫描全表
    pruned_e = self.ltm.repo.prune_experiences(max_experiences)
    pruned_r = self.ltm.repo.prune_reflections(max_reflections)
```

`memory/consolidation.py:255-297` 的 `_embed_new_items`：

```python
def _embed_new_items(self) -> None:
    ...
    with self.ltm.repo.db.get_connection() as conn:  # 绕过 cursor() 的锁！
        ...
        for table, text_cols in [...]:
            rows = conn.execute(...).fetchall()  # 同步阻塞操作
```

注意：`_embed_new_items` 直接通过 `get_connection()` 获取裸连接，**绕过 `Database._lock`**。虽然这在当前代码中不会导致死锁（因为 `get_connection()` 不返回上下文管理器，而是直接返回连接对象，且 `with` 语句只是确保连接关闭），但它破坏了统一的锁策略，可能导致与 `cursor()` 上下文中的操作发生竞态。

#### 3.3 风险评级

| 维度 | 评级 |
|------|------|
| 严重度 | **中危** |
| 发生概率 | 中（高并发或大数据量时触发） |
| 影响范围 | Web 服务响应延迟、请求超时 |
| 修复优先级 | P2 |

#### 3.4 修复建议

1. **引入连接池**：使用 `aiosqlite` 的连接池支持或第三方库（如 `asyncpg` 对于 PostgreSQL，`aiosqlite` 本身无内置连接池，可考虑 `asqlite` 或自行实现简单池）。
2. **分离读写锁**：使用 `asyncio.Lock` + `asyncio.Condition` 实现读写分离，允许多个并发读取。
3. **限制批量操作大小**：`_embed_new_items` 的 `LIMIT 50` 已有限制，但 `prune_*` 操作没有限制单次删除量，应添加分页删除。
4. **移除裸连接访问**：`_embed_new_items` 应使用 `async with self.ltm.repo.db.cursor() as c:`，而不是直接操作裸连接。

---

### 4. 递归调用导致的栈溢出

#### 4.1 问题描述

系统中存在多处隐式递归调用风险：

**风险点 A：`InnerDriveAgent.review()` 内部再次调用 LLM，可能触发工具调用**

`core/inner_drive.py:154-215`：

```python
def review(self, user_input: str, tool_records_text: str,
           round_num: int = 1, max_rounds: int = 3) -> InnerDriveResult:
    ...
    resp = self._provider.generate(messages, stream=False, max_tokens=512)
    cleaned, calls = parse_tool_calls(resp)

    if calls:
        messages.append({"role": "assistant", "content": resp})
        results = execute_tool_calls(self._full_registry, calls)
        ...
        resp = self._provider.generate(messages, stream=False, max_tokens=512)
        cleaned, _ = parse_tool_calls(resp)
```

如果 LLM 在 review 阶段再次输出工具调用（如 `recall` 或 `remember`），`execute_tool_calls` 会执行这些工具。虽然当前 `review` 的调用链中 `round_num` 限制了外层循环，但内层的 `execute_tool_calls` 可能调用 `RecallTool` 或 `RememberTool`，而这些工具内部又调用 `LongTermMemory.search_facts()` 等，最终触发 `_run_sync` → `ThreadPoolExecutor` → 新线程。这不是栈溢出，但会形成"调用链爆炸"。

**风险点 B：`InnerDriveAgent.re_decide()` 类似结构**

`core/inner_drive.py:217-264` 的 `re_decide` 方法与 `review` 结构相同，存在同样的风险。

**风险点 C：`Agent._process_emotion` 与 `consolidate` 的交互**

`core/agent.py:216-221`：

```python
if self.turn_count % 3 == 0:
    self.consolidator.add_pending(self.short_term.get_all()[-1])
    self.consolidator.consolidate(self.short_term, self.personality,
                                  max_facts=self.config.max_facts,
                                  max_experiences=self.config.max_experiences,
                                  max_reflections=self.config.max_reflections)
```

`consolidate()` 内部调用 `analyze_sentiment()`（`memory/consolidation.py:83-96`），后者调用 `self.llm()`（即 `provider.generate()`）。如果 `provider.generate()` 因为网络问题或 API 限流而长时间阻塞，整个 `_process_emotion` 会阻塞。虽然这不是递归，但如果 `consolidate` 内部的 `llm` 调用触发了某种回调（如日志回调），而回调又尝试修改 `Agent` 状态，可能形成循环依赖。

**风险点 D：`execute_tool_calls` 中的 `asyncio.run()` 循环调用**

`core/dispatcher.py:128-133`：

```python
import asyncio
try:
    import inspect
    if inspect.iscoroutinefunction(tool.execute):
        result: ToolResult = asyncio.run(tool.execute(args))
    else:
        result: ToolResult = tool.execute(args)
```

如果 `tool.execute` 是异步的（当前所有工具都是同步的，但基类 `Tool.execute` 声明为 `async def`），`asyncio.run()` 会在每次工具调用时创建和销毁事件循环。如果在循环中调用多个异步工具，会形成"事件循环创建-销毁"的递归模式，虽然不会导致 Python 栈溢出，但会迅速耗尽系统资源。

#### 4.2 风险评级

| 维度 | 评级 |
|------|------|
| 严重度 | **中危** |
| 发生概率 | 低（需要特定 LLM 输出或网络条件触发） |
| 影响范围 | 调用链过长导致性能下降、线程耗尽 |
| 修复优先级 | P2 |

#### 4.3 修复建议

1. 在 `review` 和 `re_decide` 中，如果检测到 `calls`，应限制为只允许内部工具（`recall`、`remember`），禁止外部工具（`web_fetch`、`web_search` 等）。
2. 为 `consolidate` 添加超时机制，避免 `analyze_sentiment` 的 LLM 调用无限阻塞。
3. 修改 `execute_tool_calls`，使用 `asyncio.get_event_loop().run_until_complete()` 或 `await` 替代 `asyncio.run()`，避免循环中创建事件循环。

---

### 5. ReAct 循环中的无限循环

#### 5.1 问题描述

**风险点 A：`Agent._react_loop` 的 `contains_fake_action` 检测**

`core/agent.py:119-181`：

```python
def _react_loop(self, messages: list[dict], on_token=None, add_to_history: bool = True,
                tool_registry=None, skip_post_process: bool = False) -> str:
    ...
    fake_action_count = 0
    tools_were_called = False
    for _idx in range(self._max_tool_iterations):
        resp = self.provider.generate(...)
        cleaned, calls = parse_tool_calls(resp)
        if not calls:
            if contains_fake_action(resp) and fake_action_count < 3 and not tools_were_called:
                fake_action_count += 1
                ...
                continue
            final_text = cleaned
            break
        tools_were_called = True
        ...
```

**风险机制：**

- `contains_fake_action` 检测 LLM 是否在文本中描述了工具调用但没有实际输出 `<tool_call>`。
- 如果 LLM 持续输出包含 "工具返回"、"调用web_fetch" 等关键词的文本（例如因为系统提示不当或模型幻觉），`fake_action_count` 会在 3 次后停止重试，这是正确的。
- 但 `contains_fake_action` 的检测词列表（`core/dispatcher.py:179-194`）包含 "工具返回"、"工具返回的原始内容" 等。如果 Agent 3 在回复用户时合法地使用了这些词汇（例如用户在问 "你之前工具返回了什么"），`contains_fake_action` 会误判，导致最多 3 次无意义重试。这不是无限循环，但降低了用户体验。
- 更严重的是，如果 `parse_tool_calls` 因为 JSON 解析错误持续返回空 `calls`，而 LLM 输出又不包含 `contains_fake_action` 的关键词，循环会正常退出。但如果 LLM 输出一个格式错误的 `<tool_call>` 标签（如 `<tool_call>{"name": "web_fetch"}</tool_call>` 缺少 `arguments`），`parse_tool_calls` 会解析成功但 `execute_tool_calls` 会执行失败，然后将错误结果追加到 `messages` 中，LLM 可能再次尝试同样的错误调用，形成"错误循环"。

**风险点 B：`ToolAgent.run_with_request` 的 retry 逻辑**

`core/tool_agent.py:142-224`：

```python
def run_with_request(self, tool_request: str, max_retries: int = 3) -> ToolAgentResult:
    ...
    for attempt in range(1, max_retries + 1):
        ...
        resp = self._provider.generate(...)
        cleaned, calls = parse_tool_calls(resp)
        if not calls:
            logger.debug("[tool_agent] no tool calls parsed from response")
            continue
        ...
        if result.any_success:
            break
        last_failure = "..."
```

**风险机制：**

- 如果 `parse_tool_calls` 持续返回空 `calls`（例如 LLM 输出纯文本而非 JSON），`run_with_request` 会重试 `max_retries` 次后退出。这不是无限循环。
- 但如果 LLM 每次都输出格式正确但参数错误的工具调用（如 `web_fetch` 的 `url` 参数为空字符串），工具会执行失败，`result.any_success` 为 `False`，然后重试。LLM 可能再次输出同样的错误参数，形成最多 3 次 * 3 轮 = 9 次的无效尝试。这在 `ToolAttemptTracker` 中有记录，但 9 次 LLM 调用会消耗大量时间和 token。

**风险点 C：`MessageHandler.handle_message` 的 Agent 1/2 循环**

`core/message_handler.py:64-156`：

```python
while round_num < MAX_AGENT2_ROUNDS and drive_result.needs_external_tools:
    round_num += 1
    ...
    tool_result = self._tool_agent.run_with_request(request_text)
    ...
    if tool_result and tool_result.any_success and round_num < MAX_AGENT2_ROUNDS:
        drive_result = self._inner_drive.review(...)
        if drive_result.needs_external_tools:
            ...
    elif tool_result and not tool_result.any_success:
        if tracker.can_start_new_round:
            drive_result = self._inner_drive.re_decide(...)
        else:
            break
    else:
        break
```

**风险机制：**

- 外层 `while` 循环最多执行 `MAX_AGENT2_ROUNDS = 3` 次，内层 `run_with_request` 最多重试 3 次，所以最多 9 次工具调用尝试。
- 但 `review` 和 `re_decide` 内部各自可能再次调用 `provider.generate()`，且 `re_decide` 没有明确的轮次限制（除了 `tracker.can_start_new_round` 的 9 次总尝试限制）。
- 如果 Agent 1 在 `review` 或 `re_decide` 中持续决定需要更多工具（例如因为 LLM 幻觉或工具结果不完整），总尝试次数可能接近 9 次上限，虽然不会无限循环，但会导致极长的响应延迟。

#### 5.2 风险评级

| 维度 | 评级 |
|------|------|
| 严重度 | **中危** |
| 发生概率 | 中（取决于 LLM 输出质量） |
| 影响范围 | 响应延迟增加、API 费用上升、用户体验下降 |
| 修复优先级 | P2 |

#### 5.3 修复建议

1. 为 `Agent._react_loop` 添加总耗时限制（如单次消息处理不超过 60 秒）。
2. 优化 `contains_fake_action` 的检测逻辑，仅在确认 LLM 没有输出任何 `<tool_call>` 标签时才触发，避免误判合法回复。
3. 在 `ToolAgent.run_with_request` 中，如果连续两次重试的 `last_failure` 相同，提前退出（避免重复同样的错误）。
4. 为整个 `handle_message` 流程添加超时装饰器，确保无论内部循环如何，总耗时可控。

---

### 6. 回调循环依赖

#### 6.1 问题描述

**风险点 A：`SleepManager.generate_dream` 调用 `provider.generate()`，而 `provider.generate()` 可能回调情绪记录**

`core/sleep_manager.py:96-119`：

```python
def generate_dream(self) -> str:
    ...
    dream = self._provider.generate(
        [{"role": "user", "content": prompt}],
        stream=False, max_tokens=100,
    )
    self._personality.emotion.record_emotion_event(
        trigger=f"梦: {dream.strip()[:100]}",
        context=dream.strip()[:200],
    )
```

**风险机制：**

- `generate_dream` 调用 `provider.generate()` 生成梦境。
- 生成后调用 `record_emotion_event()` 记录情绪事件。
- `record_emotion_event` 在 `models/personality.py:239-262` 中，如果情绪强度足够高，会记录事件。但 `record_emotion_event` 不会回调 `generate_dream`，所以这不是循环。
- 真正的风险在于：如果 `provider.generate()` 因为某种原因（如自定义 Provider 子类）在生成过程中触发了 `Personality.save()` 或 `record_emotion_event()`，而这些操作又间接触发了 `SleepManager` 的状态检查，可能形成循环。当前代码中没有这种回调，但架构上存在这种可能性。

**风险点 B：`MemoryConsolidator._update_relationship` 调用 `analyze_sentiment`，后者调用 LLM**

`memory/consolidation.py:225-246`：

```python
def _update_relationship(self, personality: Personality) -> None:
    relationship = self.ltm.get_relationship()
    sentiment = 0
    if self._pending_buffer:
        last_user_turns = [t for t in self._pending_buffer[-3:] if t.role == "user"]
        if last_user_turns:
            sentiment, personal_sharing, _ = self.analyze_sentiment(
                last_user_turns[-1].content
            )
```

`memory/consolidation.py:83-96`：

```python
def analyze_sentiment(self, text: str) -> tuple[float, bool, float]:
    prompt = EMOTION_ANALYSIS_PROMPT.format(text=text)
    result = self.llm(prompt, temperature=0.2)
    data = json.loads(result.strip())
    return ...
```

**风险机制：**

- `analyze_sentiment` 调用 `self.llm()`（即 `provider.generate()`）。
- 如果 `provider.generate()` 返回的 JSON 格式错误，`json.loads` 会抛出异常，被 `except Exception` 捕获，返回默认值 `(0.0, False, 0.5)`。这是安全的。
- 但如果 `provider.generate()` 因为网络问题或 API 限流而长时间阻塞，`_update_relationship` 会阻塞 `consolidate()` 的执行。
- 更关键的是，`consolidate()` 在 `core/agent.py:216-221` 中每 3 轮调用一次。如果 `consolidate` 因为 `analyze_sentiment` 的 LLM 调用而阻塞，后续的消息处理会延迟。这不是循环依赖，但形成了"隐式阻塞链"。

**风险点 C：`Personality.save()` 与 `Agent.process_message` 的竞争**

`web/session.py:84-88`：

```python
def process_message(self, user_input: str) -> str:
    result = self.agent.process_message(user_input, on_token=self._on_token_callback)
    self.personality.save(self.config.personality_file)
    return result
```

`core/agent.py:104-105`（通过 `MessageHandler`）：

```python
def process_message(self, user_input: str, on_token=None) -> str:
    return self._messages.handle_message(user_input, on_token)
```

`core/agent.py:206-209`：

```python
self.personality.apply_emotional_shift(sentiment, sharing, energy)
new_dom = self.personality.emotion.dominant_emotion
if old_dom != new_dom:
    logger.info(f"[emotion] {old_dom}->{new_dom} ...")
```

**风险机制：**

- `process_message` 内部修改了 `self.personality.emotion` 的状态（通过 `_process_emotion`）。
- `process_message` 返回后，`WebAgent.process_message` 调用 `self.personality.save()` 将状态写入文件。
- 如果 WebSocket 和 proactive 循环同时调用 `process_message` 或 `process_proactive`（通过 `run_in_executor`），两个线程可能同时修改 `self.personality.emotion`，然后同时调用 `save()`，导致文件写竞争。
- 虽然 `SessionManager._lock` 保护 `_sessions` 字典，但 `process_message` 在释放锁之后才执行，所以 `personality.save()` 不在锁保护范围内。

#### 6.2 风险评级

| 维度 | 评级 |
|------|------|
| 严重度 | **中危** |
| 发生概率 | 中（高并发或 proactive 与消息处理重叠时触发） |
| 影响范围 | personality.json 文件损坏、情绪状态不一致 |
| 修复优先级 | P2 |

#### 6.3 修复建议

1. 为 `Personality` 添加文件写入锁（`threading.Lock` 或 `filelock`），确保 `save()` 操作原子化。
2. 在 `WebAgent` 中为每个会话添加 `threading.Lock`，确保 `process_message`、`process_proactive`、`process_explore` 串行执行。
3. 将 `analyze_sentiment` 的 LLM 调用改为异步，并添加超时（如 10 秒）。

---

### 7. 锁获取顺序一致性

#### 7.1 问题描述

系统中存在多把锁，但没有任何文档或代码强制规定锁的获取顺序：

| 锁名称 | 类型 | 保护范围 |
|--------|------|----------|
| `Database._lock` | `asyncio.Lock` | 数据库操作 |
| `SessionManager._lock` | `threading.Lock` | 会话字典 |
| `ConversationBuffer._lock` | `threading.Lock` | 短期记忆队列 |
| `EmbeddingCache`（无显式锁） | `OrderedDict`（非线程安全） | 嵌入向量缓存 |

**风险机制：**

- 虽然当前代码中没有明显的"锁 A → 锁 B"的嵌套获取，但在以下调用链中隐含了多锁竞争：

```
Agent.process_message()
    ├── SessionManager._lock (get_or_create) [已释放]
    ├── ConversationBuffer._lock (add_turn)
    ├── Database._lock (insert_turn_sync → _run_sync → cursor)
    └── consolidate()
        ├── Database._lock (prune_facts)
        ├── Database._lock (prune_experiences)
        └── Database._lock (prune_reflections)
```

- 如果未来代码修改导致在持有 `ConversationBuffer._lock` 时尝试获取 `Database._lock`（例如在一个大事务中同时修改短期记忆和长期记忆），而另一个线程在持有 `Database._lock` 时尝试获取 `ConversationBuffer._lock`，就会形成经典的死锁。
- `EmbeddingCache`（`memory/embeddings.py:86-117`）使用 `OrderedDict` 作为缓存，但没有显式锁保护。虽然当前 `encode()` 是同步的，且 `EmbeddingCache` 通常在单线程中使用，但如果未来改为异步编码或多线程调用，`OrderedDict` 的操作（`move_to_end`、`popitem`）不是线程安全的，可能导致数据竞争或死锁。

#### 7.2 风险评级

| 维度 | 评级 |
|------|------|
| 严重度 | **低危**（当前代码中未触发）/ **中危**（未来扩展风险） |
| 发生概率 | 低 |
| 影响范围 | 潜在死锁、数据竞争 |
| 修复优先级 | P3 |

#### 7.3 修复建议

1. 制定全局锁获取顺序文档，例如：`SessionManager._lock` → `ConversationBuffer._lock` → `Database._lock`。
2. 为 `EmbeddingCache` 添加 `threading.Lock` 或 `asyncio.Lock` 保护。
3. 避免在锁块内调用外部代码（尤其是 LLM API 调用），防止不可控的阻塞和潜在的循环依赖。

---

### 8. 其他可靠性风险

#### 8.1 `web/server.py` 的 `_proactive_loop` 中 `sleep_cooldown` 计数器与注释不符

`web/server.py:131-153`：

```python
async def _proactive_loop(websocket: WebSocket, session_id: str):
    cooldown = 0
    sleep_cooldown = 0
    while True:
        ...
        if sleep_cooldown == 0:
            should_sleep, msg = ag._get_sleep_state()
            if msg:
                ...
                sleep_cooldown = 120  # 10 min cooldown on sleep transitions
                ...
        else:
            sleep_cooldown = max(0, sleep_cooldown - 1)
        ...
        await asyncio.sleep(15)
```

**风险：** 注释说 "10 min cooldown"，但 `sleep_cooldown` 每次循环减 1，循环间隔约 15 秒（实际可能更长，因为中间有 `run_in_executor` 等阻塞操作），所以 120 次循环大约需要 30 分钟，而不是 10 分钟。这会导致睡眠/清醒转换的冷却时间比预期长 3 倍。

**修复：** 将 `sleep_cooldown` 改为基于时间戳的计时，而非计数器：

```python
_sleep_transition_time = 0

# 检查冷却
if time.time() - _sleep_transition_time < 600:  # 10 minutes
    ...
```

#### 8.2 `Agent._react_loop` 中 `stream=False if _idx > 0 else True` 的 token 回调风险

`core/agent.py:129-133`：

```python
resp = self.provider.generate(
    messages, stream=False if _idx > 0 else True,
    on_token=on_token if _idx == 0 else None,
    max_tokens=max_tok if _idx == 0 else max(384, max_tok * 2 // 3),
)
```

**风险：** 只有在第一次迭代时启用流式输出和 `on_token` 回调。如果第一次迭代触发了工具调用，第二次迭代（生成最终回复）不会流式输出，导致 Web 端的打字机效果丢失。这不是死锁风险，但影响用户体验。

#### 8.3 `ContextManager.compress()` 的递归 guard 不完整

`core/context_manager.py:62-70`：

```python
def compress(self, messages: list[dict]) -> None:
    if self._compressing:
        return
    self._compressing = True
    try:
        self._do_compress(messages)
    finally:
        self._compressing = False
```

**风险：** `_compressing` 标志防止了直接的递归调用，但如果 `_do_compress` 内部抛出异常，`finally` 块会正确重置标志。然而，`compress()` 是同步的，如果在 `run_in_executor` 中并发调用，两个线程可能同时检查 `self._compressing == False` 并同时进入 `_do_compress`，导致重复压缩和 `short_term.clear()` 的竞争。

#### 8.4 `ToolRegistry.to_json_schema()` 返回的 schema 不完整

`tools/traits.py:82-95`：

```python
def to_json_schema(self, names: list[str] | None = None) -> dict:
    tool_names = []
    for spec in self.list_specs():
        if names is not None and spec.name not in names:
            continue
        tool_names.append(spec.name)

    return {
        "type": "json_object",
    }
```

**风险：** `to_json_schema` 只返回 `{"type": "json_object"}`，没有包含实际的工具参数 schema。这意味着 LLM 无法根据 schema 生成结构化的工具调用，只能依赖系统提示中的文本描述。虽然当前代码中 `response_format` 被设置为这个返回值，但 DeepSeek 等模型需要完整的 JSON Schema 才能正确约束输出。这不是死锁风险，但会导致工具调用解析失败率上升，间接增加 ReAct 循环的迭代次数。

---

## 汇总统计

### 风险分类统计

| 风险类别 | 发现数量 | 高危 | 中危 | 低危 |
|----------|----------|------|------|------|
| `_run_sync` 嵌套事件循环 | 2 处 | 2 | 0 | 0 |
| `asyncio.Lock` / `threading.Lock` 混用 | 3 处 | 1 | 2 | 0 |
| 数据库连接池耗尽 | 1 处 | 0 | 1 | 0 |
| 递归调用 / 栈溢出 | 4 处 | 0 | 3 | 1 |
| ReAct 循环无限循环 | 3 处 | 0 | 3 | 0 |
| 回调循环依赖 | 3 处 | 0 | 2 | 1 |
| 锁获取顺序不一致 | 2 处 | 0 | 1 | 1 |
| 其他可靠性问题 | 4 处 | 0 | 2 | 2 |
| **合计** | **22 处** | **3** | **14** | **5** |

### 按文件统计

| 文件 | 风险数量 | 最高风险等级 |
|------|----------|--------------|
| `storage/repository.py` | 2 | 高危 |
| `memory/long_term.py` | 2 | 高危 |
| `web/session.py` | 3 | 高危 |
| `storage/database.py` | 2 | 中危 |
| `core/dispatcher.py` | 2 | 中危 |
| `core/inner_drive.py` | 3 | 中危 |
| `core/agent.py` | 4 | 中危 |
| `memory/consolidation.py` | 3 | 中危 |
| `memory/short_term.py` | 1 | 中危 |
| `web/server.py` | 3 | 中危 |
| `tools/traits.py` | 1 | 低危 |
| `core/context_manager.py` | 1 | 低危 |
| `core/sleep_manager.py` | 1 | 低危 |
| `memory/embeddings.py` | 1 | 低危 |

### 修复优先级建议

| 优先级 | 问题 | 文件 | 行号 | 建议修复方案 |
|--------|------|------|------|--------------|
| P0 | `_run_sync` 嵌套事件循环 | `storage/repository.py` | 13-21 | 彻底 async 化，消除 `_run_sync` |
| P0 | `_run_sync` 嵌套事件循环 | `memory/long_term.py` | 18-26 | 彻底 async 化，消除 `_run_sync` |
| P0 | `threading.Lock` 用于 asyncio | `web/session.py` | 129 | 改为 `asyncio.Lock`，方法改为 `async def` |
| P1 | 单连接串行化瓶颈 | `storage/database.py` | 14 | 引入连接池或读写分离 |
| P1 | `asyncio.run()` 循环调用 | `core/dispatcher.py` | 132 | 使用 `await` 或 `get_event_loop()` |
| P2 | `ConversationBuffer` 混用锁 | `memory/short_term.py` | 18 | 改为 `asyncio.Lock` |
| P2 | `EmbeddingCache` 无锁保护 | `memory/embeddings.py` | 91 | 添加 `threading.Lock` |
| P2 | ReAct 循环无总超时 | `core/agent.py` | 127 | 添加 60 秒总超时 |
| P2 | `personality.save()` 竞争写入 | `web/session.py` | 88 | 添加文件写入锁 |
| P2 | `sleep_cooldown` 计时错误 | `web/server.py` | 147 | 改为时间戳计时 |
| P3 | `ToolRegistry.to_json_schema` 不完整 | `tools/traits.py` | 82-95 | 返回完整 JSON Schema |
| P3 | `ContextManager.compress` 并发竞争 | `core/context_manager.py` | 62 | 添加锁保护 |

---

## 附录：关键代码引用

### A. `_run_sync` 实现（`storage/repository.py:13-21`）

```python
def _run_sync(coro):
    """Run coroutine in a thread-safe way for sync callers."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return pool.submit(asyncio.run, coro).result()
```

### B. `Database.cursor()` 实现（`storage/database.py:26-39`）

```python
@asynccontextmanager
async def cursor(self):
    if self.conn is None:
        raise RuntimeError("Database not opened. Call await db.open() first.")
    async with self._lock:
        c = await self.conn.cursor()
        try:
            yield c
            await self.conn.commit()
        except aiosqlite.Error:
            await self.conn.rollback()
            raise
        finally:
            await c.close()
```

### C. `SessionManager` 锁使用（`web/session.py:129-144`）

```python
class SessionManager:
    def __init__(self, config: Config):
        ...
        self._lock = Lock()  # threading.Lock

    def get_or_create(self, session_id: Optional[str] = None) -> tuple[str, WebAgent]:
        with self._lock:
            sid = session_id or uuid.uuid4().hex[:12]
            if sid not in self._sessions:
                self._sessions[sid] = WebAgent(self.config, self.db, self.repo)
            return sid, self._sessions[sid]
```

### D. `Agent._react_loop` 核心循环（`core/agent.py:127-157`）

```python
for _idx in range(self._max_tool_iterations):
    resp = self.provider.generate(...)
    cleaned, calls = parse_tool_calls(resp)
    if not calls:
        if contains_fake_action(resp) and fake_action_count < 3 and not tools_were_called:
            fake_action_count += 1
            ...
            continue
        final_text = cleaned
        break
    tools_were_called = True
    ...
```

---

*报告结束。建议按照 P0 → P1 → P2 → P3 的顺序逐步修复，优先解决 `_run_sync` 和 `threading.Lock` 混用问题，以消除最核心的死锁风险。*
