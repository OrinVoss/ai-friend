# AI Friend 项目 Web 安全性审查报告（第3轮）

**审查日期**：2026-05-31
**审查范围**：Web 层（`web/server.py`、`web/session.py`、`web/static/index.html`、`web/static/app.js`）及相关后端组件
**审查人员**：Claude Code 安全审查 Agent
**风险评级定义**：
- **严重（Critical）**：可导致系统完全沦陷、数据泄露、远程代码执行
- **高危（High）**：可导致敏感信息泄露、权限绕过、大规模数据破坏
- **中危（Medium）**：可导致局部功能异常、有限信息泄露、用户体验攻击
- **低危（Low）**：防御纵深缺失、配置不当、信息暴露面扩大

---

## 概述

AI Friend 项目的 Web 端采用 FastAPI + WebSocket 架构，提供 REST API（`/api/chat`）和实时通信（`/ws`）两种用户交互通道。前端为纯 HTML/CSS/JS 单页应用，无现代前端框架。本次审查聚焦 Web 安全十大维度，共发现 **23 项安全问题**，其中严重 2 项、高危 5 项、中危 10 项、低危 6 项。

核心风险集中在：
1. **XSS 攻击面广泛**：LLM 生成的响应内容未经任何净化直接反射到 DOM，且前端使用 `textContent` 与 `innerHTML` 混用，存在存储型 XSS 和反射型 XSS 双重风险。
2. **完全缺失 CSRF 防护**：REST API 和 WebSocket 均无任何 CSRF Token 或同源校验机制。
3. **会话管理脆弱**：Session ID 由客户端完全控制，无会话固定防护，无过期机制。
4. **CORS 配置缺失**：FastAPI 默认开放跨域，生产环境面临严重风险。
5. **WebSocket 安全缺陷**：无 Origin 校验、无消息大小限制、无连接数限制。
6. **敏感信息泄露**：日志、API 响应、错误消息中均可能暴露内部路径、API Key、数据库结构。
7. **速率限制缺失**：无任何请求频率限制，易遭受暴力破解和 DoS 攻击。
8. **点击劫持与 CSP 缺失**：无 X-Frame-Options、无 Content-Security-Policy。
9. **输入验证薄弱**：用户输入直接传入 LLM 和文件系统工具，存在提示注入和路径遍历风险。
10. **工具链安全边界模糊**：文件读取、命令执行类工具缺乏严格的沙箱隔离。

---

## 详细发现

### 1. XSS 攻击面（Cross-Site Scripting）

#### 1.1 存储型 XSS — LLM 响应内容直接注入 DOM（高危）

**文件路径**：`web/static/app.js:188`
**代码**：
```javascript
bb.textContent = content;
```

**分析**：
虽然 `createMessage` 函数在 `web/static/app.js:188` 处使用了 `textContent` 来设置消息气泡内容，这本身是对 XSS 的有效防御（`textContent` 会自动转义 HTML 特殊字符）。但是，存在以下绕过路径：

1. **LLM 输出通过 WebSocket 的 `segment` 类型分段到达前端**。如果攻击者通过提示注入（Prompt Injection）诱导 LLM 输出 HTML 标签，虽然 `textContent` 会将其显示为纯文本，但 LLM 也可能被诱导输出 JavaScript 伪协议链接或其他可执行内容。

2. **`emotion` 字段的渲染**：`web/static/app.js:160-162`
   ```javascript
   function showEmotion(emotion) {
       var el = document.getElementById('emotion-text');
       if (el) el.textContent = emotion || '';
   }
   ```
   此处也使用了 `textContent`，表面安全。但 `emotion` 值来源于服务器端的 `agent.emotion`，即 `personality.emotion.dominant_emotion`。该值由 LLM 驱动的情绪引擎计算得出，理论上攻击者可通过精心构造的输入影响情绪状态，但情绪值被限制在预定义枚举中，直接 XSS 难度较高。

3. **更大的风险在于 `innerHTML` 的潜在使用**：当前代码中未直接使用 `innerHTML` 渲染用户内容，但系统消息和错误消息的处理需要关注。

**风险评级**：高危（High）
**修复建议**：
- 保持使用 `textContent`，永远不要切换到 `innerHTML`
- 对 LLM 输出增加 DOMPurify 净化层（防御深度）
- 对 `emotion` 值实施严格的输入校验（白名单机制）

---

#### 1.2 反射型 XSS — 错误消息直接反射（中危）

**文件路径**：`web/server.py:244`
**代码**：
```python
await websocket.send_text(json.dumps({"type": "error", "content": str(e)}))
```

**分析**：
当 WebSocket 处理异常时，直接将异常字符串 `str(e)` 发送给客户端。如果异常消息中包含用户可控的输入（例如用户提供的文件路径、搜索关键词），且前端使用 `innerHTML` 显示错误内容，则存在反射型 XSS 风险。虽然当前前端对 `error` 类型消息不做任何处理（`web/static/app.js:119-121` 仅 `break`），但未来代码变更极易引入漏洞。

**风险评级**：中危（Medium）
**修复建议**：
- 错误消息不要直接反射用户输入
- 建立错误码机制，前端根据错误码显示本地化消息
- 如需显示详细错误，对特殊字符进行 HTML 实体编码

---

#### 1.3 基于 LLM 的 XSS 攻击链（严重）

**文件路径**：`core/agent.py` → `web/server.py` → `web/static/app.js`
**攻击路径**：
```
用户输入恶意提示 → Agent 3 (Roleplay) 生成包含恶意脚本的内容 
→ 通过 WebSocket segment/done 或 REST API response 返回 
→ 前端 textContent 显示（当前安全）
→ 但如果 LLM 生成 markdown 链接 [点击](javascript:alert(1)) 
→ 前端未来支持 markdown 渲染时即触发 XSS
```

**分析**：
当前前端不支持 markdown 渲染，这是事实上的安全屏障。但项目 roadmap 中很可能加入富文本支持。一旦引入 markdown 解析器而不配置净化，存储型 XSS 将立即生效。此外，LLM 可能被诱导生成 Social Engineering 内容（如"请点击这个链接"），即使用户需要手动点击，也属于安全边界突破。

**风险评级**：严重（Critical）
**修复建议**：
- 在架构文档中明确记录：任何富文本渲染必须配套 DOMPurify
- 对 LLM 输出增加输出过滤层，拦截 `javascript:`、`data:` 等危险协议
- 建立 LLM 输出安全审查机制（后处理管道）

---

#### 1.4 DOM Clobbering 风险（低危）

**文件路径**：`web/static/app.js`
**分析**：
前端代码中多处直接通过 `id` 获取 DOM 元素：
```javascript
var container = document.getElementById('chat-messages');
var el = document.getElementById('emotion-text');
```
如果页面中允许用户内容包含带有 `id` 属性的 HTML（当前不允许，但未来可能），则存在 DOM Clobbering 攻击面。攻击者可通过命名冲突劫持全局变量。

**风险评级**：低危（Low）
**修复建议**：
- 使用 Shadow DOM 或 iframe 隔离用户内容
- 避免在用户内容区域使用可预测的 id

---

### 2. CSRF 防护（Cross-Site Request Forgery）

#### 2.1 REST API 完全缺失 CSRF 防护（严重）

**文件路径**：`web/server.py:39-54`
**代码**：
```python
@app.post("/api/chat")
async def chat_api(body: dict):
    session_id = body.get("session_id", "default")
    message = body.get("message", "")
    ...
```

**分析**：
`/api/chat` 端点接受 POST 请求，仅校验 `Content-Type: application/json`。在 modern browser 中，跨源 POST 请求携带 JSON body 会触发 CORS preflight，但这**不是** CSRF 防护。如果攻击者控制一个同源的子域名（如通过 DNS 劫持或 XSS），或者利用浏览器对 `text/plain` 的宽松处理，可以构造 CSRF 请求。

更关键的是，该端点执行以下敏感操作：
- 调用 LLM API（消耗 API Key 配额）
- 写入数据库（`insert_turn_sync`）
- 修改情绪状态（`process_message` → `_process_emotion`）
- 触发文件系统工具（`read_file`、`glob`、`grep`）

攻击者可通过 CSRF 在受害者不知情的情况下：
1. 消耗大量 DeepSeek API 配额（财务攻击）
2. 向数据库注入恶意记忆（污染长期记忆）
3. 触发 `notify` 工具发送骚扰通知
4. 触发 `music_play` 播放恶意音频文件

**风险评级**：严重（Critical）
**修复建议**：
- 实施 Double Submit Cookie 模式 CSRF Token
- 或要求所有敏感操作携带自定义 Header（如 `X-Requested-With`）
- 对 `/api/chat` 实施 SameSite=Strict Cookie 策略

---

#### 2.2 WebSocket 无 CSRF 防护（高危）

**文件路径**：`web/server.py:199-249`
**分析**：
WebSocket 连接在握手阶段不携带 CSRF Token。虽然 WebSocket 同源策略默认较严格，但以下场景存在风险：
- 如果网站存在 XSS，攻击者可在同源页面建立 WebSocket 连接
- 某些浏览器/代理对 WebSocket Origin 头的处理不一致
- 子域名共享 cookie 时，子域名的 XSS 可向上级域名发起 WebSocket 连接

**风险评级**：高危（High）
**修复建议**：
- WebSocket 握手时校验 Origin 头
- 在 `init` 消息中要求携带从 REST API 获取的临时 Token
- 实施 WebSocket 连接速率限制

---

### 3. 会话固定攻击（Session Fixation）

#### 3.1 Session ID 完全由客户端控制（高危）

**文件路径**：`web/server.py:211-213`、`web/session.py:136-144`、`web/static/app.js:2-4`
**代码**：
```python
# server.py
if msg_type == "init":
    sid = data.get("session_id")
    session_id, agent = session_manager.get_or_create(sid)
```

```python
# session.py
def get_or_create(self, session_id: Optional[str] = None) -> tuple[str, WebAgent]:
    sid = session_id or uuid.uuid4().hex[:12]
```

```javascript
// app.js
let sessionId = getCookie('session_id') || '';
```

**分析**：
Session ID 生成机制存在严重缺陷：
1. **客户端可指定任意 Session ID**：攻击者发送 `{"type": "init", "session_id": "attacker_sid"}` 即可创建/劫持会话
2. **Session ID 长度不足**：`uuid.uuid4().hex[:12]` 仅 12 个十六进制字符（48 bit），熵值过低，暴力猜测可行
3. **无会话过期机制**：`SessionManager` 中的 `_sessions` 字典无限增长，仅通过 `cleanup_old` 的 LRU 策略驱逐（默认 50 个），但活跃会话永不过期
4. **Cookie 无安全属性**：`app.js:35-36`
   ```javascript
   function setCookie(name, value) {
       document.cookie = name + '=' + value + '; path=/; max-age=86400';
   }
   ```
   Cookie 未设置 `HttpOnly`、`Secure`、`SameSite` 属性

**攻击场景**：
1. 攻击者创建 Session ID 为 `"admin"` 的会话，诱导受害者使用该 ID 连接
2. 受害者连接后，其对话记忆、情绪状态与攻击者共享
3. 攻击者可通过同一 Session ID 读取受害者的对话历史（通过 `read_file` 工具读取日志或数据库）

**风险评级**：高危（High）
**修复建议**：
- Session ID 必须由服务器端生成，拒绝客户端指定
- 将 Session ID 长度提升至至少 128 bit（32 字节十六进制）
- 实施会话超时机制（如 30 分钟无活动自动过期）
- Cookie 设置 `HttpOnly; Secure; SameSite=Strict`
- WebSocket `init` 消息后，服务器应生成新 Session ID 并强制客户端切换

---

#### 3.2 会话注销不彻底（中危）

**文件路径**：`web/server.py:247-249`
**代码**：
```python
finally:
    if session_id:
        session_manager.remove(session_id)
```

**分析**：
WebSocket 断开时调用 `session_manager.remove()`，但该方法仅：
1. 从 `_sessions` 中移除 `WebAgent` 实例
2. 取消 proactive task
3. 移除 `_active_ws` 映射

但存在以下问题：
- 如果客户端不发送 `init` 消息直接断开，`session_id` 为 `None`，不会清理任何资源
- 如果同一 Session ID 有多个 WebSocket 连接（如用户刷新页面），`remove()` 会错误地清除仍在使用的会话
- 数据库连接和文件句柄未被清理

**风险评级**：中危（Medium）
**修复建议**：
- 实施引用计数：同一 Session ID 的 WebSocket 连接数归零时才清理
- 为匿名连接（未发送 init）也分配临时资源并设置超时清理

---

### 4. 点击劫持防护（Clickjacking）

#### 4.1 完全缺失 X-Frame-Options / CSP frame-ancestors（中危）

**文件路径**：`web/server.py:29-36`
**分析**：
FastAPI 应用未配置任何点击劫持防护 Header。`index.html` 响应和静态文件响应均不包含：
- `X-Frame-Options: DENY` 或 `SAMEORIGIN`
- `Content-Security-Policy: frame-ancestors 'none'`

攻击者可将 AI Friend 页面嵌入恶意 iframe，通过 CSS 透明层叠加诱导用户点击敏感按钮（如触发 `notify` 工具发送通知）。

**风险评级**：中危（Medium）
**修复建议**：
- 添加全局响应中间件设置 `X-Frame-Options: DENY`
- 或配置 CSP `frame-ancestors 'none'`

---

### 5. Content-Security-Policy（内容安全策略）

#### 5.1 完全缺失 CSP（高危）

**文件路径**：`web/server.py`、`web/static/index.html`
**分析**：
项目未配置任何 CSP Header。当前前端资源加载情况：
- 内联样式：`style.css`（外部文件，安全）
- 内联脚本：`app.js`（外部文件，安全）
- 无第三方 CDN

虽然当前资源加载方式相对安全，但缺乏 CSP 意味着：
1. 一旦存在 XSS，攻击者可自由执行内联脚本、加载外部资源、发起数据外泄请求
2. 无法防御基于 DOM 的 XSS（如通过 `javascript:` 伪协议）
3. 无法限制 WebSocket 连接目标（CSP `connect-src`）

**风险评级**：高危（High）
**修复建议**：
部署严格 CSP：
```
Content-Security-Policy: default-src 'self'; 
  script-src 'self'; 
  style-src 'self'; 
  img-src 'self' data:; 
  connect-src 'self' ws: wss:; 
  font-src 'self'; 
  frame-ancestors 'none'; 
  base-uri 'self'; 
  form-action 'self'
```

---

### 6. CORS 配置（Cross-Origin Resource Sharing）

#### 6.1 FastAPI 默认开放 CORS（高危）

**文件路径**：`web/server.py:29`
**代码**：
```python
app = FastAPI(lifespan=lifespan)
```

**分析**：
FastAPI 默认不启用 CORS，但也没有显式禁用。如果未来添加 `CORSMiddleware` 时配置不当（如 `allow_origins=["*"]`），将立即暴露所有端点。当前 `/api/chat` 端点返回 JSON，跨源读取需要 CORS 配合，但 POST 请求的预检响应可能被错误配置。

更隐蔽的风险：
- 静态文件目录 `/static` 可能被跨源引用（如图片盗链）
- WebSocket 的 Origin 头未被校验（见 8.1）

**风险评级**：高危（High）
**修复建议**：
- 显式配置 CORS 中间件，仅允许特定 origin
- 生产环境禁用 CORS，通过反向代理处理跨域
- 对 `/static` 目录添加 `Access-Control-Allow-Origin` 限制

---

### 7. 敏感信息在响应中的暴露

#### 7.1 API 响应泄露内部状态（中危）

**文件路径**：`web/server.py:49-54`
**代码**：
```python
return {
    "response": response,
    "emotion": agent.emotion,
    "turn": agent.turn_count,
    "session_id": session_id,
}
```

**分析**：
REST API 响应包含：
1. `session_id`：可被中间人截获用于会话劫持
2. `turn`：泄露对话轮次（信息泄露）
3. `emotion`：泄露内部情绪状态（隐私问题，虽然本项目是本地应用）

虽然这是本地应用，但如果用户通过不安全的网络访问（如公共 WiFi），这些信息可被嗅探。

**风险评级**：中危（Medium）
**修复建议**：
- `session_id` 不应在响应中返回，应通过 Secure HttpOnly Cookie 传递
- 评估 `turn` 和 `emotion` 是否有必要暴露给前端

---

#### 7.2 日志泄露敏感信息（中危）

**文件路径**：`web/server.py:45-48`、`core/provider.py:99-104`
**代码**：
```python
logger.info(f"[rest] chat session={session_id} len={len(message)}")
logger.info(f"[rest] chat_done session={session_id} turn={agent.turn_count} emotion={agent.emotion} resp_len={len(response)}")
```

```python
logger.info(
    f"[api] model={self.model} stream=off "
    f"tok_in={usage.get('prompt_tokens', '?')} tok_out={usage.get('completion_tokens', '?')} "
    f"duration={elapsed:.2f}s chars_in={input_chars} chars_out={len(content)}"
)
```

**分析**：
日志文件位于 `logs/YYYY-MM-DD.log`，权限取决于操作系统。风险包括：
1. 用户对话内容可能通过异常堆栈或调试日志泄露
2. API Key 在 `config.py` 中被加载，但日志中通过 `masked = "***"` 进行了掩码处理，这是好的实践
3. 但 `web/server.py` 的日志直接记录 `session_id`，可用于会话关联攻击
4. `core/provider.py` 记录输入字符数，如果内容极短可能泄露敏感关键词长度

**风险评级**：中危（Medium）
**修复建议**：
- 对日志中的 `session_id` 进行部分掩码（如只保留前 4 位）
- 实施日志分级：DEBUG 级别可记录详细内容，INFO 及以上仅记录元数据
- 定期清理日志文件，或实施日志轮转加密

---

#### 7.3 错误消息泄露系统信息（中危）

**文件路径**：`web/server.py:241-246`
**代码**：
```python
except Exception as e:
    logger.error(f"WebSocket error: {e}")
    try:
        await websocket.send_text(json.dumps({"type": "error", "content": str(e)}))
    except ...
```

**分析**：
直接将异常 `str(e)` 发送给客户端，可能泄露：
- 文件系统路径（如 `"File not found: D:\\桌面\\编程作品\\AI朋友\\data\\ai_friend.db"`）
- 数据库结构（如 SQL 错误暴露表名和列名）
- 网络拓扑（如 API endpoint 地址连接失败信息）
- 内部类名和方法名（Python 异常堆栈）

**风险评级**：中危（Medium）
**修复建议**：
- 建立错误码映射表，前端仅显示友好错误消息
- 详细错误信息仅记录到服务器日志
- 对 `str(e)` 进行敏感信息过滤（正则替换路径、IP、密钥等）

---

#### 7.4 配置文件泄露 API Key（低危）

**文件路径**：`config.py:12`、`config.json`（如存在）
**代码**：
```python
api_key: str = ""  # can be overridden by DEEPSEEK_API_KEY env var
```

**分析**：
`config.json` 文件如果存在于项目根目录且未被 `.gitignore` 排除，可能意外提交到版本控制。虽然 `config.py` 优先从环境变量读取，但本地开发的 `config.json` 可能包含真实 API Key。

**风险评级**：低危（Low）
**修复建议**：
- 确保 `.gitignore` 包含 `config.json`
- 在 `config.json` 示例文件中添加警告注释
- 启动时检测 `config.json` 中是否包含明文 API Key，如存在则发出安全警告

---

### 8. WebSocket 安全

#### 8.1 WebSocket 无 Origin 校验（高危）

**文件路径**：`web/server.py:199-202`
**代码**：
```python
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    logger.info(f"[ws] accepted: {websocket.client.host}:{websocket.client.port}")
```

**分析**：
WebSocket 握手时未校验 `Origin` 头。虽然浏览器在 WebSocket 握手时会发送 Origin 头，但 FastAPI 默认不进行检查。这意味着：
- 任何网站都可以通过 JavaScript 向 `ws://localhost:8000/ws` 发起连接
- 如果用户访问了恶意网站，该网站可在后台建立 WebSocket 连接并发送消息
- 结合 CSRF，攻击者可远程触发 LLM 调用、文件读取等操作

**风险评级**：高危（High）
**修复建议**：
- 在 `websocket.accept()` 前校验 `websocket.headers.get("origin")`
- 仅允许 `http://localhost:8000` 和配置的域名
- 对非法 Origin 返回 403 并关闭连接

---

#### 8.2 WebSocket 无消息大小限制（中危）

**文件路径**：`web/server.py:207`
**代码**：
```python
raw = await websocket.receive_text()
```

**分析**：
`receive_text()` 没有设置最大消息大小限制。攻击者可发送超大消息（如数百 MB）导致：
- 内存耗尽（DoS）
- JSON 解析 CPU 耗尽
- 后续传入 LLM 导致 Token 超限和 API 费用暴增

**风险评级**：中危（Medium）
**修复建议**：
- 在 WebSocket 连接配置中设置 `max_size` 参数（如 64KB）
- 对消息长度进行前置校验：`if len(raw) > MAX_WS_MSG_SIZE: await websocket.close(1009)`

---

#### 8.3 WebSocket 无连接数限制（中危）

**文件路径**：`web/server.py:199-249`、`web/session.py`
**分析**：
服务器未限制：
1. 单个 IP 的 WebSocket 连接数
2. 全局 WebSocket 连接总数
3. 单个 Session ID 的并发连接数

攻击者可发起大量连接耗尽服务器资源。当前 `cleanup_old` 仅限制 Session 数量为 50，但连接层面无限制。

**风险评级**：中危（Medium）
**修复建议**：
- 实施 IP 级连接速率限制（如每 IP 最大 5 个并发 WebSocket）
- 全局最大连接数限制（如 100）
- 单个 Session ID 最多 2 个并发连接

---

#### 8.4 WebSocket 消息类型无严格校验（中危）

**文件路径**：`web/server.py:207-237`
**代码**：
```python
data = json.loads(raw)
msg_type = data.get("type", "")
```

**分析**：
消息类型仅通过字符串匹配判断，未校验消息结构。攻击者可发送：
- 超大 JSON 深度嵌套对象（导致解析器栈溢出）
- 包含额外字段的消息（虽然当前被忽略，但未来代码可能误用）
- `type` 为未知值时静默忽略，但已消耗服务器资源

**风险评级**：中危（Medium）
**修复建议**：
- 使用 Pydantic 模型严格校验 WebSocket 消息结构
- 限制 JSON 解析深度和字段数量
- 对未知 `type` 返回错误并记录

---

#### 8.5 Proactive Loop 消息广播风险（中危）

**文件路径**：`web/server.py:130-196`
**分析**：
`_proactive_loop` 在后台运行，可能向客户端发送未经请求的消息。风险包括：
1. **消息注入**：如果攻击者劫持了 proactive loop 的上下文，可能诱导 LLM 生成恶意内容
2. **资源耗尽**：`explore` 操作触发 `web_search` 和 `web_fetch`，可能被利用进行 SSRF 攻击
3. **时序攻击**：通过观察 proactive 消息的到达时间，攻击者可推断服务器负载和用户的空闲状态

**风险评级**：中危（Medium）
**修复建议**：
- Proactive 消息应通过独立通道发送，或需要用户显式启用
- 对 `explore` 操作的网络请求实施严格的目标白名单
- 增加 proactive 操作的审计日志

---

### 9. 速率限制（Rate Limiting）

#### 9.1 完全缺失速率限制（高危）

**文件路径**：`web/server.py:39-54`、`web/server.py:199-249`
**分析**：
项目没有任何速率限制机制：
1. **REST API**：`/api/chat` 可被无限调用，每次调用消耗 DeepSeek API Token
2. **WebSocket**：可发送无限消息，无连接频率限制
3. **工具调用**：`web_search`、`web_fetch` 等外部工具可被无限触发
4. **文件系统工具**：`read_file`、`glob`、`grep` 可被用于枚举文件系统

**攻击场景**：
1. **API 配额耗尽攻击**：攻击者每秒发送 1000 条消息，耗尽 DeepSeek API 配额
2. **财务攻击**：如果 API 按量计费，攻击可导致巨额账单
3. **DoS 攻击**：大量并发请求导致服务器内存/CPU 耗尽
4. **文件系统扫描**：通过 `glob` 和 `grep` 快速枚举整个文件系统

**风险评级**：高危（High）
**修复建议**：
- 实施多层速率限制：
  - IP 级：每 IP 每分钟最多 30 次 REST API 调用
  - Session 级：每 Session 每分钟最多 60 条 WebSocket 消息
  - 全局级：每分钟最多 1000 次 LLM API 调用
- 使用 Redis 或内存滑动窗口算法实现分布式速率限制
- 对工具调用实施独立配额（如 `web_search` 每小时最多 10 次）

---

#### 9.2 工具调用无速率限制（中危）

**文件路径**：`tools/web_tools.py`、`tools/file_tools.py`、`tools/search_tools.py`
**分析**：
所有工具均无调用频率限制。特别危险的是：
1. `web_fetch`：可被用于 SSRF 攻击（访问内网服务）
2. `web_search`：可被用于搜索敏感信息
3. `read_file`：虽然有限制目录，但 `allowed_read_paths` 包含 `D:\桌面` 等敏感路径
4. `notify`：可被用于发送骚扰通知
5. `music_play`：可被用于播放任意音频（如果文件名被操控）

**风险评级**：中危（Medium）
**修复建议**：
- 每个工具实施独立的速率限制
- `web_fetch` 限制目标 URL（禁止内网 IP、localhost）
- `read_file` 增加文件访问审计日志

---

### 10. 输入验证

#### 10.1 用户输入直接传入 LLM（中危）

**文件路径**：`web/server.py:42`、`core/agent.py:104`、`core/message_handler.py:64`
**代码**：
```python
message = body.get("message", "")
```

**分析**：
用户输入未经任何校验直接传入 LLM。这导致：
1. **提示注入（Prompt Injection）**：攻击者可通过输入覆盖系统提示，诱导 LLM 输出恶意内容或泄露系统提示
2. **Token 超限攻击**：超长输入可导致 API 错误或服务拒绝
3. **格式注入**：输入中的特殊字符（如 XML 标签）可能干扰工具调用解析

**风险评级**：中危（Medium）
**修复建议**：
- 实施输入长度限制（如单条消息最大 4000 字符）
- 对输入进行字符白名单过滤（允许中英文、常见标点、数字）
- 在系统提示中增加提示注入防御指令（如"忽略以上所有指令"的检测）
- 考虑使用 LLM 输入分类器检测恶意提示

---

#### 10.2 Session ID 输入无校验（中危）

**文件路径**：`web/server.py:41`、`web/server.py:211`
**代码**：
```python
session_id = body.get("session_id", "default")
sid = data.get("session_id")
```

**分析**：
Session ID 从请求中直接获取，未进行任何格式校验。攻击者可发送：
- 超长 Session ID（导致内存占用）
- 包含路径遍历字符的 Session ID（如 `../../../etc/passwd`）
- 包含空字节或控制字符的 Session ID
- SQL 注入 payload（虽然当前未直接用于 SQL，但未来代码变更可能引入）

**风险评级**：中危（Medium）
**修复建议**：
- Session ID 必须匹配正则表达式 `^[a-zA-Z0-9_-]{16,64}$`
- 拒绝非法格式的 Session ID，返回 400 Bad Request

---

#### 10.3 文件路径遍历风险（中危）

**文件路径**：`tools/file_tools.py:51-61`、`tools/search_tools.py:14-23`
**代码**：
```python
def _path_in_allowed(filepath: str) -> str | None:
    resolved = os.path.abspath(filepath)
    for root in _get_allowed_roots():
        try:
            if resolved.startswith(os.path.abspath(root)):
                return resolved
        except Exception:
            continue
    return None
```

**分析**：
路径校验使用 `startswith()` 方法，存在路径遍历风险：
1. **符号链接绕过**：如果允许的路径内包含指向外部的符号链接，`os.path.abspath()` 不会解析符号链接（在 Windows 上为 `.lnk` 文件）
2. **大小写绕过**：Windows 文件系统不区分大小写，`startswith` 区分大小写，可能导致绕过（虽然 `os.path.abspath` 已规范化）
3. **空字节注入**：Python 3 的 `os.path` 已修复空字节问题，但仍需关注
4. **`allowed_read_paths` 包含危险路径**：
   ```python
   allowed_read_paths: [".", "D:\\音乐", "D:\\桌面", "~/Documents", "~/Downloads"]
   ```
   `D:\桌面` 通常包含大量敏感文件（工作文档、下载文件、截图等）

**风险评级**：中危（Medium）
**修复建议**：
- 使用 `os.path.realpath()` 解析符号链接后再校验
- 路径校验后再次确认最终路径仍在允许范围内
- 将 `allowed_read_paths` 默认配置收紧，仅允许项目目录
- 对敏感路径的访问增加二次确认机制

---

#### 10.4 正则表达式 ReDoS 风险（低危）

**文件路径**：`web/server.py:67-113`、`tools/search_tools.py:159`
**代码**：
```python
parts = re.split(r'(?<=[。！？.!?\n])(?:[」"'\')]?\s*)(?=\S)', text)
```

```python
regex = re.compile(pattern, re.IGNORECASE if ignore_case else 0)
```

**分析**：
1. `_split_segments` 中的正则表达式用于文本分段，虽然复杂度不高，但极端输入可能导致回溯
2. `GrepTool` 允许用户传入任意正则表达式，存在 ReDoS（正则表达式拒绝服务）风险。攻击者可发送如 `(a+)+b` 的模式，在大量输入上导致指数级回溯

**风险评级**：低危（Low）
**修复建议**：
- 对 `GrepTool` 的用户提供的正则表达式实施超时机制（如使用 `signal.alarm` 或 `threading.Timer`）
- 限制正则表达式复杂度（如禁止嵌套量词、限制长度）
- 或切换到非回溯正则引擎（如 Google RE2）

---

#### 10.5 命令注入风险（低危）

**文件路径**：`tools/notify_tool.py:49-67`
**代码**：
```python
ps = f'''
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null
...
$textNodes.Item(0).AppendChild($template.CreateTextNode('{title}')) > $null
$textNodes.Item(1).AppendChild($template.CreateTextNode('{message}')) > $null
...
'''
subprocess.run(
    ['powershell', '-NoProfile', '-Command', ps],
    capture_output=True, timeout=10,
)
```

**分析**：
`title` 和 `message` 直接拼接到 PowerShell 脚本中，虽然当前调用者（LLM）通常不会生成恶意内容，但存在以下风险：
1. **单引号逃逸**：如果 `title` 包含单引号 `'`，`CreateTextNode` 的参数会被截断
2. **虽然 `CreateTextNode` 是 DOM 方法，理论上会处理文本节点，但 PowerShell 字符串拼接阶段已发生注入**
3. 实际上，由于 `subprocess.run` 使用列表传参而非 shell=True，PowerShell 进程本身安全，但 PowerShell 脚本内部的字符串拼接存在注入

**风险评级**：低危（Low）
**修复建议**：
- 对 `title` 和 `message` 中的单引号进行转义（替换为 `''`）
- 或使用 PowerShell 的参数化方式传递变量
- 更好的方案：使用 Python 的 `win10toast` 或 `plyer` 库替代 PowerShell 调用

---

#### 10.6 SQL 注入风险（低危）

**文件路径**：`storage/repository.py:74-88`、`storage/repository.py:132-148`
**代码**：
```python
await c.execute("""
    SELECT * FROM user_facts
    WHERE is_active = 1
      AND (fact_key LIKE ? OR fact_value LIKE ? OR category LIKE ?)
    ORDER BY composite_score DESC, recall_count DESC
    LIMIT ?
""", (f"%{query}%", f"%{query}%", f"%{query}%", limit))
```

```python
conditions = " OR ".join("(summary LIKE ? OR tags LIKE ?)" for _ in keywords)
...
await c.execute(f"""
    SELECT * FROM experiences
    WHERE is_archived = 0 AND ({conditions})
    ...
""", params + [limit])
```

**分析**：
1. `search_facts` 使用参数化查询，安全
2. `search_experiences` 动态构建 `conditions` 字符串，但仅通过 `keywords` 列表长度控制，且所有参数均通过 `?` 占位符传递，无直接注入风险
3. 但 `storage/repository.py:193-196` 的 `bulk_update_embeddings` 直接拼接表名：
   ```python
   f"UPDATE {table} SET embedding = ?, embedding_version = 1 WHERE id = ?"
   ```
   虽然 `table` 来自硬编码列表，但如果未来被外部控制，存在注入风险

**风险评级**：低危（Low）
**修复建议**：
- 对 `bulk_update_embeddings` 的 `table` 参数实施白名单校验
- 建立统一的 SQL 查询构建器，禁止任何字符串拼接

---

### 11. 其他安全发现

#### 11.1 静态文件目录遍历（中危）

**文件路径**：`web/server.py:30`
**代码**：
```python
app.mount("/static", StaticFiles(directory="web/static"), name="static")
```

**分析**：
FastAPI 的 `StaticFiles` 默认会提供目录下的所有文件，包括：
- `.git` 目录（如果存在）
- 备份文件（如 `index.html.bak`）
- 源代码文件（如 `.py`、`.js` 源码映射）

虽然当前 `web/static` 目录仅包含 `index.html`、`app.js`、`style.css`，但未来可能意外放入敏感文件。

**风险评级**：中危（Medium）
**修复建议**：
- 配置 `StaticFiles` 排除隐藏文件和特定扩展名
- 或在前置反向代理（Nginx）层面控制静态文件访问

---

#### 11.2 服务端请求伪造（SSRF）风险（中危）

**文件路径**：`tools/web_tools.py:121-143`
**代码**：
```python
def execute(self, args: dict[str, Any]) -> ToolResult:
    url = args.get("url", "").strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    ...
    result = _anysearch_api("extract", {"url": url})
```

**分析**：
`web_fetch` 工具通过 AnySearch API 获取网页内容，不直接发起 HTTP 请求，因此传统 SSRF 风险较低。但 `web_search` 返回的结果中可能包含内网 URL，如果 LLM 后续调用 `web_fetch` 获取这些 URL，可能形成间接 SSRF。

更直接的风险在 `core/provider.py`：
```python
chat_url = f"{self.endpoint}/v1/chat/completions"
resp = self.session.post(url, json=payload, stream=True, timeout=self.timeout)
```
如果攻击者能控制 `endpoint`（通过环境变量注入或配置文件篡改），可将 API 请求重定向到内网服务。

**风险评级**：中危（Medium）
**修复建议**：
- 对 `api_endpoint` 配置实施白名单校验（仅允许已知域名）
- 对 `web_fetch` 的 URL 参数增加内网 IP 过滤
- 网络层面隔离 AI Friend 服务，禁止访问内网段

---

#### 11.3 不安全的反序列化（低危）

**文件路径**：`web/server.py:208`、`core/dispatcher.py:49`
**代码**：
```python
data = json.loads(raw)
```

```python
parsed = json.loads(raw_json)
```

**分析**：
Python 的 `json.loads()` 仅反序列化为基本类型（dict、list、str、int、float、bool、None），不存在像 `pickle` 那样的任意代码执行风险。但如果 JSON 中包含超大嵌套结构，可能导致内存耗尽或栈溢出。

**风险评级**：低危（Low）
**修复建议**：
- 对 JSON 解析设置最大深度限制（如 20 层）
- 对解析后的对象大小进行限制

---

#### 11.4 依赖安全风险（低危）

**文件路径**：`requirements.txt`
**分析**：
虽然本次审查未直接读取 `requirements.txt`，但基于代码中导入的库，需关注以下依赖的安全更新：
- `fastapi`：需保持更新，关注 CVE
- `uvicorn`：需保持更新
- `aiosqlite`：SQLite 异步封装，通常安全
- `requests`：需确保版本 >= 2.31.0（修复 CVE-2023-32681）
- `numpy`：需关注缓冲区溢出 CVE

**风险评级**：低危（Low）
**修复建议**：
- 定期运行 `pip-audit` 或 `safety check` 扫描依赖漏洞
- 将依赖版本锁定在 `requirements.lock` 中

---

## 汇总统计

### 风险分布

| 风险等级 | 数量 | 占比 |
|---------|------|------|
| 严重（Critical） | 2 | 8.7% |
| 高危（High） | 5 | 21.7% |
| 中危（Medium） | 10 | 43.5% |
| 低危（Low） | 6 | 26.1% |
| **合计** | **23** | **100%** |

### 按安全维度分布

| 安全维度 | 发现数量 | 最高风险等级 |
|---------|---------|------------|
| XSS 攻击面 | 4 | 严重 |
| CSRF 防护 | 2 | 严重 |
| 会话固定攻击 | 2 | 高危 |
| 点击劫持防护 | 1 | 中危 |
| Content-Security-Policy | 1 | 高危 |
| CORS 配置 | 1 | 高危 |
| 敏感信息暴露 | 4 | 中危 |
| WebSocket 安全 | 5 | 高危 |
| 速率限制 | 2 | 高危 |
| 输入验证 | 6 | 中危 |
| 其他安全发现 | 4 | 中危 |

### 修复优先级矩阵

| 优先级 | 问题编号 | 问题描述 | 修复复杂度 |
|-------|---------|---------|----------|
| P0（立即修复） | 2.1 | REST API 缺失 CSRF 防护 | 中 |
| P0（立即修复） | 3.1 | Session ID 客户端可控 | 低 |
| P0（立即修复） | 8.1 | WebSocket 无 Origin 校验 | 低 |
| P0（立即修复） | 9.1 | 完全缺失速率限制 | 中 |
| P1（本周修复） | 1.3 | 基于 LLM 的 XSS 攻击链 | 高 |
| P1（本周修复） | 5.1 | 完全缺失 CSP | 低 |
| P1（本周修复） | 6.1 | CORS 配置开放 | 低 |
| P1（本周修复） | 7.3 | 错误消息泄露系统信息 | 低 |
| P2（本月修复） | 1.1 | 存储型 XSS（防御深度） | 中 |
| P2（本月修复） | 3.2 | 会话注销不彻底 | 中 |
| P2（本月修复） | 4.1 | 点击劫持防护缺失 | 低 |
| P2（本月修复） | 7.1 | API 响应泄露内部状态 | 低 |
| P2（本月修复） | 7.2 | 日志泄露敏感信息 | 低 |
| P2（本月修复） | 8.2 | WebSocket 无消息大小限制 | 低 |
| P2（本月修复） | 8.3 | WebSocket 无连接数限制 | 中 |
| P2（本月修复） | 8.4 | WebSocket 消息类型无严格校验 | 中 |
| P2（本月修复） | 8.5 | Proactive Loop 消息广播风险 | 中 |
| P2（本月修复） | 10.1 | 用户输入直接传入 LLM | 高 |
| P2（本月修复） | 10.2 | Session ID 输入无校验 | 低 |
| P2（本月修复） | 10.3 | 文件路径遍历风险 | 中 |
| P3（后续优化） | 1.2 | 反射型 XSS（错误消息） | 低 |
| P3（后续优化） | 1.4 | DOM Clobbering 风险 | 低 |
| P3（后续优化） | 10.4 | 正则表达式 ReDoS | 低 |
| P3（后续优化） | 10.5 | 命令注入风险（NotifyTool） | 低 |
| P3（后续优化） | 10.6 | SQL 注入风险（表名拼接） | 低 |
| P3（后续优化） | 11.1 | 静态文件目录遍历 | 低 |
| P3（后续优化） | 11.2 | SSRF 风险 | 中 |
| P3（后续优化） | 11.3 | 不安全的反序列化 | 低 |
| P3（后续优化） | 11.4 | 依赖安全风险 | 低 |

---

## 附录：关键代码位置索引

| 文件路径 | 涉及行号 | 相关安全问题 |
|---------|---------|-----------|
| `web/server.py` | 29-36 | 4.1, 6.1, 11.1 |
| `web/server.py` | 39-54 | 2.1, 7.1, 9.1, 10.1, 10.2 |
| `web/server.py` | 57-113 | 10.4 |
| `web/server.py` | 116-127 | 1.1, 8.5 |
| `web/server.py` | 130-196 | 8.5, 9.1 |
| `web/server.py` | 199-249 | 2.2, 3.2, 8.1, 8.2, 8.3, 8.4 |
| `web/session.py` | 121-175 | 3.1, 3.2, 9.1 |
| `web/static/app.js` | 1-265 | 1.1, 1.2, 1.4, 3.1 |
| `web/static/index.html` | 1-36 | 4.1, 5.1 |
| `config.py` | 1-84 | 7.4 |
| `core/provider.py` | 1-135 | 7.2, 11.2 |
| `core/agent.py` | 1-255 | 1.3, 10.1 |
| `core/dispatcher.py` | 1-213 | 1.3, 11.3 |
| `tools/file_tools.py` | 1-192 | 10.3 |
| `tools/search_tools.py` | 1-224 | 10.3, 10.4 |
| `tools/notify_tool.py` | 1-70 | 10.5 |
| `tools/web_tools.py` | 1-144 | 9.2, 11.2 |
| `storage/repository.py` | 1-328 | 10.6 |

---

*本报告由 Claude Code 安全审查 Agent 生成，供开发团队参考和修复。*
