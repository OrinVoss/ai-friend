# AI Friend 项目性能与可扩展性审查报告 —— 内存使用专题

**审查日期**: 2026-05-31
**审查范围**: memory/short_term.py, web/session.py, core/agent.py, core/context_manager.py, memory/consolidation.py 及相关依赖文件
**审查维度**: 内存占用、对象生命周期、引用循环、缓存策略、数据累积、峰值控制

---

# 概述

AI Friend 项目采用三层 Agent 架构（Agent 1 InnerDrive → Agent 2 ToolAgent → Agent 3 Roleplay），同时支持 CLI 和 Web 双模式运行。本项目在内存管理方面存在多处隐患：短期记忆缓冲区容量配置不一致、Web 会话无过期机制导致对象无限增长、ReAct 循环中消息列表持续累积、嵌入向量缺乏全局缓存控制、大文件读取存在内存峰值风险、WebSocket 消息缺乏背压机制，以及多处潜在的 Python 对象引用循环。这些问题在单用户 CLI 模式下表现不明显，但在 Web 多会话场景下会随着运行时间线性恶化，最终可能导致进程 OOM 或被操作系统终止。

本次审查共识别出 **8 大类内存风险**，涵盖 20+ 个具体代码位置，风险评级从高（Critical）到低（Low）分布如下：

| 风险等级 | 数量 | 说明 |
|---------|------|------|
| Critical | 2 | 可导致进程 OOM 或内存泄漏 |
| High | 4 | 长期运行后显著影响性能 |
| Medium | 6 | 在特定场景下造成内存浪费 |
| Low | 4 | 轻微或可忽略的内存开销 |

---

## 详细发现

---

### 1. ConversationBuffer 的 maxlen 与内存占用

**风险评级**: High

#### 1.1 默认 maxlen 与配置不一致

**文件**: `memory/short_term.py` 第 15 行
**代码**:
```python
@dataclass
class ConversationBuffer:
    maxlen: int = 20
```

**文件**: `config.py` 第 19 行
**代码**:
```python
short_term_capacity: int = 500
```

**问题描述**:
`ConversationBuffer` 的默认 `maxlen` 为 20，但 `Config` 中配置的 `short_term_capacity` 为 500。在 `web/session.py` 第 34 行中，`WebAgent` 使用 `config.short_term_capacity` 初始化缓冲区：

```python
self.short_term = ConversationBuffer(maxlen=config.short_term_capacity)
```

而在 CLI 模式下（`main.py` 未在本次审查范围内，但从架构推断），如果直接使用默认构造 `ConversationBuffer()`，则 maxlen 仅为 20。这种不一致导致：
- Web 端短期记忆可保存 500 条，内存占用约为 20 条版本的 25 倍
- CLI 端可能只有 20 条，行为不一致

更严重的是，`ConversationBuffer` 使用 `collections.deque` 的 `maxlen` 特性，超出容量时自动丢弃最旧元素。虽然 deque 本身不会无限增长，但 **500 条对话记录的内存占用仍然相当可观**。假设每条记录平均 500 字符（含 metadata），500 条约需 250KB 文本数据；加上 `Turn` 对象、datetime 对象、dict 开销，实际内存占用可达 **2-5MB 每会话**。

#### 1.2 Turn 对象持有完整 content 字符串

**文件**: `memory/short_term.py` 第 23-35 行
**代码**:
```python
def add_turn(self, role: str, content: str,
             metadata: Optional[dict] = None) -> Turn:
    turn = Turn(
        turn_id=self._next_id,
        role=role,
        content=content,
        timestamp=datetime.now(),
        metadata=metadata or {},
    )
```

**问题描述**:
`Turn` 对象直接持有 `content` 字符串的引用。如果用户输入或 AI 回复包含大段文本（如通过 `read_file` 读取的文件内容、通过 `web_fetch` 获取的网页全文），这些大字符串会被完整地保存在短期记忆中。`content` 字符串可能达到数千甚至上万字符，500 条这样的记录将使短期记忆缓冲区膨胀到 **数十 MB**。

#### 1.3 content 未做截断或压缩

**文件**: `memory/short_term.py` 第 51-64 行的 `format_for_prompt` 方法虽然对输出做了截断（`max_chars=3000`），但这只是格式化时的截断，原始 `content` 仍然完整地保存在 `_turns` deque 中。没有任何机制在存储前对大 content 进行截断或摘要。

#### 1.4 get_all_reversed 返回完整列表副本

**文件**: `memory/short_term.py` 第 46-49 行
**代码**:
```python
def get_all_reversed(self) -> list[Turn]:
    """Return turns in reverse order (newest first) without extra copy."""
    with self._lock:
        return list(reversed(self._turns))
```

**问题描述**:
注释声称 "without extra copy"，但实际上 `list(reversed(self._turns))` 创建了一个全新的 `list` 对象，其中包含对原有 `Turn` 对象的引用。虽然 `Turn` 对象本身没有被深拷贝，但列表容器是新分配的。在 `_build_messages`（`core/message_handler.py` 第 274-291 行）中，每次调用都会遍历 `get_all_reversed()` 的结果，对于 500 条记录，这意味着每次构建消息都要遍历 500 个元素并做 token 估算，CPU 和内存压力都会累积。

#### 1.5 修复建议

1. 统一 `maxlen` 默认值与配置值，或移除默认值强制要求传入
2. 在 `add_turn` 中对 `content` 做长度限制，超过阈值时存储摘要或截断版本
3. 考虑使用 `__slots__` 减少 `Turn` 对象的内存开销
4. `get_all_reversed` 应返回迭代器而非列表，避免中间容器分配

---

### 2. SessionManager 会话无限增长

**风险评级**: Critical

#### 2.1 _sessions 字典无过期机制

**文件**: `web/session.py` 第 126-128 行
**代码**:
```python
class SessionManager:
    def __init__(self, config: Config):
        self._sessions: dict[str, WebAgent] = {}
        self._proactive_tasks: dict[str, object] = {}
        self._active_ws: dict[str, object] = {}
```

**问题描述**:
`SessionManager` 维护三个字典：`_sessions`（会话 Agent 对象）、`_proactive_tasks`（异步任务）、`_active_ws`（WebSocket 连接）。这些字典只有两种移除方式：
1. 客户端断开 WebSocket 时调用 `remove()`（第 146-153 行）
2. 超过 `max_sessions=50` 时调用 `cleanup_old()`（第 169-174 行）

**关键问题**:
- `cleanup_old()` 仅在超过 50 个会话时触发，且采用 FIFO 策略移除最旧的会话。但 "最旧" 是根据字典插入顺序决定的，而字典在 Python 3.7+ 中确实保持插入顺序。然而，**如果某个旧会话仍然活跃（WebSocket 未断开），`cleanup_old()` 会直接将其驱逐**，导致该会话的状态丢失，但客户端仍认为连接有效。
- 更危险的是，如果使用 REST API（`/api/chat`）而非 WebSocket，每次请求都会创建新会话（如果 `session_id` 未提供或不存在），但 REST 请求结束后 **不会自动调用 `remove()`**。这意味着通过 REST API 的匿名请求会不断创建新的 `WebAgent` 实例，每个实例包含完整的 Agent 状态（Personality、LTM、ShortTerm、Provider、Retriever、Consolidator 等），内存占用可达 **10-30MB**。50 个会话就是 **500MB-1.5GB**，且没有自动清理机制。

#### 2.2 WebAgent 持有大量重量级对象

**文件**: `web/session.py` 第 28-80 行
**代码**:
```python
class WebAgent:
    def __init__(self, config: Config, db: Database, repo: Repository):
        self.config = config
        self.db = db
        self.repo = repo
        self.personality = Personality.load(config.personality_file)
        self.ltm = LongTermMemory(repo)
        self.short_term = ConversationBuffer(maxlen=config.short_term_capacity)
        # ... 恢复 30 条历史记录
        self.provider = KimiProvider(...)
        # ... EmbeddingEngine, MemoryRetriever, MemoryConsolidator
        self.agent = Agent(...)
```

**问题描述**:
每个 `WebAgent` 实例都独立持有：
- 一个 `Personality` 对象（含 `EmotionalState`，后者包含 `emotion_events` 列表、`history` 列表等）
- 一个 `LongTermMemory` 对象（持有 `Repository` 引用）
- 一个 `ConversationBuffer`（maxlen=500）
- 一个 `KimiProvider`（含 `requests.Session`，保持 HTTP 连接池）
- 一个 `EmbeddingEngine`（含 `requests.Session`）
- 一个 `MemoryRetriever`
- 一个 `MemoryConsolidator`（含 `_pending_buffer` 列表）
- 一个 `Agent`（含 `_tool_call_history`、`_context`、`_proactive`、`_cli`、`_messages` 等）
- 一个 `ToolRegistry` 及所有工具实例

这些对象的总内存 footprint 估算：
- `Personality` + `EmotionalState`: ~50KB（含 emotion_events 历史）
- `ConversationBuffer` (500 turns): ~2-5MB
- `KimiProvider` (session + headers): ~100KB
- `EmbeddingEngine`: ~50KB
- `Agent` 内部状态: ~500KB（含消息列表、工具历史等）
- 工具实例: ~100KB
- **总计: 约 3-6MB 每会话**

50 个会话 = **150-300MB**。虽然不算极端，但加上长期记忆检索时加载的数据、嵌入向量、LLM 响应缓存等，实际占用会更高。

#### 2.3 cleanup_old 的 FIFO 策略不安全

**文件**: `web/session.py` 第 169-174 行
**代码**:
```python
def cleanup_old(self, max_sessions: int = 50) -> None:
    with self._lock:
        while len(self._sessions) > max_sessions:
            oldest = next(iter(self._sessions))
            self._sessions.pop(oldest)
            logger.info(f"Session evicted: {oldest}")
```

**问题描述**:
`cleanup_old()` 被调用时（目前代码中未看到显式调用位置，可能是计划中的功能），仅移除 `_sessions` 中的条目，但：
- 不会取消对应的 proactive task
- 不会关闭对应的 WebSocket
- 不会清理 `_proactive_tasks` 和 `_active_ws` 字典中的条目

这导致被驱逐的会话的 task 和 WebSocket 引用仍然保留在内存中，形成 **僵尸引用**。如果 `cleanup_old()` 被定期调用，这些僵尸引用会不断累积。

#### 2.4 修复建议

1. 为会话添加 **TTL（Time-To-Live）机制**：记录最后活动时间，定期扫描并移除过期会话
2. `cleanup_old()` 应同步清理 `_proactive_tasks` 和 `_active_ws`
3. REST API 端点应要求提供 `session_id`，避免匿名请求创建无限会话
4. 考虑会话状态的 **序列化与反序列化**：将不活跃会话状态写入磁盘，从内存中移除
5. 共享重量级对象：`KimiProvider`、`EmbeddingEngine`、`Database` 等应在会话间共享，而非每个 `WebAgent` 独立创建

---

### 3. _tool_call_history 的 20 条限制

**风险评级**: Medium

#### 3.1 截断策略正确但数据冗余

**文件**: `core/agent.py` 第 162-169 行
**代码**:
```python
for r in results:
    self._tool_call_history.append({
        "name": r["name"],
        "success": r["success"],
        "output": r["output"[:200],
        "time": time.time(),
    })
if len(self._tool_call_history) > 20:
    self._tool_call_history = self._tool_call_history[-20:]
```

**问题描述**:
`_tool_call_history` 被限制为 20 条，且 `output` 被截断为 200 字符，这部分设计是合理的。但存在以下问题：

1. **每次截断都创建新列表**: `self._tool_call_history = self._tool_call_history[-20:]` 会创建一个新的列表对象并赋值。虽然旧列表会被垃圾回收（如果没有其他引用），但这种模式在频繁工具调用的场景下会产生大量短生命周期的列表对象，增加 GC 压力。

2. **output 截断发生在 append 之后**: `r["output"[:200]` 的写法实际上有语法错误风险——如果 `r["output"]` 是字符串，`r["output"[:200]` 等价于 `r["output"][:200]`，这是正确的。但如果 `r["output"]` 不是字符串（如 None），会抛出 TypeError。虽然从 `execute_tool_calls` 的实现来看 `output` 总是字符串，但这种写法不够健壮。

3. **time.time() 的浮点数精度**: 每条记录存储 `time.time()` 的完整浮点数（约 17 位有效数字），对于历史记录而言，毫秒级精度已足够，可以存储为整数时间戳减少内存。

#### 3.2 修复建议

1. 使用 `collections.deque(maxlen=20)` 替代列表，避免手动截断和列表重新分配
2. 将时间戳存储为 `int(time.time())` 或 `int(time.time() * 1000)`
3. 对 `output` 做防御性类型检查后再截断

---

### 4. 消息列表在 _react_loop 中的累积

**风险评级**: Critical

#### 4.1 messages 列表在循环中持续增长

**文件**: `core/agent.py` 第 119-181 行
**代码**:
```python
def _react_loop(self, messages: list[dict], on_token=None, add_to_history: bool = True,
                tool_registry=None, skip_post_process: bool = False) -> str:
    for _idx in range(self._max_tool_iterations):
        resp = self.provider.generate(
            messages, stream=False if _idx > 0 else True,
            ...
        )
        cleaned, calls = parse_tool_calls(resp)
        if not calls:
            ...
            break
        messages.append({"role": "assistant", "content": resp})
        results = execute_tool_calls(registry, calls)
        ...
        messages.append({"role": "user", "content": format_tool_results(results)})
```

**问题描述**:
`_react_loop` 是 Agent 3（Roleplay）的核心 ReAct 循环。每次迭代中：
1. 将 assistant 的完整响应 `resp` append 到 `messages`
2. 将 tool results 格式化的文本 append 到 `messages`

如果 `_max_tool_iterations=10`，最多会追加 20 条消息（10 条 assistant + 10 条 user）。这些消息的内容包括：
- LLM 的完整响应文本（可能数百到数千 token）
- 工具返回的原始结果（`format_tool_results` 的输出，可能包含大量文本）

更严重的是，`_react_loop` 被 `_build_messages` 调用，而 `_build_messages` 已经构建了一个包含 system prompt + 历史对话的 `messages` 列表。`_react_loop` 在此基础上继续追加，导致：
- 第 1 轮迭代：`messages` 已有 N 条，追加 2 条 → N+2
- 第 2 轮迭代：`messages` 已有 N+2 条，追加 2 条 → N+4
- ...
- 第 10 轮迭代：`messages` 已有 N+18 条，追加 2 条 → N+20

这个列表在 `_react_loop` 结束后才被释放（如果没有被其他引用持有）。在 10 轮迭代的最坏情况下，`messages` 列表可能包含 **N+20 条消息，总字符数可达数万**，内存占用显著。

#### 4.2 工具结果文本未被截断

**文件**: `core/dispatcher.py` 第 153-169 行的 `format_tool_results` 函数：
```python
def format_tool_results(results: list[dict]) -> str:
    parts = []
    for r in results:
        tag = "成功" if r["success"] else "失败"
        parts.append(
            f'<tool_result name="{r["name"]}">\n'
            f"工具 {r['name']} 执行{tag}:\n"
            f"{r['output']}\n"
            f"</tool_result>"
        )
```

**问题描述**:
`format_tool_results` 直接使用 `r["output"]` 的完整内容，没有任何长度限制。如果工具返回大量文本（如 `web_fetch` 返回 8000 字符的网页内容、`read_file` 返回大量文件内容），这些文本会完整地进入 `messages` 列表。

结合 `web_tools.py` 第 140 行：
```python
return ToolResult.ok(f"{header}:\n```\n{content[:8000]}\n```")
```

`web_fetch` 最多返回 8000 字符的内容。如果 `_react_loop` 中连续调用多次 `web_fetch`，这些 8000 字符的块会全部累积在 `messages` 中。

#### 4.3 ToolAgent 中的 messages 同样累积

**文件**: `core/tool_agent.py` 第 82-140 行的 `run` 方法和第 142-224 行的 `run_with_request` 方法都存在同样的模式：在循环中向 `messages` 追加 assistant 响应和 tool results。

#### 4.4 修复建议

1. 在 `_react_loop` 中，对每轮追加的消息内容做长度限制，超过阈值时截断或替换为摘要
2. `format_tool_results` 应对每个工具的 `output` 做截断（如最多 2000 字符）
3. 考虑在 `_react_loop` 中使用生成器或流式处理，避免完整消息列表常驻内存
4. 限制 `_max_tool_iterations` 的默认值（目前为 10，建议降至 5）

---

### 5. 嵌入向量的内存占用

**风险评级**: High

#### 5.1 EmbeddingCache 缺乏全局大小控制

**文件**: `memory/embeddings.py` 第 86-117 行
**代码**:
```python
class EmbeddingCache:
    def __init__(self, max_size: int = 1000):
        self._max_size = max_size
        self._cache: OrderedDict[str, np.ndarray] = OrderedDict()

    def get(self, text: str) -> np.ndarray | None:
        key = self._hash(text)
        if key in self._cache:
            self._cache.move_to_end(key)
            return self._cache[key].copy()

    def set(self, text: str, vec: np.ndarray):
        key = self._hash(text)
        if key in self._cache:
            self._cache.move_to_end(key)
        self._cache[key] = vec.copy()
        while len(self._cache) > self._max_size:
            self._cache.popitem(last=False)
```

**问题描述**:
`EmbeddingCache` 使用 LRU 策略，默认最大 1000 条。每条缓存项存储：
- SHA-256 哈希字符串（64 字符）
- 一个 `np.ndarray` 向量（dim=512，float32）

向量内存占用：512 * 4 bytes = 2KB。加上 ndarray 对象开销、OrderedDict 开销、哈希字符串，**每条约 2.5-3KB**。1000 条约 **2.5-3MB**。

但关键问题是：**`EmbeddingCache` 目前没有被任何代码使用**。在 `memory/embeddings.py` 中定义了 `EmbeddingCache` 类，但在 `EmbeddingEngine` 中没有实例化或使用它。`WebAgent`（`web/session.py` 第 52-55 行）创建 `EmbeddingEngine` 时也没有传入 cache 参数。这意味着：
- 每次调用 `encode()` 或 `encode_single()` 都会向嵌入服务器发起 HTTP 请求
- 没有本地缓存来避免重复编码相同文本
- 如果将来启用 `EmbeddingCache`，每个 `WebAgent` 实例会独立持有一个 cache，50 个会话就是 50 * 3MB = **150MB**

#### 5.2 嵌入向量在数据库和内存中双重存储

**文件**: `memory/consolidation.py` 第 255-297 行的 `_embed_new_items` 方法：
```python
def _embed_new_items(self) -> None:
    if not self._embed or not self._embed.health_check():
        return
    ...
    for table, text_cols in [
        ("user_facts", ["category", "fact_key", "fact_value"]),
        ("experiences", ["summary", "emotional_tone", "tags"]),
        ("reflections", ["content"]),
    ]:
        rows = conn.execute(
            f"SELECT id, {col_list} FROM {table} "
            "WHERE embedding IS NULL LIMIT 50"
        ).fetchall()
        ...
        vecs = self._embed.encode(texts)
        for (tbl, rid), vec in zip(targets, vecs):
            all_updates.append((tbl, rid, EmbeddingEngine.vec_to_bytes(vec)))
```

**问题描述**:
`_embed_new_items` 从数据库读取最多 50 条未编码记录，编码后将向量以 BLOB 形式写回数据库。这部分设计是合理的。但问题在于：

1. **检索时从数据库读取嵌入向量**: `memory/retrieval.py` 第 122-127 行：
```python
if hasattr(c, 'embedding') and c.embedding is not None:
    try:
        vec = EmbeddingEngine.bytes_to_vec(bytes(c.embedding))
        semantic = float(np.dot(vec, query_vec))
    except Exception:
        pass
```
每次检索时，都会将 BLOB 转换为 `np.ndarray`。对于 50 个候选 facts，这意味着创建 50 个临时 ndarray。虽然这些 ndarray 在计算后会被释放，但频繁的创建/销毁增加了 GC 压力。

2. **没有内存中的向量索引**: 所有语义搜索都需要从 SQLite 读取 BLOB、反序列化为 ndarray、计算点积。对于大量候选（如 `get_all_active_facts(limit=50)` 返回 50 条），这个过程在每次用户消息时都会重复执行，CPU 和内存效率都不高。

#### 5.3 修复建议

1. 在 `EmbeddingEngine` 中启用 `EmbeddingCache`，并在会话间共享 cache 实例
2. 考虑使用 FAISS 或类似库构建内存中的向量索引，避免每次检索都反序列化 BLOB
3. 限制每次检索加载的候选数量，或实现分页/分层检索
4. 将嵌入维度从 512 降至 384 或 256（如果模型支持），可减少 25-50% 的向量内存占用

---

### 6. 大文件读取的内存峰值

**风险评级**: High

#### 6.1 read_file 一次性读取整个文件到内存

**文件**: `tools/file_tools.py` 第 144-150 行
**代码**:
```python
try:
    with open(resolved, encoding="utf-8", errors="replace") as f:
        all_lines = f.readlines()
except PermissionError:
    return ToolResult.fail(f"无权限: {filepath}")
except Exception as e:
    return ToolResult.fail(f"读取失败: {e}")

total_lines = len(all_lines)
start = max(0, offset)
end = min(total_lines, start + limit)
selected = all_lines[start:end]
```

**问题描述**:
`ReadFileTool._read_one()` 方法使用 `f.readlines()` 一次性将整个文件读取到内存中，即使只需要其中 200 行。虽然文件大小被限制为 500KB（第 10 行 `MAX_FILE_SIZE = 500 * 1024`），但 500KB 的文本文件仍然会产生：
- 一个包含所有行的列表（`all_lines`）
- 每个行字符串对象
- 随后创建的 `selected` 子列表

对于 500KB 的文件，假设平均行长度 50 字符，约 10,000 行。`f.readlines()` 会创建一个包含 10,000 个字符串的列表，内存峰值约为 **1-2MB**（含对象开销）。虽然不算巨大，但在并发场景下（多个会话同时读取文件），峰值会叠加。

更严重的是，这个工具返回的结果会进入 `_react_loop` 的 `messages` 列表（通过 `format_tool_results`），然后进入 LLM 的 prompt。如果 LLM 的 prompt 中包含大量文件内容，API 请求本身的内存占用也会显著增加。

#### 6.2 批量读取多个文件

**文件**: `tools/file_tools.py` 第 180-191 行
**代码**:
```python
paths = [p.strip() for p in filepath_raw.split(",") if p.strip()]
if len(paths) > 5:
    return ToolResult.fail("最多同时读取 5 个文件")

results = []
for p in paths:
    r = self._read_one(p, limit, offset)
    results.append(r.output if r.success else f"[失败] {p}: {r.output}")
return ToolResult.ok("\n\n---\n\n".join(results))
```

**问题描述**:
批量读取时，每个文件都独立调用 `_read_one()`，结果字符串通过 `"\n\n---\n\n".join(results)` 拼接。如果同时读取 5 个 500KB 文件，结果字符串可能达到 **2.5MB**，加上中间列表和字符串的内存开销，峰值可能达到 **5-10MB**。

#### 6.3 web_fetch 返回内容无限制

**文件**: `tools/web_tools.py` 第 140 行
**代码**:
```python
return ToolResult.ok(f"{header}:\n```\n{content[:8000]}\n```")
```

**问题描述**:
`web_fetch` 对返回内容做了 8000 字符的截断，这是好的。但截断发生在获取完整内容之后——`_anysearch_api` 函数（第 16-35 行）已经通过 HTTP 请求获取了完整的 API 响应，包括完整的网页内容。如果 AnySearch API 返回的内容非常大（如几 MB），在截断前已经占用了大量内存。

#### 6.4 修复建议

1. `read_file` 应使用 `itertools.islice` 或逐行读取，避免 `f.readlines()` 的内存峰值
2. 批量读取时应流式处理，或限制总输出大小
3. `web_fetch` 应在 HTTP 响应层面限制内容大小（如设置 `max_length` 参数给 AnySearch API，或在流式读取时截断）
4. 工具返回的结果在进入 `messages` 列表前应做二次截断

---

### 7. WebSocket 消息缓冲

**风险评级**: Medium

#### 7.1 无背压机制的流式发送

**文件**: `web/server.py` 第 116-127 行
**代码**:
```python
async def _send_segments(websocket: WebSocket, agent, response: str, emotion: str):
    segments = _split_segments(response)
    for i, seg in enumerate(segments):
        if i > 0:
            await asyncio.sleep(_calc_delay(emotion, len(seg)))
        await websocket.send_text(json.dumps({
            "type": "segment", "content": seg,
        }, ensure_ascii=False))
```

**问题描述**:
`_send_segments` 将 AI 的完整响应分割为多个片段，通过 WebSocket 逐段发送。虽然 `await websocket.send_text()` 是异步的，但 **FastAPI 的 WebSocket 实现内部有发送缓冲区**。如果客户端接收缓慢（如网络延迟、客户端处理慢），服务器的发送缓冲区会累积未发送的消息。

更严重的是，`_proactive_loop`（第 130-196 行）在后台持续运行，可能在没有用户输入的情况下主动发送消息。如果 proactive 消息频繁且客户端处理慢，发送缓冲区会不断增长。

#### 7.2 无消息队列大小限制

**文件**: `web/server.py` 第 199-249 行的 WebSocket 端点：
```python
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    ...
    try:
        while True:
            raw = await websocket.receive_text()
            ...
```

**问题描述**:
WebSocket 端点没有限制同时处理的请求数量或消息队列大小。如果客户端发送大量消息（如恶意攻击或程序错误），`process_message` 会在 `run_in_executor` 中同步执行，可能阻塞线程池。

#### 7.3 修复建议

1. 为 WebSocket 发送添加背压检测：如果发送缓冲区超过阈值，暂停生成新片段或丢弃旧片段
2. 限制 `_proactive_loop` 同时发送的消息数量，避免后台任务淹没客户端
3. 为 WebSocket 消息处理添加速率限制（如每秒最多 N 条消息）
4. 考虑使用 `asyncio.Queue` 管理待发送消息，并设置最大队列大小

---

### 8. Python 对象引用循环

**风险评级**: Medium

#### 8.1 Agent 与 MessageHandler 相互引用

**文件**: `core/agent.py` 第 87-88 行
**代码**:
```python
self._cli = CliController(self)
self._messages = MessageHandler(self)
```

**文件**: `core/message_handler.py` 第 17-23 行
**代码**:
```python
class MessageHandler:
    def __init__(self, agent):
        self._agent = agent
        self._tool_agent = None
        self._inner_drive = None
```

**问题描述**:
`Agent` 持有 `MessageHandler` 的引用，`MessageHandler` 又持有 `Agent` 的引用，形成 **循环引用**。虽然 Python 的循环垃圾回收器（generational GC）可以处理这种情况，但：
- 循环引用会导致对象无法被立即回收，必须等待 GC 扫描
- 如果循环引用链中的对象定义了 `__del__` 方法，可能导致对象无法被回收（Python 3.4+ 已改善，但仍有问题）
- 在长时间运行的服务器进程中，循环引用会增加 GC 负担，导致停顿

类似地，`Agent` 与 `CliController`、`Agent` 与 `ContextManager`、`Agent` 与 `ProactivityManager`、`Agent` 与 `SleepManager` 之间都存在循环引用。

#### 8.2 WebAgent 与 Agent 相互引用

**文件**: `web/session.py` 第 73-79 行
**代码**:
```python
self.agent = Agent(
    personality=self.personality, provider=self.provider,
    ltm=self.ltm, retriever=self.retriever,
    consolidator=self.consolidator, short_term=self.short_term,
    config=config,
)
self.agent._tool_registry = registry
```

**问题描述**:
`WebAgent` 持有 `Agent` 的引用（`self.agent`），`Agent` 又通过 `_messages`（`MessageHandler`）间接引用回 `WebAgent`（通过 `MessageHandler._agent`）。虽然这不是直接的循环引用，但引用链较长，增加了 GC 的复杂度。

#### 8.3 SessionManager 持有 WebSocket 和 Task 引用

**文件**: `web/session.py` 第 126-128 行
**代码**:
```python
self._sessions: dict[str, WebAgent] = {}
self._proactive_tasks: dict[str, object] = {}
self._active_ws: dict[str, object] = {}
```

**问题描述**:
`SessionManager` 持有 `WebAgent`、asyncio Task 和 WebSocket 的引用。当客户端断开连接时，`remove()` 方法会清理这些引用。但如果 `remove()` 未被调用（如异常退出、进程被 kill），这些对象会一直被 `SessionManager` 持有，无法被 GC。

#### 8.4 LongTermMemory 的 _run_sync 创建 ThreadPoolExecutor

**文件**: `memory/long_term.py` 第 17-27 行
**代码**:
```python
@staticmethod
def _run_sync(coro):
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return pool.submit(asyncio.run, coro).result()
```

**问题描述**:
`_run_sync` 在每次调用时都可能创建一个新的 `ThreadPoolExecutor`（如果没有正在运行的事件循环）。`ThreadPoolExecutor` 会创建并维护一个线程池，即使使用 `with` 语句，线程的销毁也有延迟。频繁调用 `_run_sync` 会导致线程频繁创建/销毁，增加内存和 CPU 开销。

更关键的是，`storage/repository.py` 第 13-21 行也定义了相同的 `_run_sync` 函数，存在 **代码重复**。

#### 8.5 修复建议

1. 在循环引用的一方使用 `weakref.ref` 或 `weakref.proxy` 打破循环
2. 为 `Agent` 添加显式的 `close()` 或 `shutdown()` 方法，在会话结束时清理所有引用
3. `SessionManager` 应使用 `weakref.WeakValueDictionary` 存储 `_sessions`，允许 `WebAgent` 在不被其他地方引用时被自动回收
4. `_run_sync` 应使用全局共享的 `ThreadPoolExecutor`，而非每次创建新的
5. 合并 `memory/long_term.py` 和 `storage/repository.py` 中重复的 `_run_sync` 实现

---

## 汇总统计

### 风险分布

| 序号 | 问题类别 | 风险等级 | 影响范围 | 文件位置 |
|-----|---------|---------|---------|---------|
| 1.1 | ConversationBuffer maxlen 配置不一致 | High | 所有模式 | memory/short_term.py:15, config.py:19 |
| 1.2 | Turn 对象持有完整 content 字符串 | High | 所有模式 | memory/short_term.py:23-35 |
| 1.3 | content 未做存储前截断 | Medium | 所有模式 | memory/short_term.py:23-35 |
| 1.4 | get_all_reversed 返回完整列表副本 | Medium | 所有模式 | memory/short_term.py:46-49 |
| 2.1 | SessionManager 会话无过期机制 | Critical | Web 模式 | web/session.py:126-128 |
| 2.2 | WebAgent 持有大量重量级对象 | High | Web 模式 | web/session.py:28-80 |
| 2.3 | cleanup_old 的 FIFO 策略不安全 | Medium | Web 模式 | web/session.py:169-174 |
| 3.1 | _tool_call_history 截断创建新列表 | Low | 所有模式 | core/agent.py:162-169 |
| 3.2 | output 截断语法风险 | Low | 所有模式 | core/agent.py:165 |
| 4.1 | _react_loop messages 列表持续增长 | Critical | 所有模式 | core/agent.py:119-181 |
| 4.2 | format_tool_results 未截断输出 | High | 所有模式 | core/dispatcher.py:153-169 |
| 4.3 | ToolAgent messages 同样累积 | High | 所有模式 | core/tool_agent.py:82-224 |
| 5.1 | EmbeddingCache 未启用 | Medium | Web 模式 | memory/embeddings.py:86-117 |
| 5.2 | 嵌入向量双重存储与频繁反序列化 | Medium | 所有模式 | memory/retrieval.py:122-127, memory/consolidation.py:255-297 |
| 6.1 | read_file 一次性读取整个文件 | High | 所有模式 | tools/file_tools.py:144-150 |
| 6.2 | 批量读取多个文件内存峰值 | Medium | 所有模式 | tools/file_tools.py:180-191 |
| 6.3 | web_fetch 获取完整内容后截断 | Low | 所有模式 | tools/web_tools.py:140 |
| 7.1 | WebSocket 无背压机制 | Medium | Web 模式 | web/server.py:116-127 |
| 7.2 | 无消息队列大小限制 | Low | Web 模式 | web/server.py:199-249 |
| 8.1 | Agent 与 MessageHandler 循环引用 | Medium | 所有模式 | core/agent.py:87-88, core/message_handler.py:17-23 |
| 8.2 | WebAgent 与 Agent 间接循环引用 | Medium | Web 模式 | web/session.py:73-79 |
| 8.3 | SessionManager 持有 Task/WebSocket 引用 | Medium | Web 模式 | web/session.py:126-128 |
| 8.4 | _run_sync 重复创建 ThreadPoolExecutor | Medium | 所有模式 | memory/long_term.py:17-27, storage/repository.py:13-21 |

### 内存占用估算

| 组件 | 单实例内存 | 50 会话总计 | 说明 |
|-----|-----------|------------|------|
| ConversationBuffer (500 turns) | 2-5 MB | 100-250 MB | 假设平均 500 字符/turn |
| WebAgent 对象图 | 3-6 MB | 150-300 MB | 含 Agent、Provider、Retriever 等 |
| _react_loop messages 峰值 | 1-5 MB | 50-250 MB | 取决于工具调用次数和内容大小 |
| EmbeddingCache (1000条, 未启用) | 2.5-3 MB | 0 MB | 当前未使用 |
| 嵌入向量 BLOB (数据库) | N/A | N/A | 存储在 SQLite 中，不在内存 |
| 文件读取峰值 | 1-2 MB | 5-10 MB | 并发读取时叠加 |
| **总计（当前）** | **~7-18 MB/会话** | **~350-810 MB** | 不含 LLM API 响应和操作系统开销 |

### 关键修复优先级

**P0（立即修复）**:
1. 为 `SessionManager` 添加会话 TTL 和自动清理机制
2. 在 `_react_loop` 和 `ToolAgent` 中对消息内容做长度限制
3. 修复 `format_tool_results` 的输出截断

**P1（短期修复）**:
4. 统一 `ConversationBuffer` 的 maxlen 配置，或对 content 做存储前截断
5. 启用 `EmbeddingCache` 并在会话间共享
6. 优化 `read_file` 的读取方式，避免 `f.readlines()`
7. 为 WebSocket 添加背压和速率限制

**P2（中期优化）**:
8. 使用 `weakref` 打破对象循环引用
9. 共享 `KimiProvider`、`EmbeddingEngine` 等重量级对象
10. 合并 `_run_sync` 实现，使用全局线程池
11. 考虑将不活跃会话状态序列化到磁盘

---

*本报告由 Claude Code 自动生成，基于对代码的静态分析。实际内存占用可能因运行环境、Python 版本、依赖库版本等因素有所不同。建议使用 `tracemalloc` 或 `memory_profiler` 进行运行时验证。*
