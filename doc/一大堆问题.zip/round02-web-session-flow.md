# 第2轮代码审查：Web会话状态数据流深度审查

**审查日期**: 2026-05-31
**审查范围**: `web/session.py`, `web/server.py`, `core/agent.py` 及其关联模块
**审查目标**: 跟踪Web会话从创建到消息处理到状态更新到保存的完整数据流，识别状态泄漏、竞态条件、资源泄漏

---

## 概述

AI Friend 的 Web 端采用 FastAPI + WebSocket 架构，通过 `SessionManager` 管理用户会话。每个会话对应一个 `WebAgent` 实例，内含完整的三层 Agent 架构（Agent 1 InnerDrive -> Agent 2 ToolAgent -> Agent 3 Roleplay）、情绪引擎、记忆系统（短期+长期）和工具注册表。`SessionManager` 同时维护 proactive task（ asyncio.Task ）和活跃 WebSocket 的映射。

本次审查发现 **7个高风险问题**、**5个中风险问题**、**4个低风险问题**，涉及全局状态共享、竞态条件、资源泄漏、数据隔离缺失等多个维度。核心风险在于：**所有会话共享同一个 personality.json 文件、同一个 SQLite 数据库、同一个 SleepManager 状态文件，导致情绪状态、睡眠状态、长期记忆在会话间完全互通，不存在真正的多用户隔离。**

---

## 数据流图

### 整体架构数据流

```
                              HTTP POST /api/chat
                              WebSocket /ws
                                     |
                                     v
+----------------------------+  +-----------------------------+
|   SessionManager (单例)     |  |   session_manager (模块级)   |
|  D:\桌面\编程作品\AI朋友\web\session.py:121  |  |  D:\桌面\编程作品\AI朋友\web\server.py:18   |
|                            |  |                             |
|  _sessions: dict[sid, WebAgent]            |  |  config = load_config()      |
|  _proactive_tasks: dict[sid, asyncio.Task] |  |  session_manager = SessionManager(config) |
|  _active_ws: dict[sid, WebSocket]          |  |                             |
+-------------+--------------+  +-------------+---------------+
              |                              |
              v                              v
+----------------------------+  +-----------------------------+
|      WebAgent (每会话)      |  |    lifespan (启动/关闭)      |
|  D:\桌面\编程作品\AI朋友\web\session.py:27   |  |  await session_manager.open()|
|                            |  |  (db.open() + repo初始化)    |
|  + personality (Personality)|  +-----------------------------+
|  |   + emotion (EmotionalState)              |
|  |   + config (PersonalityConfig)            |
|  + short_term (ConversationBuffer)           |
|  + ltm (LongTermMemory)                      |
|  |   + repo (Repository)                     |
|  |       + db (Database - 共享!)              |
|  + retriever (MemoryRetriever)               |
|  + consolidator (MemoryConsolidator)         |
|  + provider (KimiProvider)                   |
|  + agent (Agent)                             |
|      + _messages (MessageHandler)            |
|      + _sleep (SleepManager)                 |
|      + _proactive (ProactivityManager)       |
|      + _context (ContextManager)             |
|      + _tool_registry (ToolRegistry)         |
+----------------------------+
              |
              v
+----------------------------+
|    三层 Agent 处理流程      |
|  Agent 1: InnerDrive.assess |
|  Agent 2: ToolAgent.run_with_request |
|  Agent 3: Agent._react_loop |
+----------------------------+
              |
              v
+----------------------------+
|    状态持久化路径           |
|  1. personality.save() -> personality.json |
|  2. repo.insert_turn_sync() -> SQLite      |
|  3. ltm.store_fact/exp/refl() -> SQLite    |
|  4. SleepManager._save_sleep_state() -> .sleep_state |
+----------------------------+
```

### 会话生命周期数据流

```
[WebSocket 连接建立]
    |
    v
[ws] receive "init" message
    |
    v
SessionManager.get_or_create(sid)
    |-- 若 sid 不存在:
    |   WebAgent.__init__(config, db, repo)
    |   |-- Personality.load("personality.json")  <-- 读取共享文件
    |   |-- ConversationBuffer(maxlen=500)
    |   |-- 恢复最近30轮对话 (repo.get_recent_turns_sync)
    |   |-- KimiProvider(...)
    |   |-- MemoryRetriever(ltm, embed_engine)
    |   |-- MemoryConsolidator(ltm, llm_gen, embed_engine)
    |   |-- ToolRegistry + 注册8个工具
    |   +-- Agent(...)
    |       +-- SleepManager(".sleep_state")  <-- 共享睡眠状态文件
    |       +-- ProactivityManager(...)
    |       +-- ContextManager(...)
    |       +-- MessageHandler(...)
    +-- 返回 (sid, WebAgent)
    |
    v
asyncio.create_task(_proactive_loop(websocket, sid))
    |
    v
SessionManager.register_proactive(sid, task, websocket)
    |-- 取消旧 task（若存在）
    |-- 存储新 task 和 websocket
    |
    v
[ws] send "init_ok"

[消息处理循环]
    |
    v
[ws] receive "message"
    |
    v
agent.agent.last_activity_time = time.time()
loop.run_in_executor(None, agent.process_message, content)
    |
    v
WebAgent.process_message()
    |-- agent.process_message(on_token=...)
    |-- MessageHandler.handle_message()
    |   |-- Agent 1: InnerDrive.assess()
    |   |-- Agent 2: ToolAgent.run_with_request() (if needed)
    |   +-- Agent 3: _react_loop()
    |       |-- provider.generate() (stream=True for first iter)
    |       |-- parse_tool_calls()
    |       |-- execute_tool_calls()
    |       +-- _process_emotion()
    |           |-- consolidator.analyze_sentiment()
    |           |-- personality.apply_emotional_shift()
    |           |-- emotion.record_emotion_event()
    |           +-- consolidator.consolidate() (每3轮)
    |-- personality.save("personality.json")  <-- 写共享文件!
    +-- 返回 response
    |
    v
_send_segments(websocket, agent, response, emotion)
    |-- 分段发送 + 打字延迟模拟
    +-- 发送 "done" 消息

[Proactive Loop - 独立任务]
    |
    v
while True:
    |-- get_active_ws(sid) 或回退到传入的 websocket
    |-- get_or_create(sid) -> agent
    |-- ag._get_sleep_state() -> 检查睡眠/唤醒
    |-- ag._calculate_proactivity(idle) -> 计算主动性分数
    |-- ag.decide_proactive_action(idle) -> Agent 1 决策
    |-- process_explore_with_intent() 或 process_proactive_with_intent()
    |   +-- personality.save("personality.json")  <-- 再次写共享文件!
    +-- _send_segments(active_ws, ...)

[WebSocket 断开]
    |
    v
finally:
    SessionManager.remove(sid)
    |-- _sessions.pop(sid, None)
    |-- _proactive_tasks.pop(sid) -> task.cancel()
    +-- _active_ws.pop(sid, None)
```

### HTTP REST API 数据流

```
POST /api/chat
    |
    v
chat_api(body: dict)
    |-- session_id = body.get("session_id", "default")
    |-- _, agent = session_manager.get_or_create(session_id)
    |-- response = agent.process_message(message)  <-- 同步调用!
    |-- 返回 JSON {response, emotion, turn, session_id}
    +-- personality.save() 在 process_message 内部被调用
```

---

## 详细发现

### 高风险问题

#### HR1: 全局情绪状态共享 —— 所有会话共用同一个 personality.json

**文件**: `D:\桌面\编程作品\AI朋友\web\session.py:32-33`, `D:\桌面\编程作品\AI朋友\web\session.py:88-89`
**行号**: 32, 88

```python
# web/session.py:32
self.personality = Personality.load(config.personality_file)

# web/session.py:88 (process_message 末尾)
self.personality.save(self.config.personality_file)
```

**问题描述**:
每个 `WebAgent` 在初始化时都从同一个 `personality.json` 文件加载情绪状态，在处理消息后又会将更新后的情绪写回同一个文件。当多个会话同时活跃时：

1. 会话A处理消息，情绪从 "neutral" 变为 "angry"
2. 会话B处理消息，读取 personality.json（此时已经是 "angry"）
3. 会话B的情绪被会话A的情绪污染
4. 会话A的 personality.save() 和 会话B的 personality.save() 形成写竞争

**代码路径**:
- `WebAgent.__init__()` -> `Personality.load(config.personality_file)` -> 读取文件
- `WebAgent.process_message()` -> `Agent._react_loop()` -> `_process_emotion()` -> `personality.apply_emotional_shift()` -> `personality.save()`

**影响**: 多用户场景下情绪状态完全混乱，一个用户的负面输入会影响所有其他用户的交互体验。

**风险评级**: 严重 —— 这是架构级别的设计缺陷，假设了单用户单会话模型。

**建议**:
1. 将情绪状态与会话ID绑定，存储在 SQLite 的 `conversation_turns` 表中或新建 `session_states` 表
2. 或者每个会话使用独立的 personality 文件（如 `personality_{sid}.json`）
3. 在 `Personality.load()` 中增加会话隔离参数

---

#### HR2: 睡眠状态全局共享 —— 所有会话共用同一个 .sleep_state 文件

**文件**: `D:\桌面\编程作品\AI朋友\core\agent.py:59-65`, `D:\桌面\编程作品\AI朋友\core\sleep_manager.py:25-38`
**行号**: 59-65, 25-38

```python
# core/agent.py:59-65
sleep_file = os.path.join(
    os.path.dirname(os.path.abspath(config.personality_file)), ".sleep_state"
)
self._sleep = SleepManager(
    sleep_state_file=sleep_file,
    personality=personality, ltm=ltm, provider=provider,
)

# core/sleep_manager.py:25-38
class SleepManager:
    def _load_sleep_state(self) -> bool:
        try:
            with open(self._sleep_state_file) as f:
                return f.read().strip() == "1"
        except Exception as e:
            logger.warning(f"Failed to read sleep state: {e}")
            return False

    def _save_sleep_state(self) -> None:
        try:
            with open(self._sleep_state_file, "w") as f:
                f.write("1" if self._sleeping else "0")
        except Exception as e:
            logger.warning(f"Failed to save sleep state: {e}")
```

**问题描述**:
每个 `Agent` 实例都创建自己的 `SleepManager`，但所有 `SleepManager` 都指向同一个 `.sleep_state` 文件。在 `web/session.py` 中，`config.personality_file` 是 `"personality.json"`，所以 `sleep_file` 始终指向项目根目录的 `.sleep_state`。

当会话A触发睡眠（写入 "1"），会话B读取时也会认为自己在睡眠。在 `_proactive_loop` 中，如果 `ag._sleeping` 为 True， proactive 行为会被跳过（`await asyncio.sleep(30); continue`）。

**代码路径**:
- `web/server.py:154` -> `if ag._sleeping: await asyncio.sleep(30); continue`

**影响**: 一个会话的睡眠状态会全局影响所有会话的 proactive 行为。

**风险评级**: 严重

**建议**:
1. 睡眠状态应与会话绑定，存储在内存中（`SessionManager._sessions[sid].agent._sleep._sleeping`）或数据库中
2. 移除文件持久化，或改为按会话ID命名文件

---

#### HR3: Proactive Task 的 WebSocket 竞争和消息错发

**文件**: `D:\桌面\编程作品\AI朋友\web\server.py:130-196`, `D:\桌面\编程作品\AI朋友\web\session.py:155-167`
**行号**: 136, 155-167

```python
# web/server.py:136
active_ws = session_manager.get_active_ws(session_id) or websocket

# web/session.py:155-163
def register_proactive(self, session_id: str, task, websocket) -> None:
    with self._lock:
        old_task = self._proactive_tasks.pop(session_id, None)
        if old_task:
            old_task.cancel()
        self._proactive_tasks[session_id] = task
        self._active_ws[session_id] = websocket
```

**问题描述**:
在 `_proactive_loop` 中，每次循环都通过 `get_active_ws(session_id)` 获取"最新的" WebSocket。这意味着：

1. 用户断开旧 WebSocket 并建立新连接（页面刷新）
2. 新连接发送 "init"，创建新的 proactive task
3. `register_proactive` 取消旧 task，但旧 task 的 `finally` 块或异常处理可能仍在运行
4. 旧 task 在 `await _send_segments(active_ws, ...)` 时可能持有对新 WebSocket 的引用
5. 如果旧 task 恰好在取消前执行了 `get_active_ws()`，它会获取到新 WebSocket 并发送消息

更严重的是，`register_proactive` 取消了旧 task，但旧 task 的取消不是原子的：

```python
# web/server.py:192-196
except asyncio.CancelledError:
    break
except Exception as e:
    logger.warning(f"Proactive error: {e}")
    await asyncio.sleep(30)
```

`CancelledError` 只在 `await` 点被抛出。如果旧 task 正在执行同步代码（如 `loop.run_in_executor(None, agent.process_explore_with_intent, intent)`），取消信号不会立即生效。此时新 task 已经启动，两个 task 可能同时运行。

**影响**: 消息可能发送到错误的 WebSocket，或同一消息重复发送。

**风险评级**: 高

**建议**:
1. 在 `register_proactive` 中不仅取消旧 task，还应设置一个"generation counter"，每个 task 只处理自己 generation 的消息
2. 在 `_proactive_loop` 中定期检查 `session_manager.get_active_ws(session_id) is websocket`，如果不匹配则退出
3. 使用 `asyncio.shield` 保护关键区域，或在同步代码执行前检查取消状态

---

#### HR4: cleanup_old 不完整 —— 只清理 _sessions，不清理 _proactive_tasks 和 _active_ws

**文件**: `D:\桌面\编程作品\AI朋友\web\session.py:169-174`
**行号**: 169-174

```python
def cleanup_old(self, max_sessions: int = 50) -> None:
    with self._lock:
        while len(self._sessions) > max_sessions:
            oldest = next(iter(self._sessions))
            self._sessions.pop(oldest)
            logger.info(f"Session evicted: {oldest}")
```

**问题描述**:
`cleanup_old` 在驱逐会话时：
1. 没有取消对应的 proactive task（`_proactive_tasks` 中仍保留引用）
2. 没有清理 `_active_ws` 中的 WebSocket 引用
3. 没有调用 `WebAgent` 的任何清理方法
4. `WebAgent` 持有的 `ConversationBuffer`、`Agent` 等资源不会被释放

被驱逐的会话的 proactive task 仍持有对 `WebAgent` 的引用（通过闭包），导致：
- 内存泄漏（`WebAgent` 及其所有组件无法被 GC）
- 已取消/过期的 task 可能仍在尝试发送消息到已关闭的 WebSocket
- `_proactive_tasks` 字典无限增长

**影响**: 长期运行后内存泄漏，proactive task 字典膨胀。

**风险评级**: 高

**建议**:
```python
def cleanup_old(self, max_sessions: int = 50) -> None:
    with self._lock:
        while len(self._sessions) > max_sessions:
            oldest = next(iter(self._sessions))
            self._sessions.pop(oldest)
            task = self._proactive_tasks.pop(oldest, None)
            if task:
                task.cancel()
            self._active_ws.pop(oldest, None)
            logger.info(f"Session evicted: {oldest}")
```

---

#### HR5: HTTP API 与 WebSocket 共用会话但无并发控制

**文件**: `D:\桌面\编程作品\AI朋友\web\server.py:39-54`, `D:\桌面\编程作品\AI朋友\web\server.py:223-234`
**行号**: 39-54, 223-234

```python
# HTTP endpoint
@app.post("/api/chat")
async def chat_api(body: dict):
    session_id = body.get("session_id", "default")
    _, agent = session_manager.get_or_create(session_id)
    response = agent.process_message(message)  # 同步调用!
    ...

# WebSocket endpoint
elif msg_type == "message":
    _, agent = session_manager.get_or_create(session_id)
    agent.agent.last_activity_time = time.time()
    loop = asyncio.get_event_loop()
    response = await loop.run_in_executor(None, agent.process_message, content)
```

**问题描述**:
HTTP API 直接同步调用 `agent.process_message()`，而 WebSocket 通过 `run_in_executor` 在线程池中执行。两者可能同时操作同一个 `WebAgent` 实例：

1. WebSocket 消息处理在线程A中执行 `agent.process_message()`
2. 同时 HTTP 请求在主线程中执行 `agent.process_message()`
3. 两者同时修改 `Agent.turn_count`、`ConversationBuffer._turns`、`Personality.emotion` 等状态

`ConversationBuffer` 有 `_lock` 保护，但 `Agent` 的 `turn_count`、`last_activity_time`、`_consecutive_negative` 等字段没有锁保护。`Personality.emotion` 的修改也没有锁。

**影响**: 状态损坏、turn_count 重复/跳过、情绪计算错误。

**风险评级**: 高

**建议**:
1. 为每个 `WebAgent` 添加一个 `asyncio.Lock` 或 `threading.Lock`，确保同一会话的消息处理串行化
2. HTTP API 也应使用 `run_in_executor` 并等待完成
3. 或者将 HTTP API 标记为弃用，统一使用 WebSocket

---

#### HR6: 长期记忆数据库无会话隔离 —— 所有会话共享同一张表

**文件**: `D:\桌面\编程作品\AI朋友\storage\database.py:47-116`, `D:\桌面\编程作品\AI朋友\storage\repository.py`
**行号**: 47-116

**问题描述**:
`Database` 和 `Repository` 在 `SessionManager.open()` 中只初始化一次，所有 `WebAgent` 共享同一个 `Repository` 实例。`conversation_turns`、`user_facts`、`experiences` 等表都没有 `session_id` 列。

这意味着：
1. 会话A的对话记录被会话B恢复（`WebAgent.__init__:36-37` 恢复最近30轮，不分会话）
2. 会话A提取的用户事实被会话B检索到
3. 会话A的关系度（trust/intimacy/familiarity）影响会话B的关系度计算
4. `ProactivityManager._ltm.get_relationship()` 返回全局关系度

**代码路径**:
```python
# web/session.py:36-37
for t in repo.get_recent_turns_sync(30):
    self.short_term.add_turn(t["role"], t["content"])
```

这段代码恢复最近30轮对话时不区分会话ID，新会话会加载其他会话的历史。

**影响**: 严重的隐私泄漏和数据污染，多用户场景下完全不可用。

**风险评级**: 严重

**建议**:
1. 在所有相关表中添加 `session_id` 列
2. `Repository` 的所有查询方法增加 `session_id` 过滤
3. `WebAgent.__init__` 恢复历史时传入 `session_id`
4. 考虑是否需要全局共享的事实（如用户基本信息）vs 会话隔离的事实

---

#### HR7: 情绪事件记录未按会话隔离

**文件**: `D:\桌面\编程作品\AI朋友\models\personality.py:239-262`, `D:\桌面\编程作品\AI朋友\core\agent.py:212-215`
**行号**: 239-262, 212-215

```python
# core/agent.py:212-215
self.personality.emotion.record_emotion_event(
    trigger=last_user_turn[:100] if last_user_turn else "",
    context=last_user_turn[:200] if last_user_turn else "",
)
```

**问题描述**:
`EmotionalState.emotion_events` 是一个内存中的列表，存储在 `Personality` 对象中。由于所有会话共享同一个 `personality.json`（HR1），情绪事件在加载时会被所有会话共享。但即使不考虑文件共享，情绪事件列表本身也没有按会话隔离。

`record_emotion_event` 只在情绪强度 > 0.6 时记录，这些事件被用于后续的情绪分析和 prompt 构建。如果会话A产生了强烈的负面情绪事件，会话B的情绪分析也会看到这些事件（通过共享的 personality.json）。

**影响**: 情绪历史在会话间泄漏，影响情绪分析的准确性。

**风险评级**: 高

**建议**:
1. 情绪事件应存储在数据库中，按 `session_id` 隔离
2. 或至少将 `emotion_events` 从 `personality.json` 中分离，改为按会话存储

---

### 中风险问题

#### MR1: WebSocket 断开时 proactive task 的取消不是立即生效的

**文件**: `D:\桌面\编程作品\AI朋友\web\server.py:247-249`, `D:\桌面\编程作品\AI朋友\web\session.py:146-153`
**行号**: 247-249, 146-153

```python
# web/server.py:247-249
finally:
    if session_id:
        session_manager.remove(session_id)

# web/session.py:146-153
def remove(self, session_id: str) -> None:
    with self._lock:
        self._sessions.pop(session_id, None)
        task = self._proactive_tasks.pop(session_id, None)
        if task:
            task.cancel()
        self._active_ws.pop(session_id, None)
```

**问题描述**:
`task.cancel()` 只是设置取消标志，task 只有在下一个 `await` 点才会抛出 `CancelledError`。在 `_proactive_loop` 中：

```python
# web/server.py:166-180
loop = asyncio.get_event_loop()
intent = await loop.run_in_executor(None, ag.decide_proactive_action, idle)
if intent.action == "explore" and ag._check_rate_limit("explore"):
    response = await loop.run_in_executor(None, agent.process_explore_with_intent, intent)
```

如果 task 正在 `run_in_executor` 中执行同步代码（可能耗时数秒），`cancel()` 不会中断它。此时：
1. WebSocket 已断开，但 task 仍在运行
2. task 完成后尝试 `await _send_segments(active_ws, ...)`
3. `active_ws` 可能已经被从 `_active_ws` 中移除，或 WebSocket 已关闭
4. 发送操作会抛出异常，被 `except Exception` 捕获，然后 `await asyncio.sleep(30)`

**影响**: 资源浪费，异常日志噪音。

**风险评级**: 中

**建议**:
1. 在 `_proactive_loop` 的每次循环开始时检查 `session_manager.get_active_ws(session_id) is websocket`
2. 在 `run_in_executor` 前后检查 `asyncio.current_task().cancelled()`
3. 捕获 WebSocket 发送异常时，如果是连接已关闭，直接 break

---

#### MR2: HTTP API 的 session_id 默认为 "default" 导致冲突

**文件**: `D:\桌面\编程作品\AI朋友\web\server.py:41`, `D:\桌面\编程作品\AI朋友\web\server.py:229`
**行号**: 41, 229

```python
# web/server.py:41
session_id = body.get("session_id", "default")

# web/server.py:229
if not session_id:
    session_id = "default"
```

**问题描述**:
如果客户端不提供 `session_id`，HTTP API 和 WebSocket 都使用 `"default"` 作为会话ID。这意味着：
1. 未提供 session_id 的多个客户端会共享同一个 `WebAgent`
2. 它们的对话历史、情绪状态完全混合
3. 一个客户端的 proactive task 会向所有未提供 session_id 的客户端发送消息（实际上只发送到最新注册的 WebSocket）

**影响**: 意外的数据共享，调试困难。

**风险评级**: 中

**建议**:
1. 在 HTTP API 中，如果未提供 session_id，生成一个新的 UUID
2. 在 WebSocket 中，如果 init 消息未提供 session_id，同样生成新 UUID
3. 或者要求客户端必须提供 session_id，否则返回错误

---

#### MR3: ConversationBuffer 恢复历史时不区分会话

**文件**: `D:\桌面\编程作品\AI朋友\web\session.py:36-37`
**行号**: 36-37

```python
for t in repo.get_recent_turns_sync(30):
    self.short_term.add_turn(t["role"], t["content"])
```

**问题描述**:
`get_recent_turns_sync(30)` 从数据库获取最近30轮对话，不区分会话。这意味着：
1. 新创建的会话会加载其他会话的对话历史
2. AI 会把其他用户的对话当作自己的记忆
3. 隐私泄漏：会话B可能看到会话A的敏感对话内容

**影响**: 隐私泄漏，对话上下文混乱。

**风险评级**: 中

**建议**:
1. `conversation_turns` 表添加 `session_id` 列
2. `get_recent_turns` 方法增加 `session_id` 参数
3. `WebAgent.__init__` 恢复历史时传入 `session_id`

---

#### MR4: Agent._react_loop 中的 tool_call_history 是实例级别但未限制大小

**文件**: `D:\桌面\编程作品\AI朋友\core\agent.py:57`, `D:\桌面\编程作品\AI朋友\core\agent.py:162-169`
**行号**: 57, 162-169

```python
self._tool_call_history: list[dict] = []  # recent tool call records

if len(self._tool_call_history) > 20:
    self._tool_call_history = self._tool_call_history[-20:]
```

**问题描述**:
`_tool_call_history` 存储在 `Agent` 实例中，虽然限制了20条，但每条记录包含 `output[:200]`，大约 200-300 字节。这不是严重的内存问题，但：
1. 这个历史被注入到 Agent 3 的 prompt 中（`core/message_handler.py:263`）
2. 如果工具输出包含敏感信息（如文件内容、搜索结果），这些信息会在会话间持久化（如果考虑将来的会话隔离）
3. 目前这个列表在 `Agent` 生命周期内持续累积，但 `Agent` 随 `WebAgent` 一起被缓存

**影响**: 潜在的敏感信息泄漏到 prompt 中。

**风险评级**: 中

**建议**:
1. 考虑是否需要在会话隔离时清空 `_tool_call_history`
2. 对注入 prompt 的历史记录进行更严格的过滤

---

#### MR5: ProactivityManager 的速率限制是实例级别而非全局

**文件**: `D:\桌面\编程作品\AI朋友\core\proactivity.py:94-115`
**行号**: 94-115

```python
def check_rate_limit(self, action: str) -> bool:
    now = time.time()
    if action == "explore":
        if now - self._last_explore_time < 3600:
            return False
        self._last_explore_time = now
        return True
```

**问题描述**:
`_last_explore_time` 和 `_last_chat_time` 是 `ProactivityManager` 的实例变量。由于每个 `WebAgent` 有自己的 `Agent`，每个 `Agent` 有自己的 `ProactivityManager`，所以速率限制是按会话的。

但这与预期行为可能不一致：如果设计意图是全局限制（防止API费用过高），那么实例级别的限制是不够的。如果设计意图是按会话限制，那么当前实现是正确的。

更关键的是，由于 `ProactivityManager` 在 `Agent.__init__` 中创建，而 `Agent` 在 `WebAgent.__init__` 中创建，当会话被 `cleanup_old` 驱逐后重新创建时，速率限制状态会重置。

**影响**: 取决于设计意图，可能是行为不符合预期。

**风险评级**: 中

**建议**:
1. 明确速率限制的设计意图（全局 vs 每会话）
2. 如果是全局限制，将 `_last_explore_time` 和 `_last_chat_time` 提升到 `SessionManager` 级别
3. 如果是每会话限制，考虑是否在会话恢复时应持久化这些时间戳

---

### 低风险问题

#### LR1: SessionManager._lock 是 threading.Lock 而非 asyncio.Lock

**文件**: `D:\桌面\编程作品\AI朋友\web\session.py:3`, `D:\桌面\编程作品\AI朋友\web\session.py:129`
**行号**: 3, 129

```python
from threading import Lock
# ...
self._lock = Lock()
```

**问题描述**:
`SessionManager` 的方法（`get_or_create`, `remove`, `register_proactive`, `cleanup_old`）都在异步上下文中被调用，但使用的是 `threading.Lock`。在 CPython 中，`threading.Lock` 会阻塞当前线程，而 asyncio 事件循环运行在同一个线程中。这意味着：

1. 如果一个协程获取了锁并执行耗时操作（虽然当前锁保护的代码很快），它会阻塞事件循环
2. 更关键的是，在 `asyncio` 环境中应该使用 `asyncio.Lock` 来避免阻塞事件循环中的其他协程

不过当前锁保护的代码都很短（字典操作），实际影响很小。

**影响**: 理论上的事件循环阻塞风险。

**风险评级**: 低

**建议**:
```python
import asyncio
# ...
self._lock = asyncio.Lock()
```

并将所有 `with self._lock:` 改为 `async with self._lock:`。

---

#### LR2: WebAgent 的 provider 是 KimiProvider 但配置中默认是 DeepSeek

**文件**: `D:\桌面\编程作品\AI朋友\web\session.py:40-46`, `D:\桌面\编程作品\AI朋友\config.py:13`
**行号**: 40-46, 13

```python
# web/session.py:40-46
self.provider = KimiProvider(
    endpoint=config.api_endpoint, api_key=config.api_key,
    model=config.api_model, ...
)

# config.py:13
api_model: str = "deepseek-v4-flash"
```

**问题描述**:
`WebAgent` 使用 `KimiProvider` 类，但配置默认指向 DeepSeek 的端点和模型。需要确认 `KimiProvider` 是否兼容 DeepSeek API。从 `core/provider.py` 的审查来看（未在本次审查范围内，但从代码引用推断），`KimiProvider` 可能是通用 OpenAI 兼容客户端。

**影响**: 如果 `KimiProvider` 有 Kimi 特定的逻辑，可能导致 DeepSeek 调用失败。

**风险评级**: 低

**建议**:
1. 确认 `KimiProvider` 的命名是否准确
2. 如果支持多 provider，考虑根据配置动态选择

---

#### LR3: _proactive_loop 中的 sleep_cooldown 是整数递减而非时间戳比较

**文件**: `D:\桌面\编程作品\AI朋友\web\server.py:131-153`
**行号**: 131-153

```python
cooldown = 0
sleep_cooldown = 0
while True:
    # ...
    if sleep_cooldown == 0:
        should_sleep, msg = ag._get_sleep_state()
        if msg:
            # ...
            sleep_cooldown = 120  # 10 min cooldown
    else:
        sleep_cooldown = max(0, sleep_cooldown - 1)
    # ...
    await asyncio.sleep(15)
```

**问题描述**:
`sleep_cooldown` 初始为 120，每次循环减 1，循环间隔约 15 秒（实际可能更长，因为中间有 `run_in_executor` 等阻塞操作）。所以 120 次循环大约需要 30 分钟，而不是注释中说的 "10 min cooldown"。

更准确的实现应该是基于时间戳：
```python
sleep_cooldown_until = 0
# ...
if time.time() < sleep_cooldown_until:
    continue
# ...
sleep_cooldown_until = time.time() + 600  # 10 minutes
```

**影响**: 睡眠转换的冷却时间比预期长（约30分钟 vs 10分钟）。

**风险评级**: 低

**建议**:
将 `sleep_cooldown` 改为基于时间戳的实现。

---

#### LR4: WebSocket 异常处理过于宽泛

**文件**: `D:\桌面\编程作品\AI朋友\web\server.py:241-246`
**行号**: 241-246

```python
except Exception as e:
    logger.error(f"WebSocket error: {e}")
    try:
        await websocket.send_text(json.dumps({"type": "error", "content": str(e)}))
    except (WebSocketDisconnect, ConnectionError, RuntimeError):
        pass
```

**问题描述**:
`except Exception as e` 捕获所有异常，包括：
1. `json.JSONDecodeError` - 客户端发送了非法 JSON
2. `KeyError` - 消息格式不正确
3. `RuntimeError` - 可能的内部错误

这些异常被统一处理为 "WebSocket error"，没有区分客户端错误和服务器错误。特别是 `JSONDecodeError` 应该返回更友好的错误信息。

**影响**: 调试困难，客户端无法区分错误类型。

**风险评级**: 低

**建议**:
```python
except json.JSONDecodeError as e:
    logger.warning(f"Invalid JSON from client: {e}")
    await websocket.send_text(json.dumps({"type": "error", "content": "Invalid message format"}))
except WebSocketDisconnect:
    logger.info(f"WebSocket disconnected: {session_id}")
except Exception as e:
    logger.exception(f"WebSocket error: {e}")
    try:
        await websocket.send_text(...)
    except ...
```

---

## 补充发现：数据流中的隐藏耦合

### 1. ContextManager.compressed_summary 是全局的

`ContextManager` 存储在 `Agent` 实例中，当上下文压缩触发时（`core/context_manager.py:62-98`）：
```python
def compress(self, messages: list[dict]) -> None:
    # ...
    self._compressed_summary = result.strip()
    self._estimated_tokens_used = 0
    self._short_term.clear()
```

`compressed_summary` 被注入到 Agent 3 的 prompt 中（`core/message_handler.py:260`）。由于 `Agent` 实例按会话隔离，`compressed_summary` 也是按会话的，这是正确的。但需要注意：如果将来实现会话恢复，需要同时恢复 `compressed_summary`。

### 2. MemoryConsolidator._pending_buffer 是实例级别

`MemoryConsolidator` 存储在 `WebAgent` 中，`_pending_buffer` 累积待整合的对话轮次。由于 `WebAgent` 按会话隔离，这也是正确的。但 `cleanup_old` 驱逐会话时，这些待整合的轮次会丢失。

### 3. EmbeddingEngine 是共享的

`EmbeddingEngine` 在 `WebAgent.__init__` 中创建，但所有实例使用相同的 `endpoint` 和 `dim`。这是合理的，因为嵌入服务是无状态的。

---

## 汇总统计

| 类别 | 数量 | 问题编号 |
|------|------|----------|
| 高风险 | 7 | HR1-HR7 |
| 中风险 | 5 | MR1-MR5 |
| 低风险 | 4 | LR1-LR4 |
| **总计** | **16** | |

### 按主题分类

| 主题 | 问题数量 | 涉及问题 |
|------|----------|----------|
| 会话隔离/数据泄漏 | 5 | HR1, HR2, HR6, HR7, MR3 |
| 并发/竞态条件 | 3 | HR3, HR5, MR1 |
| 资源泄漏 | 2 | HR4, MR1 |
| 状态持久化 | 3 | HR1, HR2, MR5 |
| 错误处理 | 2 | LR3, LR4 |
| 架构设计 | 3 | HR6, MR2, LR2 |

### 修复优先级建议

**P0（立即修复）**:
- HR1: personality.json 全局共享
- HR6: 数据库无会话隔离
- HR2: 睡眠状态全局共享

**P1（本周修复）**:
- HR3: Proactive Task WebSocket 竞争
- HR4: cleanup_old 不完整
- HR5: HTTP/WebSocket 并发冲突
- HR7: 情绪事件未隔离

**P2（下周修复）**:
- MR1: Proactive task 取消延迟
- MR2: default session_id 冲突
- MR3: 历史恢复不区分会话
- MR4: tool_call_history 敏感信息
- MR5: 速率限制层级不明确

**P3（可选优化）**:
- LR1-LR4: 代码质量和可维护性改进

---

## 附录：关键代码引用

### A1. 会话创建流程
```python
# web/session.py:136-144
def get_or_create(self, session_id: Optional[str] = None) -> tuple[str, WebAgent]:
    with self._lock:
        sid = session_id or uuid.uuid4().hex[:12]
        if sid not in self._sessions:
            logger.info(f"[session] create: {sid}")
            self._sessions[sid] = WebAgent(self.config, self.db, self.repo)
        else:
            logger.debug(f"[session] restore: {sid}")
        return sid, self._sessions[sid]
```

### A2. Proactive Loop 核心逻辑
```python
# web/server.py:130-196
async def _proactive_loop(websocket: WebSocket, session_id: str):
    cooldown = 0
    sleep_cooldown = 0
    while True:
        try:
            active_ws = session_manager.get_active_ws(session_id) or websocket
            _, agent = session_manager.get_or_create(session_id)
            ag = agent.agent
            # ... sleep/wake check ...
            # ... proactivity scoring ...
            if random.random() < score:
                loop = asyncio.get_event_loop()
                intent = await loop.run_in_executor(None, ag.decide_proactive_action, idle)
                if intent.action == "explore" and ag._check_rate_limit("explore"):
                    response = await loop.run_in_executor(None, agent.process_explore_with_intent, intent)
                elif intent.action == "chat" and ag._check_rate_limit("chat"):
                    response = await loop.run_in_executor(None, agent.process_proactive_with_intent, intent)
                if response:
                    ag.last_activity_time = time.time()
                    cooldown = 12
                    await _send_segments(active_ws, agent, response, agent.emotion)
            await asyncio.sleep(15)
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.warning(f"Proactive error: {e}")
            await asyncio.sleep(30)
```

### A3. 情绪处理流程
```python
# core/agent.py:183-221
def _process_emotion(self) -> None:
    sentiment, sharing, energy = 0.1, False, 0.5
    last_user_turn = ""
    try:
        all_turns = self.short_term.get_all()
        for t in reversed(all_turns):
            if t.role == "user":
                last_user_turn = t.content
                break
        sentiment, sharing, energy = self.consolidator.analyze_sentiment(last_user_turn)
    except (json.JSONDecodeError, ValueError, KeyError) as e:
        logger.warning(f"Sentiment analysis parse error: {e}")

    if sentiment < -0.5:
        self._consecutive_negative += 1
    elif sentiment > 0.1:
        self._consecutive_negative = max(0, self._consecutive_negative - 1)

    hurt_multiplier = 1.0 + self._consecutive_negative * 0.4
    sentiment *= hurt_multiplier
    old_dom = self.personality.emotion.dominant_emotion
    self.personality.apply_emotional_shift(sentiment, sharing, energy)
    new_dom = self.personality.emotion.dominant_emotion
    # ... logging ...

    self.personality.emotion.record_emotion_event(
        trigger=last_user_turn[:100] if last_user_turn else "",
        context=last_user_turn[:200] if last_user_turn else "",
    )
    if self.turn_count % 3 == 0:
        self.consolidator.add_pending(self.short_term.get_all()[-1])
        self.consolidator.consolidate(self.short_term, self.personality, ...)
```

### A4. 数据库 Schema（无 session_id）
```sql
-- storage/database.py:102-109
CREATE TABLE IF NOT EXISTS conversation_turns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    turn_number INTEGER NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
    content TEXT NOT NULL,
    emotional_state TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

*报告结束。本次审查覆盖了 Web 会话状态的完整数据流，识别了16个问题，其中7个高风险问题需要优先修复。*
